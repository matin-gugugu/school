# 容量外部接入路由

只读取当前执行路径实际需要的集成 Reference：

| 集成 | Reference | 何时读取 |
|---|---|---|
| Top P 策略 | [integration-top-p.md](integration-top-p.md) | 云上回收 `scope=all/gpu` 或策略内精确模型 |
| KConf | [integration-kconf.md](integration-kconf.md) | 正缺口换算实例，或云上回收换算理论实例 |
| iSvc | [integration-isvc.md](integration-isvc.md) | 换算卡数、机器数，或需要确认部署规格 |
| 资源域模型持有量 | [resource.md](resource.md) | 云上回收请求卡数或机器数时，以当前 `online` 持有卡数校准理论释放上限 |
| 天问 | [integration-tianwen.md](integration-tianwen.md) | 查询 cache、TTFT、TPOT |
| 成本 | [integration-cost.md](integration-cost.md) | 云上容量回收始终查询前一天模型可计费成本并估算增量上云日成本；直接看板导航读取 [cost.md](cost.md) |

不要为容量、流量或余量的基础查询加载无关集成文件。外部接入只提供事实证据，不改变
容量场景、公式或完成深度。
