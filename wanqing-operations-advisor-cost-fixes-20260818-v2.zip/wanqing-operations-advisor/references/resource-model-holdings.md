# 资源域模型持有量口径

仅在以下两种情况读取：直接询问指定模型持有量，或云上容量回收请求卡数/机器数并需要
资源域校准。其他资源场景读取 `resource.md`。

## 模型和数据范围

- 数据表：`kce_server.kce_ai_infra_pods`。
- 默认集群：`kce-ai-infra-bjzey1-hb1az3`。
- 当前持有量默认查询最近 300 秒；云上回收固定使用当前 300 秒、`service-type=online`。
- 活跃 Pod 一行，窗口内直接汇总 `gpuRequestNum`，不再按 Pod 做快照去重。
- 排除资源池 `wanqing-test`、`langbridge-training`。
- X60 同时匹配 `X60`、`X60卡`；X50/X40 使用相同规则。
- 卡数使用 `sum(gpuRequestNum)`；8 卡等效机器数为 `gpu_cards / 8`。

常规模型排除 `unknown` 及名称包含 `test`、`zhipu`、`private` 的记录。`labels` 包含
`llm-inference-pool=offline` 时为 offline，否则为 online。上线验证模型使用
`modelServiceName LIKE '%test%'` 且排除 `%private%`，不区分 online/offline。

## 模型身份门控

普通资源问答中，用户未指定模型时不运行查询，提示其指定模型并返回万擎资源看板。用户
提供模糊表达时先由资源场景候选发现和模型解析得到成功 Artifact；多个模型必须走批量入口。
查询只消费解析后的精确 `modelServiceName`，歧义时等待用户确认。

云上容量回收不再次解析模型。固定 Workflow 复用已经按 `capacity/cloud-reclaim` 成功解析的
同一 Artifact，通过内部 `--capacity-model-artifact` 查询；该参数不得由 Agent 手工调用。
资源 Artifact 的模型、解析文件、消费场景、时间窗、service type 和 GPU 卡型必须与回收
候选一致。

## 云上回收校准

只有 `detail-level=cards|machines` 执行该阶段。Workflow 在 iSvc 单实例卡数确定后统一查询
当前持有量，并按“模型 + GPU 卡型”计算：

```text
aligned_reclaimable_gpu_cards_by_type[gpu_type]
  = min(raw_reclaimable_gpu_cards_by_type[gpu_type],
        current_online_held_gpu_cards_by_type[gpu_type])

aligned_reclaimable_gpu_cards
  = sum(aligned_reclaimable_gpu_cards_by_type)

aligned_reclaimable_8_card_machine_equivalents
  = aligned_reclaimable_gpu_cards / 8
```

- 保留原始理论 `reclaimable_*` 字段用于审计；最终回答优先使用
  `aligned_reclaimable_*`/`final_reclaimable_*`。
- 某卡型没有记录，但同一模型存在其他卡型记录时，该卡型持有量按 0；不得借用其他卡型。
- 模型在整个当前窗口没有记录时校准值为 `null`、结果为 `partial`，不得解释为持有 0 卡。
- 查询失败或证据不一致时不得退回未校准理论量充当最终释放量。
- 8 卡等效机器数不是物理宿主机数，也不代表迁流后已经形成空闲机器。

直接查询指定模型持有量时，生产入口、候选发现、常规/上线验证参数和结果解释仍以
[resource.md](resource.md) 的“内部模型持有机器”章节为准。
