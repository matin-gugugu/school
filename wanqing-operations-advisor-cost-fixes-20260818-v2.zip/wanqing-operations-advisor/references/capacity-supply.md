# 供给画像

同时读取 [capacity.md](capacity.md)。本场景只查询配置容量，不加载 KConf、iSvc、资源、
其他容量场景或详细兼容契约。

### 证据、计算与输出

```text
确定 model、provider、priority=在线
→ 排除仍在进行中的分钟
→ 以数据水位线前最后一个完整分钟为窗口终点
→ 取最近 30 个连续自然分钟，并要求每个目标 provider 在每分钟都有容量
→ 各 provider 分别计算 30 分钟 totalTpm 算术平均值
→ 将 provider 均值相加，输出分项、占比和整体当前配置容量
```

供给画像只使用配置容量形成结论，不表述实际 Token 流量。当前工程入口
`query-headroom` 根据模型解析 Artifact 的 `target_scenario=supply-profile` 只查询容量，
不以用量缺失阻断供给画像。最近 30 个连续共同完整分钟不足时只返回 `partial`，不得用
已有分钟求不完整平均，也不得退回最新单分钟容量。用户继续问“还剩多少”或“能否承接”
时，切换到余量与扩容。

发起当前供给查询时，使用 `--window-relation current --lookback-seconds 2160`，
由脚本以运行时钟为 `to`、回溯 36 分钟得到 `from`。该窗口覆盖 300 秒水位保护、
SQL 起点严格排除和 30 个完整分钟。窗口仍
不足 30 个连续共同完整容量分钟时返回 `partial`，不自动扩大到更旧数据。
