# 云上容量回收

同时读取 [capacity.md](capacity.md)。按范围和请求深度读取 Top P、KConf、iSvc
接入文件：[integration-top-p.md](integration-top-p.md)、
[integration-kconf.md](integration-kconf.md)、
[integration-isvc.md](integration-isvc.md)，并始终读取
[integration-cost.md](integration-cost.md)。请求卡数或机器数时，同时读取
[resource-model-holdings.md](resource-model-holdings.md)。不加载供给、流量、普通扩容或
完整资源域文件。

## 目录

1. [生产首选入口](#生产首选入口)
2. [适用范围与证据](#适用范围与证据)
3. [前一日容量 P90 与流量 P90](#前一日容量-p90-与流量-p90)
4. [计算与限制](#计算与限制)

### 生产首选入口

生产命令、范围参数、策略模型身份、批量失败隔离和逐模型确认恢复统一见
[capacity-workflow.md](capacity-workflow.md)。入口只能是 `cloud-reclaim-prepare`，随后只
执行其 `next_action`，最后运行 `render-report`。`scope=all/gpu` 直接使用版本化策略
`model_scope`；`scope=explicit` 的全部输入若已是策略内精确模型名，也直接从同一
`model_scope` 生成逐模型身份 Artifact，否则才通过目标窗口候选发现解析用户表达。旧
`cloud-reclaim*` 计算命令只用于 finalize 内部装配、fixture 回放和兼容测试。

### 适用范围与证据

该场景回答“按前一天云上容量 P90 和流量 P90，云上余量理论上能够替代多少内部实例，
对应节省多少内部 GPU 卡和 8 卡等效机器，以及估算增加多少云上日成本”。“模型汰换上云
后能提供多少机器”“迁云后能节省多少卡/增加多少云上成本”等问题均进入本场景。

这里先计算只由云上余量决定的原始理论可回收内部实例数；它不使用 iSvc 当前
`desired_instances`、`ready_instances` 封顶。请求卡数或机器数时，再查询资源域当前
300 秒 `online` 模型持有 GPU 卡数，以“模型 + GPU 卡型”为粒度校准理论释放卡数上限。
校准结果仍不是迁流后实际下线的实例数，也不表示已经形成空闲物理机器。

用户明确给出一个或多个模型且未同时要求 Top N 时，生产调用使用
`cloud-reclaim-prepare --scope explicit`，只评估用户指定模型，不应用 Top P 前缀；
`finalize` 内部再使用 `cloud-reclaim-explicit` 装配。不得把模型在静态
名单中的位置转换成 `top_p`，也不得补齐该模型之前的候选。用户同时明确指定模型和
Top N 时先确认范围，不静默选择其中一个。

用户未指定模型但明确给出卡型或 Top P 时使用
`cloud-reclaim-prepare --scope gpu --gpu <卡型> [--top-p N]`；只给卡型时默认取该卡型
完整静态名单。模型、卡型和 Top P 均未给出时使用
`cloud-reclaim-prepare --scope all`，固定按 X60 全部 9 个模型 → X40 全部 3 个模型的顺序执行。默认
入口不是跨卡型 Top 12，也不改变每组的容量、用量、KConf 或 iSvc 口径。

所有范围都必须按用户最终问题传 `--detail-level`：`instances` 只要求理论可回收实例数，
`cards` 再要求经当前持有量校准的理论节省卡数，`machines` 再要求校准后的 8 卡等效
机器数；省略时兼容为 `machines`。`instances` 在 prepare 和内部装配阶段都跳过 iSvc 与
资源持有量查询，不能被部署规格或资源持有量证据阻塞。

成本查询不受 `detail-level` 影响；三条路径都查询容量 handoff 为 `ready` 的模型前一天
`billable_usage_cost`。`instances` 只跳过 iSvc 和资源持有量，不跳过成本域。

显式模型与 Top P 的选择范围不同，但策略内精确显式模型可以复用版本化
`model_scope` 作为身份来源；模糊或策略外显式输入仍执行候选发现与确认。进入容量查询后，
各范围都使用相同的前一日 `public` 容量/用量完整性、KConf、iSvc、计算公式和逐模型停止
条件；任一模型无容量行不影响其他模型继续。

`prepare` 为内部单卡型装配入口 `cloud-reclaim` 准备：

- `policy.gpu_type`、`policy.top_p`，以及对应卡型固定有序名单的前 N 个候选；
- 前一完整自然日 `provider=public`、`priority=在线` 的容量完整分钟和用量语义完整分钟；
- 同一业务窗口内两套独立样本中的 `capacity_tpm`、`usage_tpm` 和各自自然分钟起点；
- 成本域对同一精确模型、同一前一日窗口返回的 `billable_usage_cost`；
- KConf 返回的正数单实例容量，以及对应 `key`、`stage`、字段路径、版本
  和查询时间；
- 需要卡数或 8 卡等效机器数时补充 iSvc API 返回的在线已部署模型单实例卡数。
- 需要卡数或 8 卡等效机器数时，由 Workflow 复用同一精确模型解析 Artifact，批量查询
  资源域最近 300 秒的 `online` 模型持有量；不再次模糊解析模型，也不使用 offline 持有量。

`prepare --scope explicit` 为内部 `cloud-reclaim-explicit` 装配时，将第一项替换为
`selection.mode=explicit_models`、`selection.source=user_explicit`、由用户明确给出的
模型经解析后形成的精确 `selection.models[]`，以及模型和顺序完全一致的 `candidates[]`；
原始表达保留在各模型解析 Artifact 的 `user_input`，且不提供 `policy`。
其余容量、KConf 和 iSvc 证据要求与单卡型入口完全相同。

`prepare --scope all` 为内部 `cloud-reclaim-all` 装配时，输入改为 `candidates_by_gpu.X60[]` 和
`candidates_by_gpu.X40[]`，两组必须同时存在且分别完整覆盖静态名单的 9 个和 3 个模型，
并为每个模型提供上述相同证据。外层先把相对 Artifact 路径按原始批量输入文件解析为
绝对路径，再把两组写入 `01-x60/`、`02-x40/`，分别调用原 `cloud-reclaim`；因此不会
因分组目录改变而丢失证据引用，也不会破坏单卡型输入契约。

每个候选使用 `cloud.provider=public`、`cloud.priority=在线`，容量证据放入
`cloud.capacity_minute_samples[]`，字段为 `minute_start_epoch_seconds`、`capacity_tpm`；
用量证据放入 `cloud.usage_minute_samples[]`，字段为 `minute_start_epoch_seconds`、
`usage_tpm`、`sample_origin`。`sample_origin=clickhouse_observed` 表示 CK 原始非零分钟，
`sample_origin=inferred_zero_sparse_usage_contract` 表示按稀疏写入契约补 0。交接同时保存
原始用量覆盖率、补零样本数、策略版本和置信度。旧的 `cloud.minute_samples[]` 只作为
历史回放兼容输入。生产 Workflow 在
每个候选的 `kconf.artifact` 引用规范化 KConf
Artifact，自动提取 `key`、`stage`、`field_path`、版本、查询时间和
`single_instance_capacity_tpm`，并保留 `capacity_source`、`device_type` 和选择规则。
多个候选同时返回 `device_type_required` 时，合并展示各模型可选卡型，一次询问
用户；已成功的 KConf Artifact 可以继续进入 Workflow，未命中或待选卡型的候选在结果中
保持 `partial`，不得用其他模型配置补齐。直接提供这些内联字段只用于 fixture 和历史回放。
iSvc 字段只由 API Artifact 填充
`isvc.single_instance_gpu_cards` 和 `isvc.single_instance_gpu_cards_by_type`，不得人工
填写。

生产查询对多个候选运行 `query-headroom-batch`，按候选顺序重复传
`--model-artifact`，固定使用 `--provider public`、`--provider-scope cloud`、
`--window-relation previous_day --max-workers 4`。批量命令只解析一次窗口，以一条
容量 SQL 和一条用量 SQL 覆盖全部模型，并发执行这两条 SQL；单模型时继续使用
`query-headroom`。

```bash
python3.10 scripts/capacity.py query-headroom-batch \
  --model-artifact /tmp/model-01.json \
  --model-artifact /tmp/model-02.json \
  --provider public \
  --provider-scope cloud \
  --window-relation previous_day \
  --timezone Asia/Shanghai \
  --max-workers 4 \
  --output-dir /tmp/wanqing-headroom-batch \
  --output /tmp/wanqing-headroom-batch.json
```

`previous_day` 生产命令省略 `--from`/`--to`，不复制候选 Artifact 中的历史时间戳。
成功查询 Artifact 在 `handoffs.cloud_reclaim` 分别保存全部容量完整分钟和用量语义完整分钟；
Workflow 输入使用
`cloud.headroom_artifact` 引用该 Artifact，自动提取两套样本，不得由 Agent 手工复制。
直接传 `cloud.capacity_minute_samples`、`cloud.usage_minute_samples`，或兼容的
`cloud.minute_samples`，只用于规范化证据回放和测试。

Top P Workflow 先按 `scripts/top_p_policy.py` 校验卡型、N 和候选顺序；显式模型
Workflow 校验 `selection.source=user_explicit`，并要求 `selection.models[]` 与
`candidates[]` 的模型和顺序完全一致。两种入口随后都为每个候选加载
`model_artifact`。版本化策略范围可以证明策略内精确模型身份，用户模糊表达本身不能；
无论身份来源如何，每个候选仍必须提供目标场景为 `cloud-reclaim` 的成功独立解析 Artifact。

这里的“同一”还覆盖候选的五个下游证据：`cloud.headroom_artifact`、成本域
`cloud-daily-billing`、`kconf.artifact`、`isvc.artifact` 和资源域 `model-holdings`
Artifact 的模型交接必须都是
`verified_artifact`，且规范化绝对路径与候选 `model_artifact` 相同。Workflow 自动调用
成本、iSvc 和资源域持有量查询时会传入该文件并生成闭环证据。成本交接标记为
`cloud_reclaim_cost_estimation`，资源域交接标记为 `cloud_reclaim_resource_alignment`；
两者都保留原容量解析目标。缺少标记、只写相同模型名、引用另一个解析文件，或领域、
场景、锚点不一致时均停止，不混算。

规范化证据使用：

```bash
python3.10 scripts/capacity.py cloud-reclaim \
  --input /tmp/wanqing-cloud-reclaim-input.json \
  --output /tmp/wanqing-cloud-reclaim.json
```

上述生产输入的 Top P 或显式模型候选都必须包含 `model_artifact`。离线回放旧的规范化 JSON 时显式
增加 `--evidence-mode replay`；该模式只用于验证公式，不能补成生产证据。

以下命令只供 `finalize` 内部装配和离线兼容测试，不作为生产首选入口：

```bash
python3.10 scripts/workflow.py cloud-reclaim \
  --input /tmp/wanqing-cloud-reclaim-input.json \
  --output-dir /tmp/wanqing-cloud-reclaim-workflow \
  --max-workers 4 \
  --output /tmp/wanqing-cloud-reclaim-workflow.json
```

用户明确指定模型的内部装配入口为：

```bash
python3.10 scripts/workflow.py cloud-reclaim-explicit \
  --input /tmp/wanqing-cloud-reclaim-explicit-input.json \
  --output-dir /tmp/wanqing-cloud-reclaim-explicit-workflow \
  --max-workers 4 \
  --output /tmp/wanqing-cloud-reclaim-explicit-workflow.json
```

显式模型输入的选择字段为：

```json
{
  "observed_at": "2026-08-05T12:00:00+08:00",
  "selection": {
    "mode": "explicit_models",
    "source": "user_explicit",
    "models": ["glm-5.2"]
  },
  "candidates": [
    {
      "model": "glm-5.2",
      "model_artifact": "/tmp/wanqing-model-resolution.json",
      "cloud": {"headroom_artifact": "/tmp/wanqing-headroom.json"},
      "kconf": {"artifact": "/tmp/wanqing-kconf.json"}
    }
  ]
}
```

该入口允许一个或多个用户明确指定的模型，但 `selection.models[]` 和 `candidates[]`
必须非空、无重复且完全同序；不得同时提供 `policy`。候选内的其他证据字段沿用下表。

默认双卡型全量的内部装配入口为：

```bash
python3.10 scripts/workflow.py cloud-reclaim-all \
  --input /tmp/wanqing-cloud-reclaim-all-input.json \
  --output-dir /tmp/wanqing-cloud-reclaim-all-workflow \
  --max-workers 4 \
  --output /tmp/wanqing-cloud-reclaim-all-workflow.json
```

批量输入不接受顶层 `policy` 或 `candidates`。输入 Schema 为：

| 字段 | 必填 | 约束 |
|---|---|---|
| `observed_at` | 是 | 本次评估时间，带时区的 ISO 8601 字符串 |
| `candidates_by_gpu` | 是 | 对象，必须且只能含 `X60`、`X40` 两个键 |
| `candidates_by_gpu.X60` | 是 | 恰好 9 个候选对象，模型名与顺序必须等于 X60 完整静态名单 |
| `candidates_by_gpu.X40` | 是 | 恰好 3 个候选对象，模型名与顺序必须等于 X40 完整静态名单 |
| `[].model` | 是 | 当前位置对应的精确模型名 |
| `[].model_artifact` | 是 | 目标场景为 `cloud-reclaim` 的成功模型解析 Artifact 路径 |
| `[].cloud.headroom_artifact` | 是 | 同模型、前一完整自然日、`public` 在线的成功 `query-headroom` Artifact 路径 |
| `[].kconf.artifact` | 是 | 同模型的成功 KConf 单实例容量 Artifact 路径 |
| `[].isvc.artifact` | 否 | 可复用的同模型 iSvc Artifact；不提供时 Workflow 自动只读查询 |
| `[].isvc.service_name` | 否 | 同模型存在多种活动规格时用于精确选择 KSN |

以下只展示分组骨架；字符串代表按上表构造的候选对象数组，不能直接作为执行输入：

```json
{
  "observed_at": "2026-08-05T12:00:00+08:00",
  "candidates_by_gpu": {
    "X60": ["按 X60 固定顺序提供全部 9 个现有候选对象"],
    "X40": ["按 X40 固定顺序提供全部 3 个现有候选对象"]
  }
}
```

这里数组元素仍是单卡型入口已有的候选对象，而不是字符串；上例字符串只用于紧凑表示
完整列表。外层先对两组候选只读取一次 iSvc 列表，再以有界并发执行 X60、X40 分组；
Manifest 保留共享 iSvc Manifest、两组原始 summary 和分组 Manifest 路径，并额外输出带
`policy_gpu_type` 的 12 个扁平候选。只有两组对应字段都完整时才汇总实例、卡数和 8 卡
等效机器数；任一组 iSvc 证据不完整时，外层卡数类总计为 `null` 且状态为 `partial`。
两组业务窗口必须完全相同，否则停止，避免跨窗口相加。

Workflow 默认对缺少 iSvc Artifact 的候选统一调用一次
`isvc.py query-models --pool online --max-workers 4`，只消费单实例卡型与卡数，不使用
期望或就绪实例数限制理论回收结果。同一模型存在多种活动规格时，在候选的
`isvc.service_name` 提供精确 KSN，批量命令仍复用同一列表响应；复用已有证据时提供
`isvc.artifact`。
`--isvc-fixture` 只用于离线测试。

`cards/machines` 路径在 iSvc 规格确认后，由 Workflow 统一调用一次
`resource.py model-holdings --service-type online --window-seconds 300`。该调用通过内部
`--capacity-model-artifact` 参数复用已验证的 `capacity/cloud-reclaim` 精确模型身份；此
参数只供固定 Workflow 使用，不是资源域普通用户入口。查询返回各模型、各卡型当前持有
GPU 卡数并按 8 卡折算等效机器数。离线回放只有显式提供 `--resource-fixture` 才验证该
校准阶段；未提供时保持旧公式回放，不得把回放结果表述为生产校准事实。

成本路径在 headroom 完成后，由 Workflow 统一调用一次
`cost.py query-cloud-daily-cost`。该调用同时传入容量模型 Artifact 和逐模型 headroom
Artifact，从后者复用前一完整自然日窗口；不重新解析模型或手算日期。离线回放只有显式
提供 `--cost-fixture` 才验证成本阶段；未提供时标记 `fixture_replay_skipped`，不得把回放
结果表述为生产成本估算。

批量结果始终按候选输入顺序输出。只有容量 handoff 为 `ready` 的候选进入成本、iSvc/KConf
子批次；容量不完整的候选保留原位置并标记 `partial`，其无关部署歧义或配置缺失不触发
查询，也不阻塞其他候选。进入依赖子批次后 KConf 或 iSvc 证据不可用仍只影响该候选；
只有所有候选证据完整时才输出完整总计。证据不完整时
完整总计为 `null`，`reclaimable_instances_partial_sum` 仅表示已完成模型的小计，不得
表述为全部候选的理论释放量。模型解析证据不一致、候选顺序错误或跨窗口混用仍立即停止，
不得作为普通单模型缺失降级。

### 前一日容量 P90 与流量 P90

“前一天云上流量峰均值”固定定义为前一天云上分钟流量的 P90 分位值，不再对最高
10% 分钟求平均。云上容量也固定取前一天云上分钟容量的 P90。两者使用同一个业务窗口、
模型、provider 和在线口径，但分别在容量完整分钟集合与用量语义完整分钟集合上使用
nearest-rank 计算：

```text
Nc = 前一日 public 在线容量完整分钟数
Nu = 前一日 public 在线用量语义完整分钟数（含契约补 0）
rc = ceil(Nc × 0.90)
ru = ceil(Nu × 0.90)

previous_day_cloud_capacity_p90_tpm
  = 第 rc 个按 capacity_tpm 升序排列的分钟值

previous_day_cloud_traffic_p90_tpm
  = 第 ru 个按 usage_tpm 升序排列的分钟值

previous_day_cloud_traffic_peak_mean_tpm
  = previous_day_cloud_traffic_p90_tpm
```

容量一天内变化时，不再使用流量 P90 分钟对应的容量，也不得使用全天最大值、全天均值、
最后一个容量点或当天容量替代。容量检查原始分钟完整性；用量检查补零后的语义分钟
完整性，并把原始非零分钟覆盖单独作为诊断。容量原始覆盖不足、用量查询失败或用量语义
覆盖不足时返回 `partial`，不使用另一侧的完整性为其兜底。

### 计算与限制

```text
cloud_reclaimable_tpm
  = max(previous_day_cloud_capacity_p90_tpm
        - previous_day_cloud_traffic_p90_tpm,
        0)

cloud_reclaim_to_traffic_ratio
  = cloud_reclaimable_tpm
    / previous_day_cloud_traffic_p90_tpm

estimated_incremental_cloud_daily_cost
  = cloud_reclaim_to_traffic_ratio
    * previous_day_billable_usage_cost

reclaimable_instances
  = floor(cloud_reclaimable_tpm
          / kconf.single_instance_capacity_tpm)

reclaimable_gpu_cards_by_type[gpu_type]
  = reclaimable_instances
    × isvc.single_instance_gpu_cards_by_type[gpu_type]

reclaimable_gpu_cards
  = sum(reclaimable_gpu_cards_by_type)

reclaimable_8_card_machine_equivalents_by_type[gpu_type]
  = reclaimable_gpu_cards_by_type[gpu_type] / 8

reclaimable_8_card_machine_equivalents
  = sum(reclaimable_8_card_machine_equivalents_by_type)

aligned_reclaimable_gpu_cards_by_type[gpu_type]
  = min(reclaimable_gpu_cards_by_type[gpu_type],
        current_online_held_gpu_cards_by_type[gpu_type])

aligned_reclaimable_gpu_cards
  = sum(aligned_reclaimable_gpu_cards_by_type)

aligned_reclaimable_8_card_machine_equivalents
  = aligned_reclaimable_gpu_cards / 8
```

- `cloud_reclaimable_tpm` 是兼容字段名，业务含义是云上可承接的迁移 TPM。
- “上云成本”规范字段是 `estimated_incremental_cloud_daily_cost`，表示按前一天流量 P90
  线性放大的增量日成本估算，单位沿用源表 `true_usage_cost`，不默认称为元。另保留
  `estimated_projected_cloud_daily_cost=前一天成本+增量估算`。
- 前一天流量 P90 为 0、成本无行或成本查询失败时，成本估算保持 `null` 且结果为
  `partial`；容量、实例、卡数和持有量结果仍保留。成本总量只有所有候选都完整时输出，
  否则仅保留完整候选 `partial_sum`。
- 回收实例换算使用 `floor`，不得向上取整；负 TPM 归零。原始实例数不使用当前内部部署
  实例数或 iSvc 期望/就绪实例数封顶。
- KConf 证据必须精确对应同一模型用于折算的在线单实例容量。多供应商实例配置不一致时必须
  分供应商计算；目前数据只能识别聚合 `public`，无法可靠拆分时不输出实例汇总。
- iSvc 证据不可用时，`reclaimable_gpu_cards=null`，只输出可回收实例数；不得用 GPU
  型号、资源域持有量或经验值猜单实例卡数。
- 原始理论卡数与资源持有量必须按模型、按 GPU 卡型对齐；某卡型没有持有量时按该模型在
  其他卡型的返回记录判断为该卡型 0 卡，不得用其他卡型持有量补足。
- 模型在当前 300 秒窗口完全没有持有量记录时，该模型的校准值为 `null` 且结果
  `partial`，不得解释为持有 0 卡。资源查询失败同样不得回退到未校准理论量充当最终量。
- 保留 `reclaimable_*` 原始理论字段用于审计；最终回答优先使用
  `aligned_reclaimable_*`/`final_reclaimable_*`。如果校准未完成，完整最终总计保持 `null`。
- 8 卡等效机器数统一由校准后卡数除以 8，允许小数；它表示容量等价值，不是实际空闲
  物理机器数，不得再独立对机器数取一次最小值。
- 结果不额外扣减安全预留，直接使用“前一日云上容量 P90 减云上流量 P90”。它是理论迁移
  与资源节省能力，不保证覆盖前一日最大分钟，也不代表已执行迁流、释放物理机器或已经
  产生实际账单或金额节省。成本结果是线性估算，不包含合同单价、cache 计价、最小计费
  单位和计费周期，不能用于判断“是否成本更优”。
