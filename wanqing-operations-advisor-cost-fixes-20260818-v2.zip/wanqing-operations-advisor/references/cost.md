# 成本域路由

本文件负责直接面向用户的三个成本看板导航场景。它们都不查询、计算或推断成本数据，
也不调用资源域、容量域、SQL、API 或 Workflow。云上容量回收中的模型成本查询是容量
Workflow 的受控辅助证据，按 [integration-cost.md](integration-cost.md) 执行，不从这里
单独发起。

## 场景路由

| 用户最终要的结果 | 场景 | 固定入口 |
|---|---|---|
| 今天、最近一周或最近一个月的云上成本构成，以及各项为什么被上云 | `cloud_cost_composition` | [万擎成本看板](https://kwaibi.corp.kuaishou.com/pc/dashboard/preview?dashboardId=2122207&sheetId=324058) |
| 哪些资源或用量相对机器成本、云上价格处于亏损、倒挂或不划算 | `resource_cost_loss_comparison` | [万擎成本看板](https://kwaibi.corp.kuaishou.com/pc/dashboard/preview?dashboardId=2122207&sheetId=324058) |
| 指定自部署集群的运营系数 | `self_deployed_operation_coefficient` | [自部署集群运营系数看板](https://kwaibi.corp.kuaishou.com/pc/dashboard/preview?dashboardId=2122207&sheetId=324058&tabIds=1130876) |

按用户最终要的指标路由，不按孤立关键词路由：

- “云上成本构成”“为什么上云”进入 `cloud_cost_composition`。
- “哪些资源和量是亏损的”“哪些资源成本倒挂”“相比机器成本或云上价格哪些不划算”进入
  `resource_cost_loss_comparison`。
- “自部署集群运营系数”进入 `self_deployed_operation_coefficient`。
- “云上还能承接多少 TPM”仍属于容量域；“自部署集群有多少机器或 GPU”仍属于资源域。
- “云上容量回收后预计增加多少云上日成本”仍进入容量域云上回收，由 Workflow 跨成本域
  查询和估算；不得使用本页看板链接替代结构化成本证据。
- 其他成本问题当前未接入。说明能力边界并停止，不切换领域推导答案。

## 执行与输出

1. 直接返回命中场景的固定看板链接，不运行任何查询或脚本。
2. 用户给出时间范围时，在回复中原样说明该范围，并提示在看板中选择对应时间；不得手算
   日期，也不得声称链接已预设该筛选条件。
3. 用户给出集群名时，在回复中原样说明该集群，并提示在看板中筛选；不得把集群名拼入
   URL。未给出集群名时仍返回链接，提示筛选目标集群，不为此暂停。
4. 同时命中两个场景时，将其拆成两个结果并分别返回对应链接。
5. 不输出具体亏损资源、亏损用量、成本、构成占比、上云原因或运营系数；不使用“已查询”
   “查询结果”等措辞。

推荐回复：

```text
{时间范围}的云上成本构成及各项上云原因，请查看万擎成本看板，并在看板中选择
{时间范围}。
```

```text
{集群名}自部署集群的运营系数，请查看自部署集群运营系数看板，打开后筛选
{集群名}。
```

```text
哪些资源和用量相对机器成本或云上价格处于亏损，请查看万擎成本看板：
[https://kwaibi.corp.kuaishou.com/pc/dashboard/preview?dashboardId=2122207&sheetId=324058](https://kwaibi.corp.kuaishou.com/pc/dashboard/preview?dashboardId=2122207&sheetId=324058)
```
