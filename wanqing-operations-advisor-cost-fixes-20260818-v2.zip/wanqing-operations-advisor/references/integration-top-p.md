# Top P 策略接入

仅用于云上容量回收的策略范围和策略内精确模型身份。

当前使用 Skill 内置静态策略 `scripts/top_p_policy.py`，按 GPU 卡型维护有序名单。
Top P 只在用户未指定具体模型时负责生成候选。用户明确指定一个或多个模型且未同时要求
Top N 时，由生产入口 `scripts/workflow.py cloud-reclaim-prepare --scope explicit`
接收用户表达并自动生成解析和选择证据；内部装配仍通过
`cloud-reclaim-explicit` 的
`selection.mode=explicit_models`、`selection.source=user_explicit` 和
解析后的精确 `selection.models[]` 固定用户范围；原始表达保留在模型解析 Artifact。
不得根据指定模型在名单中的位置推导 `top_p`，也不得
自动补齐前缀。显式模型入口仍强制执行模型解析、容量完整性、KConf 和 iSvc 证据门控。
当显式输入全部精确命中本节版本化名单时，prepare 直接使用该策略作为受信身份注册表，
生成独立 `model-resolution` Artifact；因此模型不需要在目标日前一日容量表中有记录才能
被认定为合法。非精确表达或名单外模型仍使用容量锚点候选发现和确认，不猜别名。

显式单卡型 `cloud-reclaim` 中，`policy.gpu_type` 必须为 `X60` 或 `X40`，
`policy.top_p=N` 必须由本次请求或上游路由策略明确提供，不在单卡型接口内设置默认值；
用户只给卡型时由上游路由策略把 N 设置为该卡型名单长度。候选固定取对应卡型名单的前
N 个，不按流量、容量、名称或最近出现时间重新排序。

用户只要求“云上容量回收”且未指定模型、卡型和 Top P 时，默认使用
`scripts/workflow.py cloud-reclaim-prepare --scope all`：固定先评估 X60 全部 9 个模型，再评估 X40
全部 3 个模型。该默认值是两次独立的单卡型全量策略，不是跨卡型 Top 12 排名；每组
分别校验候选、执行 Workflow、判断完整性，最后仅在外层 Manifest 对不同模型结果求和。
`candidates_by_gpu` 必须同时且只能包含 X60、X40 两组，并完整覆盖各自有序名单；策略
若未来出现跨卡型重复模型，默认编排直接停止，避免重复计算。

X60 有序名单：

1. `qwen3.5-397b-a17b`
2. `deepseek-v3`
3. `deepseek-v3.1`
4. `kimi-k2.5`
5. `deepseek-v3.2`
6. `kimi-k2.6`
7. `deepseek-v4-flash`
8. `deepseek-v4-pro`
9. `glm-5.2`

X40 有序名单：

1. `qwen3-vl-32b-instruct`
2. `qwen3-235b-a22b-instruct-2507`
3. `qwen3-32b`

因此 X60 的 `top_p=2` 固定选择 `qwen3.5-397b-a17b`、`deepseek-v3`；X40 的
`top_p=2` 固定选择 `qwen3-vl-32b-instruct`、`qwen3-235b-a22b-instruct-2507`。
`top_p` 不得超过对应名单长度。X60 和 X40 没有共同的跨卡型排名；默认全量评估由
外层编排按 X60 → X40 顺序分别执行两次策略和 Workflow，不合并后再截断。用户明确
未指定模型但指定卡型或 N 时，继续使用原 `cloud-reclaim` 单组入口，不自动扩展到另一
卡型；只指定卡型时取该卡型完整静态名单。用户同时明确指定模型和 Top N 时先确认范围，
不静默选择或合并两种选择方式。

Top P 输入的 `candidates[]` 至少覆盖前 N 个模型，并按固定顺序排列；脚本直接根据静态策略校验
模型精确值，不再要求或信任调用方填写 `whitelisted=true`。每个模型仍需生成目标场景为
`cloud-reclaim` 的独立 `model-resolution` Artifact；静态白名单不替代模型解析证据。
策略证据在容量结果中记录为 `skill_static_policy`、版本 `1`。名单变化需要更新 Skill
策略、文档和回归测试后重新发布，不由 Agent 在执行时临时增删或重排。
