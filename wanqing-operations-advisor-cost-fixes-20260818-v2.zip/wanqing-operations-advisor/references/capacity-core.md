# 容量公共规则

本文件只记录所有容量场景共享的数据契约、查询口径、状态语义和跨领域边界。先通过
[capacity.md](capacity.md) 选择场景，再同时读取本文件和对应的一个场景文件。涉及 Top P、
KConf、iSvc 或天问时，通过 [data-integration.md](data-integration.md) 选择对应集成文件。

公共口径以本文件为准；场景公式、证据深度和停止条件以对应场景文件为准。

## 目录

1. [边界与运行约束](#边界与运行约束)
2. [当前能力](#当前能力)
3. [数据源与字段](#数据源与字段)
4. [公共查询口径](#公共查询口径)
5. [业务场景路由与统一 SOP](#业务场景路由与统一-sop)
6. [跨领域交接](#跨领域交接)
7. [结果解释与异常](#结果解释与异常)
8. [待补数据契约](#待补数据契约)

## 边界与运行约束

容量域回答：

- 供给画像：指定模型、provider 的在线配置容量；
- 流量画像：模型整体及 provider 的实际 TPM、占比和已有性能指标；
- 余量与扩容：以前一完整自然日评估容量余量、新增 TPM 承接能力、缺口、实例数、
  GPU 卡数和 8 卡等效机器数；
- 云上容量回收：评估云上余量可承接多少迁移流量，换算原始理论可回收内部实例数；有
  iSvc 证据时计算原始理论节省卡数，再按资源域当前 `online` 模型持有量校准最终卡数和
  8 卡等效机器数；同时跨成本域查询前一天模型成本并估算增量上云日成本。

执行时遵守：

- 必须使用本文件指定的执行组件，不得让模型自由拼接或执行生产 SQL。
- 每个 Workflow 保存规范化请求、外部 SourceEvidence 和最终 Result；只有跨轮次等待确认或
  工具调用时保存 Checkpoint。内部确定性变换无需成为新的信任边界。
- 查询失败、字段缺失或口径待确认时，返回已有证据和缺失项，不猜结论。
- fixture、示例和历史验证值只用于测试，不得作为实时证据。
- 所有操作只读；不得声称已经修改容量、配置、路由或资源。

## 当前能力

“工程已实现”和“业务口径已确认”是两个独立状态。脚本能计算，不代表结果已经可以
作为生产承诺。

### 业务能力

| 业务场景 | 典型问题 | 主要执行路径 | 当前可用范围 |
|---|---|---|---|
| 供给画像 | 当前配置容量是多少，`public`/`internal` 各多少 | 容量查询 | 单、多 provider 最近 30 个完整分钟容量均值已实现 |
| 流量画像 | 当前实际 TPM、provider 占比、cache、TTFT、TPOT | 用量查询后组装画像 | 同一 T10 窗口的实际 TPM 均值和占比已实现；天问固定导航链接已接入，性能指标值待接入 |
| 余量与扩容 | 哪里有冗余，新增 TPM 能否承接，缺多少实例、卡数或 8 卡等效机器 | 查询或回放容量证据；未指定范围时扫描版本化候选名单；出现缺口后按需补充 KConf、iSvc 和资源证据 | 前一日内部容量 P90 减内部流量 P90 已实现；默认候选与 internal 范围已接入；KConf 归一化优先、普通配置回退和多卡型澄清已实现；按卡型卡数和等效机器换算已接 iSvc Artifact |
| 云上容量回收 | 模型汰换上云后理论可节省多少内部实例、卡数或 8 卡等效机器，预计增加多少云上日成本 | 使用固定云上回收 Workflow | 前一日云上容量 P90 减流量 P90、实例换算、iSvc 理论卡数、资源域当前持有量校准及成本域线性估算已实现 |

### 执行组件职责

| 组件 | 主要命令 | 责任边界 |
|---|---|---|
| `scripts/capacity.py` | `list-models`、`list-models-batch`、`query-headroom`、`query-headroom-batch`、`headroom`、`traffic-profile`、`cloud-reclaim`、`inspect` | 保持全部公开容量命令、参数和 Artifact 契约，作为查询层与计算层的薄 CLI 门面；`reclaim-capacity` 只是 `cloud-reclaim` 的兼容别名 |
| `scripts/capacity_query.py` | 由 `capacity.py` 调用 | 负责模型候选、窗口解析、SQL、完整分钟、provider 对齐、稀疏流量补零、覆盖率和批量查询证据规整 |
| `scripts/capacity_metrics.py` | 由容量与回收入口调用 | 负责 nearest-rank P90、余量、扩容实例/卡数/机器、理论回收、流量画像及按卡型持有量封顶，不发起生产查询 |
| `scripts/cost.py`、`scripts/cost_query.py`、`scripts/cost_metrics.py` | 由云上回收 Workflow 调用 | 负责成本域 CLI、前一天模型账单查询和十进制线性估算；不修改容量、KConf、iSvc 或资源结果 |
| `scripts/reclaim_assembly.py` | 由现代回收和旧兼容命令共同调用 | 负责校验并装配模型、headroom、KConf、iSvc 证据，执行基础回收计算和 X60/X40 分组汇总 |
| `scripts/legacy_workflow.py` | `cloud-reclaim`、`cloud-reclaim-explicit`、`cloud-reclaim-all` | 只保留旧命令兼容适配；不再被现代回收 finalize 调用 |
| `scripts/model_resolver.py` | `resolve`、`resolve-batch` | 消费单模型候选 Artifact 或批量候选 Manifest，把用户表达解析为唯一精确模型名；不查询业务指标 |
| `scripts/top_p_policy.py` | 公共函数 | 保存 X60、X40 版本化有序候选名单，供普通余量默认扫描和云上回收复用；校验 `gpu_type`、`top_p`、候选前缀及用户显式模型范围 |
| `scripts/isvc.py` | `query-model`、`query-models` | 单模型入口保持兼容；批量入口只读取一次完整 online 部署列表，再按输入顺序生成单实例总卡数和按卡型分项 Artifact |
| `scripts/capacity_pipeline.py` | 由 `workflow.py` 调用 | 生产供给、流量、余量与扩容的低自由度编排；校验任务、自动选择单/批量入口、执行最小查询源，并只在确有缺口且请求扩容换算时生成 KConf 检查点 |
| `scripts/reclaim_pipeline.py` | 由 `workflow.py` 调用 | 云上回收 prepare/finalize/report 状态机；固定范围、裁剪逐模型依赖并从受绑定计算 Manifest 重建报告 |
| `scripts/capacity_evidence_contract.py` | 公共函数 | 把普通容量请求的模型、provider、窗口和扩容策略语义绑定到逐模型证据，防止跨任务复用不兼容 Artifact |
| `scripts/workflow.py` | `capacity-analyze`、`capacity-analyze-finalize`、`render-capacity-report`；`cloud-reclaim-prepare`、`cloud-reclaim-finalize`、`render-report` | 前三者是普通容量分析的唯一生产入口；后三者是云上回收的唯一生产入口。旧 `cloud-reclaim-explicit`、`cloud-reclaim`、`cloud-reclaim-all` 只作为外部兼容命令 |

组件和子命令是执行机制，不是用户业务场景。多 provider、历史窗口和闲时时段是查询
参数或辅助证据，也不作为独立业务场景。

兼容命令 `cloud-reclaim-explicit` 和 `cloud-reclaim` 为各自候选保存规范化输入
和容量结果 Artifact；`cloud-reclaim-all` 进一步为 X60、X40 保存独立子目录和分组
Manifest。生产调用由 `prepare/finalize` 自动准备并传入这些证据。
iSvc 证据不可用时保留实例结果并把对应分组及外层 Manifest 标记为 `partial`，不恢复
旧的资源域峰值机器基线链路。

## 数据源与字段

### 容量时间序列

- 数据表：`wanqing_data.ai_infra_all_model_quota_info`
- 工程状态：**已接入**

查询按分钟、provider、model 和在线/离线分组：

| 输出字段 | 来源与计算 |
|---|---|
| `t` | `timestamp` 向下取整到分钟后转为毫秒时间戳 |
| `provider` | 供应类型；`internal` 为内部自部署，`public` 为云上 |
| `priority` | 请求等级；输出值为 `在线` 或 `离线`。`scene IN ('batch', 'offline')` 为离线，其他为在线 |
| `model` | 底表真实模型值 |
| `capacity` | `max(totalTpm)` |

容量查询必须在 `WHERE` 阶段排除离线记录，不能只生成 `priority` 标签。

### 实际用量时间序列

- 数据表：`kce_server.ai_infra_billing_gateway_log_flatten_map_timestamp`
- 工程状态：**已接入**

第一层查询按分钟、provider、workload、model 和在线/离线分组：

| 输出字段 | 来源与计算 |
|---|---|
| `t` | `req_start_time` 向下取整到分钟后转为毫秒时间戳 |
| `provider` | `x_ks_provider`，规范值为 `internal` 或 `public` |
| `priority` | 请求等级；输出值为 `在线` 或 `离线`。Critical、Standard 为在线；Sheddable 为离线；其他按现有 CASE 归在线 |
| `workload_id` | `x_ks_wq_workload_id` |
| `model` | `x_higress_llm_model` |
| `token` | `sum(ifNull(output_token, 0)) + sum(ifNull(input_token, 0))` |

用量查询同样必须在 `WHERE` 阶段排除离线记录。分区下界使用 `$from` 所在日期，
上界使用 `$to - 1` 所在日期；两端都显式使用业务时区。

该用量表采用稀疏写入契约：目标 model、provider 在某个自然分钟的在线 Token 用量为
0 时不写该分钟记录。生产查询成功且模型已经公共模型 Artifact 验证后，
`query-headroom` 在同一业务窗口和 300 秒水位线内建立预期自然分钟轴，并对每个目标
provider 的缺行分钟补 `usage_tpm=0`，再按分钟聚合和计算 P90。该规则只适用于用量表，
不适用于容量表，也不用于掩盖查询失败、字段错误或尚未闭合的分钟。

Artifact 同时保存两套完整性：`usage_raw_*` 表示 CK 实际返回的非零分钟覆盖，
`usage_effective_*` 表示按稀疏写入契约补 0 后参与计算的语义分钟覆盖；并保存补 0 的
分钟数、provider-minute 数、样本来源、策略版本和
`zero_fill_confidence=source_contract_based`。当前没有独立摄入心跳，因此该置信度只证明
查询成功并符合数据源契约，不能区分“真实零流量”和未被外部健康信号发现的摄入丢失。
多 provider 的当前分钟另存 `current_usage_sample_origin_by_provider`；若同一分钟同时含
原始观测和契约补 0，聚合来源标记为
`mixed_clickhouse_observed_and_inferred_zero`，不得把整个聚合值标成全量补 0。
流量画像的主口径另存最近 10 个语义完整分钟中每个 provider 的原始观测数、补零数和
置信度。若某个 provider 的 T10 全部由契约补零构成，数值仍为 0，但结果必须降级为
`partial`；不得据此断言该 provider 无流量，也不得表述其他 provider 占比为 100%。

### 外部证据

| 证据 | 用途 | 当前状态 |
|---|---|---|
| KConf 单实例容量 | TPM 缺口换算扩容实例，或云上可承接迁移 TPM 换算理论可回收内部实例 | Agent 工具返回契约、配置选择和 `--kconf-artifact` 交接已实现 |
| 资源域 Artifact | 扩容时初步校验资源总量；云上回收时按模型、卡型提供当前 `online` 持有量上限 | 数量交接和云上回收 `model-holdings` 校准已对接；物理宿主机拓扑与调度可行性不在当前证据内 |
| iSvc 单实例部署卡数 | 扩容实例换算所需卡数和 8 卡等效机器数；理论可回收内部实例换算节省卡数和 8 卡等效机器数 | 只读 API、普通/PD 拓扑解析和 Artifact 交接已实现 |
| Top P 白名单 | 限定云上容量回收候选模型 | X60/X40 静态有序名单及前 N 校验已接入 |
| 天问性能指标 | cache、TTFT、TPOT | 固定导航链接已接入；结构化指标值待接入 |
| 前一天模型云上成本 | 估算云上余量对应的增量上云日成本 | `true_usage_cost` 可计费口径、跨域 Artifact 和线性估算已接入；固定成本看板仍不作为金额证据 |

外部系统的详细契约见 [data-integration.md](data-integration.md)。

## 公共查询口径

### 维度与默认值

| 维度 | 规则 |
|---|---|
| `model` | 最终查询使用底表真实精确值；用户表达不精确时先执行公共模型解析，不在指标查询中猜别名 |
| `provider` | `public` 表示全部云上，`internal` 表示全部内部自部署 |
| `provider_scope` | `public → cloud`，`internal → self_deployed`，两者一起为 `mixed` |
| `priority` | 值为 `在线`、`离线`；当前容量、余量和目前 TPM 默认在线 |
| 时间 | 默认业务时区为 `Asia/Shanghai`；查询和回答保留 `from`、`to`、业务时区及窗口关系 |

不拆分云供应商或自部署集群。`mixed` 不能使用仅描述内部机器的资源域 Artifact；需要
校验内部机器时另行查询 `internal`。

### 模型名锚点与解析

需要按模型过滤且没有可复用的成功模型解析 Artifact 时，先阅读
[model-resolution.md](model-resolution.md)，再按主场景选择唯一锚点：

| 主场景 | `list-models` / `list-models-batch --anchor-source` | provider 和窗口 |
|---|---|---|
| 供给画像 | `capacity` | 用户目标 provider；当前场景窗口，未命中时可用最近 24 小时确认名称 |
| 流量画像 | `usage` | 用户目标 provider；当前场景窗口，未命中时可用最近 24 小时确认名称 |
| 余量与扩容 | `capacity` | 未指定范围时以版本化 `model_scope` 直接生成模型身份；显式模型表达使用 `internal`、在线、前一完整自然日发现候选 |
| 云上容量回收 | `capacity` | `public`、在线、前一完整自然日；策略范围及策略内精确显式模型直接以版本化 `model_scope` 为身份源，其他显式表达使用该窗口发现候选 |

例如流量画像先运行：

```bash
python3.10 scripts/capacity.py list-models \
  --anchor-source usage \
  --model-input 'GLM 5' \
  --provider public \
  --provider internal \
  --priority 在线 \
  --window-relation custom \
  --from 1785744000 \
  --to 1785830400 \
  --output /tmp/wanqing-capacity-model-candidates.json
```

再用 `scripts/model_resolver.py resolve` 生成公共解析 Artifact。只有解析结果为 success
时，才把该 Artifact 通过 `query-headroom --model-artifact` 交给后续生产查询；领域脚本
从 `handoffs.model.model` 读取并校验精确值，不由 Agent 手工复制模型字符串。
候选窗口扩大到最近 24 小时只证明名称近期存在，不改变“当前”共同完整分钟、前一完整
自然日或用户自定义的最终指标窗口。

同一场景有两个及以上未解析模型时必须改用批量入口；批次只解析一次时间窗口，默认最多
四条候选请求并发执行，并按输入顺序落盘：

```bash
python3.10 scripts/capacity.py list-models-batch \
  --anchor-source capacity \
  --model-input 'deepseek-v4-pro' \
  --model-input 'qwen3.5-397b' \
  --provider public \
  --window-relation previous_day \
  --timezone Asia/Shanghai \
  --max-workers 4 \
  --output-dir /tmp/wanqing-capacity-model-candidates \
  --output /tmp/wanqing-capacity-model-candidates-batch.json
```

随后将该 Manifest 交给 `model_resolver.py resolve-batch`。不得逐模型串行调用 `list-models`
或自行编写并发脚本。单模型继续使用原 `list-models` 和 `resolve`，参数与 Artifact 不变。

候选 SQL 固定只返回模型名和最近出现时间，最多 20 个，不计算 TPM。KConf 和 iSvc 是
条件补充证据，不作为容量问题的第二套模型猜测来源；解析后的精确名称在其中未命中时
按相应停止条件返回部分结果。

模型解析 Artifact 不是只在首次查询时看一眼。场景、候选锚点和下游命令都按公共契约
复核：供给、余量和云上回收使用 `capacity` 锚点，流量画像使用 `usage` 锚点。规范化
计算入口默认 `--evidence-mode production`；`headroom`、`traffic-profile` 通过
`--model-artifact` 提供证据，`cloud-reclaim` 的每个 Top P 候选通过
`model_artifact` 提供证据。只有 fixture 或历史回放显式传
`--evidence-mode replay`；其结果保留 `replay_unverified` 标记，不能回答当前生产值。

### 多 provider 共同时间窗口

各 provider 的 `totalTpm` 是独立容量，可以相加，但必须先按自然分钟对齐。供给画像使用
最近 30 个连续共同完整分钟：

```text
T30
  = 数据水位线前最近 30 个连续自然分钟
    ∩ 每个目标 provider 的完整容量分钟集合

current_30m_capacity_average_tpm
  = mean(
      sum(provider_capacity_tpm(t)),
      t ∈ T30
    )
```

- `T30` 必须恰好覆盖最近 30 个连续完整分钟；任一 provider 缺任一分钟即返回
  `partial`，不以 0 补齐，也不向前抓取更旧分钟凑满 30 个样本。
- provider 分项分别对同一个 `T30` 求平均；整体容量等于这些 provider 均值之和。
- 流量画像使用同一个水位线终点前的最近 10 个连续语义完整分钟 `T10`。每个 provider
  先在 `T10` 内按稀疏写入契约补 0，再分别求算术平均；整体 TPM 等于 provider 均值之和，
  占比也只从这些均值计算。无需要求所有 provider 在每分钟都有 CK 原始行。
- “当前”容量和用量统一设置 300 秒数据水位保护，只使用水位线之前的自然分钟。
  供给画像需要 T30；流量画像需要 T10。任一目标 provider 的 T10 全由补零构成时，即使
  语义窗口完整也返回 `partial` 并保留补零置信度警告。
- 当前供给查询通常至少覆盖 36 分钟：30 分钟样本 + 5 分钟水位保护 + SQL 严格起点边界。
  当前流量画像通常至少覆盖 16 分钟：10 分钟样本 + 相同 5 分钟水位保护 + 严格起点边界。

### 时间、单位与类型

- TPM 表示 token/minute。
- 容量和用量统一到分钟粒度。
- 供给画像的“当前容量”取数据水位线前最近 30 个连续共同完整自然分钟的算术平均值；
  流量画像的“当前 TPM”取同一水位线前最近 10 个连续语义完整自然分钟的算术平均值。
- 查询完整自然日时，`to` 使用下一日零点。
- `list-models`、`list-models-batch` 和 `query-headroom` 必须显式声明
  `--window-relation`。查询前一
  完整自然日时只传 `--window-relation previous_day` 和 `--timezone`，省略
  `--from`/`--to`；脚本从平台运行时钟计算业务时区的今日零点与前一日
  零点。不得让 Agent 手算该窗口的日期或 Unix 时间戳。
- 查询“当前”时只传 `--window-relation current --lookback-seconds <秒数>` 和
  `--timezone`，同样省略 `--from`/`--to`。供给画像回溯 2160 秒，保证在
  300 秒水位保护和严格起点之后仍有 30 个完整分钟；流量画像回溯 960 秒，
  对应 10 个完整分钟。`current` 禁止显式传入 `--from`/`--to`，防止过期
  或错误年份的时间戳被表述为当前数据。
- `query-headroom-batch` 接受按用户输入顺序重复提供的 `--model-artifact`，整个批次
  只解析一次 `current` 或 `previous_day` 窗口，再把同一 `from/to/resolved_at` 注入
  每个模型 Artifact。容量和用量分别使用一条带模型 `IN` 过滤的 SQL，并在两类证据都
  需要时并行执行；不得在批次内逐模型重新读取运行时钟。
- 生产查询仍显式传入 `previous_day` 的 `--from`/`--to` 时，脚本必须同时
  校验本地零点、连续日期和运行时钟的真实前一日；任一不符即返回
  `error`。fixture 或历史回放可使用历史日期，但仍必须对齐业务时区零点
  且覆盖连续两个本地日期。
- 前一完整自然日的生产查询要求容量原始分钟完整覆盖同一个业务日；用量侧要求查询成功，
  再以“原始非零分钟 + 契约补零分钟”形成完整语义日。Artifact 分别记录容量原始覆盖、
  用量原始覆盖、用量语义覆盖和补零数量。容量不足、用量查询失败或用量语义分钟不足时
  返回 `partial`；跨数据源共同分钟只保留为诊断信息，不参与两侧 P90 计算。
- `capacity_tpm` 是配置供给，`usage_tpm` 是实际观测值或按已声明稀疏契约推断的 0；
  通过 `sample_origin` 区分，且不得与容量混称或相加。

## 业务场景路由与统一 SOP

先根据用户最终要的结果选择一个主场景，再决定执行哪些子命令。不要根据命令名反推
业务场景。

| 用户最终要的结果 | 主场景 | 必需证据 | 执行入口 |
|---|---|---|---|
| 当前配置容量及 `public`/`internal` 分项 | 供给画像 | 容量分钟序列 | 生产统一使用 `capacity-analyze`，内部只执行容量查询 |
| 当前实际 TPM、provider 占比及性能指标 | 流量画像 | 用量分钟序列；性能指标可选 | 生产统一使用 `capacity-analyze`，内部只执行用量查询 |
| 可用余量、新增 TPM 缺口、实例数、卡数或 8 卡等效机器数 | 余量与扩容 | 容量、用量；配置、iSvc 和资源按需 | 生产统一使用 `capacity-analyze`；只有确有缺口且请求换算时进入 `capacity-analyze-finalize` |
| 模型迁云后的理论可回收内部实例数、节省卡数、8 卡等效机器数和估算增量上云日成本 | 云上容量回收 | 前一日 `public` 在线容量/用量、成本域前一日模型成本、KConf 单实例容量；卡数/机器数再取 iSvc 与资源域当前 `online` 模型持有量 | 统一从 `cloud-reclaim-prepare` 开始：指定模型用 `--scope explicit`，指定卡型/N 用 `--scope gpu`，均未指定用 `--scope all`；随后执行 `finalize` 和 `render-report` |

### 统一 SOP

1. **拆分原子任务**：识别用户最终要的是供给、流量、余量扩容还是云上容量回收。一个
   用户问题可以包含多个原子任务；每个原子任务只保留一个主场景，并用唯一 `task_id`
   关联结果。普通容量任务放进同一份 `capacity-analyze` 请求；云上容量回收保持独立。
2. **规范参数**：确定 `provider`、`priority`、时间窗口和业务时区；模型需要过滤但尚未
   验证精确值时，先按“模型名锚点与解析”生成成功 Artifact，再使用解析出的精确值。
   对“目前容量哪里有冗余”这类普通余量问题，模型和 provider 均未指定时使用 Schema 1.1
   的版本化全量候选模型域与 `internal/self_deployed`；用户指定模型、GPU Top P 或 provider
   时按用户范围完整覆盖默认值，不取隐式交集。
   供给画像中的“当前容量”使用最近 30 个连续共同完整分钟均值；流量画像中的“当前
   TPM”使用同一业务 T10 窗口的均值。“当前还可承接多少”默认使用前一完整自然日作为评估
   窗口，不投影到当天容量；对该窗口只声明 `previous_day`，不手算日期或时间戳。
   其他历史或闲时问题没有明确时间时，
   先引导用户给出开始时间、结束时间和时区，不自行定义“典型闲时”。
3. **获取最小证据**：只查询主场景得出结论必需的数据，不为丰富展示扩大查询。
   同一场景有多个模型时使用批量入口和默认 `--max-workers 4`；输出按输入顺序落盘，
   完成顺序不得改变候选顺序。扩容依赖按模型裁剪：只有正缺口模型进入 KConf/iSvc/资源
   子批次，其他模型不因无关配置或部署证据暂停。
4. **执行确定性计算**：使用对应场景的固定公式，将结果写入 Result。
5. **按条件补证据**：扩容仅在出现 TPM 缺口时读取 KConf 单实例容量；需要换算卡数和
   8 卡等效机器数时再读取 iSvc 单实例部署卡数。云上回收必须读取 KConf 单实例容量，
   需要理论节省卡数或 8 卡等效机器数时再读取 iSvc，并自动读取资源域最近 300 秒
   `online` 模型持有量进行上限校准；云上回收同时读取前一天模型成本并估算增量上云日
   成本。需要判断实际空闲物理机器时仍需额外资源拓扑证据。KConf 普通配置存在多个卡型时先
   引导用户明确承载卡型，不根据 iSvc 自动代选。
6. **检查停止条件**：证据不足或口径待确认时返回 `partial`，明确已知结果、缺失项和
   停止原因，不切换场景规避缺口。
7. **输出结论**：先回答用户最终问题，再列模型、provider、时间、单位、公式和来源。

### 生产容量分析 Workflow

生产请求 Schema、命令、批量隔离、逐模型恢复参数和报告结构统一见
[capacity-workflow.md](capacity-workflow.md)。本文件只保留容量口径、公式和证据深度定义。
生产入口仍只有 `capacity-analyze`；后续仅执行其 `next_action`。请求是控制参数，不是业务
证据，禁止填写解析结果、容量、流量、KConf 或 iSvc 数值。外部 SourceEvidence 内容变化后
必须以 `ARTIFACT_INVALID` 停止，`partial` 中的 `null` 不得解释为 0。

### 条件串联

```text
余量与扩容
→ 有 TPM 缺口时查 KConf，归一化优先、普通配置逐模型回退
→ 普通配置多卡型时等待用户明确承载卡型
→ KConf 成功证据换算实例数
→ 有 iSvc 证据时换算卡数和 8 卡等效机器数
→ 资源域初步校验对应等效机器的资源总量

云上容量回收
→ 前一日 public 在线容量/用量计算云上可承接的迁移 TPM
→ 成本域按同一模型和窗口查询前一天 billable_usage_cost
→ 按同一 KConf 选择规则补齐每个候选的单实例容量
→ KConf 单实例容量换算原始理论可回收内部实例，不按 iSvc 期望/就绪实例数封顶
→ 有 iSvc 证据时换算原始理论节省卡数
→ 资源域查询各模型当前 online 持有卡数，按模型与卡型封顶
→ 用校准后卡数换算最终 8 卡等效机器数
→ 用云上可承接迁移 TPM / 前一天云上流量 P90 × 前一天成本估算增量上云日成本
```

供给画像和流量画像是独立结果，不自动继续计算余量。历史窗口、闲时时段和多 provider
只是参数，不建立新的业务场景。

## 跨领域交接

### 与资源域

容量域输出：

- TPM 余量和缺口；
- 扩容所需实例数、GPU 卡数和 8 卡等效机器数。

资源域负责：

- 空闲整机和实际可用机器；
- GPU 型号、资源池和机器是否可分配；
- 对扩容所需资源总量进行初步校验。

资源域现有 Artifact 不包含完整的部署拓扑与调度约束，因此数量校验通过只表示资源总量
初步足够，不表示扩容实例已经能够实际落地。

云上容量回收的 `cards/machines` 路径查询资源域 `model-holdings`。iSvc 的单实例部署
卡数属于服务部署证据，由容量域先把理论可回收内部实例数换算为原始节省卡数；iSvc 的
期望/就绪实例数不参与计算或封顶。随后以资源域当前 300 秒 `online` 持有卡数为上限，
按模型和卡型校准最终理论释放卡数。结果仍不等价于资源域实际空闲卡或空闲物理机器。

### 与成本域

云上回收通过成本域 `cloud-daily-billing` Artifact 取得同一模型前一天的
`billable_usage_cost`，再按云上余量与前一天云上流量 P90 的比例估算增量上云日成本。
这是一项线性估算，单位沿用源表 `true_usage_cost`，不等于实际账单、合同报价或已经节省
的成本。成本域两个固定看板导航场景仍不提供结构化金额证据。

### 与 KConf、iSvc 和天问

- 容量域只消费 `kconf_single_config_data` 的只读成功 Artifact，不修改配置；
  模型、provider、priority、scene 或配置选择语义无法精确校验时不进行实例换算。
- iSvc 只消费 `status=success`、模型精确匹配、`pool=online` 且卡型规格唯一的 Artifact；
  保留模型、serviceName、期望/就绪实例、拓扑因子和查询时间证据。
- 天问固定导航链接只作为导航证据；未读取到结构化指标值时不猜值，不从链接参数推断
  model、provider、priority 或时间窗口。
- 具体 key、stage、字段路径和指标契约见
  [data-integration.md](data-integration.md)。

## 结果解释与异常

- 先给结论，再说明模型、provider、时间窗口、时区、在线口径和数据来源。
- 配置容量与实际用量分别标注，不相加、不混称。
- `status=partial` 时只报告已知分项、缺失项和停止原因。
- 即使脚本返回 `success`，涉及未明确的自定义历史或闲时口径时也不得输出最终结论。
- 查询失败时报告错误，不复用失败 Artifact，也不把旧验证值当成实时值。
- 相同模型、provider、时间窗口和口径优先复用成功 Artifact；用户要求刷新或参数变化时
  重新查询。
- Artifact 默认权限为 0600。终端只读取摘要；不要把完整明细一次性加载到模型上下文。
- 按主场景输出最小结果集：

| 主场景 | 必须输出 |
|---|---|
| 供给画像 | 最近 30 个连续共同完整分钟的整体配置容量均值、provider 均值和占比、窗口起止分钟及样本数 |
| 流量画像 | 同一 T10 的整体实际 TPM 均值、provider 均值和占比、窗口起止与样本数、每个 provider 的原始观测数/补零数/置信度，以及已有性能指标 |
| 余量与扩容 | 前一日内部部署容量 P90、内部流量 P90、可承接 TPM、目标新增 TPM、缺口及有证据支持的实例数、卡数和 8 卡等效机器数 |
| 云上容量回收 | 候选、前一日云上容量 P90、云上流量峰均值（P90）、云上可承接迁移 TPM、前一日模型可计费成本、估算增量上云日成本、原始理论可回收内部实例数和卡数、资源域当前 online 持有卡数，以及校准后的最终理论释放卡数和 8 卡等效机器数 |

- 后续追问使用：

```bash
python3.10 scripts/capacity.py inspect \
  /tmp/wanqing-query-headroom.json \
  --section summary
```

## 待补数据契约

| 项目 | 状态 | 影响 |
|---|---|---|
| Top P 静态名单更新机制与业务负责人 | 待确认 | 当前名单变更需要更新 Skill 并重新发布 |
| 单实例容量 KConf | 已接入 | 归一化未命中且普通配置多卡型时需用户明确承载卡型 |
| iSvc 在线已部署模型单实例卡数 API | 已接入 | 多活动规格不一致时仍需用户提供精确 serviceName |
| 天问性能指标 | 固定导航链接已接入，指标值待接入 | cache、TTFT、TPOT |
| 云上回收前一日模型成本 | 已接入 | 支持线性估算增量上云日成本；固定看板不作为证据，仍不判断成本是否更优 |
