# 模型名解析

本文件定义用户模型表达解析为真实精确模型名的公共契约。它只负责身份解析，不选择业务
领域、不计算 TPM、卡数或机器数，也不改变容量、资源、KConf 和 iSvc 的精确查询语义。
先由 [domain-classification.md](domain-classification.md) 选择主领域和场景，再由对应领域
Reference 确定候选锚点来源、过滤条件和时间窗口。

生产供给画像、流量画像和余量与扩容由 `workflow.py capacity-analyze` 在内部执行本文件
的候选发现、单/批量解析和 Artifact 交接；生产云上容量回收由
`cloud-reclaim-prepare` 内部执行。以下底层命令保留为 Workflow 实现契约和离线验证说明，
Agent 不在生产请求中自行串联。

## 目录

1. [适用条件](#适用条件)
2. [执行流程](#执行流程)
3. [候选 Artifact](#候选-artifact)
4. [匹配等级](#匹配等级)
5. [自动选择与停止条件](#自动选择与停止条件)
6. [执行入口](#执行入口)
7. [解析 Artifact 与交接](#解析-artifact-与交接)
8. [复用、跨源校验与异常](#复用跨源校验与异常)

## 适用条件

业务查询需要按模型过滤时，只有以下输入可直接进入领域精确查询：

- 同一问题中已经生成且仍适用的成功 `model-resolution` Artifact；
- 用户从本次候选列表中明确确认的精确名称，且已重新生成成功解析 Artifact。

没有“仅凭任意上游字段即可绕过解析”的通用受信入口。专用例外是云上回收
`scope=all/gpu`，以及 `scope=explicit` 中全部输入都精确命中版本化策略名单的请求：模型
来自带 `policy_source`、`policy_version` 和 SHA-256 父证据的
`wanqing.model_scope`，Workflow 为每个策略模型生成 `match_method=trusted_model_scope` 的
解析 Artifact。它只证明策略模型身份，不证明目标日有容量数据；目标日无行由后续批量
容量查询对该模型单独标记。策略外或非精确显式表达，以及普通 JSON 中的 `model` 字段，
不适用此例外。

`GLM 5`、`GLM5`、`GLM` 等用户表达本身不是精确证据。用户完全没有提供模型表达，且
场景又要求指定模型时，沿用领域 Reference 的模型门控，不运行无边界候选查询。

模型解析是查询前置步骤，不是新领域或业务场景。无需模型过滤的资源总览、空闲资源等
问题不触发它。

## 执行流程

```text
提取用户原始模型表达
→ 路由主领域和场景
→ 由领域 Reference 确定唯一锚点来源和场景过滤条件
→ 单模型运行领域 list-models；多模型运行领域 list-models-batch
→ 单模型运行 model_resolver.py resolve；多模型运行 resolve-batch
→ success：把 model-resolution Artifact 传给领域精确查询
→ partial：展示候选并等待用户确认，不运行指标查询
→ error：报告候选源或输入错误，不猜模型
```

候选发现只返回真实模型名称和最小身份信息，不计算业务指标。不得让模型自由拼 SQL、
扫描无限时间范围、从历史印象补候选，或同时让多个数据源各自模糊选择一次。

当前问题使用场景窗口发现候选：容量供给使用
`--window-relation current --lookback-seconds 2160`，流量画像使用
`--window-relation current --lookback-seconds 960`，两者都省略 `--from`/`--to`。
“当前”窗口未命中时，可用 `--lookback-seconds 86400` 将候选发现窗口扩大到
最近 24 小时。扩大窗口只用于验证标识，不改变最终指标窗口。历史问题使用用户指定窗口；
前一日余量和需要发现候选的显式模型回收使用前一完整自然日。容量候选命令必须显式传
`--window-relation previous_day` 并省略 `--from`/`--to`，由领域脚本使用平台
运行时钟解析；不得由 Agent 手算相对日期或 Unix 时间戳。策略范围和策略内精确显式
回收不运行容量候选发现；仍在同一前一日窗口执行逐模型容量查询。

场景与锚点来源是固定契约，由 `scripts/model_contract.py` 集中定义，解析器和下游加载器
都要校验：

| 目标领域/场景 | 必需 `anchor_source` |
|---|---|
| `capacity/supply-profile` | `capacity` |
| `capacity/traffic-profile` | `usage` |
| `capacity/headroom` | `capacity` |
| `capacity/cloud-reclaim` | `capacity` |
| `resource/model-holdings` | `resource_model_holdings` |

候选 Artifact 的 `query.anchor_source` 与
`handoffs.model_candidates.anchor_source` 必须相同，并符合上表；不能用流量表发现的候选
去执行余量或回收，也不能把容量候选跨到资源持有量场景。

## 候选 Artifact

容量和资源领域的 `list-models` 统一生成单模型候选 Artifact；`list-models-batch` 为每个
输入生成相同契约的独立候选 Artifact，并额外生成保持输入顺序的批量 Manifest：

```json
{
  "scenario": "model-candidates",
  "status": "success",
  "query": {
    "anchor_source": "usage",
    "model_input": "GLM 5",
    "window": {
      "relation": "custom",
      "from_epoch_seconds": 1785744000,
      "to_epoch_seconds": 1785830400,
      "resolution_source": "explicit"
    }
  },
  "handoffs": {
    "model_candidates": {
      "status": "ready",
      "anchor_source": "usage",
      "candidates": [
        {"model": "glm-5", "source": "usage"},
        {"model": "glm-5.1", "source": "usage"}
      ]
    }
  }
}
```

候选最多 20 个。候选源可以用输入比较键的前两个字符做宽泛家族兜底，但必须在 SQL
`LIMIT` 和本地截断前按以下顺序排序：比较键完全相等、比较键双向完整前缀、两字符家族
兜底；同一等级内再按最近出现时间和精确名称排序。这样 `qwen3.5 397b` 对
`qwen3.5-397b-a17b` 的完整前缀候选不会被更近出现的 `qwen-plus` 等宽泛家族候选挤出。
相同精确名称先去重；多个 provider、分钟或 Pod 行中的重复名称不构成歧义。候选为空仍
表示候选查询成功，由解析器输出 `model_not_found`。

## 匹配等级

解析器对用户输入和候选执行 Unicode NFKC、首尾去空白和大小写归一化；比较键继续删除
空白、`-` 和 `_`，但保留小数点、数字及其他可能具有业务含义的字符：

```text
GLM 5   → glm5
glm-5   → glm5
GLM 5.1 → glm5.1
glm-5-1 → glm51
```

按以下等级依次匹配，前一等级有结果时不降级：

| 等级 | `match_method` | 是否可自动选择 |
|---|---|---|
| 原始值完全相同 | `exact` | 唯一时可以 |
| 忽略大小写后完全相同 | `case_insensitive_exact` | 唯一时可以 |
| 忽略空白、`-`、`_` 后完全相同 | `separator_insensitive_exact` | 唯一时可以 |
| 比较键前缀或包含 | `prefix_suggestion` / `contains_suggestion` | 不可以 |
| 拼写相似度达到阈值 | `typo_suggestion` | 不可以 |

不得自动补版本、选择最新版本、取流量最大或最近出现的模型，也不得把 `glm-5-1` 自动
映射为 `glm-5.1`。拼写相似只用于候选排序。

## 自动选择与停止条件

前三个等级在最优等级只有一个真实候选时自动解析。若 `glm-5` 与 `glm_5` 同时存在，
两者对 `GLM 5` 都是分隔符等价候选，必须返回 `user_confirmation_required`。

前缀、包含或拼写相似即使只剩一个候选，也必须由用户确认。一次请求中有多个歧义模型
时合并为一次询问；用户确认后用 `--selected-model` 重新运行解析器。该参数必须是候选
Artifact 中的原始精确值，不能再做模糊匹配。

候选超过限制、候选源不可用、候选 Artifact 不是 success、用户没有确认歧义，或没有
找到候选时，不运行下游指标查询。

## 执行入口

容量候选和资源候选的命令由各领域 Reference 定义。取得候选 Artifact 后运行：

```bash
python3.10 scripts/model_resolver.py resolve \
  --input 'GLM 5' \
  --candidates-artifact /tmp/wanqing-model-candidates.json \
  --target-domain capacity \
  --target-scenario traffic-profile \
  --output /tmp/wanqing-model-resolution.json
```

同一领域、场景和候选过滤参数下有两个及以上模型表达时，领域脚本先生成批量候选
Manifest，再运行公共批量解析器：

```bash
python3.10 scripts/model_resolver.py resolve-batch \
  --candidates-manifest /tmp/wanqing-model-candidates-batch.json \
  --target-domain capacity \
  --target-scenario cloud-reclaim \
  --max-workers 4 \
  --output-dir /tmp/wanqing-model-resolutions \
  --output /tmp/wanqing-model-resolutions-batch.json
```

`resolve-batch` 不访问数据源，只对逐模型候选 Artifact 做有界并发本地解析。Manifest 和
逐模型 Artifact 按原始 `--model-input` 顺序输出。只在全部输入解析成功且精确模型互不重复
时生成 `handoffs.model_artifacts.status=ready`；任一输入歧义、失败或重复时整体为
`partial` 或 `error`，不运行下游指标查询。

若返回 `user_confirmation_required`，展示 `summary.candidates`。用户选择 `glm-5.1` 后：

```bash
python3.10 scripts/model_resolver.py resolve \
  --input 'GLM' \
  --candidates-artifact /tmp/wanqing-model-candidates.json \
  --target-domain capacity \
  --target-scenario traffic-profile \
  --selected-model glm-5.1 \
  --output /tmp/wanqing-model-resolution-confirmed.json
```

批量解析的歧义统一收集在 `summary.confirmations`。用户确认后复用原候选 Manifest，并按
其中的零基 `index` 传入一个或多个 `--selection INDEX=EXACT_MODEL`，不得把候选列表外的
名称作为确认值。

## 解析 Artifact 与交接

成功结果至少包含：

```json
{
  "domain": "common",
  "scenario": "model-resolution",
  "status": "success",
  "query": {
    "target_domain": "capacity",
    "target_scenario": "traffic-profile",
    "anchor_source": "usage"
  },
  "summary": {
    "decision": "resolved",
    "user_input": "GLM 5",
    "resolved_model": "glm-5",
    "match_method": "separator_insensitive_exact"
  },
  "handoffs": {
    "model": {
      "status": "ready",
      "model": "glm-5",
      "target_domain": "capacity",
      "target_scenario": "traffic-profile",
      "anchor_source": "usage"
    }
  }
}
```

只有 `status=success` 且 `handoffs.model.status=ready` 可交给领域脚本。回答中简要说明：
“已将用户输入的 GLM 5 解析为数据源精确模型名 `glm-5`”。不要把解析窗口中的历史出现
记录表述为当前业务指标。

领域查询不得把 `handoffs.model.model` 复制为裸字符串后丢失来源；生产命令使用
`--model-artifact` 传入本 Artifact，并由脚本校验 `domain`、`scenario`、`status`、
`target_domain`、`target_scenario` 和精确模型名。容量场景统一使用
`supply-profile`、`traffic-profile`、`headroom`、`cloud-reclaim`；资源模型持有量使用
`model-holdings`。解析器要求 `target_domain` 与候选 Artifact 的 `domain` 一致；Artifact
目标与当前命令不一致时停止，不跨领域或场景复用。唯一例外是固定云上容量回收 Workflow：
资源域 `model-holdings` 的内部参数 `--capacity-model-artifact` 可以消费已经验证的
`capacity/cloud-reclaim` 精确模型 Artifact，用于最终持有量校准。该交接不得改写模型名，
必须在证据中标记 `handoff_usage=cloud_reclaim_resource_alignment`，也不得由 Agent 手工
用于其他资源查询。

多模型候选发现和解析必须使用领域 `list-models-batch` 与公共 `resolve-batch`。候选批次只
解析一次窗口，以默认 `--max-workers 4` 并发执行原有单输入候选查询；公共解析器随后在
本地有界并发生成独立解析 Artifact。下游批量命令按该 Manifest 的用户模型顺序重复传入
独立的 `--model-artifact`。所有 Artifact 必须属于同一目标场景，模型不得重复；所有
Manifest 和逐模型 Artifact 保持输入顺序，即使并发任务的实际完成顺序不同也不得重排。

同时提供 `--model` 和 `--model-artifact` 时，两者必须完全一致。查询类命令只有在明确
提供完整 fixture 时才允许裸 `--model`，结果标记为 `fixture_unverified`。规范化证据
计算命令默认 `--evidence-mode production`：`headroom`、`traffic-profile` 必须提供
相应场景的 `--model-artifact`；`cloud-reclaim` 的每个 Top P 或用户显式候选必须提供
`model_artifact`。只有历史回放或 fixture 才显式使用 `--evidence-mode replay`，裸模型
结果标记为 `replay_unverified`，不得当成当前生产结论。KConf 生产规范化、iSvc 生产查询
和云上容量回收 Workflow 同样必须提供成功解析 Artifact。

下游结果的 `query.model_resolution` 保留解析证据。云上容量回收 Workflow 进一步要求
每个候选的容量、KConf 和 iSvc Artifact 都记录同一个模型解析 Artifact 的规范化绝对
路径；只验证模型字符串相同还不够。使用别的解析文件或目标场景不一致时 Workflow
立即停止，避免多阶段证据在无声中串错模型；证据身份正确但单个来源未命中时只将该模型
及整体标记为 `partial`，保留其他模型成功结果。

## 复用、跨源校验与异常

同一对话中模型、主领域和场景未改变时可复用成功解析 Artifact；用户切换模型、改变
模型范围或锚点来源时重新解析。指代“它”“这个模型”只有在上下文唯一时才复用。

解析成功后所有下游查询使用精确等值条件。容量、用量、资源、KConf 或 iSvc 中任一后续
来源没有同名记录时，返回该来源未命中或部分结果；不得在后续来源中重新模糊选择近似
名称。发现跨源名称不一致时，等待经过验证的映射；当前不建设自动跨域别名映射。

Top P 白名单、KConf 卡型选择、iSvc 多部署规格选择等业务门控仍然独立生效。模型解析
成功不能绕过白名单、配置唯一性、serviceName 选择或数据完整性要求。
