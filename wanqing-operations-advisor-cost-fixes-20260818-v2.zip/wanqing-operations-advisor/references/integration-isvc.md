# iSvc 接入

仅在请求需要 GPU 卡数、8 卡等效机器数或部署规格确认时读取。

## 目录

1. [接口](#接口)
2. [单模型与批量执行](#单模型与批量执行)
3. [模型门控与错误恢复](#模型门控与错误恢复)
4. [部署筛选](#部署筛选)
5. [拓扑计算](#拓扑计算)
6. [有效证据](#有效证据)

## 接口

`scripts/isvc.py` 是本契约的只读适配器。本节只定义接口、字段解析和有效证据条件；
何时调用以及 Artifact 如何参与余量、扩容或回收计算，以
[capacity-headroom.md](capacity-headroom.md) 或
[capacity-reclaim.md](capacity-reclaim.md) 为准。

使用只读接口：

```text
GET http://inference-service-deployer.internal/api/v1/isvcs
```

当前已验证链路不需要认证头。通过 `WANQING_ISVC_ENDPOINT` 或 `--endpoint` 覆盖地址；
响应必须满足 `code=0` 且 `data.info` 为数组。接口不提供有效的模型服务端筛选，脚本拉取
列表后在本地精确过滤，不把全部无关部署写入结果 Artifact。

## 单模型与批量执行

运行：

```bash
python3.10 scripts/isvc.py query-model \
  --model-artifact /tmp/wanqing-model-resolution.json \
  --pool online \
  --output /tmp/wanqing-isvc-glm-5.1.json
```

多个模型使用批量入口，只执行一次列表 API 请求：

```bash
python3.10 scripts/isvc.py query-models \
  --model-artifact /tmp/model-01.json \
  --model-artifact /tmp/model-02.json \
  --service-selection 'model-02=model-02-online' \
  --pool online \
  --max-workers 4 \
  --output-dir /tmp/wanqing-isvc-batch \
  --output /tmp/wanqing-isvc-batch.json
```

`--service-selection` 使用 `MODEL=SERVICE`，只在需要精确 KSN 时提供。批量入口复用同一
响应并有界并发规范化，逐模型 Artifact 和 Manifest 均保持输入顺序；单个模型缺失、
歧义或拓扑非法只使该模型和整体状态变为 `partial`。

## 模型门控与错误恢复

生产容量分析由 `capacity-analyze` 在内部执行以下硬门控；云上回收由其独立 Workflow
执行。底层命令或离线验证在调用前，从当前主场景已经成功的 `model-resolution` Artifact 取得文件路径，
并把该路径原样传给 `--model-artifact`。即使已知解析出的精确模型名，也不得把它复制成
`--model <名称>`；`--model` 只允许与完整 `--fixture` 同时使用，或与
`--model-artifact` 同时提供用于一致性校验。不存在成功 Artifact 时先返回模型发现与解析
流程，不发起 iSvc 请求。

命令返回 `error` 时，先读取本次输出 Artifact 的 `summary` 和 `errors`，再判断失败层级。
`summary.request_sent=false` 表示请求没有到达 iSvc，不能表述为 iSvc HTTP 接口失败；
`summary.failure_stage=model_validation` 且错误提示缺少 `--model-artifact` 时，如果当前场景
已有成功解析 Artifact，立即用上述固定命令修正并只重试一次，不等待用户再次追问。没有
可复用 Artifact 时回到模型解析步骤。只有 `request_sent=true` 后出现的网络、HTTP 或响应
校验错误，才能表述为 iSvc 接口或响应失败。终端错误摘要会回显有限条 `errors`，完整证据
仍以 Artifact 为准。

## 部署筛选

筛选和标识规则：

- 模型名依次读取 `spec.modelServiceName`、`pdSpec.modelServiceName`、annotation
  `serving.kwai.io/modelServiceName`、label `pod-inherits/modelServiceName`，并与
  `--model-artifact` 交接的精确模型名匹配；不在 iSvc 列表中
  二次模糊选择；
- 资源池精确使用 label `pod-inherits/llm-inference-pool=online`；不根据 KSN 名称猜在线；
- serviceName/KSN 依次读取 label `pod-inherits/serviceName`、annotation
  `serving.kwai.io/ksn`、`metadata.name`；
- 普通部署的期望实例数是 `spec.worker.replicas`，PD 部署的期望实例数是
  `pdSpec.replicas`；只把期望实例数大于 0 的部署作为当前规格证据；
- `status.readyReplicas` 只表示就绪实例数，不参与单实例卡数公式。与期望实例数不一致时
  保留拓扑结果并告警。

iSvc 的容量交接只暴露单实例总卡数和按卡型分项。`desired_instances` 和
`ready_instances` 保留在部署明细中说明状态，不进入单实例卡数交接；它们是否参与
业务计算统一由对应容量场景 Reference 定义。

## 拓扑计算

单实例卡数固定按以下字段计算：

```text
普通：
  cards_by_type[spec.worker.deviceType]
    = tensorParallelSize × pipelineParallelSize

PD 每个 role：
  role_cards
    = role.replicas × tensorParallelSize × pipelineParallelSize

  cards_by_type[role.spec.worker.deviceType]
    += role_cards

single_instance_gpu_cards = sum(cards_by_type)
```

当前已确认的 PD 公式不乘 `role.spec.worker.replicas`。脚本保留该字段作为证据；出现大于
1 的值时返回 `partial` 并停止容量交接，等待重新确认契约。TP、PP、role replicas 和
卡型必须来自 spec，缺失时不默认成 1，也不用 metadata label 补计算字段。

## 有效证据

同一模型存在多个活动 online 部署时，先分别校验每条匹配部署。至少有一条有效部署时，
忽略未通过拓扑校验的兄弟记录，把其 serviceName、iSvc name 和错误写入
`invalid_deployments` 与 `warnings`，继续使用有效部署判断单实例规格；所有匹配部署均非法时
返回 `invalid_deployment_data`，不产生卡数交接。有效部署的卡型分布完全相同才输出唯一
规格；分布不同时仍返回 `ambiguous_deployment_specs`，必须用 `--service-name` 精确选择，
不得因存在一条有效记录就自动取第一条。空结果、全部缩零、所有匹配部署均非法和 API
错误都不得产生卡数交接。Artifact 保留查询时间、响应摘要哈希、命中数量、有效/非法部署
数量、serviceName、期望/就绪实例数和完整计算因子。

不得用 GPU 型号默认卡数、资源域 `model-holdings` 或人工经验代替 iSvc 证据。
云上容量回收先用本 Artifact 把理论实例换算为原始理论卡数，再由资源域当前 `online`
持有卡数校准释放上限；资源域只负责上限，不能反推或替代单实例部署卡数。

iSvc 成功 Artifact 同样在 `query.model_resolution` 保留 `--model-artifact` 的完整解析
证据。云上容量回收 Workflow 复用 `isvc.artifact` 时要求它与候选的模型解析 Artifact
路径、模型、领域、场景和锚点全部一致；Workflow 自动查询 iSvc 时会自动满足该契约。
