# 流量画像

同时读取 [capacity.md](capacity.md)。只有用户要求 cache、TTFT 或 TPOT 时读取天问
接入文件 [integration-tianwen.md](integration-tianwen.md)；不加载 KConf、iSvc 或其他容量场景。

### 适用范围与证据

```text
确定 model、provider、priority=在线
→ 查询 public、internal 的实际分钟用量
→ 在水位线前预期自然分钟轴上逐 provider 补齐稀疏零流量分钟
→ 选择同一水位线终点前最近 10 个连续语义完整分钟
→ 每个 provider 分别计算 T10 算术平均，再计算整体实际 TPM 和占比
→ 保存每个 provider 的原始观测数、补零数和置信度
→ 有天问证据时补充 cache、TTFT、TPOT
→ 始终返回固定天问导航链接
→ 缺失性能指标值时返回已有 TPM 结果并标记 partial
```

模型解析 Artifact 的 `target_scenario=traffic-profile` 使 `query-headroom` 只查询用量，
不查询容量，也不因容量缺失阻断流量画像。发起当前流量查询时，使用
`--window-relation current --lookback-seconds 960`，由脚本以运行时钟为 `to`、回溯
16 分钟得到 `from`。窗口不足
T10 时返回 `partial`，不向前抓取更旧分钟凑数。

`query-headroom` 在 `handoffs.traffic_profile.profile_input` 生成可直接交给
`traffic-profile` 的规范化输入。`traffic-profile` 本身不直接查询 ClickHouse，输入必须提供：

- 顶层 `as_of_minute`：T10 最后一个完整分钟的起点，使用带时区的 ISO 8601 时间；
- 顶层 `priority=在线|离线`；回答“目前 TPM”默认使用 `在线`；
- 顶层 `tpm_basis=observed_10m_average` 和覆盖相同 T10 的 `window`；
- 每条 route 的 `route_type=cloud|self_deployed`、匹配的
  `provider=public|internal`、T10 平均 TPM，以及 `usage_evidence` 中的窗口分钟数、原始
  观测数、补零数和置信度；每个 provider 只能有一条聚合 route，不得重复拆行后双算；
- 可选的 cache 命中率、TTFT、TPOT；固定天问导航链接由脚本自动附加。

### 计算与停止条件

```text
T10
  = 水位线前最近 10 个连续语义完整自然分钟

provider_tpm
  = mean(provider_usage_tpm(t)), t ∈ T10

total_tpm
  = sum(provider_tpm)

provider_share
  = provider_tpm / total_tpm
  = null，当 total_tpm = 0
```

- 每分钟内先合并 provider 的全部在线 workload，再按稀疏写入契约为各 provider 缺行补 0；
  所有 provider 必须使用完全相同的 T10，不得拼接不同最新分钟，也不下钻云供应商或内部
  集群。
- 生产 CK 查询成功时不因单个缺行向前回退。单个 provider 只要 T10 内至少有一个原始观测，
  可按“原始观测 + 契约补零”输出；若整窗 10 个点全由补零构成，数值保留为 0 但结果标记
  `partial`，所有 provider 占比返回 `null`；不得断言“该 provider 无流量”或“其他
  provider 占 100%”。
- 所有 provider 合计为 0 时 TPM 合法为 0，各占比返回 `null`。查询失败、字段异常、未过
  水位线或 T10 不完整时仍返回 `partial`，不得补 0 掩盖错误。
- 当前 TPM 必须是 `tpm_basis=observed_10m_average`；旧 `observed` 单分钟基准仅为兼容，
  `configured_capacity` 只能解释配置分配。`current_usage_tpm`、`current_observed_tpm`、
  `latest_common_usage_minute` 和 `current_usage_by_provider` 继续保留为最新单分钟诊断字段，
  不得作为流量画像主结论。
- 24 小时均值或峰值可以另报，但不能替代当前 T10 均值。
- 性能指标缺失不影响 TPM 结果；返回已有指标、固定天问导航链接和缺失项。
