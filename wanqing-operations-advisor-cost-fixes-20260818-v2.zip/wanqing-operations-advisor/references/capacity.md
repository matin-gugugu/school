# 容量域路由与生产执行

本文件提供正常容量请求需要的公共规则。再读取且只读取当前场景文件；详细字段、历史兼容
和实现排障才读取 `capacity-core.md`、`capacity-workflow.md`。

## 场景

| 最终结果 | 场景文件 | 首入口 |
|---|---|---|
| 配置容量及 provider 分项 | [capacity-supply.md](capacity-supply.md) | `workflow.py capacity-analyze` |
| 实际 TPM、provider 占比、性能入口 | [capacity-traffic.md](capacity-traffic.md) | `workflow.py capacity-analyze` |
| 余量、承接、缺口、扩容换算 | [capacity-headroom.md](capacity-headroom.md) | `workflow.py capacity-analyze` |
| 迁云后的理论回收实例、卡数、机器数 | [capacity-reclaim.md](capacity-reclaim.md) | `workflow.py cloud-reclaim-prepare` |

## 公共执行规则

1. 生产只调用上表首入口并严格执行 `next_action`；不得手工调用候选发现、模型解析、
   `query-headroom`、KConf、iSvc 或资源命令拼装结果。
2. Workflow 负责模型解析。歧义时按返回的确认结构补充选择并重跑；不得猜模型版本。
3. 两个及以上模型保持一个批量请求和原始顺序。模型身份未确定时整批等待确认；进入查询后
   单项失败只影响该项。
4. 相对时间只传 `current` 或 `previous_day` 与 `Asia/Shanghai`，由脚本读取运行时钟；
   不手算当前日期或 Unix 时间戳。
5. 只执行请求深度需要的依赖。无正缺口不查 KConf/iSvc/资源；实例层不查 iSvc/资源。
6. 每次执行保存 JSON Artifact；终端只读取精简摘要或最终报告。复用时在当前请求重新校验
   状态、模型、provider、窗口、参数和证据绑定。
7. 严格执行 `outcome`、`reason_code` 和 `next_action`。`partial`、`NO_ROWS`、查询失败和
   等待确认不得互相替代；缺失值不得写成 0。
8. 配置容量、实际流量、理论实例/卡数/机器数和物理资源必须分别表述。

## 普通容量请求

供给、流量、余量与扩容使用严格请求 JSON：

```json
{
  "schema_version": "1.1",
  "tasks": [
    {
      "task_id": "capacity-redundancy",
      "scenario": "headroom"
    }
  ]
}
```

`scenario` 必须从 `supply-profile`、`traffic-profile`、`headroom` 中选择一个；
Schema 1.1 的 `headroom` 在模型未指明时使用版本化 X60→X40 全量候选名单，在 provider
未指明时使用 `providers=["internal"]` 和 `provider_scope=self_deployed`。指定模型时提供
`model_inputs`；指定候选范围时提供
`model_scope={"mode":"gpu_candidates","gpu_type":"X60|X40","top_p":N}`；两者不得
同时提供。显式 `providers` 只支持 `internal`、`public`，并完整覆盖默认值。

省略 `schema_version` 仍按 1.0 解析；Schema 1.0 继续要求非空 `model_inputs` 和 `providers`。
供给、流量场景在 1.1 中也继续要求这两个字段。
`headroom` 任务按需增加 `incremental_tpm`、`reserve_ratio`、
`detail_level=headroom|decision|instances|cards|resources` 和已有 `resource_artifact`。
供给默认当前 36 分钟回看，流量默认当前 16 分钟回看，余量默认前一完整自然日；具体口径
以场景文件为准。未知字段、重复模型、非法枚举或不兼容参数必须停止。

运行：

```bash
python3.10 scripts/workflow.py capacity-analyze \
  --input <request.json> \
  --output-dir <artifact-dir> \
  --output <result-or-checkpoint.json>
```

按 `next_action` 完成确认、一次 KConf 工具调用、`capacity-analyze-finalize` 或
`render-capacity-report`。只有 `outcome.request_state=NEEDS_INPUT` 才恢复 Checkpoint。

## 云上容量回收

从以下入口开始：

```bash
python3.10 scripts/workflow.py cloud-reclaim-prepare \
  --scope <explicit|gpu|all> \
  --detail-level <instances|cards|machines> \
  --output-dir <artifact-dir> \
  --output <result-or-checkpoint.json>
```

- `explicit` 按用户顺序重复传 `--model-input`。
- `gpu` 传 `--gpu X60|X40`，可选 `--top-p N`。
- `all` 不接受模型、卡型或 Top P，按版本化策略执行双卡型全量。
- `instances` 跳过 iSvc 和资源；`cards/machines` 由 Workflow 自动查询 iSvc 和当前
  `online` 模型持有量。Agent 不得手工调用资源域完成校准。

严格执行后续 `cloud-reclaim-finalize`、逐模型确认和 `render-report` 动作。旧
`cloud-reclaim*` 命令只保留内部装配、历史回放和兼容测试，不作为生产首入口。

## 按需深入

- 请求 Schema、Checkpoint、Evidence Index、报告投影或旧 Artifact：读取
  [capacity-workflow.md](capacity-workflow.md)。
- 数据字段、分钟完整性、provider 对齐或通用异常：读取
  [capacity-core.md](capacity-core.md)。
- 模型确认：读取 [model-resolution.md](model-resolution.md)。
- 仅在当前路径实际需要时读取对应 `integration-*.md`；不要一次加载所有集成文件。
