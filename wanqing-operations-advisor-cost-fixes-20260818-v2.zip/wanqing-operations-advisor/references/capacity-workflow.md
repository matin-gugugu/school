# 容量生产 Workflow 契约

本文件只定义生产编排、请求 Schema、批量隔离和可恢复暂停。公共口径见
[capacity-core.md](capacity-core.md)，场景公式由 [capacity.md](capacity.md) 路由，模型身份契约见 [model-resolution.md](model-resolution.md)，
KConf 与 iSvc 字段契约分别见 [integration-kconf.md](integration-kconf.md) 和
[integration-isvc.md](integration-isvc.md)。

## 目录

1. [入口](#入口)
2. [`capacity-analyze` 请求 Schema 1.0/1.1](#capacity-analyze-请求-schema-1011)
3. [身份与批量隔离](#身份与批量隔离)
4. [可恢复暂停](#可恢复暂停)
5. [报告契约](#报告契约)
6. [运行时对象](#运行时对象)
7. [代码边界](#代码边界)

## 入口

| 业务 | 首个命令 | 后续命令 |
|---|---|---|
| 供给、流量、余量与扩容 | `workflow.py capacity-analyze` | 严格执行 `next_action`：按需确认、一次 KConf 调用、`capacity-analyze-finalize`、`render-capacity-report` |
| 云上容量回收 | `workflow.py cloud-reclaim-prepare` | 严格执行 `next_action`：按需确认、一次 KConf 调用、`cloud-reclaim-finalize`、`render-report` |

Agent 不直接串联 `list-models`、`resolve`、`query-headroom`、KConf、iSvc 或资源命令。

## `capacity-analyze` 请求 Schema 1.0/1.1

顶层只允许 `schema_version` 和 `tasks`；`schema_version` 省略时按 `1.0` 解析，显式提供时
只允许 `1.0` 或 `1.1`。未知字段立即返回 `INVALID_INPUT`，相近拼写会给出建议，禁止静默
忽略。单次请求最多 20 个任务、单任务归一化后最多 20 个模型、全部任务合计最多 100 个
模型；超限必须拆成多个独立请求。数字字段必须是有限数字，不接受 `NaN` 或正负无穷。

每个任务的公共字段：

| 字段 | 必需 | 说明 |
|---|---|---|
| `task_id` | 是 | 请求内唯一，最多 64 个安全字符 |
| `scenario` | 是 | `supply-profile`、`traffic-profile`、`headroom` |
| `model_inputs` | 条件 | 非空、无重复的用户原始模型表达数组；1.1 未指定范围的 `headroom` 可省略 |
| `model_scope` | 1.1 条件 | `default_candidates`、`gpu_candidates` 或 `explicit_models`；只用于 `headroom` |
| `providers` | 条件 | `public`、`internal` 或二者组合；1.1 `headroom` 可省略并默认 internal |
| `provider_scope` | 否 | 由 providers 唯一推导；提供时必须一致 |
| `priority` | 否 | 当前只允许 `在线` |
| `timezone` | 否 | 默认 `Asia/Shanghai` |
| `window_relation` | 否 | 场景默认值；相对窗口不得手算时间戳 |
| `lookback_seconds`、`from`、`to` | 条件 | 与窗口关系互斥 |
| `selected_models` | 否 | 模型歧义恢复，键为 `model_inputs` 的零基下标 |
| `service_selections` | 否 | iSvc 多规格恢复，键为 `model_inputs` 的零基下标；只用于 `cards/resources` |

`selected_models` 和 `service_selections` 的下标键只能使用规范十进制字符串 `0`、`1`、
`2`……，不接受 `01` 等前导零别名，避免两个 JSON key 归一化到同一模型位置。

`headroom` 还允许 `incremental_tpm`、`reserve_ratio`、`detail_level` 和
`resource_artifact`。其他场景出现这些字段会拒绝请求。

Schema 1.0 继续要求 `model_inputs` 和 `providers`。Schema 1.1 的 `headroom` 规则如下：

- 没有 `model_inputs` 和 `model_scope`：使用版本化双卡型全量候选名单，记录
  `selection_source=skill_default`；
- `model_scope.mode=gpu_candidates`：必须给 `gpu_type=X60|X40`，`top_p` 可选；
- 显式 `model_inputs`：只评估用户模型表达，并走候选发现/歧义确认；
- `model_inputs` 与 default/gpu 候选范围互斥；
- 没有 `providers`：使用 `internal/self_deployed` 并记录
  `provider_selection_source=skill_default`；显式 providers 完整覆盖默认值。

```json
{
  "schema_version": "1.1",
  "tasks": [
    {
      "task_id": "capacity-redundancy",
      "scenario": "headroom"
    }
  ]
}
```

`detail_level` 是完整性边界：`headroom` 只需余量；`decision` 只需余量、缺口和承接结论；
`instances` 再需要 KConf；`cards` 再需要 iSvc；`resources` 再需要资源证据。Workflow 的
canonical `outcome` 必须满足该深度，不得把不完整 SourceEvidence 提升为完整结果。依赖深度按模型判断，不按整个任务判断：同一任务只有存在正 TPM 缺口的
模型进入 KConf 子批次，只有这些模型按请求深度继续进入 iSvc 和资源查询；最终按原始模型
下标合并，余量已足的模型保留原容量结果。

云上回收使用 CLI `--detail-level instances|cards|machines`，默认 `machines` 以兼容旧调用。
三条路径都在容量/用量之后并行取得前一日成本证据，分别是“容量/用量 → 成本 → KConf”、
“容量/用量 → 成本 → KConf → iSvc → 资源域当前持有量校准”和“容量/用量 → 成本 →
KConf → iSvc → 资源域当前持有量校准 → 8 卡等效换算”。
`instances` 不查询 iSvc 或资源域，也不接受 `--service-selection`。

## 身份与批量隔离

- 用户显式模型表达通过场景锚点发现和解析；出现歧义时整批停在确认阶段，因为模型身份
  尚未确定。Schema 1.1 的 default/gpu 候选范围直接从版本化受信 `model_scope` 生成逐模型
  解析 Artifact，不再要求目标日前一日容量表重复证明策略范围中的模型身份。
- `cloud-reclaim-prepare --scope all/gpu` 的模型集合来自版本化 Top-P 策略，是受信的
  `wanqing.model_scope`，不依赖目标日前一日容量表再次证明模型身份。
- 进入容量查询后，每个模型独立记录 SourceEvidence 状态。某个模型无行、证据不全或规范化
  失败，只影响该项和批量结果；其他模型继续计算，保持输入顺序。
- 云上回收按容量交接状态裁剪依赖：只有云上容量 handoff 为 `ready` 的模型进入成本、
  iSvc、资源持有量和 KConf 子批次。无容量证据的模型保留在原位置并最终输出 `partial`，但不得
  触发无关部署歧义、配置或资源查询，也不得阻塞其他候选。合并 Manifest 记录
  eligible/skipped 数量。
- 外部数据进入 Workflow 时验证请求语义、模型身份、provider、窗口以及 KConf/iSvc 选择，
  并生成与文件位置无关的 `evidence_id`。finalize 对新格式只验证 ID、状态和内容摘要，不再
  重建已接受的基础查询结果；旧 Artifact 走兼容校验。兼容路径不得替代 canonical ID。
- 普通容量 Workflow 必须把 provider 集合、provider scope、priority、窗口关系、时区、
  detail level、预留比例和新增 TPM 与容量证据逐项比对；文件路径和模型名相同但查询语义
  不同仍按 `ARTIFACT_INVALID` 停止。两条 Workflow 都保存规范化 Request，并把外部证据
  绑定到 Result 的 `evidence_index`。
- 禁止因单项失败退化为逐模型串行查询或临时脚本。

## 可恢复暂停

模型歧义返回 `MODEL_CONFIRMATION_REQUIRED`，在 `selected_models` 中按输入下标补充选择并
重跑 analyze。

iSvc 同一模型存在多规格时返回 `ISVC_CONFIRMATION_REQUIRED`：

- 普通容量请求在 `tasks[].service_selections` 中补充 `{模型输入下标: serviceName}`；
- 云上回收重跑 prepare，并重复传 `--service-selection MODEL=SERVICE`。

KConf 普通配置存在多卡型时返回 `DEVICE_TYPE_REQUIRED`。使用同一 plan 和原始 KConf 工具
返回重跑 finalize，并为每个模型重复传：

```bash
--device-type-selection MODEL=DEVICE
```

兼容参数 `--device-type` 仅适用于确认整批模型都使用同一卡型；不得与逐模型选择同时使用。

## 报告契约

`render-capacity-report` 输出稳定的逐任务、逐模型结构。每个模型包含：

- `requested_result_complete`：该模型是否完整满足请求深度；
- `missing_requested_metrics`：请求需要但仍缺失的指标；
- `evidence_status`：Result 边界已经验证的主 SourceEvidence 状态；
- `metrics` 与 `quotable_metrics`：规范字段及允许面向用户引用的字段；
- `evidence_ids`：canonical SourceEvidence 引用；
- `evidence_artifacts`：兼容期保留的底层路径。

Result 边界从已验证 SourceEvidence 一次性生成不可变 `report_projection`。报告命令只校验
Result 的 canonical 状态与该投影一致，再完成展示，不重新读取和重算整条中间 Artifact
链。只有证据完整且对应字段存在时才进入 `quotable_metrics`；因此缺 KConf 的 partial 行
仍可引用完整基础余量，但不能引用缺失的实例或卡数。缺失值不得解释为 0。

容量报告投影 Schema 2.1 中，`headroom` 额外提供 `redundancy_overview`，按
`usable_headroom_tpm` 降序列出正余量
模型，并分别列出零余量和证据不完整模型；`scan_complete` 只有全部模型证据完整时为 true。

云上回收 finalize 在 Result 边界完成候选、实例、卡数和机器数校验并生成
`report_projection`。`render-report` 只做纯投影；Result 的 summary、状态或 reason code 与
固定投影不一致时返回 `ARTIFACT_INVALID`。

## 运行时对象

容量 Workflow 只维护四类持久对象：

| 对象 | 何时存在 | 内容 |
|---|---|---|
| Request | 始终 | 规范化模型表达、provider、窗口、场景和计算参数 |
| SourceEvidence | 外部数据进入系统时 | 与路径无关的 `evidence_id`、`source`、`query_identity`、`state`、`minimal_payload`、`content_digest` |
| Checkpoint | 仅 `outcome.request_state=NEEDS_INPUT` | 当前阶段、原因和唯一恢复动作 |
| Result | 完成或部分完成时 | 业务结果、canonical `outcome`、Evidence 引用和固定报告投影 |

`evidence_id` 只由 `source + content_digest` 生成，不包含文件路径；`query_identity`、`state` 和
`minimal_payload` 用于解释与业务校验，不再各自参与另一套摘要或状态机。

`outcome.evidence_state` 使用 `OK | PARTIAL | NO_DATA | FAILED`；
`outcome.request_state` 使用 `COMPLETE | PARTIAL | NEEDS_INPUT | FAILED`。顶层
`status/complete/reason_code/next_action` 只由该对象派生。兼容期仍可输出旧
`provenance.parents` 和阶段文件，但只把它们视为 lineage。Request、批量 Manifest、Plan、
组装输入和最终报告不进入 `evidence_index`，业务层不得对它们重复建立证据状态。

## 代码边界

- `workflow.py`：生产 CLI 薄路由；按命令只加载普通容量、云上回收或旧兼容实现中的一个；
- `legacy_workflow.py`：只保留原 `cloud-reclaim*` 命令的参数和输出兼容适配，仅在旧命令
  实际执行时延迟加载，不进入普通容量或现代回收；
- `reclaim_assembly.py`：新旧回收共用的候选证据校验、规范化、基础回收计算调用和卡型分组汇总；
- `workflow_errors.py`：新旧入口共用的稳定公开异常类型；
- `capacity_workflow_contract.py`：Schema、枚举、选择参数解析；
- `workflow_core.py`：canonical Outcome、Evidence Index、Checkpoint 及兼容投影；
- `capacity_evidence_contract.py`：普通容量请求与逐模型容量证据的语义绑定；
- `capacity_pipeline.py`：普通容量状态机与证据装配；
- `reclaim_pipeline.py`：云上回收状态机；
- `capacity_query.py`：容量候选、查询窗口、SQL、完整分钟、稀疏流量和批量证据规整；
- `capacity_metrics.py`：P90、余量、扩容、回收、流量画像和持有量封顶的确定性计算；
- `cost.py` / `cost_query.py` / `cost_metrics.py`：成本域 CLI、前一天账单查询与十进制估算；
- `capacity_report.py`：稳定报告投影；
- `capacity_workflow_support.py`：两条 Workflow 共用的执行、Evidence ID 绑定、lineage 兼容、
  KConf/iSvc 批量命令构造和 KConf 检查点校验；
- `capacity.py`：兼容的容量 CLI 与 Artifact 门面；`kconf.py`、`isvc.py`：外部证据适配器。

两条 Workflow 共用请求与逐模型选择契约；业务公式仍只在领域脚本实现，不复制到编排层。
