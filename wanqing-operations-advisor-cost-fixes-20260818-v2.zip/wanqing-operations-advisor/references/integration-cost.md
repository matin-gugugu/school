# 云上容量回收的成本接入

本文件只定义 `cloud-reclaim-prepare` 的成本域辅助证据。成本构成、上云原因和自部署运营
系数仍按 [cost.md](cost.md) 返回固定看板，不作为结构化金额证据。

## 查询契约

Workflow 在容量域确认模型身份并得到成功的前一日 `public` 在线 headroom Artifact 后，
调用一次 `scripts/cost.py query-cloud-daily-cost`。成本命令只接受同批次、同顺序的：

- `--capacity-model-artifact`：目标为 `capacity/cloud-reclaim` 的精确模型身份；
- `--headroom-artifact`：同模型、同身份文件、`public/cloud/在线`、前一完整自然日的成功
  `query-headroom` Artifact。

成本域复用 headroom 中已经解析的 `from/to/timezone`，不自行重算日期、不再次模糊解析模型。
一个批次只执行一条带精确模型 `IN` 的 SQL。数据表为
`wanqing_data.ai_infra_billing_project_usage_bill_day`，时间条件使用
`data_time >= 前一日零点毫秒 AND data_time < 当日零点毫秒`，业务时区固定来自容量证据。

在线场景口径为 `Sheddable → 离线场景`、其他值 → `在线场景`。每个模型的
`billable_usage_cost` 严格按下列 OR 口径汇总：

```text
x_ks_model_demotion_type IN (Capacity, Load, Proactive, Token)
OR provider = 公共云
```

同时排除包含 `langbridge`、`flicker`、`private`、`kat`、`dataagent` 的模型，以及
`kimi-k2-instruct-0905`、`gemma-3-27b-it`。过滤规则、模型顺序、数据日、行数和最新数据
时间都写入 `cost/cloud-daily-billing` Artifact。无返回行表示证据缺失，金额保持 `null`，
不得记为 0。成本单位标记为 `source_true_usage_cost_unit`；除非源表契约另行确认，不得称为元。

## 估算公式

finalize 从容量计算结果读取最终的 `cloud_reclaimable_tpm` 和
`previous_day_cloud_traffic_p90_tpm`，再消费成本 Artifact：

```text
cloud_reclaim_to_traffic_ratio
  = cloud_reclaimable_tpm / previous_day_cloud_traffic_p90_tpm

estimated_incremental_cloud_daily_cost
  = cloud_reclaim_to_traffic_ratio * previous_day_billable_usage_cost

estimated_projected_cloud_daily_cost
  = previous_day_billable_usage_cost + estimated_incremental_cloud_daily_cost
```

这里“上云成本”规范输出为 `estimated_incremental_cloud_daily_cost`，表示按前一天流量 P90
线性放大得到的增量日成本估算；`estimated_projected_cloud_daily_cost` 仅作为迁流后的总日
成本估算。计算内部使用十进制定点语义。流量 P90 小于等于 0、成本无行或容量证据缺失时，
对应估算为 `null` 并返回 `partial`；不得产生无穷值或用其他模型补齐。

成本查询失败只降低成本维度完整性，不抹掉容量、KConf、iSvc 或资源持有量结果。总成本只
在所有候选估算完整时输出；否则总量为 `null`，另保留完整候选的 `partial_sum`。该估算不
读取合同单价、cache 计价、最小计费单位或计费周期，因此不能用于判断“是否成本更优”，
也不能表述为已经发生的账单或已经节省的成本。
