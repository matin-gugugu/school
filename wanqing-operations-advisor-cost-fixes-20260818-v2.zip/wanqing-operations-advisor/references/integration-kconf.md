# KConf 接入

仅在 Workflow 确认正 TPM 缺口需要实例换算，或云上回收需要理论实例换算时读取。

## 目录

1. [工具与数据契约](#工具与数据契约)
2. [配置选择](#配置选择)
3. [单模型与批量执行](#单模型与批量执行)
4. [最小证据](#最小证据)
5. [失败与恢复](#失败与恢复)

## 工具与数据契约

容量域使用 Agent 运行时暴露的只读工具 `kconf_single_config_data`。Skill
只定义何时调用、如何校验和如何交接证据，不负责注册工具；运行时工具列表中不存在
该工具时不得模拟调用。工具参数以 Agent 注册的 Schema 为唯一事实源；当前使用
`key` 和 `stage`，不猜测 `stage` 默认值或环境别名。

## 配置选择

已确认单实例容量使用 `key=cloud.llmdevops.stability-capacity-by-instance`、
`stage=production`。成功返回必须满足 `result=1`、`message=success`，且返回的
`data.key` 和 `data.stage` 与请求一致。配置版本位于 `data.version`，普通配置位于
`data.data.capacities[]`，归一化配置位于 `data.data.normalizedCapacities[]`。

单实例在线容量固定按以下顺序选择：

1. 用精确 `modelServiceName` 和 `scene=online` 查找 `normalizedCapacities`；唯一
   命中且 `tpm>0` 时直接使用。
2. 归一化配置未命中时，再用相同模型和 scene 查找 `capacities`。
3. 普通配置唯一命中时使用其 `tpm`；多个 `deviceType` 时返回
   `device_type_required`，展示卡型及对应 TPM，引导用户明确承载卡型。
4. 用户选择后按模型、`scene=online`、`deviceType` 精确匹配。不根据 iSvc
   当前卡型替用户做选择；不取第一条，不求和、平均、最大或最小值。

只使用选中行的 `tpm`。不用 `defaultAppTPM`代替；即使 `pdSeparated=true`，
也不自行将 `inputTPM` 和 `outputTPM` 相加或替代 `tpm`。不用 offline 配置兜底，
不在 KConf 选择层对模型名做别名、前缀或模糊匹配。用户模型表达必须先按
[model-resolution.md](model-resolution.md) 解析；本层只消费解析后的精确名称。

## 单模型与批量执行

将 Agent 工具的 JSON 返回保存为临时输入后运行：

```bash
python3.10 scripts/kconf.py normalize \
  --input /tmp/wanqing-kconf-tool-result.json \
  --model-artifact /tmp/wanqing-model-resolution.json \
  --key cloud.llmdevops.stability-capacity-by-instance \
  --stage production \
  --output /tmp/wanqing-kconf-glm-5.1.json
```

多个模型使用相同 `key + stage` 时，只执行 `cloud-reclaim-prepare` Manifest 中的唯一
KConf `next_action`，把同一份原始结果交给 `cloud-reclaim-finalize`。后者内部调用以下
批量规范化入口；不要在 Agent 外部重复编排：

```bash
python3.10 scripts/kconf.py normalize-batch \
  --input /tmp/wanqing-kconf-tool-result.json \
  --model-artifact /tmp/model-01.json \
  --model-artifact /tmp/model-02.json \
  --key cloud.llmdevops.stability-capacity-by-instance \
  --stage production \
  --max-workers 4 \
  --output-dir /tmp/wanqing-kconf-batch \
  --output /tmp/wanqing-kconf-batch.json
```

批量入口只读取一次原始配置，并为每个模型生成独立最小 Artifact。某模型未命中或需要
选择卡型时只将该模型和批量 Manifest 标为 `partial`，其他成功 Artifact 继续可用；输出
顺序与 `--model-artifact` 顺序一致。

云上回收的 prepare 先按云上容量 handoff 裁剪依赖，只把 `ready` 模型传给
`normalize-batch`。容量证据不完整的模型不查询 KConf；finalize 为它生成显式的
`dependency_skipped_upstream_evidence_missing` 占位 Artifact，再按原候选顺序合并。占位项
只能维持该模型及总体 `partial`，不能被解释为 KConf 无配置或单实例容量为 0。

普通配置返回 `device_type_required` 时，不存在可供容量计算消费的 handoff。用户
明确卡型后复用同一份工具返回和配置版本，增加 `--device-type <GPU卡型>`
重新运行规范化；多个模型同时需要卡型时合并为一次用户询问。

## 最小证据

工具成功结果必须转为下列最小 Artifact，不把整份无关配置写入容量结果：

```json
{
  "domain": "capacity",
  "scenario": "kconf-single-instance-capacity",
  "status": "success",
  "generated_at": "2026-08-04T15:30:00+08:00",
  "query": {
    "source_tool": "kconf_single_config_data",
    "model_resolution": {
      "mode": "verified_artifact",
      "artifact": "/tmp/wanqing-model-resolution.json",
      "resolved_model": "glm-5.1",
      "target_domain": "capacity",
      "target_scenario": "cloud-reclaim",
      "anchor_source": "capacity"
    }
  },
  "handoffs": {
    "capacity": {
      "status": "ready",
      "model": "glm-5.1",
      "provider": "internal",
      "priority": "在线",
      "scene": "online",
      "capacity_source": "normalizedCapacities",
      "device_type": null,
      "selection_rule": "exact_model_online_normalized_first",
      "key": "cloud.llmdevops.stability-capacity-by-instance",
      "stage": "production",
      "field_path": "data.data.normalizedCapacities[modelServiceName=glm-5.1,scene=online].tpm",
      "single_instance_capacity_tpm": 1000000,
      "version": 302,
      "retrieved_at": "2026-08-04T15:30:00+08:00"
    }
  }
}
```

`scripts/kconf.py` 不调用 Agent 工具；它只解析工具返回、选择配置并生成最小
Artifact，不保存完整 KConf 配置。成功 handoff 要求模型精确匹配、
`provider=internal`、`priority=在线`、`scene=online`、容量是大于 0 的有限数字，
且选择来源、卡型、key、stage、字段路径、版本和带时区查询时间完整。生产余量与扩容由
`capacity-analyze-finalize` 在内部通过 `headroom --kconf-artifact` 传入；直接使用
`query-headroom --kconf-artifact` 或 `headroom --kconf-artifact` 只作为 Workflow 内部
执行和离线验证入口。云上容量回收 Workflow 在候选的 `kconf.artifact` 引用。

云上容量回收 Workflow 使用 KConf Artifact 时，`query.model_resolution` 必须指向候选
的同一个 `model_artifact`；模型名相同但解析 Artifact 不同仍视为证据链不闭合。余量与
扩容等其他场景的目标场景值按其自己的模型解析 Artifact 记录。

## 失败与恢复

工具不可用或共享返回失败时不生成成功 Artifact，按
[capacity-headroom.md](capacity-headroom.md) 或
[capacity-reclaim.md](capacity-reclaim.md) 的停止
条件返回部分结果。key/stage 不一致、字段缺失、值非正数或配置语义未确认时不得生成
成功 Artifact；批量中只有单个模型未命中时标记该模型和整体 `partial`。模型解析路径、
模型、领域、场景或锚点不一致属于证据链错误，仍使执行返回 `error`，不得降级混算。
真实返回结构、归一化优先和普通多卡型回退已通过脱敏测试和已提供的线上样本
验证。字段参与哪个容量场景及其计算方式由对应容量场景 Reference 定义。

批量普通配置如果不同模型需要不同卡型，使用
`kconf.py normalize-batch --device-type-selection MODEL=DEVICE`，可重复传入。
`capacity-analyze-finalize` 和 `cloud-reclaim-finalize` 暴露相同参数并校验模型必须属于
当前 plan。兼容的整批 `--device-type` 不能和逐模型选择同时使用。
