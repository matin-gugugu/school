# 天问接入

仅在流量画像需要 cache、TTFT 或 TPOT 时读取。

cache、TTFT、TPOT 等性能指标统一返回以下固定天问导航链接：

```text
https://tianwen.corp.kuaishou.com/dashboard/50030/detail?instructionId=5530&activeTab=12
```

`scripts/capacity.py traffic-profile` 始终把该链接写入摘要的 `tianwen_links`。Agent 回答
性能指标相关问题时也返回该链接。链接只作为导航入口，不代表已经读取到指标值；未取得
结构化指标证据时，cache、TTFT 和 TPOT 保持缺失并标记 `partial`，不得从页面名称、截图
或历史记忆猜数。

后续接入结构化性能指标时，流量画像默认把 cache 命中率、TTFT 和 TPOT 对齐到 TPM 的
同一 T10 业务窗口；若底层指标不支持该窗口或聚合方式尚未确认，保持 `partial` 并明确
说明时间口径不一致，不得把单分钟或看板默认窗口混入 T10 结论。

不要根据 model、provider 或 priority 修改链接参数，也不要自行构造其他看板 URL。用户
无权访问时，仍可返回该固定入口并说明需要申请天问看板权限。

性能数值查询仍需确认：

- cache 命中率、TTFT、TPOT 的指标名、单位、聚合方式和默认时间窗口；
- 指标能否按 model、provider 和 priority 拆分；
- 可供 Agent 读取结构化指标值的查询接口及权限契约。
