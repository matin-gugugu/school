# 资源域

本文件集中记录资源域的数据契约、场景口径和结果解释。仅当用户问题属于资源域时读取。

## 目录

1. [数据源与字段](#数据源与字段)
2. [GPU 和资源池映射](#gpu-和资源池映射)
3. [场景路由](#场景路由)
4. [资源总览](#资源总览)
5. [线上空闲资源](#线上空闲资源)
6. [指定资源池](#指定资源池)
7. [系统软件开发机](#系统软件开发机)
8. [内部模型持有机器](#内部模型持有机器)
9. [实际可用资源](#实际可用资源)
10. [结果解释与异常](#结果解释与异常)
11. [待补数据契约](#待补数据契约)

## 数据源与字段

- 机器资源表：`kce_server.machine_snapshot_prod`
- 内部模型 Pod 表：`kce_server.kce_ai_infra_pods`
- 默认集群：`kce-ai-infra-bjzey1-hb1az3`
- 机器资源表默认快照搜索窗口：最近 3600 秒
- 内部模型 Pod 表默认查询窗口：最近 300 秒
- 每台机器取最新记录：`ORDER BY timestamp DESC LIMIT 1 BY name`

旧“万擎资源运营视图”（dashboardId=2115499、datasetId=256338）只作为口径来源。

| 字段 | 含义 |
|---|---|
| `name` | 机器唯一标识 |
| `gpuModel` | GPU 型号 |
| `suitName` | 机器套型 |
| `nGpuAllocatable` | 可分配 GPU 卡数 |
| `nGpuRequest` | 已申请 GPU 卡数 |
| `resourcePoolLabelKeys` | 资源池标签数组 |
| `clusterName` | 集群名称 |
| `timestamp` | Unix 秒时间戳 |

单机余量口径：

```text
gpu_remaining = greatest(nGpuAllocatable - nGpuRequest, 0)
```

内部模型 Pod 表使用以下字段：

| 字段 | 含义 |
|---|---|
| `modelServiceName` | 内部模型服务名 |
| `GPUType` | GPU 类型，如 `X60` 或 `X60卡` |
| `labels` | Pod 标签数组 |
| `gpuRequestNum` | 请求的 GPU 卡数 |
| `resourcePool` | 资源池 |
| `clusterName` | 集群名称 |
| `timestamp` | Unix 秒时间戳 |

## GPU 和资源池映射

| 展示类型 | `gpuModel` | `suitName` 参考 | 单机卡数 |
|---|---|---|---:|
| X60 | `X60*8` | GE131 | 8 |
| X50 | `X50*8` | GE121、GE151 | 8 |
| X40 | `X40*8` | GE103、GE117 | 8 |

已确认资源池：

- 线上空闲范围：`wanqing-common`、`wanqing-multi-machine`、`wanqing-buffer`
- QA 持有：`wanqing-qa`
- 系统软件开发机：`wanqing-test`
- 资源总览默认排除：`langbridge-training`、`wanqing-fix`

脚本只接受 X60、X50、X40 白名单值。资源池参数只允许字母、数字、点、下划线、冒号和连字符；不得让模型传入任意 SQL。

## 场景路由

统一运行：

```bash
python3.10 scripts/resource.py SCENARIO [OPTIONS]
```

| 用户问题 | `SCENARIO` |
|---|---|
| GPU 总量、用量、余量、机器数 | `overview` |
| 线上空闲、去碎片、可拼整机 | `idle` |
| 测试池、QA 池、指定资源池 | `pool` |
| 系统软件开发机 | `system-dev` |
| 实际可用 X60/X50/X40 | `available` |
| 内部开源模型或上线验证中模型持有多少机器 | `model-holdings` |
| 读取已有查询结果 | `inspect` |

`list-models` 和 `list-models-batch` 是 `model-holdings` 的查询前置命令，不是新的资源
业务场景。它们只按持有量范围发现真实 `modelServiceName` 候选；公共匹配规则和解析 Artifact 见
[model-resolution.md](model-resolution.md)。

### 资源占用量模型门控

用户询问资源占用量、模型持有 GPU 或模型持有机器时：

1. 完全没有提供模型表达时，不运行 `list-models` 或 `model-holdings`，引导用户指定要查
   的模型，并同时返回[万擎资源看板](https://kwaibi.corp.kuaishou.com/pc/dashboard/preview?dashboardId=2115499&sheetId=273865)。
2. 已提供 `GLM 5` 等模型表达，但没有成功模型解析 Artifact 时，单模型先运行
   `list-models` 再运行 `resolve`；两个及以上模型必须运行 `list-models-batch` 和
   `resolve-batch`。不得要求用户预先知道内部连字符和大小写格式。
3. 解析唯一成功后，把成功 Artifact 通过 `model-holdings --model-artifact` 交给查询；
   脚本读取其中的精确 `modelServiceName`。
4. 返回多个候选时一次展示并等待用户确认；确认后重新生成成功解析 Artifact。

建议回复：

```text
请指定需要查询的模型名称或常用表达；系统会先核对真实 modelServiceName。
你也可以先查看万擎资源看板：
https://kwaibi.corp.kuaishou.com/pc/dashboard/preview?dashboardId=2115499&sheetId=273865
```

## 资源总览

运行示例：

```bash
python3.10 scripts/resource.py overview \
  --gpu X60 \
  --gpu X50 \
  --output /tmp/wanqing-resource-overview.json
```

默认查询 X60、X50、X40，并排除 `langbridge-training` 和 `wanqing-fix`。用户明确要求全部资源池时增加 `--include-all-pools`。

每个 GPU 型号展示：

- 物理机器数
- GPU 总卡数、已用卡数、余卡数
- 按 8 卡折算的等效机器数

机器数和卡数都要保留。若机器并非全部 8 卡，不得用卡数除以 8 代替物理机器数。

## 线上空闲资源

运行示例：

```bash
python3.10 scripts/resource.py idle \
  --gpu X60 \
  --output /tmp/wanqing-idle-x60.json
```

默认口径：

```text
有效余卡 = sum(单机余卡)，仅计入单机余卡 >= 4 的机器
等效空闲整机 = floor(有效余卡 / 8)
完全空闲物理机 = count(单机余卡 = 8)
```

默认使用三个线上池。需要覆盖时重复传入 `--pool`；需要调整碎片阈值时使用 `--fragment-threshold`。

回答时依次展示等效空闲整机、有效余卡、非碎片机器数和完全空闲物理机数。明确说明等效整机可能由多台半空闲机器的卡拼成，不等于完全空闲物理主机数。

## 指定资源池

运行示例：

```bash
python3.10 scripts/resource.py pool \
  --pool wanqing-test \
  --gpu X60 \
  --output /tmp/wanqing-test-x60.json
```

多次传入 `--pool` 表示机器标签命中其中任意一个池，使用 `hasAny` 语义。输出机器数和 GPU 总卡、已用卡、余卡。

空列表表示查询窗口内没有命中记录；某个型号返回 0 表示确有聚合行但数值为 0。不要因为 GPU 用量为 0 就断言资源池不存在。

## 系统软件开发机

运行示例：

```bash
python3.10 scripts/resource.py system-dev \
  --output /tmp/wanqing-system-dev.json
```

该指标来自数据集 256338 的 `resourcePoolLabelKeys`。看板 Widget 的底层计算口径为：

```sql
CASE
  WHEN hasAny(resourcePoolLabelKeys, array('wanqing-test')) = 1 THEN 1
  ELSE 0
END
```

即：机器的标签数组包含 `wanqing-test` 时，计为一台系统软件开发机。

脚本默认使用 `wanqing-test`。只有口径发生变更或需要验证其他标签时，才通过参数或环境变量覆盖：

```bash
export WANQING_SYSTEM_DEV_POOLS='pool-a,pool-b'
```

也可以重复传入 `--pool`。

## 内部模型持有机器

使用 `kce_server.kce_ai_infra_pods` 查询内部开源模型在时间窗内持有的 GPU 卡数，
并按 8 卡一机折算等效机器数。同一场景通过 `--model-scope` 区分常规模型与上线验证
中的模型，不新建子命令。

用户提供的名称未经过精确校验时，先用与目标 `model-holdings` 相同的 `model-scope`、
cluster、GPU、服务类型和排除池发现候选：

```bash
python3.10 scripts/resource.py list-models \
  --model-input 'GLM 5' \
  --model-scope regular \
  --service-type online \
  --window-seconds 300 \
  --output /tmp/wanqing-resource-model-candidates.json
```

同一资源持有量口径下有两个及以上模型表达时，共享一次窗口解析并有界并发发现候选：

```bash
python3.10 scripts/resource.py list-models-batch \
  --model-input 'GLM 5' \
  --model-input 'deepseek-v4-pro' \
  --model-scope regular \
  --service-type online \
  --window-seconds 300 \
  --max-workers 4 \
  --output-dir /tmp/wanqing-resource-model-candidates \
  --output /tmp/wanqing-resource-model-candidates-batch.json
```

将批量 Manifest 交给 `model_resolver.py resolve-batch`，目标固定为 `resource/model-holdings`。
批量输出保持模型输入顺序；存在任一歧义或失败时停止
`model-holdings` 并一次汇总确认项。单模型入口和其他机器查询场景不使用该批量命令。

当前 300 秒未命中时，可改用包含边界的 `--from/--to` 查询最近 24 小时确认名称；该
回查不改变最终 `model-holdings` 默认最近 300 秒的持有量窗口。候选 Artifact 经
`scripts/model_resolver.py resolve` 成功解析后，再执行下列精确查询。候选发现最多返回
20 个名称，不统计 GPU 卡数或机器数。

### 常规模型

```bash
python3.10 scripts/resource.py model-holdings \
  --model-artifact /tmp/wanqing-resource-model-resolution.json \
  --gpu X60 \
  --output /tmp/wanqing-model-holdings-glm-5.2.json
```

默认 `--model-scope regular`。生产查询必须使用 `--model-artifact`；多模型时可重复
传入，最多 20 个。脚本校验目标领域为 `resource`、目标场景为 `model-holdings`，再使用
其中的 `modelServiceName` 精确匹配。裸 `--model` 只用于 fixture 离线验证。常规模型口径：

- 排除模型名 `unknown`。
- 排除名称中包含 `test`、`zhipu`、`private` 的记录。
- `labels` 包含 `llm-inference-pool=offline` 时记为 `offline`，否则记为
  `online`。使用 `--service-type online|offline` 可只查询一种服务类型。
- 按模型、GPU 类型和服务类型分组。

云上容量回收是唯一的内部跨域入口：固定 Workflow 在模型已经按
`capacity/cloud-reclaim` 成功解析后，通过内部参数 `--capacity-model-artifact` 复用同一
精确模型身份，并固定查询最近 300 秒、`--service-type online` 的持有量。该参数不得由
Agent 手工调用，也不得用于普通资源持有量问答；模型没有匹配记录时返回 `partial`，不能
把缺失解释为持有 0 卡。

### 上线验证中模型

保持 `model-holdings` 场景，只切换范围参数：

```bash
python3.10 scripts/resource.py model-holdings \
  --model-scope launch-validation \
  --model-artifact /tmp/wanqing-launch-model-resolution.json \
  --gpu X60 \
  --output /tmp/wanqing-model-holdings-launch-validation.json
```

上线验证中口径严格使用：

- `modelServiceName LIKE '%test%'`
- `modelServiceName NOT LIKE '%private%'`
- 按模型和 GPU 类型分组，不区分 online/offline，因此不得同时传
  `--service-type`。

该范围同样必须传 `--model-artifact`，且解析名称必须包含 `test`、不包含 `private`；可重复传入
多个精确模型名。不要套用常规模型的 `zhipu` 排除条件。用户未指定模型时，执行上面的
资源占用量模型门控，不得直接返回全部验证中模型明细。

### 共享参数与结果

两个范围未指定时间时均查询最近 300 秒；复现指定窗口时同时传入包含边界的 Unix 秒
时间戳：

```bash
python3.10 scripts/resource.py model-holdings \
  --model-artifact /tmp/wanqing-resource-model-resolution.json \
  --gpu X60 \
  --from 1785304200 \
  --to 1785304499 \
  --output /tmp/wanqing-model-holdings-glm-5.2.json
```

需要查询多个离散自然分钟时，保持 `model-holdings` 场景并重复传入 Unix 秒分钟起点；
`--minute-start` 与 `--from/--to` 互斥：

```bash
python3.10 scripts/resource.py model-holdings \
  --model-artifact /tmp/wanqing-resource-model-resolution.json \
  --gpu X60 \
  --service-type online \
  --minute-start 1785304200 \
  --minute-start 1785304260 \
  --output /tmp/wanqing-model-holdings-minutes.json
```

离散分钟模式按分钟、模型、GPU 类型和服务类型分组，返回
`summary.minute_samples[]`、请求/返回分钟数和 `missing_minutes`。任一请求分钟没有匹配
记录时 Artifact 为 `partial`，不得将缺失分钟解释为持有量 0。该模式只服务明确指定的
历史持有量查询；云上容量回收只使用当前 300 秒窗口，不使用离散分钟。

共享查询口径：

- 集群默认为 `kce-ai-infra-bjzey1-hb1az3`。
- `kce_ai_infra_pods` 已确认一条活跃 Pod 一行，窗口内直接汇总
  `gpuRequestNum`，不再按 Pod 做快照去重。
- 排除资源池 `wanqing-test`、`langbridge-training`。
- X60 同时匹配 `X60`、`X60卡`；X50/X40 使用相同规则。未传 `--gpu` 时查询
  X60、X50、X40。
- GPU 卡数使用 `sum(gpuRequestNum)`。

结果返回每个模型的总量和 GPU 类型分项；常规模型还返回 online/offline 分项：

```text
equivalent_machines = gpu_cards / 8
```

回答“持有多少机器”时，先给 8 卡等效机器数，再给 GPU 卡数、模型范围、GPU 类型、
查询时间窗，以及该范围存在的 online/offline 分项。该表当前没有物理宿主机去重字段，
因此不得把
`equivalent_machines` 表述为物理机器数；如需物理机器数，必须补充 Pod 到宿主机的
字段契约。查询窗口内没有返回行时，表述为“没有匹配记录”，不要自动断言持有量为 0。

## 实际可用资源

运行示例：

```bash
python3.10 scripts/resource.py available \
  --gpu X60 \
  --gpu X50 \
  --output /tmp/wanqing-available.json
```

默认查询 X60 和 X50：

```text
实际可用 = max(0, 系统软件开发机 + 线上空闲等效整机 + QA 持有机器 - 固定保留机器)
```

系统软件开发机和 QA 合计常态固定保留 6 台 X60，因此 X60 的计算式为：

```text
实际可用 X60 = max(0, 系统软件开发机 + 线上空闲等效整机 + QA 持有机器 - 6)
```

若固定保留大于上述三项合计，`actual_available_machines` 保持 0，并在
`reservation_deficit_machines` 记录尚未满足的固定保留数量；不得输出负的可用机器数。


| 分项 | 口径 |
|---|---|
| 系统软件开发机 | `resourcePoolLabelKeys` 包含 `wanqing-test` |
| 线上空闲等效整机 | 三个线上池，去碎片后有效余卡除以 8 向下取整 |
| QA 持有机器 | `wanqing-qa` 标签机器数 |
| 系统软件开发机与 QA 固定保留机器 | X60 为 6，X50/X40 为 0 |

回答使用下表：

| 类别 | X60 | X50 |
|---|---:|---:|
| 系统软件开发机 | N | N |
| 线上空闲等效整机 | N | N |
| QA 持有机器 | N | N |
| 系统软件开发机与 QA 固定保留（扣减） | -6 | 0 |
| 实际可用机器 | N | N |

## 结果解释与异常

- 先给结论，再说明集群、时间窗口、资源池和碎片阈值。
- 某型号没有返回行时，表述为“查询窗口内无记录”，不要自动写成 0。
- 请求一个或多个 GPU 型号时，只有每个请求型号都恰好返回一行才是 `success`；少任一型号
  返回 `partial`、`reason_code=NO_ROWS`，并在 `missing_gpu_types` 列出缺项。不得用其余
  卡型的成功行把整体提升为成功。
- Artifact 状态为 `partial` 时，只报告已知分项和缺失项；`complete=false` 的数值 0 不得
  表述为确定的零。
- 查询失败时报告错误，不把旧验证数值当作实时结果。
- 业务命令的参数错误和查询失败也写出最小错误 Artifact，分别使用 `INVALID_INPUT` 或
  `QUERY_FAILED`，而不是只在终端打印错误后不留证据。
- 后续追问复用 Artifact：

```bash
python3.10 scripts/resource.py inspect \
  /tmp/wanqing-available.json \
  --section summary
```

- 完整 Artifact 包含查询 SQL 和窄化后的 ClickHouse 聚合结果，默认文件权限为 0600。不要把完整 Artifact 一次性加载到模型上下文。

## 待补数据契约

1. 系统软件开发机与 QA 合计固定保留 6 台 X60 的负责人、有效期和版本管理方式。
2. 数据新鲜度 SLA，以及最近一小时没有快照时的升级路径。
