# 余量与扩容

同时读取 [capacity.md](capacity.md)。只有出现正 TPM 缺口且请求深度需要换算时，
再读取 [integration-kconf.md](integration-kconf.md)、
[integration-isvc.md](integration-isvc.md) 或资源 Reference。

## 目录

1. [适用范围与口径](#适用范围与口径)
2. [证据与计算](#证据与计算)
3. [决策解释](#决策解释)
4. [资源域校验](#资源域校验)
5. [当前停止条件](#当前停止条件)

### 适用范围与口径

```text
确定 provider=internal、priority=在线
→ 取业务时区的前一完整自然日作为评估窗口
→ 查询评估窗口内逐分钟容量和实际用量
→ 容量和用量分别形成各自的完整分钟集合
→ 在各自集合上分别计算内部部署容量 P90 和内部流量 P90
→ 容量 P90 减流量 P90，得到前一日可承接流量
→ 有新增 TPM 时计算缺口
→ 有缺口且有单实例容量时换算实例数
→ 有 iSvc 单实例卡数时换算所需卡数和 8 卡等效机器数
→ 需要落地判断时交给资源域校验
```

“GLM5.1 当前还可以承接多少 TPM”默认只评估内部自部署供给，因此固定使用
`provider=internal`、`provider_scope=self_deployed`、`priority=在线`。云上 `public`
容量不并入这一内部承接余量；若用户明确询问单一其他 provider，按该 provider 执行并
单独说明范围；只有混合承接时才先确认聚合口径，不直接套用内部 P90 结论。

“目前容量哪里有冗余”这类未指定模型和 provider 的问题，使用 Schema 1.1 默认模型域：
按版本化策略依次评估 X60、X40 候选名单，provider 固定为 `internal/self_deployed`。名单
本身生成受信 `wanqing.model_scope` 和逐模型解析 Artifact，不依赖前一日容量表再次证明
模型身份；进入容量查询后仍逐模型隔离 `NO_ROWS`、查询失败或不完整证据。用户指定模型、
X60/X40 Top P 或 provider 时完整覆盖相应默认值；同时指定模型和候选范围时停止并确认。

用户明确说“云上还可以打多少流量”“云上还能承接多少 TPM”时，仍属于单模型余量问题，
使用 `query-headroom --provider public --provider-scope cloud` 和前一完整自然日窗口；只
输出云上容量与流量的 P90 差额，不因出现“云上”而自动进入 Top P 云上容量回收。只有
继续询问该余量能够替代多少内部实例、节省多少卡或机器时，才进入云上容量回收。

### 证据与计算

必需证据是评估窗口内逐分钟的在线容量和实际用量；新增承接判断还需要
`incremental_tpm`。仅在出现缺口后，按需补充 KConf 单实例容量、iSvc 单实例卡数和
资源域 Artifact。
`query-headroom` 负责查询并按分钟合并 workload。容量和用量使用同一个业务窗口、模型、
provider 与在线口径，但分别形成各自的完整分钟集合；容量 P90 和流量 P90 分别在各自
集合上计算，不要求时间戳相交。用量集合是窗口内预期自然分钟轴：CK 有行时使用聚合值，
无行时按稀疏写入契约取 0。多 provider 时先对每个 provider 的缺行分钟补 0，再在同一
自然分钟相加；不得拼接不同 provider 的不同分钟。fixture 和历史回放仍只使用显式样本，
不会自动套用生产 CK 的稀疏写入契约。

确认存在 TPM 缺口后，调用 `kconf_single_config_data`，单模型使用 `kconf.py normalize`，
多模型使用 `kconf.py normalize-batch`，按“归一化优先、普通配置回退”规范化。返回
`device_type_required` 时，先向用户
展示普通配置的全部卡型和对应 TPM；用户明确后对同一配置版本加
`--device-type` 重新规范化。只将 `status=success` 的 KConf Artifact 通过
`query-headroom --kconf-artifact` 或 `headroom --kconf-artifact` 传入。再运行
`isvc.py query-model --model-artifact <本场景模型解析Artifact>`，不得改用裸
`--model`；把成功
Artifact 通过 `query-headroom --isvc-artifact` 或 `headroom --isvc-artifact` 传入。
生产执行优先使用 KConf Artifact；`--single-instance-capacity-tpm` 只作兼容标量入口，
不得与 `--kconf-artifact` 同时使用。生产 CLI 不接受人工单实例卡数；直接在
规范化输入提供 KConf 值或 `isvc` 只用于 fixture 和历史回放。

多模型需要继续计算扩容实例、卡数和机器数时，Workflow 从原批次筛选正缺口模型组成
KConf 与 iSvc 子批次，保留原始模型下标并在 finalize 后合并；子批次内部模型、顺序和解析
Artifact 必须完全一致，不能仅凭模型字符串配对。新增 TPM 和预留比例仍对原批次的每个
模型使用同一值：

```bash
python3.10 scripts/capacity.py query-headroom-batch \
  --model-artifact /tmp/model-01.json \
  --model-artifact /tmp/model-02.json \
  --provider internal \
  --provider-scope self_deployed \
  --window-relation previous_day \
  --timezone Asia/Shanghai \
  --incremental-tpm 5000000 \
  --reserve-ratio 0 \
  --kconf-manifest /tmp/kconf-batch/manifest.json \
  --isvc-manifest /tmp/isvc-batch/manifest.json \
  --resource-artifact /tmp/wanqing-available.json \
  --max-workers 4 \
  --output-dir /tmp/headroom-batch \
  --output /tmp/headroom-batch.json
```

只比较 TPM 余量或承接能力时可以省略 KConf、iSvc 和资源证据。KConf 或 iSvc Manifest
中某个模型不是 `success` 时，该模型保留已能计算的余量、缺口或实例数并标记 `partial`，
不得影响同批其他模型；已显式传入但模型、顺序或来源模型 Artifact 不一致时按
`INVALID_INPUT` 停止，不能自动按文件名猜测配对。
批量资源校验默认为 `per_model_independent`：分别判断每个模型单独扩容时资源是否足够，
不能据此声称多个模型同时扩容时共享资源总量仍然足够。需要同时扩容的总量判断时必须
另行汇总各卡型需求后再与资源域证据比较。

核心公式：

```text
C
  = 前一日 internal 在线容量完整分钟集合

U
  = 前一日 internal 在线预期自然分钟集合

usage_tpm(t, provider)
  = CK 聚合值，若该 model/provider/minute 有记录
  = 0，若生产 CK 查询成功但该稀疏零流量分钟无记录

previous_day_capacity_p90_tpm
  = nearest_rank_p90(capacity_tpm(t), t ∈ C)

previous_day_traffic_p90_tpm
  = nearest_rank_p90(usage_tpm(t), t ∈ U)

raw_headroom_tpm
  = previous_day_capacity_p90_tpm
    - previous_day_traffic_p90_tpm

usable_headroom_tpm
  = max(raw_headroom_tpm
        - previous_day_capacity_p90_tpm × reserve_ratio, 0)

deficit_tpm
  = max(incremental_tpm
        - usable_headroom_tpm, 0)
```

P90 使用 nearest-rank：`rank=ceil(N×0.90)`，取升序排列后的第 `rank` 个值。
`reserve_ratio` 默认是 0；只有用户或正式策略提供预留比例时才扣减。负的原始余量保留在
`raw_headroom_tpm`，用于承接和扩容判断时归零。该口径不替代流量画像中的“当前 T10
实际 TPM 均值”，也不再使用当天容量进行投影。

`previous_day_capacity_p90_tpm` 和 `previous_day_traffic_p90_tpm` 是报告规范字段。
`provider_scope=self_deployed` 时同时保留 `previous_day_internal_*` 兼容别名；
`provider_scope=cloud` 时只生成语义正确的 `previous_day_public_*` 别名，不再把云上数据写入
`internal` 字段。

有配置证据时继续计算：

```text
required_instances
  = ceil(deficit_tpm / single_instance_capacity_tpm)

required_gpu_cards_by_type[gpu_type]
  = required_instances
    × single_instance_gpu_cards_by_type[gpu_type]

required_gpu_cards
  = sum(required_gpu_cards_by_type)

required_8_card_machine_equivalents_by_type[gpu_type]
  = ceil(required_gpu_cards_by_type[gpu_type] / 8)

required_8_card_machine_equivalents
  = sum(required_8_card_machine_equivalents_by_type)
```

这里的“机器数”统一表示同卡型内换算的 8 卡等效机器数。混合卡型必须先分别向上取整再
求和，不能对异构卡总数直接除以 8。它不是资源池内已经存在且可分配的物理机器数。

### 决策解释

多模型余量报告保留请求顺序，并额外生成 `redundancy_overview`：仅把证据完整且
`usable_headroom_tpm > 0` 的模型列为冗余，按可用余量从高到低排列；完整且等于 0 的模型
列入 `no_redundancy_models`，证据缺失或失败的模型单列为 `incomplete_models`，不得当作 0。

| `decision` | 含义 |
|---|---|
| `headroom_only` | 仅返回余量，用户没有提供新增 TPM |
| `can_serve` | 可用余量能够承接目标新增 TPM |
| `insufficient_data` | 已发现缺口，但缺少 KConf 单实例容量，或缺少 iSvc 单实例卡数而无法继续换算卡数和 8 卡等效机器数 |
| `expansion_required_resource_unverified` | 已算出所需 8 卡等效机器数，但缺少资源域总量校验 |
| `expand_from_available_resources` | 资源域证据显示资源总量初步足够；不等于已经满足部署拓扑和调度约束 |
| `resource_shortage` | 扩容所需机器多于资源域可用机器；云上容量回收是独立场景，不自动跳转 |

### 资源域校验

需要初步检查资源总量是否足够时，把资源域 `available` 或 `idle` Artifact 传给
`headroom`，对 iSvc 卡型分项逐一精确匹配；优先读取 `actual_available_machines`，其次
读取 `equivalent_idle_machines`。每种卡型都足够才通过数量校验。当前交接没有单机余卡
分布、部署拓扑和调度约束证据，不得将结果表述为实例已经能够实际落地。

### 当前停止条件

- 多 provider：使用 `provider_scope=mixed`；供给画像只引用最近 30 个连续共同完整分钟的
  容量均值；历史余量在容量源内部、用量源内部分别对齐 provider，再各自计算分位值。
- 前一日承接评估：生产查询必须覆盖完整自然日；容量原始分钟不足或覆盖率小于 100% 时
  返回 `partial`。用量查询成功后按稀疏写入契约补 0，并要求语义分钟覆盖率 100%；原始
  非零分钟覆盖率只作诊断，不阻断 P90。查询失败、字段异常或语义分钟不足仍返回
  `partial`，不得把这些错误补成 0，也不得另取当天容量投影。
- 自定义历史或闲时时段：未给出时间范围时，先询问开始时间、结束时间和时区；时间明确
  后沿用对应场景的分钟对齐与聚合公式，不自行发明闲时窗口。
- `kconf_single_config_data` 不可用或查询失败：不传 Artifact，只输出 TPM
  缺口，不猜实例数。已传入但未通过结构或语义校验的 KConf Artifact 返回
  `error`，不降级使用内联标量。
- KConf 归一化配置未命中且普通配置存在多个 `deviceType`：输出 TPM 缺口和
  可选卡型，暂停实例换算并引导用户明确承载卡型。不用 iSvc 当前卡型自动
  代选。
- iSvc 查询失败、无有效的活动 online 部署、所有匹配部署字段均不完整，或有效部署的同模型
  规格不唯一：只输出实例数，不猜单实例卡数、总卡数或 8 卡等效机器数。至少一条匹配部署
  有效且所有有效部署卡型分布一致时，允许忽略非法兄弟记录继续交接卡数，同时保留告警。
- 资源域证据缺失：不得声称资源总量足够；即使数量校验通过，也不得声称实例已经能够
  实际落地。
