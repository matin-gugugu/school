#!/usr/bin/env python3
"""Shared filesystem, subprocess and provenance helpers for capacity workflows."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any, Callable, Iterable

from artifact_contract import ArtifactContractError, artifact_reference
from workflow_core import (
    WorkflowCoreError,
    evidence_id_for_location,
    evidence_paths_by_role,
    validate_checkpoint_projection,
    validate_evidence_reference,
)


class WorkflowArtifactSupport:
    def __init__(self, error_type: Callable[[str, str], Exception]) -> None:
        self.error_type = error_type

    def load_object(self, path_value: str | Path) -> tuple[Path, dict[str, Any]]:
        path = Path(path_value).expanduser().resolve()
        with path.open(encoding="utf-8") as handle:
            value = json.load(handle)
        if not isinstance(value, dict):
            raise self.error_type(f"JSON 必须是对象：{path}", "INVALID_INPUT")
        return path, value

    def run_artifact_command(
        self, command: list[str], output: Path, label: str
    ) -> dict[str, Any]:
        completed = subprocess.run(
            command, check=False, capture_output=True, text=True
        )
        if not output.is_file():
            detail = completed.stdout.strip() or completed.stderr.strip()
            raise self.error_type(
                f"{label}未生成 Artifact：{detail or '无错误详情'}",
                "QUERY_FAILED",
            )
        _, artifact = self.load_object(output)
        status = artifact.get("status")
        if status not in {"success", "partial", "error"}:
            raise self.error_type(
                f"{label} Artifact 缺少有效 status", "ARTIFACT_INVALID"
            )
        if completed.returncode != 0 and status != "error":
            raise self.error_type(
                f"{label}退出码与 Artifact status 不一致", "ARTIFACT_INVALID"
            )
        return artifact


SOURCE_EVIDENCE_ROLES = frozenset(
    {
        "model_candidates",
        "model_scope",
        "model_resolution",
        "capacity_result",
        "headroom",
        "headroom_result",
        "isvc",
        "resource",
        "cost",
        "kconf",
    }
)


def parent_references(
    paths: Iterable[tuple[Path, str]],
) -> list[dict[str, str]]:
    seen: set[tuple[Path, str]] = set()
    parents: list[dict[str, str]] = []
    for path, role in paths:
        resolved = path.expanduser().resolve()
        key = (resolved, role)
        if key in seen:
            continue
        seen.add(key)
        parents.append(
            artifact_reference(
                resolved,
                role=role,
                include_in_evidence=role in SOURCE_EVIDENCE_ROLES,
            )
        )
    return parents


def provenance_paths_by_role(
    artifact: dict[str, Any],
) -> dict[str, set[Path]]:
    """Return canonical evidence paths grouped by role.

    Artifacts created before workflow schema 2.0 fall back to the legacy
    provenance projection during the compatibility window.
    """

    if artifact.get("evidence_index") is not None:
        try:
            return evidence_paths_by_role(artifact)
        except WorkflowCoreError as exc:
            raise ArtifactContractError(str(exc)) from exc

    provenance = artifact.get("provenance")
    parents = provenance.get("parents") if isinstance(provenance, dict) else None
    if not isinstance(parents, list):
        raise ArtifactContractError("Artifact 缺少父证据")
    paths_by_role: dict[str, set[Path]] = {}
    for index, parent in enumerate(parents):
        if not isinstance(parent, dict):
            raise ArtifactContractError(
                f"provenance.parents[{index}] 必须是对象"
            )
        role = parent.get("role")
        path_value = parent.get("path")
        if not isinstance(role, str) or not role:
            raise ArtifactContractError(
                f"provenance.parents[{index}] 缺少 role"
            )
        if not isinstance(path_value, str) or not path_value:
            raise ArtifactContractError(
                f"provenance.parents[{index}] 缺少 path"
            )
        paths_by_role.setdefault(role, set()).add(
            Path(path_value).expanduser().resolve()
        )
    return paths_by_role


def validate_parent_path_bindings(
    artifact: dict[str, Any],
    bindings: Iterable[tuple[str, str | Path, str | Iterable[str]]],
) -> None:
    """Require every referenced evidence path to be a parent with an allowed role."""

    paths_by_role = provenance_paths_by_role(artifact)
    for label, path_value, allowed_roles in bindings:
        roles = (
            (allowed_roles,)
            if isinstance(allowed_roles, str)
            else tuple(allowed_roles)
        )
        resolved = Path(path_value).expanduser().resolve()
        if not any(resolved in paths_by_role.get(role, set()) for role in roles):
            raise ArtifactContractError(
                f"{label} 不在 Artifact 父证据链允许的角色中"
            )


def attach_evidence_id(
    artifact: dict[str, Any],
    target: dict[str, Any],
    *,
    id_field: str,
    path_value: str | Path | None,
    role: str,
) -> None:
    """Attach one canonical evidence ID while retaining a legacy path field."""

    if path_value is None:
        target[id_field] = None
        return
    try:
        target[id_field] = evidence_id_for_location(
            artifact,
            path_value,
            role=role,
        )
    except WorkflowCoreError as exc:
        raise ArtifactContractError(str(exc)) from exc


def validate_evidence_id_binding(
    artifact: dict[str, Any],
    target: dict[str, Any],
    *,
    id_field: str,
    path_field: str,
    role: str,
) -> None:
    """Validate a canonical ID and its temporary path compatibility view."""

    evidence_reference = target.get(id_field)
    path_value = target.get(path_field)
    if not isinstance(evidence_reference, str) or not evidence_reference:
        raise ArtifactContractError(f"{id_field} 缺少 canonical evidence_id")
    if not isinstance(path_value, str) or not path_value:
        raise ArtifactContractError(f"{path_field} 缺少兼容证据路径")
    try:
        validate_evidence_reference(
            artifact,
            evidence_reference,
            role=role,
            compatibility_path=path_value,
        )
    except WorkflowCoreError as exc:
        raise ArtifactContractError(str(exc)) from exc


def build_isvc_batch_command(
    *,
    python: str,
    script: Path,
    model_artifacts: Iterable[str | Path],
    timeout: float,
    max_workers: int,
    output_dir: Path,
    output: Path,
    endpoint: str | None = None,
    fixture: str | None = None,
    service_selections: dict[str, str] | None = None,
) -> list[str]:
    """Build the one shared iSvc list-query command used by both workflows."""

    command = [python, "-B", str(script), "query-models"]
    for path in model_artifacts:
        command.extend(["--model-artifact", str(path)])
    command.extend(
        [
            "--pool",
            "online",
            "--timeout",
            str(timeout),
            "--max-workers",
            str(max_workers),
            "--output-dir",
            str(output_dir),
            "--output",
            str(output),
        ]
    )
    if endpoint:
        command.extend(["--endpoint", endpoint])
    if fixture:
        command.extend(["--fixture", fixture])
    for model, service in sorted((service_selections or {}).items()):
        command.extend(["--service-selection", f"{model}={service}"])
    return command


def build_kconf_batch_command(
    *,
    python: str,
    script: Path,
    tool_result: str | Path,
    model_artifacts: Iterable[str | Path],
    key: str,
    stage: str,
    max_workers: int,
    output_dir: Path,
    output: Path,
    device_type: str | None = None,
    device_type_selections: dict[str, str] | None = None,
) -> list[str]:
    """Build the shared KConf normalization command without reading its result."""

    command = [
        python,
        "-B",
        str(script),
        "normalize-batch",
        "--input",
        str(Path(tool_result).expanduser().resolve()),
    ]
    for path in model_artifacts:
        command.extend(["--model-artifact", str(path)])
    command.extend(
        [
            "--key",
            key,
            "--stage",
            stage,
            "--max-workers",
            str(max_workers),
            "--output-dir",
            str(output_dir),
            "--output",
            str(output),
        ]
    )
    if device_type:
        command.extend(["--device-type", device_type])
    for model, selected in sorted((device_type_selections or {}).items()):
        command.extend(["--device-type-selection", f"{model}={selected}"])
    return command


def validate_kconf_next_action(
    action: Any,
    *,
    tool: str,
    key: str,
    stage: str,
    then_command: str,
    plan_path: str | Path,
    artifact: dict[str, Any] | None = None,
) -> None:
    """Validate the immutable KConf checkpoint shared by both state machines."""

    if artifact is not None:
        try:
            validate_checkpoint_projection(artifact)
        except WorkflowCoreError as exc:
            raise ArtifactContractError(str(exc)) from exc

    if (
        not isinstance(action, dict)
        or action.get("type") != "tool_call"
        or action.get("tool") != tool
        or action.get("arguments") != {"key": key, "stage": stage}
    ):
        raise ArtifactContractError("计划没有合法的固定 KConf next_action")
    save_path = action.get("save_raw_result_as")
    then = action.get("then")
    arguments = then.get("arguments") if isinstance(then, dict) else None
    if (
        not isinstance(save_path, str)
        or not save_path
        or not isinstance(then, dict)
        or then.get("command") != then_command
        or not isinstance(arguments, dict)
        or Path(str(arguments.get("plan_artifact", ""))).expanduser().resolve()
        != Path(plan_path).expanduser().resolve()
        or Path(str(arguments.get("kconf_tool_result", ""))).expanduser().resolve()
        != Path(save_path).expanduser().resolve()
    ):
        raise ArtifactContractError("计划的 KConf 后续动作不符合固定契约")
