#!/usr/bin/env python3
"""Thin CLI and Artifact adapter for Wanqing cost queries."""

from __future__ import annotations

import argparse
import json
import sys

from artifact_contract import annotate_outcome, terminal_brief
from cost_query import SCRIPT_VERSION, query_cloud_daily_cost
from runtime import utc_now, write_artifact


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="万擎云上成本查询（只读）")
    commands = parser.add_subparsers(dest="command", required=True)
    query = commands.add_parser(
        "query-cloud-daily-cost",
        help="查询容量回收候选模型前一天的可计费云上成本",
    )
    query.add_argument(
        "--capacity-model-artifact",
        action="append",
        required=True,
        help="capacity/cloud-reclaim 模型解析 Artifact，可重复传入",
    )
    query.add_argument(
        "--headroom-artifact",
        action="append",
        required=True,
        help="同模型的成功 query-headroom Artifact，可重复传入",
    )
    query.add_argument("--fixture", help="ClickHouse JSON fixture，不访问网络")
    query.add_argument("--timeout", type=float, default=30.0)
    query.add_argument("--output", required=True)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        artifact = query_cloud_daily_cost(args)
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as exc:
        query_failure = isinstance(
            exc, (OSError, RuntimeError, json.JSONDecodeError)
        )
        artifact = {
            "schema_version": "1.0",
            "script_version": SCRIPT_VERSION,
            "domain": "cost",
            "scenario": "cloud-daily-billing",
            "status": "error",
            "generated_at": utc_now(),
            "query": {
                "source": "fixture" if getattr(args, "fixture", None) else "clickhouse",
                "capacity_model_artifacts": [
                    str(value)
                    for value in getattr(args, "capacity_model_artifact", [])
                ],
                "headroom_artifacts": [
                    str(value)
                    for value in getattr(args, "headroom_artifact", [])
                ],
            },
            "summary": {
                "decision": "query_failed" if query_failure else "invalid_input",
                "write_performed": False,
            },
            "handoffs": {},
            "evidence": {},
            "warnings": [],
            "errors": [str(exc)],
        }
        artifact["reason_code"] = (
            "QUERY_FAILED" if query_failure else "INVALID_INPUT"
        )
    annotate_outcome(artifact)
    output = write_artifact(args.output, artifact)
    print(json.dumps(terminal_brief(artifact, output), ensure_ascii=False))
    return 0 if artifact["status"] != "error" else 1


if __name__ == "__main__":
    sys.exit(main())
