#!/usr/bin/env python3
"""Capacity candidate discovery and ClickHouse evidence normalization.

This module owns query windows, SQL construction, result normalization,
coverage checks, sparse-usage handling, and bounded batch query execution.
It delegates deterministic business formulas to capacity_metrics.
"""

from __future__ import annotations

import argparse
import json
import math
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Iterable
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from capacity_metrics import (
    InputError,
    attach_isvc_artifact,
    attach_kconf_artifact,
    base_artifact,
    deep_get,
    finite_number,
    headroom,
    insufficient,
    integer_timestamp,
    load_object,
    nearest_rank_percentile,
    utc_now,
    write_artifact,
)
from isvc import normalize_card_profile
from model_contract import (
    CAPACITY_QUERY_SOURCES,
    TARGET_SCENARIOS,
    resolve_single_model,
    validate_embedded_model_resolution,
)
from model_resolver import (
    candidate_recall_rank,
    comparison_key as model_comparison_key,
)
from runtime import query_or_fixture
from top_p_policy import (
    validate_candidate_prefix,
    validate_explicit_candidate_selection,
)


MIN_PERCENTILE_SAMPLE_COUNT = 10
CURRENT_SUPPLY_WINDOW_MINUTES = 30
CURRENT_USAGE_WINDOW_MINUTES = 10
PROVIDER_SCOPE_BY_VALUE = {
    "public": "cloud",
    "internal": "self_deployed",
}
PRIORITY_VALUES = {"在线", "离线"}
WINDOW_RELATIONS = {
    "current",
    "custom",
    "previous_day",
    "previous_same_period",
}
CAPACITY_TABLE = "wanqing_data.ai_infra_all_model_quota_info"
USAGE_TABLE = "kce_server.ai_infra_billing_gateway_log_flatten_map_timestamp"
MAX_QUERY_WINDOW_SECONDS = 32 * 24 * 60 * 60
DATA_FRESHNESS_GUARD_SECONDS = 300
USAGE_ZERO_FILL_POLICY = "missing_model_provider_minute_means_zero"
USAGE_ZERO_FILL_POLICY_VERSION = "1.0"
USAGE_ZERO_FILL_CONFIDENCE = "source_contract_based"
MODEL_CANDIDATE_LIMIT = 20
MAX_BATCH_MODEL_INPUTS = 20
DEFAULT_MAX_WORKERS = 4
MAX_MAX_WORKERS = 8
SCHEMA_VERSION = "1.0"
SCRIPT_VERSION = "0.34.0"


def sql_string(value: str) -> str:
    return "'" + value.replace("\\", "\\\\").replace("'", "\\'") + "'"


def sql_array(values: Iterable[str]) -> str:
    return "[" + ", ".join(sql_string(value) for value in values) + "]"


def validate_query_text(value: str, field: str) -> str:
    normalized = str(value).strip()
    if not normalized:
        raise InputError(f"{field} 不能为空")
    if len(normalized) > 256:
        raise InputError(f"{field} 长度不能超过 256")
    if any(ord(character) < 32 for character in normalized):
        raise InputError(f"{field} 不能包含控制字符")
    return normalized


def resolve_query_window(
    args: argparse.Namespace,
    *,
    fixture_mode: bool,
) -> dict[str, Any]:
    """Resolve and validate a query window without relying on Agent time math."""
    try:
        timezone_value = ZoneInfo(args.timezone)
    except ZoneInfoNotFoundError as exc:
        raise InputError(f"timezone 无效：{args.timezone}") from exc

    relation = validate_query_text(args.window_relation, "window-relation")
    if relation not in WINDOW_RELATIONS:
        raise InputError(
            "window-relation 仅支持：" + ", ".join(sorted(WINDOW_RELATIONS))
        )

    has_from = args.from_ts is not None
    has_to = args.to_ts is not None
    if has_from != has_to:
        raise InputError("--from 与 --to 必须同时提供或同时省略")

    resolved_at = datetime.now(timezone_value)
    resolution_source = "explicit"
    lookback_seconds = args.lookback_seconds
    if relation == "current":
        if has_from:
            raise InputError(
                "current 禁止显式传入 --from/--to；"
                "请使用 --lookback-seconds 由运行时钟解析"
            )
        if lookback_seconds is None:
            raise InputError("current 必须提供 --lookback-seconds")
        if not 60 <= lookback_seconds <= MAX_QUERY_WINDOW_SECONDS:
            raise InputError(
                "lookback-seconds 必须在 60 秒～32 天之间"
            )
        args.to_ts = int(resolved_at.timestamp())
        args.from_ts = args.to_ts - lookback_seconds
        resolution_source = "runtime_clock"
    elif relation == "previous_day":
        if lookback_seconds is not None:
            raise InputError(
                "--lookback-seconds 只能与 --window-relation current 一起使用"
            )
        expected_end = resolved_at.replace(
            hour=0,
            minute=0,
            second=0,
            microsecond=0,
        )
        previous_date = expected_end.date() - timedelta(days=1)
        expected_start = datetime(
            previous_date.year,
            previous_date.month,
            previous_date.day,
            tzinfo=timezone_value,
        )
        expected_from = int(expected_start.timestamp())
        expected_to = int(expected_end.timestamp())

        if not has_from:
            args.from_ts = expected_from
            args.to_ts = expected_to
            resolution_source = "runtime_clock"
        else:
            assert args.from_ts is not None and args.to_ts is not None
            start = datetime.fromtimestamp(args.from_ts, timezone_value)
            end = datetime.fromtimestamp(args.to_ts, timezone_value)
            for field, value in (("from", start), ("to", end)):
                if any(
                    (
                        value.hour,
                        value.minute,
                        value.second,
                        value.microsecond,
                    )
                ):
                    raise InputError(
                        "previous_day 必须对齐业务时区零点；"
                        f"{field}={value.isoformat()}"
                    )
            if end.date() - start.date() != timedelta(days=1):
                raise InputError(
                    "previous_day 的 from/to 必须是连续两个本地日期零点"
                )
            if not fixture_mode and (
                args.from_ts != expected_from or args.to_ts != expected_to
            ):
                raise InputError(
                    "previous_day 必须等于运行时钟的前一完整自然日；"
                    f"期望 {expected_start.isoformat()} - "
                    f"{expected_end.isoformat()}，收到 "
                    f"{start.isoformat()} - {end.isoformat()}"
                )
            resolution_source = (
                "fixture_explicit"
                if fixture_mode
                else "runtime_clock_validated_explicit"
            )
    else:
        if lookback_seconds is not None:
            raise InputError(
                "--lookback-seconds 只能与 --window-relation current 一起使用"
            )
        if not has_from:
            raise InputError(
                f"window-relation={relation} 必须显式提供 --from 和 --to"
            )

    assert args.from_ts is not None and args.to_ts is not None
    start = datetime.fromtimestamp(args.from_ts, timezone_value)
    end = datetime.fromtimestamp(args.to_ts, timezone_value)
    window = {
        "start": start.isoformat(),
        "end": end.isoformat(),
        "timezone": args.timezone,
        "relation": relation,
        "from_epoch_seconds": args.from_ts,
        "to_epoch_seconds": args.to_ts,
        "resolution_source": resolution_source,
        "resolved_at": resolved_at.isoformat(),
    }
    if relation == "current":
        window["lookback_seconds"] = lookback_seconds
    return window


def validate_query_args(
    args: argparse.Namespace,
) -> tuple[str, list[str], ZoneInfo, dict[str, Any]]:
    verified_model = resolve_single_model(
        artifact_path=args.model_artifact,
        raw_model=args.model,
        expected_domain="capacity",
        allowed_scenarios=TARGET_SCENARIOS["capacity"],
        allow_unverified=bool(
            args.capacity_fixture and args.usage_fixture
        ),
    )
    model = validate_query_text(verified_model.model, "model")
    providers = list(
        dict.fromkeys(
            validate_query_text(provider, "provider")
            for provider in args.provider
        )
    )
    if not providers:
        raise InputError("至少提供一个 provider")
    unsupported_providers = [
        provider
        for provider in providers
        if provider not in PROVIDER_SCOPE_BY_VALUE
    ]
    if unsupported_providers:
        raise InputError(
            "provider 仅支持 internal 或 public；收到："
            + ",".join(unsupported_providers)
        )
    provider_scopes = {
        PROVIDER_SCOPE_BY_VALUE[provider] for provider in providers
    }
    expected_scope = (
        next(iter(provider_scopes))
        if len(provider_scopes) == 1
        else "mixed"
    )
    if args.provider_scope != expected_scope:
        raise InputError(
            "provider 与 provider-scope 不匹配；"
            f"当前 provider 应使用 {expected_scope}"
        )
    if args.from_ts >= args.to_ts:
        raise InputError("from 必须小于 to")
    duration = args.to_ts - args.from_ts
    if duration < MIN_PERCENTILE_SAMPLE_COUNT * 60:
        raise InputError("查询窗口至少需要 10 分钟")
    if duration > MAX_QUERY_WINDOW_SECONDS:
        raise InputError("查询窗口不能超过 32 天")
    if not 1 <= args.timeout <= 600:
        raise InputError("timeout 必须在 1～600 秒之间")
    if not 0 <= args.reserve_ratio <= 1:
        raise InputError("reserve-ratio 必须在 0～1 之间")
    for field in ("incremental_tpm", "single_instance_capacity_tpm"):
        value = getattr(args, field)
        if value is not None and (not math.isfinite(value) or value < 0):
            raise InputError(f"{field.replace('_', '-')} 必须是非负有限数字")
    if args.single_instance_capacity_tpm is not None and args.kconf_artifact:
        raise InputError(
            "--single-instance-capacity-tpm 与 --kconf-artifact 不得同时使用"
        )
    if args.provider_scope != "self_deployed" and args.resource_artifact:
        raise InputError(
            "只有 internal/self_deployed 查询可使用内部资源域 Artifact"
        )
    try:
        timezone_value = ZoneInfo(args.timezone)
    except ZoneInfoNotFoundError as exc:
        raise InputError(f"timezone 无效：{args.timezone}") from exc
    return model, providers, timezone_value, verified_model.evidence


def validate_single_calculation_model(
    source: dict[str, Any],
    *,
    model_artifact: str | None,
    evidence_mode: str,
    target_scenario: str,
) -> dict[str, Any]:
    raw_model = source.get("model")
    verified = resolve_single_model(
        artifact_path=model_artifact,
        raw_model=raw_model if isinstance(raw_model, str) else None,
        expected_domain="capacity",
        allowed_scenarios={target_scenario},
        allow_unverified=evidence_mode == "replay",
        unverified_mode="replay_unverified",
    )
    if raw_model is not None and not isinstance(raw_model, str):
        raise InputError("model 必须是字符串")
    source["model"] = verified.model
    return verified.evidence


def resolve_input_reference(
    value: Any, field: str, input_path: Path
) -> Path | None:
    if value is None:
        return None
    if not isinstance(value, str) or not value.strip():
        raise InputError(f"{field} 必须是非空路径字符串")
    path = Path(value.strip()).expanduser()
    if not path.is_absolute():
        path = input_path.parent / path
    return path.resolve()


def validate_cloud_reclaim_models(
    source: dict[str, Any],
    *,
    input_path: Path,
    evidence_mode: str,
) -> list[dict[str, Any]]:
    candidates = source.get("candidates")
    selection = source.get("selection")
    if selection is not None:
        if source.get("policy") is not None:
            raise InputError(
                "显式模型云上回收不接受 policy；不得同时使用显式模型和 Top P"
            )
        selected_models = validate_explicit_candidate_selection(
            selection, candidates
        )
        selected_count = len(selected_models)
    else:
        _, top_p, _ = validate_candidate_prefix(
            source.get("policy"), candidates
        )
        selected_count = top_p
    assert isinstance(candidates, list)

    evidence: list[dict[str, Any]] = []
    for index, candidate in enumerate(candidates[:selected_count]):
        if not isinstance(candidate, dict):
            raise InputError(f"candidates[{index}] 必须是对象")
        artifact_path = resolve_input_reference(
            candidate.get("model_artifact"),
            f"candidates[{index}].model_artifact",
            input_path,
        )
        raw_model = candidate.get("model")
        verified = resolve_single_model(
            artifact_path=artifact_path,
            raw_model=raw_model if isinstance(raw_model, str) else None,
            expected_domain="capacity",
            allowed_scenarios={"cloud-reclaim"},
            allow_unverified=evidence_mode == "replay",
            unverified_mode="replay_unverified",
        )
        if raw_model is not None and not isinstance(raw_model, str):
            raise InputError(f"candidates[{index}].model 必须是字符串")
        candidate["model"] = verified.model
        if artifact_path is not None:
            candidate["model_artifact"] = str(artifact_path)
        evidence.append(verified.evidence)
    return evidence


def attach_calculation_provenance(
    artifact: dict[str, Any],
    *,
    evidence_mode: str,
    model_resolution: dict[str, Any] | list[dict[str, Any]],
) -> None:
    query = artifact.setdefault("query", {})
    if not isinstance(query, dict):
        raise InputError("计算结果 query 必须是对象")
    query["evidence_mode"] = evidence_mode
    query["model_resolution"] = model_resolution


def capacity_query_sql(
    model: str,
    providers: list[str],
    from_ts: int,
    to_ts: int,
) -> str:
    online_expression = (
        "CASE\n"
        "        WHEN scene IN ('batch', 'offline') THEN '离线'\n"
        "        ELSE '在线'\n"
        "    END"
    )
    return f"""SELECT
    toInt64((intDiv(timestamp, 60) * 60) * 1000) AS t,
    provider,
    {online_expression} AS priority,
    model,
    max(totalTpm) AS capacity
FROM {CAPACITY_TABLE}
WHERE
    timestamp > {from_ts}
    AND timestamp < {to_ts}
    AND provider IN {sql_array(providers)}
    AND model = {sql_string(model)}
    AND ({online_expression}) = '在线'
GROUP BY t, provider, model, priority
ORDER BY t"""


def capacity_batch_query_sql(
    models: list[str],
    providers: list[str],
    from_ts: int,
    to_ts: int,
) -> str:
    online_expression = (
        "CASE\n"
        "        WHEN scene IN ('batch', 'offline') THEN '离线'\n"
        "        ELSE '在线'\n"
        "    END"
    )
    return f"""SELECT
    toInt64((intDiv(timestamp, 60) * 60) * 1000) AS t,
    provider,
    {online_expression} AS priority,
    model,
    max(totalTpm) AS capacity
FROM {CAPACITY_TABLE}
WHERE
    timestamp > {from_ts}
    AND timestamp < {to_ts}
    AND provider IN {sql_array(providers)}
    AND model IN {sql_array(models)}
    AND ({online_expression}) = '在线'
GROUP BY t, provider, model, priority
ORDER BY t, model"""


def usage_query_sql(
    model: str,
    providers: list[str],
    from_ts: int,
    to_ts: int,
    timezone_name: str,
) -> str:
    online_expression = (
        "CASE\n"
        "        WHEN x_ks_wq_request_schedule_priority IN "
        "('Critical', 'Standard') THEN '在线'\n"
        "        WHEN x_ks_wq_request_schedule_priority = "
        "'Sheddable' THEN '离线'\n"
        "        ELSE '在线'\n"
        "    END"
    )
    partition_start = (
        f"formatDateTime(toDateTime({from_ts}, "
        f"{sql_string(timezone_name)}), '%Y%m%d')"
    )
    partition_end = (
        f"formatDateTime(toDateTime({to_ts - 1}, "
        f"{sql_string(timezone_name)}), '%Y%m%d')"
    )
    return f"""SELECT
    toUnixTimestamp(toStartOfMinute(toDateTime(req_start_time/1000))) * 1000 AS t,
    x_ks_provider AS provider,
    {online_expression} AS priority,
    x_ks_wq_workload_id AS workload_id,
    x_higress_llm_model AS model,
    sum(ifNull(output_token, 0)) + sum(ifNull(input_token, 0)) AS token
FROM {USAGE_TABLE}
WHERE
    req_start_time / 1000 > {from_ts}
    AND req_start_time / 1000 < {to_ts}
    AND p_date >= {partition_start}
    AND p_date <= {partition_end}
    AND x_ks_provider IN {sql_array(providers)}
    AND x_higress_llm_model = {sql_string(model)}
    AND ({online_expression}) = '在线'
GROUP BY t, provider, priority, model, workload_id
ORDER BY t"""


def usage_batch_query_sql(
    models: list[str],
    providers: list[str],
    from_ts: int,
    to_ts: int,
    timezone_name: str,
) -> str:
    online_expression = (
        "CASE\n"
        "        WHEN x_ks_wq_request_schedule_priority IN "
        "('Critical', 'Standard') THEN '在线'\n"
        "        WHEN x_ks_wq_request_schedule_priority = "
        "'Sheddable' THEN '离线'\n"
        "        ELSE '在线'\n"
        "    END"
    )
    partition_start = (
        f"formatDateTime(toDateTime({from_ts}, "
        f"{sql_string(timezone_name)}), '%Y%m%d')"
    )
    partition_end = (
        f"formatDateTime(toDateTime({to_ts - 1}, "
        f"{sql_string(timezone_name)}), '%Y%m%d')"
    )
    return f"""SELECT
    toUnixTimestamp(toStartOfMinute(toDateTime(req_start_time/1000))) * 1000 AS t,
    x_ks_provider AS provider,
    {online_expression} AS priority,
    x_ks_wq_workload_id AS workload_id,
    x_higress_llm_model AS model,
    sum(ifNull(output_token, 0)) + sum(ifNull(input_token, 0)) AS token
FROM {USAGE_TABLE}
WHERE
    req_start_time / 1000 > {from_ts}
    AND req_start_time / 1000 < {to_ts}
    AND p_date >= {partition_start}
    AND p_date <= {partition_end}
    AND x_ks_provider IN {sql_array(providers)}
    AND x_higress_llm_model IN {sql_array(models)}
    AND ({online_expression}) = '在线'
GROUP BY t, provider, priority, model, workload_id
ORDER BY t, model"""


def model_key_sql(field: str) -> str:
    return (
        "lowerUTF8("
        f"replaceAll(replaceAll(replaceAll({field}, ' ', ''), '-', ''), '_', '')"
        ")"
    )


def model_candidates_sql(
    *,
    anchor_source: str,
    model_input: str,
    providers: list[str],
    priority: str,
    from_ts: int,
    to_ts: int,
    timezone_name: str,
) -> str:
    input_key = model_comparison_key(model_input)
    if not input_key:
        raise InputError("model-input 规范化后不能为空")
    family_prefix = input_key[:2]
    family_condition = (
        f"\n        OR startsWith(model_key, {sql_string(family_prefix)})"
        if len(input_key) >= 2
        else ""
    )
    strong_prefix_order = (
        f"(startsWith(model_key, {sql_string(input_key)}) "
        f"OR startsWith({sql_string(input_key)}, model_key)) DESC"
    )
    if anchor_source == "capacity":
        model_field = "model"
        source_key = model_key_sql(model_field)
        priority_expression = (
            "CASE WHEN scene IN ('batch', 'offline') "
            "THEN '离线' ELSE '在线' END"
        )
        return f"""WITH {source_key} AS model_key
SELECT
    model AS model,
    max(timestamp) AS last_seen_epoch_seconds
FROM {CAPACITY_TABLE}
WHERE
    timestamp > {from_ts}
    AND timestamp < {to_ts}
    AND provider IN {sql_array(providers)}
    AND ({priority_expression}) = {sql_string(priority)}
    AND model != ''
    AND (
        model_key = {sql_string(input_key)}
        OR startsWith(model_key, {sql_string(input_key)})
        OR startsWith({sql_string(input_key)}, model_key)
        {family_condition}
    )
GROUP BY model
ORDER BY
    model_key = {sql_string(input_key)} DESC,
    {strong_prefix_order},
    last_seen_epoch_seconds DESC,
    model
LIMIT {MODEL_CANDIDATE_LIMIT}"""

    if anchor_source != "usage":
        raise InputError("anchor-source 仅支持 capacity 或 usage")
    source_key = model_key_sql("x_higress_llm_model")
    priority_expression = (
        "CASE "
        "WHEN x_ks_wq_request_schedule_priority IN ('Critical', 'Standard') "
        "THEN '在线' "
        "WHEN x_ks_wq_request_schedule_priority = 'Sheddable' THEN '离线' "
        "ELSE '在线' END"
    )
    partition_start = (
        f"formatDateTime(toDateTime({from_ts}, "
        f"{sql_string(timezone_name)}), '%Y%m%d')"
    )
    partition_end = (
        f"formatDateTime(toDateTime({to_ts - 1}, "
        f"{sql_string(timezone_name)}), '%Y%m%d')"
    )
    return f"""WITH {source_key} AS model_key
SELECT
    x_higress_llm_model AS model,
    max(toInt64(req_start_time / 1000)) AS last_seen_epoch_seconds
FROM {USAGE_TABLE}
WHERE
    req_start_time / 1000 > {from_ts}
    AND req_start_time / 1000 < {to_ts}
    AND p_date >= {partition_start}
    AND p_date <= {partition_end}
    AND x_ks_provider IN {sql_array(providers)}
    AND ({priority_expression}) = {sql_string(priority)}
    AND x_higress_llm_model != ''
    AND (
        model_key = {sql_string(input_key)}
        OR startsWith(model_key, {sql_string(input_key)})
        OR startsWith({sql_string(input_key)}, model_key)
        {family_condition}
    )
GROUP BY model
ORDER BY
    model_key = {sql_string(input_key)} DESC,
    {strong_prefix_order},
    last_seen_epoch_seconds DESC,
    model
LIMIT {MODEL_CANDIDATE_LIMIT}"""


def query_model_candidates(
    args: argparse.Namespace,
    *,
    resolved_window: dict[str, Any] | None = None,
    generated_at: str | None = None,
) -> dict[str, Any]:
    window = resolved_window or resolve_query_window(
        args,
        fixture_mode=bool(args.fixture),
    )
    model_input = validate_query_text(args.model_input, "model-input")
    providers = list(
        dict.fromkeys(
            validate_query_text(provider, "provider")
            for provider in args.provider
        )
    )
    if not providers:
        raise InputError("至少提供一个 provider")
    unsupported = [
        provider for provider in providers if provider not in PROVIDER_SCOPE_BY_VALUE
    ]
    if unsupported:
        raise InputError(
            "provider 仅支持 internal 或 public；收到：" + ",".join(unsupported)
        )
    if args.from_ts >= args.to_ts:
        raise InputError("from 必须小于 to")
    duration = args.to_ts - args.from_ts
    if duration < 60 or duration > MAX_QUERY_WINDOW_SECONDS:
        raise InputError("模型候选查询窗口必须在 60 秒～32 天之间")
    if not 1 <= args.timeout <= 600:
        raise InputError("timeout 必须在 1～600 秒之间")
    sql = model_candidates_sql(
        anchor_source=args.anchor_source,
        model_input=model_input,
        providers=providers,
        priority=args.priority,
        from_ts=args.from_ts,
        to_ts=args.to_ts,
        timezone_name=args.timezone,
    )
    result = query_or_fixture(sql, args.timeout, args.fixture)
    by_model: dict[str, dict[str, Any]] = {}
    for index, row in enumerate(result["data"]):
        if not isinstance(row, dict):
            raise InputError(f"data[{index}] 必须是对象")
        model = validate_query_text(row.get("model", ""), f"data[{index}].model")
        last_seen = integer_timestamp(
            row.get("last_seen_epoch_seconds"),
            f"data[{index}].last_seen_epoch_seconds",
        )
        current = by_model.get(model)
        if current is None or last_seen > current["last_seen_epoch_seconds"]:
            by_model[model] = {
                "model": model,
                "source": args.anchor_source,
                "last_seen_epoch_seconds": last_seen,
            }
    input_key = model_comparison_key(model_input)
    candidates = sorted(
        by_model.values(),
        key=lambda item: (
            candidate_recall_rank(item["model"], model_input),
            -item["last_seen_epoch_seconds"],
            item["model"],
        ),
    )[:MODEL_CANDIDATE_LIMIT]
    handoff = {
        "status": "ready",
        "anchor_source": args.anchor_source,
        "model_field": (
            "model" if args.anchor_source == "capacity" else "x_higress_llm_model"
        ),
        "candidates": candidates,
    }
    return {
        "schema_version": SCHEMA_VERSION,
        "script_version": SCRIPT_VERSION,
        "domain": "capacity",
        "scenario": "model-candidates",
        "status": "success",
        "generated_at": generated_at or utc_now(),
        "query": {
            "anchor_source": args.anchor_source,
            "table": CAPACITY_TABLE if args.anchor_source == "capacity" else USAGE_TABLE,
            "model_input": model_input,
            "comparison_key": input_key,
            "providers": providers,
            "priority": args.priority,
            "window": window,
            "source": "fixture" if args.fixture else "clickhouse",
            "candidate_limit": MODEL_CANDIDATE_LIMIT,
            "match_basis": (
                "comparison_key_equal_then_bidirectional_prefix_then_"
                "two_character_family"
            ),
            "sql": sql,
        },
        "summary": {
            "decision": "model_candidates_ready",
            "candidate_count": len(candidates),
            "candidates": candidates,
            "write_performed": False,
        },
        "handoffs": {"model_candidates": handoff},
        "evidence": {
            "clickhouse_meta": result.get("meta", []),
            "row_count": result.get("rows", len(result.get("data", []))),
            "statistics": result.get("statistics"),
        },
        "warnings": [],
        "errors": [],
    }


def candidate_batch_args(
    args: argparse.Namespace,
    model_input: str,
    fixture: str | None,
) -> argparse.Namespace:
    return argparse.Namespace(
        anchor_source=args.anchor_source,
        model_input=model_input,
        provider=list(args.provider),
        priority=args.priority,
        from_ts=args.from_ts,
        to_ts=args.to_ts,
        timezone=args.timezone,
        window_relation=args.window_relation,
        lookback_seconds=args.lookback_seconds,
        fixture=fixture,
        timeout=args.timeout,
    )


def candidate_batch_error_artifact(
    *,
    args: argparse.Namespace,
    model_input: str,
    index: int,
    resolved_window: dict[str, Any],
    generated_at: str,
    error: Exception,
) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "script_version": SCRIPT_VERSION,
        "domain": "capacity",
        "scenario": "model-candidates",
        "status": "error",
        "generated_at": generated_at,
        "query": {
            "anchor_source": args.anchor_source,
            "model_input": model_input,
            "providers": list(args.provider),
            "priority": args.priority,
            "window": resolved_window,
            "batch": {
                "enabled": True,
                "model_index": index,
                "model_count": len(args.model_input),
                "shared_window": True,
            },
        },
        "summary": {
            "decision": "model_candidate_query_failed",
            "candidate_count": 0,
            "candidates": [],
            "write_performed": False,
        },
        "handoffs": {},
        "evidence": {},
        "warnings": [],
        "errors": [str(error)],
    }


def query_model_candidates_batch(args: argparse.Namespace) -> dict[str, Any]:
    max_workers = validate_max_workers(args.max_workers)
    model_inputs = [
        validate_query_text(value, "model-input") for value in args.model_input
    ]
    if not 2 <= len(model_inputs) <= MAX_BATCH_MODEL_INPUTS:
        raise InputError(
            f"list-models-batch 必须提供 2～{MAX_BATCH_MODEL_INPUTS} 个 "
            "--model-input"
        )
    if len(set(model_inputs)) != len(model_inputs):
        raise InputError("批量 model-input 不得重复")

    fixtures = list(args.fixture or [])
    if fixtures and len(fixtures) != len(model_inputs):
        raise InputError(
            "批量 fixture 必须按 model-input 顺序逐一提供，数量必须一致"
        )
    resolved_window = resolve_query_window(
        args,
        fixture_mode=bool(fixtures),
    )
    generated_at = utc_now()
    output_dir = Path(args.output_dir).expanduser().resolve()

    def query_one(index: int) -> tuple[int, dict[str, Any], Path]:
        model_input = model_inputs[index]
        fixture = fixtures[index] if fixtures else None
        item_args = candidate_batch_args(args, model_input, fixture)
        try:
            artifact = query_model_candidates(
                item_args,
                resolved_window=resolved_window,
                generated_at=generated_at,
            )
            artifact["query"]["batch"] = {
                "enabled": True,
                "model_index": index,
                "model_count": len(model_inputs),
                "shared_window": True,
            }
        except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as exc:
            artifact = candidate_batch_error_artifact(
                args=args,
                model_input=model_input,
                index=index,
                resolved_window=resolved_window,
                generated_at=generated_at,
                error=exc,
            )
        output_path = output_dir / f"candidates-{index + 1:03d}.json"
        write_artifact(str(output_path), artifact)
        return index, artifact, output_path

    completed_by_index: dict[int, tuple[dict[str, Any], Path]] = {}
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(query_one, index): index
            for index in range(len(model_inputs))
        }
        for future in as_completed(futures):
            index, artifact, output_path = future.result()
            completed_by_index[index] = (artifact, output_path)

    items: list[dict[str, Any]] = []
    statuses: list[str] = []
    warnings: list[str] = []
    errors: list[str] = []
    for index, model_input in enumerate(model_inputs):
        artifact, output_path = completed_by_index[index]
        item_status = str(artifact.get("status", "error"))
        statuses.append(item_status)
        items.append(
            {
                "index": index,
                "model_input": model_input,
                "status": item_status,
                "artifact": str(output_path),
                "summary": artifact.get("summary", {}),
            }
        )
        warnings.extend(
            f"{model_input}: {item}"
            for item in artifact.get("warnings", [])
            if isinstance(item, str)
        )
        errors.extend(
            f"{model_input}: {item}"
            for item in artifact.get("errors", [])
            if isinstance(item, str)
        )

    if all(status == "success" for status in statuses):
        status = "success"
        decision = "model_candidates_batch_ready"
        handoff_status = "ready"
    elif all(status == "error" for status in statuses):
        status = "error"
        decision = "model_candidates_batch_failed"
        handoff_status = "blocked"
    else:
        status = "partial"
        decision = "model_candidates_batch_partial"
        handoff_status = "partial"
    return {
        "schema_version": SCHEMA_VERSION,
        "script_version": SCRIPT_VERSION,
        "domain": "capacity",
        "scenario": "model-candidates-batch",
        "status": status,
        "generated_at": generated_at,
        "query": {
            "anchor_source": args.anchor_source,
            "model_inputs": model_inputs,
            "providers": list(args.provider),
            "priority": args.priority,
            "window": resolved_window,
            "max_workers": max_workers,
            "execution": "bounded_parallel_input_order_output",
        },
        "summary": {
            "decision": decision,
            "input_count": len(model_inputs),
            "successful_input_count": statuses.count("success"),
            "failed_input_count": statuses.count("error"),
            "max_workers": max_workers,
            "shared_window": resolved_window,
            "remote_query_count": 0 if fixtures else len(model_inputs),
            "write_performed": False,
        },
        "artifacts": {"model_candidates": items},
        "handoffs": {
            "model_candidate_artifacts": {
                "status": handoff_status,
                "artifacts": [item["artifact"] for item in items],
            }
        },
        "warnings": warnings,
        "errors": errors,
    }



def query_headroom(
    args: argparse.Namespace,
    *,
    resolved_window: dict[str, Any] | None = None,
    query_observed_at: datetime | None = None,
    prefetched_capacity_result: dict[str, Any] | None = None,
    prefetched_usage_result: dict[str, Any] | None = None,
    capacity_sql_override: str | None = None,
    usage_sql_override: str | None = None,
) -> dict[str, Any]:
    if resolved_window is None:
        resolved_window = resolve_query_window(
            args,
            fixture_mode=bool(args.capacity_fixture and args.usage_fixture),
        )
    model, providers, timezone_value, model_resolution = validate_query_args(
        args
    )
    target_scenario = model_resolution.get("target_scenario")
    query_sources = CAPACITY_QUERY_SOURCES.get(
        str(target_scenario), frozenset({"capacity", "usage"})
    )
    supply_profile_query = target_scenario == "supply-profile"
    traffic_profile_query = target_scenario == "traffic-profile"
    capacity_sql = capacity_sql_override or (
        None
        if "capacity" not in query_sources
        else capacity_query_sql(
            model, providers, args.from_ts, args.to_ts
        )
    )
    capacity_result = (
        {"data": []}
        if "capacity" not in query_sources
        else prefetched_capacity_result
        if prefetched_capacity_result is not None
        else query_or_fixture(
            str(capacity_sql), args.timeout, args.capacity_fixture
        )
    )
    usage_sql = usage_sql_override or (
        None
        if "usage" not in query_sources
        else usage_query_sql(
            model,
            providers,
            args.from_ts,
            args.to_ts,
            args.timezone,
        )
    )
    usage_result = (
        {"data": []}
        if "usage" not in query_sources
        else prefetched_usage_result
        if prefetched_usage_result is not None
        else query_or_fixture(
            str(usage_sql), args.timeout, args.usage_fixture
        )
    )

    selected_providers = set(providers)
    if query_observed_at is None:
        query_observed_at = datetime.now(timezone_value)
    complete_before_ms = (
        min(
            args.to_ts,
            int(query_observed_at.timestamp())
            - DATA_FRESHNESS_GUARD_SECONDS,
        )
        // 60
    ) * 60 * 1000
    expected_latest_eligible_minute = complete_before_ms - 60_000
    current_window = args.to_ts >= (
        int(query_observed_at.timestamp()) - DATA_FRESHNESS_GUARD_SECONDS
    )
    effective_to_ts = min(args.to_ts, complete_before_ms // 1000)
    first_complete_minute_ts = ((args.from_ts + 59) // 60) * 60
    expected_complete_minutes = set(
        range(
            first_complete_minute_ts * 1000,
            effective_to_ts * 1000,
            60_000,
        )
    )
    expected_minute_count = len(expected_complete_minutes)
    capacity_by_provider: dict[str, dict[int, float]] = {
        provider: {} for provider in providers
    }
    accepted_capacity_rows = 0
    for index, row in enumerate(capacity_result["data"]):
        if not isinstance(row, dict):
            raise InputError(f"capacity.data[{index}] 必须是对象")
        provider = str(row.get("provider", ""))
        row_model = str(row.get("model", ""))
        priority = str(row.get("priority", ""))
        if (
            provider not in selected_providers
            or row_model != model
            or priority != "在线"
        ):
            continue
        timestamp_ms = integer_timestamp(
            row.get("t"), f"capacity.data[{index}].t"
        )
        capacity = finite_number(
            row.get("capacity"), f"capacity.data[{index}].capacity"
        )
        if timestamp_ms >= complete_before_ms:
            continue
        accepted_capacity_rows += 1
        current = capacity_by_provider[provider].get(timestamp_ms)
        if current is None or capacity > current:
            capacity_by_provider[provider][timestamp_ms] = capacity

    capacity_minute_sets = [
        set(capacity_by_provider[provider]) for provider in providers
    ]
    common_capacity_minutes = (
        set.intersection(*capacity_minute_sets)
        if capacity_minute_sets
        else set()
    )
    minute_capacity = {
        timestamp_ms: sum(
            capacity_by_provider[provider][timestamp_ms]
            for provider in providers
        )
        for timestamp_ms in common_capacity_minutes
    }
    latest_common_capacity_minute = (
        max(common_capacity_minutes)
        if common_capacity_minutes
        else None
    )
    latest_capacity: dict[str, tuple[int, float]] = {}
    if latest_common_capacity_minute is not None:
        latest_capacity = {
            provider: (
                latest_common_capacity_minute,
                capacity_by_provider[provider][latest_common_capacity_minute],
            )
            for provider in providers
        }

    supply_window_end_minute = (
        latest_common_capacity_minute
        if args.capacity_fixture
        else expected_latest_eligible_minute
    )
    supply_window_start_minute = (
        None
        if supply_window_end_minute is None
        else supply_window_end_minute
        - (CURRENT_SUPPLY_WINDOW_MINUTES - 1) * 60_000
    )
    expected_supply_minutes = (
        set()
        if supply_window_start_minute is None
        or supply_window_end_minute is None
        else {
            supply_window_start_minute + offset * 60_000
            for offset in range(CURRENT_SUPPLY_WINDOW_MINUTES)
        }
    )
    available_supply_minutes = sorted(
        expected_supply_minutes & common_capacity_minutes
    )
    supply_window_complete = (
        len(available_supply_minutes) == CURRENT_SUPPLY_WINDOW_MINUTES
    )
    supply_capacity_average_by_provider: list[dict[str, Any]] = []
    supply_capacity_average_tpm: float | None = None
    if supply_window_complete:
        supply_capacity_average_by_provider = [
            {
                "provider": provider,
                "capacity_tpm": round(
                    sum(
                        capacity_by_provider[provider][timestamp_ms]
                        for timestamp_ms in available_supply_minutes
                    )
                    / CURRENT_SUPPLY_WINDOW_MINUTES,
                    4,
                ),
            }
            for provider in providers
        ]
        supply_capacity_average_tpm = (
            sum(
                sum(
                    capacity_by_provider[provider][timestamp_ms]
                    for provider in providers
                )
                for timestamp_ms in available_supply_minutes
            )
            / CURRENT_SUPPLY_WINDOW_MINUTES
        )

    raw_usage_by_provider: dict[str, dict[int, float]] = {
        provider: {} for provider in providers
    }
    usage_providers: set[str] = set()
    workload_ids: set[str] = set()
    accepted_usage_rows = 0
    for index, row in enumerate(usage_result["data"]):
        if not isinstance(row, dict):
            raise InputError(f"usage.data[{index}] 必须是对象")
        provider = str(row.get("provider", ""))
        row_model = str(row.get("model", ""))
        priority = str(row.get("priority", ""))
        if (
            provider not in selected_providers
            or row_model != model
            or priority != "在线"
        ):
            continue
        timestamp_ms = integer_timestamp(
            row.get("t"), f"usage.data[{index}].t"
        )
        token = finite_number(
            row.get("token"), f"usage.data[{index}].token"
        )
        if timestamp_ms >= complete_before_ms:
            continue
        provider_usage = raw_usage_by_provider[provider]
        provider_usage[timestamp_ms] = (
            provider_usage.get(timestamp_ms, 0.0) + token
        )
        usage_providers.add(provider)
        workload_ids.add(str(row.get("workload_id", "")))
        accepted_usage_rows += 1

    raw_usage_minute_sets = [
        set(raw_usage_by_provider[provider])
        & expected_complete_minutes
        for provider in providers
    ]
    raw_common_usage_minutes = (
        set.intersection(*raw_usage_minute_sets)
        if raw_usage_minute_sets
        else set()
    )
    raw_usage_activity_minutes = set().union(*raw_usage_minute_sets)
    usage_zero_fill_enabled = (
        not supply_profile_query and not args.usage_fixture
    )
    if usage_zero_fill_enabled:
        usage_by_provider = {
            provider: {
                timestamp_ms: raw_usage_by_provider[provider].get(
                    timestamp_ms, 0.0
                )
                for timestamp_ms in expected_complete_minutes
            }
            for provider in providers
        }
        common_usage_minutes = set(expected_complete_minutes)
    else:
        usage_by_provider = raw_usage_by_provider
        common_usage_minutes = set(raw_common_usage_minutes)

    usage_observed_minute_count_by_provider = {
        provider: len(raw_usage_minute_sets[index])
        for index, provider in enumerate(providers)
    }
    usage_zero_filled_minute_count_by_provider = {
        provider: (
            expected_minute_count
            - usage_observed_minute_count_by_provider[provider]
            if usage_zero_fill_enabled
            else 0
        )
        for provider in providers
    }
    usage_zero_filled_provider_minute_count = sum(
        usage_zero_filled_minute_count_by_provider.values()
    )
    usage_zero_filled_minute_count = (
        len(expected_complete_minutes - raw_common_usage_minutes)
        if usage_zero_fill_enabled
        else 0
    )
    usage_total_provider_minute_count = (
        expected_minute_count * len(providers)
    )
    usage_raw_provider_minute_coverage_ratio = (
        0.0
        if usage_total_provider_minute_count == 0
        else sum(usage_observed_minute_count_by_provider.values())
        / usage_total_provider_minute_count
    )
    usage_raw_minute_coverage_ratio = (
        0.0
        if expected_minute_count == 0
        else len(raw_common_usage_minutes) / expected_minute_count
    )
    usage_raw_latest_activity_minute = (
        max(raw_usage_activity_minutes)
        if raw_usage_activity_minutes
        else None
    )
    usage_raw_latest_common_activity_minute = (
        max(raw_common_usage_minutes)
        if raw_common_usage_minutes
        else None
    )
    minute_usage = {
        timestamp_ms: sum(
            usage_by_provider[provider][timestamp_ms]
            for provider in providers
        )
        for timestamp_ms in common_usage_minutes
    }
    latest_common_usage_minute = (
        max(common_usage_minutes) if common_usage_minutes else None
    )
    current_observed_tpm = (
        minute_usage[latest_common_usage_minute]
        if latest_common_usage_minute is not None
        else None
    )
    current_usage_sample_origin_by_provider: dict[str, str] = {}
    current_usage_sample_origin: str | None = None
    if latest_common_usage_minute is not None:
        current_usage_sample_origin_by_provider = {
            provider: (
                "fixture_observed"
                if not usage_zero_fill_enabled
                else "clickhouse_observed"
                if latest_common_usage_minute
                in raw_usage_by_provider[provider]
                else "inferred_zero_sparse_usage_contract"
            )
            for provider in providers
        }
        current_origins = set(
            current_usage_sample_origin_by_provider.values()
        )
        current_usage_sample_origin = (
            next(iter(current_origins))
            if len(current_origins) == 1
            else "mixed_clickhouse_observed_and_inferred_zero"
        )
    current_usage_by_provider = []
    if (
        current_observed_tpm is not None
        and latest_common_usage_minute is not None
    ):
        current_usage_by_provider = [
            {
                "provider": provider,
                "tpm": round(
                    usage_by_provider[provider][
                        latest_common_usage_minute
                    ],
                    4,
                ),
                "share": (
                    None
                    if current_observed_tpm == 0
                    else round(
                        usage_by_provider[provider][
                            latest_common_usage_minute
                        ]
                        / current_observed_tpm,
                        6,
                    )
                ),
            }
            for provider in providers
        ]

    usage_window_end_minute = (
        latest_common_usage_minute
        if args.usage_fixture
        else expected_latest_eligible_minute
    )
    usage_window_start_minute = (
        None
        if usage_window_end_minute is None
        else usage_window_end_minute
        - (CURRENT_USAGE_WINDOW_MINUTES - 1) * 60_000
    )
    expected_current_usage_minutes = (
        set()
        if usage_window_start_minute is None
        or usage_window_end_minute is None
        else {
            usage_window_start_minute + offset * 60_000
            for offset in range(CURRENT_USAGE_WINDOW_MINUTES)
        }
    )
    available_current_usage_minutes = sorted(
        expected_current_usage_minutes & common_usage_minutes
    )
    usage_window_complete = (
        len(available_current_usage_minutes)
        == CURRENT_USAGE_WINDOW_MINUTES
    )
    current_usage_average_tpm: float | None = None
    current_usage_average_by_provider: list[dict[str, Any]] = []
    current_usage_observed_minute_count_by_provider = {
        provider: len(
            set(available_current_usage_minutes)
            & set(raw_usage_by_provider[provider])
        )
        for provider in providers
    }
    current_usage_inferred_zero_count_by_provider = {
        provider: (
            len(available_current_usage_minutes)
            - current_usage_observed_minute_count_by_provider[provider]
            if usage_zero_fill_enabled
            else 0
        )
        for provider in providers
    }
    current_usage_confidence_by_provider: dict[str, str] = {}
    current_usage_inferred_zero_only_providers: list[str] = []
    for provider in providers:
        observed_count = (
            current_usage_observed_minute_count_by_provider[provider]
        )
        inferred_count = (
            current_usage_inferred_zero_count_by_provider[provider]
        )
        if not usage_window_complete:
            confidence = "insufficient_window"
        elif not usage_zero_fill_enabled:
            confidence = "fixture_observed"
        elif observed_count == CURRENT_USAGE_WINDOW_MINUTES:
            confidence = "clickhouse_observed"
        elif observed_count == 0:
            confidence = "inferred_zero_only_sparse_contract"
            current_usage_inferred_zero_only_providers.append(provider)
        else:
            confidence = (
                "observed_and_inferred_zero_sparse_contract"
            )
        current_usage_confidence_by_provider[provider] = confidence
        if not usage_window_complete:
            current_usage_inferred_zero_count_by_provider[provider] = (
                max(0, inferred_count)
            )

    if usage_window_complete:
        provider_averages = {
            provider: sum(
                usage_by_provider[provider][timestamp_ms]
                for timestamp_ms in available_current_usage_minutes
            )
            / CURRENT_USAGE_WINDOW_MINUTES
            for provider in providers
        }
        current_usage_average_tpm = sum(provider_averages.values())
        current_usage_average_by_provider = [
            {
                "provider": provider,
                "tpm": round(provider_averages[provider], 4),
                "share": (
                    None
                    if current_usage_average_tpm == 0
                    or current_usage_inferred_zero_only_providers
                    else round(
                        provider_averages[provider]
                        / current_usage_average_tpm,
                        6,
                    )
                ),
                "observed_minute_count": (
                    current_usage_observed_minute_count_by_provider[
                        provider
                    ]
                ),
                "inferred_zero_count": (
                    current_usage_inferred_zero_count_by_provider[
                        provider
                    ]
                ),
                "confidence": (
                    current_usage_confidence_by_provider[provider]
                ),
            }
            for provider in providers
        ]
    aligned_minutes = common_usage_minutes & common_capacity_minutes
    aligned_minute_usage = {
        timestamp_ms: minute_usage[timestamp_ms]
        for timestamp_ms in aligned_minutes
    }
    aligned_minute_capacity = {
        timestamp_ms: sum(
            capacity_by_provider[provider][timestamp_ms]
            for provider in providers
        )
        for timestamp_ms in aligned_minutes
    }
    aligned_latest_minute = (
        max(aligned_minutes) if aligned_minutes else None
    )
    freshness_lag_seconds = (
        None
        if aligned_latest_minute is None
        else max(
            0,
            (expected_latest_eligible_minute - aligned_latest_minute)
            // 1000,
        )
    )
    aligned_minute_coverage_ratio = (
        0.0
        if expected_minute_count == 0
        else min(1.0, len(aligned_minutes) / expected_minute_count)
    )
    capacity_freshness_lag_seconds = (
        None
        if latest_common_capacity_minute is None
        else max(
            0,
            (
                expected_latest_eligible_minute
                - latest_common_capacity_minute
            )
            // 1000,
        )
    )
    usage_freshness_lag_seconds = (
        None
        if latest_common_usage_minute is None
        else max(
            0,
            (
                expected_latest_eligible_minute
                - latest_common_usage_minute
            )
            // 1000,
        )
    )
    usage_raw_activity_lag_seconds = (
        None
        if usage_raw_latest_activity_minute is None
        else max(
            0,
            (
                expected_latest_eligible_minute
                - usage_raw_latest_activity_minute
            )
            // 1000,
        )
    )
    capacity_minute_coverage_ratio = (
        0.0
        if expected_minute_count == 0
        else min(
            1.0,
            len(common_capacity_minutes) / expected_minute_count,
        )
    )
    usage_minute_coverage_ratio = (
        0.0
        if expected_minute_count == 0
        else min(
            1.0,
            len(common_usage_minutes) / expected_minute_count,
        )
    )
    production_query = not args.capacity_fixture and not args.usage_fixture
    traffic_profile_missing: list[str] = []
    if not current_window and not args.usage_fixture:
        traffic_profile_missing.append("usage_query.current_window")
    if not usage_window_complete:
        traffic_profile_missing.append(
            "usage_query.current_10m_complete_minutes"
            f"[{CURRENT_USAGE_WINDOW_MINUTES}个连续在线样本]"
        )
    if (
        production_query
        and current_window
        and usage_freshness_lag_seconds not in {None, 0}
    ):
        traffic_profile_missing.append(
            "usage_query.current_freshness_watermark"
        )
    traffic_profile_warnings = [
        (
            f"provider={provider} 的当前10分钟窗口全部来自稀疏写入补零；"
            "数值保留为 0，但证据不足以断言该 provider 无流量，"
            "所有 provider 占比返回 null，也不得据此表述其他 provider 占比为 100%"
        )
        for provider in current_usage_inferred_zero_only_providers
    ]
    supply_missing: list[str] = []
    missing_supply_providers = [
        provider
        for provider in providers
        if not capacity_by_provider[provider]
    ]
    if missing_supply_providers:
        supply_missing.append(
            "capacity_query.providers["
            + ",".join(missing_supply_providers)
            + "]"
        )
    if not current_window and not args.capacity_fixture:
        supply_missing.append("capacity_query.current_window")
    if not supply_window_complete:
        supply_missing.append(
            "capacity_query.current_30m_common_complete_minutes"
            f"[{CURRENT_SUPPLY_WINDOW_MINUTES}个连续在线样本]"
        )
    if (
        production_query
        and current_window
        and capacity_freshness_lag_seconds not in {None, 0}
    ):
        supply_missing.append("capacity_query.current_freshness_watermark")
    missing: list[str] = []
    missing_capacity_providers = [
        provider
        for provider in providers
        if not capacity_by_provider[provider]
    ]
    if missing_capacity_providers:
        missing.append(
            "capacity_query.providers["
            + ",".join(missing_capacity_providers)
            + "]"
        )
    elif latest_common_capacity_minute is None:
        missing.append("capacity_query.latest_common_complete_minute")
    missing_usage_providers = [
        provider
        for provider in providers
        if not usage_by_provider[provider]
    ]
    if missing_usage_providers:
        missing.append(
            "usage_query.providers["
            + ",".join(missing_usage_providers)
            + "]"
        )
    if len(common_capacity_minutes) < MIN_PERCENTILE_SAMPLE_COUNT:
        missing.append(
            "capacity_query.complete_minute_buckets"
            "[至少10个在线样本]"
        )
    if len(common_usage_minutes) < MIN_PERCENTILE_SAMPLE_COUNT:
        missing.append(
            "usage_query.complete_minute_buckets"
            "[至少10个在线样本]"
        )
    if (
        production_query
        and args.window_relation == "previous_day"
        and len(common_capacity_minutes) != expected_minute_count
    ):
        missing.append(
            "capacity_query.previous_day_complete_minute_coverage"
        )
    if (
        production_query
        and args.window_relation == "previous_day"
        and len(common_usage_minutes) != expected_minute_count
    ):
        missing.append(
            "usage_query.previous_day_complete_minute_coverage"
        )
    if (
        production_query
        and current_window
        and capacity_freshness_lag_seconds not in {None, 0}
    ):
        missing.append("capacity_query.current_freshness_watermark")
    if (
        production_query
        and current_window
        and usage_freshness_lag_seconds not in {None, 0}
    ):
        missing.append("usage_query.current_freshness_watermark")

    deployment: dict[str, Any] = {
        "total_capacity_tpm": sum(
            value[1] for value in latest_capacity.values()
        )
    }
    if args.gpu:
        deployment["gpu_type"] = args.gpu
    deployment["capacity_tpm_samples"] = [
        minute_capacity[timestamp_ms]
        for timestamp_ms in sorted(common_capacity_minutes)
    ]
    source: dict[str, Any] = {
        "model": model,
        "observed_at": query_observed_at.isoformat(),
        "window": resolved_window,
        "filters": {
            "providers": providers,
            "provider_scope": args.provider_scope,
            "model": model,
            "priority": "在线",
        },
        "traffic": {
            "tpm_samples": [
                minute_usage[timestamp_ms]
                for timestamp_ms in sorted(common_usage_minutes)
            ],
            "sample_semantics": (
                "observed_or_inferred_zero_by_sparse_clickhouse_contract"
                if usage_zero_fill_enabled
                else "observed_fixture_samples_only"
            ),
            "raw_common_minute_count": len(raw_common_usage_minutes),
            "zero_filled_minute_count": usage_zero_filled_minute_count,
            "zero_fill_policy": (
                USAGE_ZERO_FILL_POLICY
                if usage_zero_fill_enabled
                else None
            ),
        },
        "deployment": {
            **deployment,
            "provider_scope": args.provider_scope,
        },
        "policy": {
            "reserve_ratio": args.reserve_ratio,
            "detail_level": args.detail_level,
        },
    }
    if args.incremental_tpm is not None:
        source["demand"] = {"incremental_tpm": args.incremental_tpm}
    if args.single_instance_capacity_tpm is not None:
        source["kconf"] = {
            "single_instance_capacity_tpm":
                args.single_instance_capacity_tpm
        }
    elif args.kconf_artifact:
        source = attach_kconf_artifact(source, args.kconf_artifact, model)
    if args.isvc_artifact:
        source = attach_isvc_artifact(source, args.isvc_artifact, model)

    query_metadata = {
        "model_resolution": model_resolution,
        "source": {
            "capacity": (
                None
                if traffic_profile_query
                else "fixture"
                if args.capacity_fixture
                else "clickhouse"
            ),
            "usage": (
                None
                if supply_profile_query
                else "fixture"
                if args.usage_fixture
                else "clickhouse"
            ),
            "kconf": (
                "artifact"
                if args.kconf_artifact
                else "scalar"
                if args.single_instance_capacity_tpm is not None
                else None
            ),
            "isvc": "artifact" if args.isvc_artifact else None,
        },
        "filters": {
            "providers": providers,
            "provider_scope": args.provider_scope,
            "model": model,
            "priority": "在线",
            "capacity_online_definition": (
                "scene not in ('batch', 'offline'); all other values online"
            ),
            "usage_online_definition": (
                "Critical/Standard and CASE fallback online; Sheddable offline"
            ),
        },
        "window_epoch_seconds": {
            "from_exclusive": args.from_ts,
            "to_exclusive": args.to_ts,
            "timezone": args.timezone,
            "relation": args.window_relation,
            "resolution_source": resolved_window["resolution_source"],
            "resolved_at": resolved_window["resolved_at"],
            "complete_before_ms": complete_before_ms,
            "freshness_guard_seconds": DATA_FRESHNESS_GUARD_SECONDS,
            "expected_latest_eligible_minute": (
                expected_latest_eligible_minute
            ),
            "freshness_lag_seconds": freshness_lag_seconds,
            "capacity_freshness_lag_seconds": (
                capacity_freshness_lag_seconds
            ),
            "usage_freshness_lag_seconds": usage_freshness_lag_seconds,
            "usage_raw_activity_lag_seconds": (
                usage_raw_activity_lag_seconds
            ),
            "current_supply_window_minutes": (
                CURRENT_SUPPLY_WINDOW_MINUTES
            ),
            "current_supply_window_start_minute": (
                supply_window_start_minute
            ),
            "current_supply_window_end_minute": (
                supply_window_end_minute
            ),
            "current_supply_complete_minute_count": len(
                available_supply_minutes
            ),
            "current_usage_window_minutes": (
                CURRENT_USAGE_WINDOW_MINUTES
            ),
            "current_usage_window_start_minute": (
                usage_window_start_minute
            ),
            "current_usage_window_end_minute": usage_window_end_minute,
            "current_usage_complete_minute_count": len(
                available_current_usage_minutes
            ),
            "current_usage_observed_minute_count_by_provider": (
                current_usage_observed_minute_count_by_provider
            ),
            "current_usage_inferred_zero_count_by_provider": (
                current_usage_inferred_zero_count_by_provider
            ),
            "current_usage_confidence_by_provider": (
                current_usage_confidence_by_provider
            ),
            "expected_minute_count": expected_minute_count,
            "capacity_complete_minute_count": len(
                common_capacity_minutes
            ),
            "usage_complete_minute_count": len(common_usage_minutes),
            "usage_effective_minute_count": len(common_usage_minutes),
            "usage_raw_common_minute_count": len(
                raw_common_usage_minutes
            ),
            "usage_observed_minute_count_by_provider": (
                usage_observed_minute_count_by_provider
            ),
            "usage_zero_filled_minute_count_by_provider": (
                usage_zero_filled_minute_count_by_provider
            ),
            "usage_zero_filled_minute_count": (
                usage_zero_filled_minute_count
            ),
            "usage_zero_filled_provider_minute_count": (
                usage_zero_filled_provider_minute_count
            ),
            "capacity_minute_coverage_ratio": round(
                capacity_minute_coverage_ratio, 6
            ),
            "usage_minute_coverage_ratio": round(
                usage_minute_coverage_ratio, 6
            ),
            "usage_effective_minute_coverage_ratio": round(
                usage_minute_coverage_ratio, 6
            ),
            "usage_raw_minute_coverage_ratio": round(
                usage_raw_minute_coverage_ratio, 6
            ),
            "usage_raw_provider_minute_coverage_ratio": round(
                usage_raw_provider_minute_coverage_ratio, 6
            ),
            "aligned_minute_coverage_ratio": round(
                aligned_minute_coverage_ratio, 6
            ),
        },
        "capacity": {
            "table": None if traffic_profile_query else CAPACITY_TABLE,
            "sql": capacity_sql,
            "query_executed": not traffic_profile_query,
            "query_succeeded": (
                None if traffic_profile_query else True
            ),
            "returned_row_count": len(capacity_result["data"]),
            "accepted_row_count": accepted_capacity_rows,
        },
        "usage": {
            "table": None if supply_profile_query else USAGE_TABLE,
            "sql": usage_sql,
            "query_executed": not supply_profile_query,
            "query_succeeded": (
                None if supply_profile_query else True
            ),
            "returned_row_count": len(usage_result["data"]),
            "accepted_row_count": accepted_usage_rows,
            "partition_end_uses_to": True,
            "zero_fill_enabled": usage_zero_fill_enabled,
            "zero_fill_policy": (
                USAGE_ZERO_FILL_POLICY
                if usage_zero_fill_enabled
                else "disabled_for_supply_profile_or_fixture"
            ),
            "zero_fill_policy_version": (
                USAGE_ZERO_FILL_POLICY_VERSION
                if usage_zero_fill_enabled
                else None
            ),
            "zero_fill_confidence": (
                USAGE_ZERO_FILL_CONFIDENCE
                if usage_zero_fill_enabled
                else "not_applicable"
            ),
            "zero_fill_scope": (
                "verified_model_x_provider_x_complete_natural_minute"
                if usage_zero_fill_enabled
                else None
            ),
            "source_contract": (
                "zero usage model/provider minutes omit rows"
                if usage_zero_fill_enabled
                else None
            ),
        },
    }
    capacity_p90_evidence: float | None = None
    capacity_p90_rank: int | None = None
    traffic_p90_evidence: float | None = None
    traffic_p90_rank: int | None = None
    if common_capacity_minutes:
        capacity_p90_evidence, capacity_p90_rank = nearest_rank_percentile(
            [
                minute_capacity[timestamp_ms]
                for timestamp_ms in common_capacity_minutes
            ],
            0.90,
        )
    if common_usage_minutes:
        traffic_p90_evidence, traffic_p90_rank = nearest_rank_percentile(
            [
                minute_usage[timestamp_ms]
                for timestamp_ms in common_usage_minutes
            ],
            0.90,
        )

    query_evidence = {
        "name": (
            "clickhouse_online_capacity"
            if supply_profile_query
            else "clickhouse_online_usage"
            if traffic_profile_query
            else "clickhouse_online_capacity_and_usage"
        ),
        "latest_common_capacity_minute": latest_common_capacity_minute,
        "capacity_latest_by_provider": [
            {
                "provider": provider,
                "t": latest_capacity[provider][0],
                "capacity_tpm": round(latest_capacity[provider][1], 4),
            }
            for provider in providers
            if provider in latest_capacity
        ],
        "current_30m_capacity_window_start_minute": (
            supply_window_start_minute
        ),
        "current_30m_capacity_window_end_minute": supply_window_end_minute,
        "current_30m_capacity_complete_minute_count": len(
            available_supply_minutes
        ),
        "current_30m_capacity_average_tpm": (
            None
            if supply_capacity_average_tpm is None
            else round(supply_capacity_average_tpm, 4)
        ),
        "current_30m_capacity_average_by_provider": (
            supply_capacity_average_by_provider
        ),
        "latest_common_usage_minute": latest_common_usage_minute,
        "usage_raw_latest_activity_minute": (
            usage_raw_latest_activity_minute
        ),
        "usage_raw_latest_common_activity_minute": (
            usage_raw_latest_common_activity_minute
        ),
        "current_usage_by_provider": current_usage_by_provider,
        "current_usage_sample_origin": current_usage_sample_origin,
        "current_usage_sample_origin_by_provider": (
            current_usage_sample_origin_by_provider
        ),
        "current_10m_usage_window_start_minute": (
            usage_window_start_minute
        ),
        "current_10m_usage_window_end_minute": usage_window_end_minute,
        "current_10m_usage_window_end_exclusive": (
            None
            if usage_window_end_minute is None
            else usage_window_end_minute + 60_000
        ),
        "current_10m_usage_complete_minute_count": len(
            available_current_usage_minutes
        ),
        "current_10m_usage_average_tpm": (
            None
            if current_usage_average_tpm is None
            else round(current_usage_average_tpm, 4)
        ),
        "current_10m_usage_average_by_provider": (
            current_usage_average_by_provider
        ),
        "current_10m_usage_observed_minute_count_by_provider": (
            current_usage_observed_minute_count_by_provider
        ),
        "current_10m_usage_inferred_zero_count_by_provider": (
            current_usage_inferred_zero_count_by_provider
        ),
        "current_10m_usage_confidence_by_provider": (
            current_usage_confidence_by_provider
        ),
        "current_10m_usage_inferred_zero_only_providers": (
            current_usage_inferred_zero_only_providers
        ),
        "current_10m_provider_shares_reportable": (
            current_usage_average_tpm not in {None, 0}
            and not current_usage_inferred_zero_only_providers
        ),
        "usage_minute_bucket_count": len(minute_usage),
        "usage_provider_count": len(usage_providers),
        "usage_workload_count": len(workload_ids),
        "capacity_complete_minute_bucket_count": len(
            common_capacity_minutes
        ),
        "usage_complete_minute_bucket_count": len(common_usage_minutes),
        "usage_effective_minute_bucket_count": len(
            common_usage_minutes
        ),
        "usage_raw_complete_minute_bucket_count": len(
            raw_common_usage_minutes
        ),
        "usage_observed_minute_count_by_provider": (
            usage_observed_minute_count_by_provider
        ),
        "usage_zero_filled_minute_count_by_provider": (
            usage_zero_filled_minute_count_by_provider
        ),
        "usage_zero_filled_minute_count": (
            usage_zero_filled_minute_count
        ),
        "usage_zero_filled_provider_minute_count": (
            usage_zero_filled_provider_minute_count
        ),
        "capacity_minute_coverage_ratio": round(
            capacity_minute_coverage_ratio, 6
        ),
        "usage_minute_coverage_ratio": round(
            usage_minute_coverage_ratio, 6
        ),
        "usage_effective_minute_coverage_ratio": round(
            usage_minute_coverage_ratio, 6
        ),
        "usage_raw_minute_coverage_ratio": round(
            usage_raw_minute_coverage_ratio, 6
        ),
        "usage_raw_provider_minute_coverage_ratio": round(
            usage_raw_provider_minute_coverage_ratio, 6
        ),
        "aligned_complete_minute_bucket_count": len(aligned_minutes),
        "expected_minute_count": expected_minute_count,
        "aligned_minute_coverage_ratio": round(
            aligned_minute_coverage_ratio, 6
        ),
        "freshness_guard_seconds": DATA_FRESHNESS_GUARD_SECONDS,
        "freshness_lag_seconds": freshness_lag_seconds,
        "capacity_freshness_lag_seconds": capacity_freshness_lag_seconds,
        "usage_freshness_lag_seconds": usage_freshness_lag_seconds,
        "usage_raw_activity_lag_seconds": (
            usage_raw_activity_lag_seconds
        ),
        "usage_zero_fill_enabled": usage_zero_fill_enabled,
        "usage_zero_fill_policy": (
            USAGE_ZERO_FILL_POLICY
            if usage_zero_fill_enabled
            else "disabled_for_supply_profile_or_fixture"
        ),
        "usage_zero_fill_policy_version": (
            USAGE_ZERO_FILL_POLICY_VERSION
            if usage_zero_fill_enabled
            else None
        ),
        "usage_zero_fill_confidence": (
            USAGE_ZERO_FILL_CONFIDENCE
            if usage_zero_fill_enabled
            else "not_applicable"
        ),
        "usage_sample_semantics": (
            "observed_or_inferred_zero_by_sparse_clickhouse_contract"
            if usage_zero_fill_enabled
            else "observed_fixture_samples_only"
        ),
        "percentile_method": "nearest-rank",
        "percentile_sample_relation": (
            "independent_capacity_and_usage_complete_minute_sets"
        ),
        "p90_decision_eligible": (
            None
            if supply_profile_query or traffic_profile_query
            else not missing
        ),
        "traffic_profile_decision_eligible": (
            not traffic_profile_missing
            and not current_usage_inferred_zero_only_providers
            if traffic_profile_query
            else None
        ),
        "previous_day_capacity_p90_tpm": (
            None
            if capacity_p90_evidence is None
            else round(capacity_p90_evidence, 4)
        ),
        "previous_day_capacity_p90_rank": capacity_p90_rank,
        "previous_day_traffic_p90_tpm": (
            None
            if traffic_p90_evidence is None
            else round(traffic_p90_evidence, 4)
        ),
        "previous_day_traffic_p90_rank": traffic_p90_rank,
    }
    if supply_profile_query:
        rounded_supply_total = (
            None
            if supply_capacity_average_tpm is None
            else round(supply_capacity_average_tpm, 4)
        )
        supply_provider_summary = [
            {
                **row,
                "share": (
                    None
                    if not rounded_supply_total
                    else round(
                        float(row["capacity_tpm"])
                        / rounded_supply_total,
                        6,
                    )
                ),
            }
            for row in supply_capacity_average_by_provider
        ]
        artifact = base_artifact("query-headroom", source)
        artifact["status"] = "partial" if supply_missing else "success"
        artifact["summary"] = {
            "model": model,
            "observed_at": source["observed_at"],
            "window": source["window"],
            "decision": (
                "insufficient_data"
                if supply_missing
                else "supply_profile_available"
            ),
            "providers": providers,
            "provider_scope": args.provider_scope,
            "priority": "在线",
            "capacity_value_rule": (
                "arithmetic mean of provider-aligned capacity over the "
                "latest 30 complete natural minutes"
            ),
            "current_30m_capacity_window_start_minute": (
                supply_window_start_minute
            ),
            "current_30m_capacity_window_end_minute": (
                supply_window_end_minute
            ),
            "current_30m_capacity_window_end_exclusive": (
                None
                if supply_window_end_minute is None
                else supply_window_end_minute + 60_000
            ),
            "current_30m_capacity_complete_minute_count": len(
                available_supply_minutes
            ),
            "current_30m_capacity_average_tpm": rounded_supply_total,
            "current_30m_capacity_average_by_provider": (
                supply_provider_summary
            ),
            "installed_capacity_tpm": rounded_supply_total,
            "latest_common_capacity_minute": (
                latest_common_capacity_minute
            ),
            "write_performed": False,
        }
        artifact["query"] = query_metadata
        artifact["evidence"] = [query_evidence]
        artifact["handoffs"]["supply_profile"] = {
            "status": "partial" if supply_missing else "ready",
            "model": model,
            "providers": providers,
            "priority": "在线",
            "window_start_minute": supply_window_start_minute,
            "window_end_minute": supply_window_end_minute,
            "sample_count": len(available_supply_minutes),
            "capacity_average_tpm": rounded_supply_total,
            "capacity_average_by_provider": supply_provider_summary,
        }
        artifact["warnings"] = [
            "供给画像缺少必需证据：" + field
            for field in supply_missing
        ]
        return artifact

    if traffic_profile_query:
        rounded_usage_total = (
            None
            if current_usage_average_tpm is None
            else round(current_usage_average_tpm, 4)
        )
        profile_window = (
            None
            if usage_window_start_minute is None
            or usage_window_end_minute is None
            else {
                "start": datetime.fromtimestamp(
                    usage_window_start_minute / 1000,
                    timezone_value,
                ).isoformat(),
                "end": datetime.fromtimestamp(
                    (usage_window_end_minute + 60_000) / 1000,
                    timezone_value,
                ).isoformat(),
                "timezone": args.timezone,
                "relation": "current_10m",
            }
        )
        profile_input: dict[str, Any] | None = None
        if usage_window_complete and profile_window is not None:
            average_by_provider = {
                str(row["provider"]): row
                for row in current_usage_average_by_provider
            }
            profile_input = {
                "model": model,
                "observed_at": source["observed_at"],
                "as_of_minute": datetime.fromtimestamp(
                    usage_window_end_minute / 1000,
                    timezone_value,
                ).isoformat(),
                "priority": "在线",
                "tpm_basis": "observed_10m_average",
                "window": profile_window,
                "routes": [
                    {
                        "route_type": PROVIDER_SCOPE_BY_VALUE[provider],
                        "provider": provider,
                        "tpm": average_by_provider[provider]["tpm"],
                        "usage_evidence": {
                            "window_minutes": CURRENT_USAGE_WINDOW_MINUTES,
                            "observed_minute_count": (
                                current_usage_observed_minute_count_by_provider[
                                    provider
                                ]
                            ),
                            "inferred_zero_count": (
                                current_usage_inferred_zero_count_by_provider[
                                    provider
                                ]
                            ),
                            "confidence": (
                                current_usage_confidence_by_provider[provider]
                            ),
                        },
                    }
                    for provider in providers
                ],
            }

        traffic_partial = bool(
            traffic_profile_missing
            or current_usage_inferred_zero_only_providers
        )
        artifact = base_artifact("query-headroom", source)
        artifact["status"] = "partial" if traffic_partial else "success"
        artifact["summary"] = {
            "model": model,
            "observed_at": source["observed_at"],
            "window": source["window"],
            "decision": (
                "insufficient_data"
                if traffic_profile_missing
                else "traffic_profile_unconfirmed_zero"
                if current_usage_inferred_zero_only_providers
                else "traffic_profile_available"
            ),
            "providers": providers,
            "provider_scope": args.provider_scope,
            "priority": "在线",
            "tpm_basis": "observed_10m_average",
            "usage_value_rule": (
                "arithmetic mean of each provider over the same latest "
                "10 freshness-protected complete natural minutes"
            ),
            "current_10m_usage_window_start_minute": (
                usage_window_start_minute
            ),
            "current_10m_usage_window_end_minute": (
                usage_window_end_minute
            ),
            "current_10m_usage_window_end_exclusive": (
                None
                if usage_window_end_minute is None
                else usage_window_end_minute + 60_000
            ),
            "current_10m_usage_complete_minute_count": len(
                available_current_usage_minutes
            ),
            "current_10m_usage_average_tpm": rounded_usage_total,
            "current_10m_usage_average_by_provider": (
                current_usage_average_by_provider
            ),
            "current_10m_usage_observed_minute_count_by_provider": (
                current_usage_observed_minute_count_by_provider
            ),
            "current_10m_usage_inferred_zero_count_by_provider": (
                current_usage_inferred_zero_count_by_provider
            ),
            "current_10m_usage_confidence_by_provider": (
                current_usage_confidence_by_provider
            ),
            "current_10m_usage_inferred_zero_only_providers": (
                current_usage_inferred_zero_only_providers
            ),
            "current_10m_provider_shares_reportable": (
                current_usage_average_tpm not in {None, 0}
                and not current_usage_inferred_zero_only_providers
            ),
            # 兼容旧消费者：以下字段仍是最新单分钟诊断值。
            "latest_common_usage_minute": latest_common_usage_minute,
            "current_observed_tpm": (
                None
                if current_observed_tpm is None
                else round(current_observed_tpm, 4)
            ),
            "current_usage_tpm": (
                None
                if current_observed_tpm is None
                else round(current_observed_tpm, 4)
            ),
            "current_usage_by_provider": current_usage_by_provider,
            "current_usage_sample_origin": current_usage_sample_origin,
            "current_usage_sample_origin_by_provider": (
                current_usage_sample_origin_by_provider
            ),
            "usage_zero_fill_policy": (
                USAGE_ZERO_FILL_POLICY
                if usage_zero_fill_enabled
                else "disabled_for_fixture"
            ),
            "usage_zero_fill_policy_version": (
                USAGE_ZERO_FILL_POLICY_VERSION
                if usage_zero_fill_enabled
                else None
            ),
            "write_performed": False,
        }
        artifact["query"] = query_metadata
        artifact["evidence"] = [query_evidence]
        artifact["handoffs"]["traffic_profile"] = {
            "status": "partial" if traffic_partial else "ready",
            "model": model,
            "providers": providers,
            "priority": "在线",
            "tpm_basis": "observed_10m_average",
            "aggregation": "arithmetic_mean",
            "window_start_minute": usage_window_start_minute,
            "window_end_minute": usage_window_end_minute,
            "window_end_exclusive": (
                None
                if usage_window_end_minute is None
                else usage_window_end_minute + 60_000
            ),
            "sample_count": len(available_current_usage_minutes),
            "average_tpm": rounded_usage_total,
            "average_by_provider": current_usage_average_by_provider,
            "inferred_zero_only_providers": (
                current_usage_inferred_zero_only_providers
            ),
            "provider_shares_reportable": (
                current_usage_average_tpm not in {None, 0}
                and not current_usage_inferred_zero_only_providers
            ),
            "profile_input": profile_input,
        }
        artifact["warnings"] = [
            "流量画像缺少必需证据：" + field
            for field in traffic_profile_missing
        ] + traffic_profile_warnings
        return artifact

    cloud_reclaim_handoff: dict[str, Any] | None = None
    if providers == ["public"] and args.provider_scope == "cloud":
        capacity_minute_samples = [
            {
                "minute_start_epoch_seconds": timestamp_ms // 1000,
                "capacity_tpm": round(
                    minute_capacity[timestamp_ms], 4
                ),
            }
            for timestamp_ms in sorted(common_capacity_minutes)
        ]
        usage_minute_samples = [
            {
                "minute_start_epoch_seconds": timestamp_ms // 1000,
                "usage_tpm": round(minute_usage[timestamp_ms], 4),
                "sample_origin": (
                    "fixture_observed"
                    if not usage_zero_fill_enabled
                    else "clickhouse_observed"
                    if timestamp_ms in raw_usage_minute_sets[0]
                    else "inferred_zero_sparse_usage_contract"
                ),
            }
            for timestamp_ms in sorted(common_usage_minutes)
        ]
        cloud_reclaim_handoff = {
            "status": (
                "ready"
                if (
                    args.window_relation == "previous_day"
                    and not missing
                )
                else "partial"
            ),
            "model": model,
            "provider": "public",
            "priority": "在线",
            "window": source["window"],
            "selection_rule": (
                "independent nearest-rank P90 over capacity and usage "
                "complete-minute sets in the same business window; "
                "production usage materializes omitted zero-traffic "
                "minutes from the ClickHouse source contract"
            ),
            "capacity_minute_samples": capacity_minute_samples,
            "usage_minute_samples": usage_minute_samples,
            "capacity_sample_count": len(capacity_minute_samples),
            "usage_sample_count": len(usage_minute_samples),
            "expected_minute_count": expected_minute_count,
            "capacity_coverage_ratio": round(
                capacity_minute_coverage_ratio, 6
            ),
            "usage_coverage_ratio": round(
                usage_minute_coverage_ratio, 6
            ),
            "usage_raw_sample_count": len(raw_common_usage_minutes),
            "usage_raw_coverage_ratio": round(
                usage_raw_minute_coverage_ratio, 6
            ),
            "usage_zero_filled_sample_count": (
                usage_zero_filled_minute_count
            ),
            "usage_zero_fill_policy": (
                USAGE_ZERO_FILL_POLICY
                if usage_zero_fill_enabled
                else "disabled_for_fixture"
            ),
            "usage_zero_fill_policy_version": (
                USAGE_ZERO_FILL_POLICY_VERSION
                if usage_zero_fill_enabled
                else None
            ),
            "usage_zero_fill_confidence": (
                USAGE_ZERO_FILL_CONFIDENCE
                if usage_zero_fill_enabled
                else "not_applicable"
            ),
            # 兼容旧消费者；新计算不再依赖跨数据源共同分钟。
            "minute_samples": [
                {
                    "minute_start_epoch_seconds": timestamp_ms // 1000,
                    "capacity_tpm": round(
                        aligned_minute_capacity[timestamp_ms], 4
                    ),
                    "usage_tpm": round(
                        aligned_minute_usage[timestamp_ms], 4
                    ),
                    "usage_sample_origin": (
                        "fixture_observed"
                        if not usage_zero_fill_enabled
                        else "clickhouse_observed"
                        if timestamp_ms in raw_usage_minute_sets[0]
                        else "inferred_zero_sparse_usage_contract"
                    ),
                }
                for timestamp_ms in aligned_minutes
            ],
            "sample_count": len(aligned_minutes),
        }
    if missing:
        artifact = insufficient("query-headroom", source, missing)
        artifact["query"] = query_metadata
        artifact["evidence"] = [query_evidence]
        if cloud_reclaim_handoff is not None:
            artifact["handoffs"]["cloud_reclaim"] = (
                cloud_reclaim_handoff
            )
        return artifact

    artifact = headroom(source, args.resource_artifact, args.gpu)
    artifact["scenario"] = "query-headroom"
    artifact["query"] = query_metadata
    artifact["summary"].update(
        {
            "providers": providers,
            "provider_scope": args.provider_scope,
            "priority": "在线",
            "capacity_value_rule": (
                "sum(provider capacity at latest common complete minute)"
            ),
            "headroom_value_rule": (
                "nearest-rank P90(capacity) minus "
                "nearest-rank P90(traffic); serveability uses selected provider scope"
            ),
            "latest_common_capacity_minute":
                latest_common_capacity_minute,
            "latest_common_usage_minute": latest_common_usage_minute,
            "usage_raw_latest_activity_minute": (
                usage_raw_latest_activity_minute
            ),
            "current_observed_tpm": (
                None
                if current_observed_tpm is None
                else round(current_observed_tpm, 4)
            ),
            "current_usage_tpm": (
                None
                if current_observed_tpm is None
                else round(current_observed_tpm, 4)
            ),
            "current_usage_sample_origin": current_usage_sample_origin,
            "current_usage_sample_origin_by_provider": (
                current_usage_sample_origin_by_provider
            ),
            "current_usage_by_provider": current_usage_by_provider,
            "usage_minute_bucket_count": len(minute_usage),
            "capacity_complete_minute_bucket_count": len(
                common_capacity_minutes
            ),
            "usage_complete_minute_bucket_count": len(
                common_usage_minutes
            ),
            "usage_effective_minute_bucket_count": len(
                common_usage_minutes
            ),
            "usage_raw_complete_minute_bucket_count": len(
                raw_common_usage_minutes
            ),
            "usage_zero_filled_minute_count": (
                usage_zero_filled_minute_count
            ),
            "usage_zero_filled_provider_minute_count": (
                usage_zero_filled_provider_minute_count
            ),
            "usage_zero_fill_policy": (
                USAGE_ZERO_FILL_POLICY
                if usage_zero_fill_enabled
                else "disabled_for_supply_profile_or_fixture"
            ),
            "usage_zero_fill_policy_version": (
                USAGE_ZERO_FILL_POLICY_VERSION
                if usage_zero_fill_enabled
                else None
            ),
            "usage_zero_fill_confidence": (
                USAGE_ZERO_FILL_CONFIDENCE
                if usage_zero_fill_enabled
                else "not_applicable"
            ),
            "capacity_minute_coverage_ratio": round(
                capacity_minute_coverage_ratio, 6
            ),
            "usage_minute_coverage_ratio": round(
                usage_minute_coverage_ratio, 6
            ),
            "usage_effective_minute_coverage_ratio": round(
                usage_minute_coverage_ratio, 6
            ),
            "usage_raw_minute_coverage_ratio": round(
                usage_raw_minute_coverage_ratio, 6
            ),
        }
    )
    artifact["evidence"].append(query_evidence)
    if cloud_reclaim_handoff is not None:
        artifact["handoffs"]["cloud_reclaim"] = cloud_reclaim_handoff
    return artifact


def validate_max_workers(value: int) -> int:
    if not 1 <= value <= MAX_MAX_WORKERS:
        raise InputError(
            f"max-workers 必须在 1～{MAX_MAX_WORKERS} 之间"
        )
    return value


def result_for_model(
    result: dict[str, Any], model: str, field: str
) -> dict[str, Any]:
    rows = result.get("data")
    if not isinstance(rows, list):
        raise InputError(f"{field} ClickHouse 结果缺少 data 数组")
    selected: list[dict[str, Any]] = []
    for index, row in enumerate(rows):
        if not isinstance(row, dict):
            raise InputError(f"{field}.data[{index}] 必须是对象")
        if str(row.get("model", "")) == model:
            selected.append(row)
    return {**result, "data": selected}


def batch_model_args(
    args: argparse.Namespace,
    model_artifact: str,
    *,
    kconf_artifact: str | None = None,
    isvc_artifact: str | None = None,
) -> argparse.Namespace:
    return argparse.Namespace(
        model_artifact=model_artifact,
        model=None,
        provider=list(args.provider),
        provider_scope=args.provider_scope,
        from_ts=args.from_ts,
        to_ts=args.to_ts,
        timezone=args.timezone,
        window_relation=args.window_relation,
        lookback_seconds=args.lookback_seconds,
        incremental_tpm=args.incremental_tpm,
        single_instance_capacity_tpm=None,
        kconf_artifact=kconf_artifact,
        isvc_artifact=isvc_artifact,
        reserve_ratio=args.reserve_ratio,
        detail_level=args.detail_level,
        resource_artifact=args.resource_artifact,
        gpu=None,
        capacity_fixture=args.capacity_fixture,
        usage_fixture=args.usage_fixture,
        timeout=args.timeout,
    )


def batch_evidence_paths(
    manifest_value: str | None,
    *,
    manifest_scenario: str,
    artifact_key: str,
    artifact_scenario: str,
    models: list[str],
    model_artifacts: list[str],
) -> tuple[list[str | None], list[str]]:
    if manifest_value is None:
        return [None] * len(models), []

    manifest_path = Path(manifest_value).expanduser().resolve()
    manifest = load_object(str(manifest_path))
    if manifest.get("domain") != "capacity":
        raise InputError(f"{artifact_key} Manifest 的 domain 必须是 capacity")
    if manifest.get("scenario") != manifest_scenario:
        raise InputError(
            f"{artifact_key} Manifest 的 scenario 必须是 {manifest_scenario}"
        )
    if manifest.get("status") not in {"success", "partial", "error"}:
        raise InputError(f"{artifact_key} Manifest 的 status 无效")
    summary = manifest.get("summary")
    if not isinstance(summary, dict) or summary.get("models") != models:
        raise InputError(
            f"{artifact_key} Manifest 的模型和顺序必须与当前批次一致"
        )
    artifacts = manifest.get("artifacts")
    if not isinstance(artifacts, dict):
        raise InputError(f"{artifact_key} Manifest 缺少 artifacts")
    items = artifacts.get(artifact_key)
    if not isinstance(items, list) or len(items) != len(models):
        raise InputError(
            f"{artifact_key} Manifest Artifact 数量与当前批次不一致"
        )

    paths: list[str | None] = []
    warnings: list[str] = []
    for index, (model, model_artifact, item) in enumerate(
        zip(models, model_artifacts, items)
    ):
        if not isinstance(item, dict):
            raise InputError(f"{artifact_key} Manifest items[{index}] 必须是对象")
        if item.get("index") != index or item.get("model") != model:
            raise InputError(
                f"{artifact_key} Manifest items[{index}] 与当前模型顺序不一致"
            )
        artifact_value = item.get("artifact")
        if not isinstance(artifact_value, str) or not artifact_value.strip():
            raise InputError(
                f"{artifact_key} Manifest items[{index}].artifact 必须是路径"
            )
        artifact_path = Path(artifact_value).expanduser()
        if not artifact_path.is_absolute():
            artifact_path = manifest_path.parent / artifact_path
        artifact_path = artifact_path.resolve()
        artifact = load_object(str(artifact_path))
        if artifact.get("domain") != "capacity":
            raise InputError(f"{artifact_key} Artifact 的 domain 必须是 capacity")
        if artifact.get("scenario") != artifact_scenario:
            raise InputError(
                f"{artifact_key} Artifact 的 scenario 必须是 {artifact_scenario}"
            )
        item_status = str(item.get("status", "error"))
        if artifact.get("status") != item_status:
            raise InputError(
                f"{artifact_key} Manifest items[{index}] 状态与 Artifact 不一致"
            )
        query = artifact.get("query")
        if not isinstance(query, dict):
            raise InputError(f"{artifact_key} Artifact 缺少 query")
        validate_embedded_model_resolution(
            query.get("model_resolution"),
            expected_model=model,
            expected_domain="capacity",
            expected_scenario="headroom",
            expected_artifact=model_artifact,
            field=f"{artifact_key} Artifact query.model_resolution",
        )
        if item_status == "success":
            paths.append(str(artifact_path))
        else:
            paths.append(None)
            warnings.append(
                f"{model}: {artifact_key} 批量证据状态为 {item_status}，"
                "保留可计算的上游结果"
            )
    return paths, warnings


def batch_error_artifact(
    *,
    model: str,
    model_resolution: dict[str, Any],
    error: Exception,
    resolved_window: dict[str, Any],
) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "script_version": SCRIPT_VERSION,
        "domain": "capacity",
        "scenario": "query-headroom",
        "status": "error",
        "generated_at": utc_now(),
        "summary": {
            "decision": "batch_model_normalization_failed",
            "model": model,
            "write_performed": False,
        },
        "query": {
            "model_resolution": model_resolution,
            "window": resolved_window,
            "batch": {"enabled": True},
        },
        "evidence": [],
        "warnings": [],
        "errors": [str(error)],
    }


def query_headroom_batch(args: argparse.Namespace) -> dict[str, Any]:
    max_workers = validate_max_workers(args.max_workers)
    if not args.model_artifact:
        raise InputError("至少提供一个 --model-artifact")

    verified_models = [
        resolve_single_model(
            artifact_path=artifact_path,
            raw_model=None,
            expected_domain="capacity",
            allowed_scenarios=TARGET_SCENARIOS["capacity"],
        )
        for artifact_path in args.model_artifact
    ]
    models = [verified.model for verified in verified_models]
    if len(set(models)) != len(models):
        raise InputError("批量模型不得重复")
    target_scenarios = {
        str(verified.evidence.get("target_scenario"))
        for verified in verified_models
    }
    if len(target_scenarios) != 1:
        raise InputError(
            "同一批次的 model-resolution target_scenario 必须一致"
        )
    target_scenario = next(iter(target_scenarios))
    expansion_evidence_supplied = any(
        (
            args.kconf_manifest,
            args.isvc_manifest,
            args.resource_artifact,
        )
    )
    expansion_options_supplied = (
        args.incremental_tpm is not None
        or args.reserve_ratio != 0
        or expansion_evidence_supplied
    )
    if target_scenario != "headroom" and expansion_options_supplied:
        raise InputError(
            "新增 TPM、预留比例和扩容证据只适用于 headroom 批量场景"
        )
    if expansion_evidence_supplied and args.incremental_tpm is None:
        raise InputError(
            "提供批量扩容证据时必须同时提供 --incremental-tpm"
        )
    if args.resource_artifact and not args.isvc_manifest:
        raise InputError(
            "--resource-artifact 需要 --isvc-manifest 提供按卡型单实例卡数"
        )

    kconf_paths, kconf_warnings = batch_evidence_paths(
        args.kconf_manifest,
        manifest_scenario="kconf-normalize-batch",
        artifact_key="kconf",
        artifact_scenario="kconf-single-instance-capacity",
        models=models,
        model_artifacts=args.model_artifact,
    )
    isvc_paths, isvc_warnings = batch_evidence_paths(
        args.isvc_manifest,
        manifest_scenario="isvc-query-models",
        artifact_key="isvc",
        artifact_scenario="isvc-single-instance-cards",
        models=models,
        model_artifacts=args.model_artifact,
    )

    resolved_window = resolve_query_window(
        args,
        fixture_mode=bool(args.capacity_fixture and args.usage_fixture),
    )
    first_model_args = batch_model_args(
        args,
        args.model_artifact[0],
        kconf_artifact=kconf_paths[0],
        isvc_artifact=isvc_paths[0],
    )
    _, providers, timezone_value, _ = validate_query_args(first_model_args)
    if expansion_evidence_supplied and args.provider_scope != "self_deployed":
        raise InputError(
            "KConf、iSvc 和资源扩容证据只适用于 internal/self_deployed"
        )
    query_observed_at = datetime.now(timezone_value)
    query_sources = CAPACITY_QUERY_SOURCES[target_scenario]
    need_capacity = "capacity" in query_sources
    need_usage = "usage" in query_sources
    capacity_sql = (
        None
        if not need_capacity
        else capacity_batch_query_sql(
            models, providers, args.from_ts, args.to_ts
        )
    )
    usage_sql = (
        None
        if not need_usage
        else usage_batch_query_sql(
            models,
            providers,
            args.from_ts,
            args.to_ts,
            args.timezone,
        )
    )

    query_tasks: dict[str, tuple[str, str | None]] = {}
    if capacity_sql is not None:
        query_tasks["capacity"] = (capacity_sql, args.capacity_fixture)
    if usage_sql is not None:
        query_tasks["usage"] = (usage_sql, args.usage_fixture)
    shared_results: dict[str, dict[str, Any]] = {}
    with ThreadPoolExecutor(
        max_workers=min(max_workers, max(1, len(query_tasks)))
    ) as executor:
        futures = {
            executor.submit(
                query_or_fixture, sql, args.timeout, fixture
            ): name
            for name, (sql, fixture) in query_tasks.items()
        }
        for future in as_completed(futures):
            shared_results[futures[future]] = future.result()

    output_dir = Path(args.output_dir).expanduser().resolve()

    def normalize_one(index: int) -> tuple[int, dict[str, Any], Path]:
        verified = verified_models[index]
        model_args = batch_model_args(
            args,
            args.model_artifact[index],
            kconf_artifact=kconf_paths[index],
            isvc_artifact=isvc_paths[index],
        )
        try:
            artifact = query_headroom(
                model_args,
                resolved_window=resolved_window,
                query_observed_at=query_observed_at,
                prefetched_capacity_result=(
                    None
                    if not need_capacity
                    else result_for_model(
                        shared_results["capacity"],
                        verified.model,
                        "capacity",
                    )
                ),
                prefetched_usage_result=(
                    None
                    if not need_usage
                    else result_for_model(
                        shared_results["usage"],
                        verified.model,
                        "usage",
                    )
                ),
                capacity_sql_override=capacity_sql,
                usage_sql_override=usage_sql,
            )
            query = artifact.setdefault("query", {})
            if isinstance(query, dict):
                query["batch"] = {
                    "enabled": True,
                    "model_index": index,
                    "model_count": len(models),
                    "shared_window": True,
                    "shared_capacity_query": capacity_sql is not None,
                    "shared_usage_query": usage_sql is not None,
                }
            evidence_warnings = []
            if kconf_paths[index] is None and args.kconf_manifest:
                evidence_warnings.extend(
                    warning
                    for warning in kconf_warnings
                    if warning.startswith(f"{verified.model}:")
                )
            if isvc_paths[index] is None and args.isvc_manifest:
                evidence_warnings.extend(
                    warning
                    for warning in isvc_warnings
                    if warning.startswith(f"{verified.model}:")
                )
            artifact.setdefault("warnings", []).extend(evidence_warnings)
        except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as exc:
            artifact = batch_error_artifact(
                model=verified.model,
                model_resolution=verified.evidence,
                error=exc,
                resolved_window=resolved_window,
            )
        output_path = output_dir / f"headroom-{index + 1:03d}.json"
        write_artifact(str(output_path), artifact)
        return index, artifact, output_path

    completed_by_index: dict[int, tuple[dict[str, Any], Path]] = {}
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(normalize_one, index): index
            for index in range(len(models))
        }
        for future in as_completed(futures):
            index, artifact, output_path = future.result()
            completed_by_index[index] = (artifact, output_path)

    items: list[dict[str, Any]] = []
    warnings: list[str] = []
    errors: list[str] = []
    statuses: list[str] = []
    for index, model in enumerate(models):
        artifact, output_path = completed_by_index[index]
        status = str(artifact.get("status", "error"))
        statuses.append(status)
        items.append(
            {
                "index": index,
                "model": model,
                "status": status,
                "artifact": str(output_path),
                "summary": artifact.get("summary", {}),
            }
        )
        warnings.extend(
            f"{model}: {item}"
            for item in artifact.get("warnings", [])
            if isinstance(item, str)
        )
        errors.extend(
            f"{model}: {item}"
            for item in artifact.get("errors", [])
            if isinstance(item, str)
        )
    if all(status == "success" for status in statuses):
        status = "success"
    elif all(status == "error" for status in statuses):
        status = "error"
    else:
        status = "partial"
    expansion_evaluation_mode = (
        "per_model_independent"
        if target_scenario == "headroom" and args.incremental_tpm is not None
        else None
    )
    if args.resource_artifact and len(models) > 1:
        warnings.append(
            "资源充足性按模型独立评估；当前结果不能证明多个模型同时扩容时"
            "共享资源总量仍然足够"
        )
    return {
        "schema_version": SCHEMA_VERSION,
        "script_version": SCRIPT_VERSION,
        "domain": "capacity",
        "scenario": "query-headroom-batch",
        "status": status,
        "generated_at": utc_now(),
        "summary": {
            "decision": "batch_query_completed",
            "models": models,
            "model_count": len(models),
            "successful_model_count": statuses.count("success"),
            "partial_model_count": statuses.count("partial"),
            "failed_model_count": statuses.count("error"),
            "max_workers": max_workers,
            "shared_query_count": len(query_tasks),
            "remote_query_count": sum(
                fixture is None for _, fixture in query_tasks.values()
            ),
            "expansion_evaluation_mode": expansion_evaluation_mode,
            "window": resolved_window,
            "write_performed": False,
        },
        "artifacts": {"headroom": items},
        "query": {
            "target_scenario": target_scenario,
            "models": models,
            "providers": providers,
            "provider_scope": args.provider_scope,
            "incremental_tpm": args.incremental_tpm,
            "reserve_ratio": args.reserve_ratio,
            "kconf_manifest": (
                None
                if args.kconf_manifest is None
                else str(Path(args.kconf_manifest).expanduser().resolve())
            ),
            "isvc_manifest": (
                None
                if args.isvc_manifest is None
                else str(Path(args.isvc_manifest).expanduser().resolve())
            ),
            "resource_artifact": (
                None
                if args.resource_artifact is None
                else str(Path(args.resource_artifact).expanduser().resolve())
            ),
            "capacity_sql": capacity_sql,
            "usage_sql": usage_sql,
            "shared_window": resolved_window,
        },
        "warnings": warnings,
        "errors": errors,
    }



