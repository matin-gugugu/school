#!/usr/bin/env python3
"""Thin public router for Wanqing deterministic workflows.

Modern production commands load only their own pipeline. Legacy reclaim commands
remain available through a lazy compatibility module.
"""

from __future__ import annotations

import argparse
import importlib
import json
import sys
from typing import Any

from artifact_contract import annotate_outcome, terminal_brief
from model_contract import load_model_resolution
from runtime import write_artifact
from workflow_errors import WorkflowError


SCHEMA_VERSION = "1.0"
SCRIPT_VERSION = "2.6.0"

CAPACITY_COMMANDS = frozenset(
    {
        "capacity-analyze",
        "capacity-analyze-finalize",
        "render-capacity-report",
    }
)
RECLAIM_COMMANDS = frozenset(
    {
        "cloud-reclaim-prepare",
        "cloud-reclaim-finalize",
        "render-report",
    }
)
MODERN_COMMANDS = CAPACITY_COMMANDS | RECLAIM_COMMANDS
LEGACY_COMMANDS = frozenset(
    {"cloud-reclaim", "cloud-reclaim-explicit", "cloud-reclaim-all"}
)

__all__ = (
    "SCHEMA_VERSION",
    "SCRIPT_VERSION",
    "WorkflowError",
    "load_model_resolution",
    "load_cloud_reclaim_handoff",
    "build_parser",
    "main",
    "load_object",
    "run_cli",
    "resolve_reference",
    "add_cloud_reclaim_arguments",
    "validate_max_workers",
    "run_artifact_command",
    "prepare_isvc_artifacts",
    "run_cloud_reclaim",
    "absolutize_candidate_references",
    "merge_number_totals",
    "merge_card_type_totals",
    "run_cloud_reclaim_all",
)


def _legacy_module() -> Any:
    return importlib.import_module("legacy_workflow")


def __getattr__(name: str) -> Any:
    """Preserve lazy access to the former workflow.py module surface."""

    legacy = _legacy_module()
    try:
        return getattr(legacy, name)
    except AttributeError as exc:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}") from exc


def build_parser() -> argparse.ArgumentParser:
    """Return the complete legacy-compatible public parser on explicit request."""

    return _legacy_module().build_parser()


def load_cloud_reclaim_handoff(*args: Any, **kwargs: Any) -> Any:
    """Compatibility export without loading legacy reclaim code on normal paths."""

    return _legacy_module().load_cloud_reclaim_handoff(*args, **kwargs)


def _modern_parser(command: str, pipeline: Any) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="万擎单 Agent 多领域确定性 Workflow"
    )
    commands = parser.add_subparsers(dest="workflow", required=True)
    if command == "capacity-analyze":
        subparser = commands.add_parser(
            command,
            help=(
                "统一编排供给画像、流量画像和余量与扩容；"
                "简单查询直接完成，只有扩容换算需要 KConf 时暂停"
            ),
        )
        pipeline.add_analyze_arguments(subparser)
    elif command == "capacity-analyze-finalize":
        subparser = commands.add_parser(
            command,
            help="消费容量分析检查点与一次原始 KConf 返回，完成扩容证据计算",
        )
        pipeline.add_finalize_arguments(subparser)
    elif command == "render-capacity-report":
        subparser = commands.add_parser(
            command,
            help="只从可信 capacity-analyze 结果生成容量分析报告 Artifact",
        )
        pipeline.add_report_arguments(subparser)
    elif command == "cloud-reclaim-prepare":
        subparser = commands.add_parser(
            command,
            help=(
                "从用户范围自动完成候选发现、模型解析、前一日云上容量与"
                "成本、iSvc 查询，并只输出一次 KConf 工具调用"
            ),
        )
        pipeline.add_common_prepare_arguments(subparser)
    elif command == "cloud-reclaim-finalize":
        subparser = commands.add_parser(
            command,
            help="消费 prepare 计划与一次原始 KConf 返回，完成规范化和回收汇总",
        )
        pipeline.add_finalize_arguments(subparser)
    elif command == "render-report":
        subparser = commands.add_parser(
            command,
            help="只从可信 cloud-reclaim-finalize Manifest 生成官方报告 Artifact",
        )
        pipeline.add_report_arguments(subparser)
    else:  # pragma: no cover - guarded by MODERN_COMMANDS
        raise WorkflowError(f"未知 Workflow：{command}")
    return parser


def _run_modern(command: str) -> int:
    if command in CAPACITY_COMMANDS:
        pipeline = importlib.import_module("capacity_pipeline")
    else:
        pipeline = importlib.import_module("reclaim_pipeline")
    args = _modern_parser(command, pipeline).parse_args()
    try:
        if command == "capacity-analyze":
            manifest = pipeline.run_analyze(args)
        elif command == "capacity-analyze-finalize":
            manifest = pipeline.run_finalize(args)
        elif command == "render-capacity-report":
            manifest = pipeline.run_report(args)
        elif command == "cloud-reclaim-prepare":
            manifest = pipeline.run_prepare(args)
        elif command == "cloud-reclaim-finalize":
            manifest = pipeline.run_finalize(args)
        else:
            manifest = pipeline.run_report(args)
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as exc:
        manifest = pipeline.error_artifact(scenario=command, error=exc)
    annotate_outcome(manifest)
    try:
        output = write_artifact(args.output, manifest)
    except OSError as exc:
        print(json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False))
        return 1
    print(json.dumps(terminal_brief(manifest, output), ensure_ascii=False))
    return 0 if manifest["status"] in {"success", "partial"} else 1


def main() -> int:
    command = sys.argv[1] if len(sys.argv) > 1 else None
    if command in LEGACY_COMMANDS:
        return _legacy_module().main_legacy_command(command)
    if command not in MODERN_COMMANDS:
        return _legacy_module().main()
    return _run_modern(command)


if __name__ == "__main__":
    raise SystemExit(main())
