#!/usr/bin/env python3
"""Shared deterministic assembly for legacy and modern cloud reclaim flows.

The module validates upstream Artifacts, normalizes candidate evidence, invokes
the capacity calculation CLI, and aggregates GPU policy groups.  It contains no
public workflow parser and is safe for both modern and compatibility callers.
"""

from __future__ import annotations

import argparse
import copy
import json
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

from isvc import IsvcError, load_capacity_handoff
from kconf import KconfError, load_capacity_handoff as load_kconf_handoff
from model_contract import (
    VerifiedModel,
    load_model_resolution,
    validate_embedded_model_resolution,
)
from runtime import utc_now, write_artifact
from top_p_policy import (
    POLICY_SOURCE as TOP_P_POLICY_SOURCE,
    POLICY_VERSION as TOP_P_POLICY_VERSION,
    default_all_model_plan,
    validate_candidate_prefix,
    validate_explicit_candidate_selection,
)
from workflow_errors import WorkflowError


SCHEMA_VERSION = "1.0"
SCRIPT_VERSION = "2.5.0"
SCRIPT_ROOT = Path(__file__).resolve().parent
CAPACITY_SCRIPT = SCRIPT_ROOT / "capacity.py"
ISVC_SCRIPT = SCRIPT_ROOT / "isvc.py"
DEFAULT_MAX_WORKERS = 4
MAX_MAX_WORKERS = 8


def assemble_reclaim_workflow(
    workflow: str,
    *,
    input_path: str | Path,
    output_dir: str | Path,
    max_workers: int,
    isvc_endpoint: str | None = None,
    isvc_timeout: float = 30.0,
    isvc_fixture: str | None = None,
) -> dict[str, Any]:
    """Run one reclaim assembly mode without routing through workflow.py."""

    if workflow not in {
        "cloud-reclaim",
        "cloud-reclaim-explicit",
        "cloud-reclaim-all",
    }:
        raise WorkflowError(f"未知回收装配模式：{workflow}")
    args = argparse.Namespace(
        input=str(Path(input_path).expanduser().resolve()),
        output_dir=str(Path(output_dir).expanduser().resolve()),
        isvc_endpoint=isvc_endpoint,
        isvc_timeout=isvc_timeout,
        isvc_fixture=isvc_fixture,
        max_workers=max_workers,
    )
    if workflow == "cloud-reclaim-all":
        return run_cloud_reclaim_all(args)
    return run_cloud_reclaim(
        args,
        explicit_models=workflow == "cloud-reclaim-explicit",
    )


def load_object(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise WorkflowError(f"JSON 必须是对象：{path}")
    return value


def run_cli(command: list[str], label: str) -> None:
    completed = subprocess.run(
        command,
        check=False,
        capture_output=True,
        text=True,
    )
    if completed.returncode == 0:
        return
    detail = completed.stdout.strip() or completed.stderr.strip()
    raise RuntimeError(f"{label}失败：{detail or '无错误详情'}")


def resolve_reference(value: Any, field: str, base: Path) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise WorkflowError(f"{field} 必须是非空路径字符串")
    path = Path(value.strip()).expanduser()
    if not path.is_absolute():
        path = base / path
    return path.resolve()


def load_cloud_reclaim_handoff(
    artifact_path: Path,
    verified_model: VerifiedModel,
    model_artifact_path: Path,
) -> tuple[
    dict[str, Any],
    list[dict[str, Any]],
    list[dict[str, Any]],
]:
    artifact = load_object(artifact_path)
    if artifact.get("domain") != "capacity":
        raise WorkflowError("云上容量 Artifact 的 domain 必须是 capacity")
    if artifact.get("scenario") != "query-headroom":
        raise WorkflowError(
            "云上容量 Artifact 的 scenario 必须是 query-headroom"
        )
    if artifact.get("status") != "success":
        raise WorkflowError("云上容量 Artifact 的 status 必须是 success")
    query = artifact.get("query")
    if not isinstance(query, dict):
        raise WorkflowError("云上容量 Artifact 缺少 query")
    validate_embedded_model_resolution(
        query.get("model_resolution"),
        expected_model=verified_model.model,
        expected_domain="capacity",
        expected_scenario="cloud-reclaim",
        expected_artifact=model_artifact_path,
        field="云上容量 Artifact query.model_resolution",
    )
    summary = artifact.get("summary")
    if not isinstance(summary, dict):
        raise WorkflowError("云上容量 Artifact 缺少 summary")
    if summary.get("providers") != ["public"]:
        raise WorkflowError("云上容量回收只接受 provider=public")
    if summary.get("provider_scope") != "cloud":
        raise WorkflowError("云上容量回收只接受 provider_scope=cloud")
    if summary.get("priority") != "在线":
        raise WorkflowError("云上容量回收只接受 priority=在线")
    handoffs = artifact.get("handoffs")
    if not isinstance(handoffs, dict):
        raise WorkflowError("云上容量 Artifact 缺少 handoffs")
    handoff = handoffs.get("cloud_reclaim")
    if not isinstance(handoff, dict):
        raise WorkflowError("云上容量 Artifact 缺少 cloud_reclaim 交接")
    if handoff.get("status") != "ready":
        raise WorkflowError("cloud_reclaim 交接尚未 ready")
    if handoff.get("model") != verified_model.model:
        raise WorkflowError("cloud_reclaim 交接模型与候选模型不一致")
    if handoff.get("provider") != "public":
        raise WorkflowError("cloud_reclaim 交接 provider 必须是 public")
    if handoff.get("priority") != "在线":
        raise WorkflowError("cloud_reclaim 交接 priority 必须是在线")
    window = handoff.get("window")
    if not isinstance(window, dict) or window.get("relation") != "previous_day":
        raise WorkflowError("cloud_reclaim 交接必须是前一完整自然日")
    capacity_samples = handoff.get("capacity_minute_samples")
    usage_samples = handoff.get("usage_minute_samples")
    if capacity_samples is not None or usage_samples is not None:
        if (
            not isinstance(capacity_samples, list)
            or len(capacity_samples) < 10
        ):
            raise WorkflowError(
                "cloud_reclaim 容量交接至少需要 10 个完整分钟"
            )
        if not isinstance(usage_samples, list) or len(usage_samples) < 10:
            raise WorkflowError(
                "cloud_reclaim 用量交接至少需要 10 个完整分钟"
            )
        return window, capacity_samples, usage_samples

    # 兼容旧的共同分钟 Artifact；新生产 Artifact 使用两套独立样本。
    minute_samples = handoff.get("minute_samples")
    if not isinstance(minute_samples, list) or len(minute_samples) < 10:
        raise WorkflowError("cloud_reclaim 交接至少需要 10 个完整分钟")
    return (
        window,
        [
            {
                "minute_start_epoch_seconds": sample.get(
                    "minute_start_epoch_seconds"
                ),
                "capacity_tpm": sample.get("capacity_tpm"),
            }
            for sample in minute_samples
            if isinstance(sample, dict)
        ],
        [
            {
                "minute_start_epoch_seconds": sample.get(
                    "minute_start_epoch_seconds"
                ),
                "usage_tpm": sample.get("usage_tpm"),
            }
            for sample in minute_samples
            if isinstance(sample, dict)
        ],
    )



def validate_max_workers(value: int) -> int:
    if not 1 <= value <= MAX_MAX_WORKERS:
        raise WorkflowError(
            f"max-workers 必须在 1～{MAX_MAX_WORKERS} 之间"
        )
    return value


def run_artifact_command(
    command: list[str], output_path: Path, label: str
) -> tuple[subprocess.CompletedProcess[str], Path]:
    completed = subprocess.run(
        command,
        check=False,
        capture_output=True,
        text=True,
    )
    if not output_path.is_file():
        detail = completed.stdout.strip() or completed.stderr.strip()
        raise RuntimeError(
            f"{label}未生成 Artifact：{detail or '无错误详情'}"
        )
    return completed, output_path


def prepare_isvc_artifacts(
    candidates: list[Any],
    selected_count: int,
    *,
    input_path: Path,
    output_dir: Path,
    args: argparse.Namespace,
) -> tuple[list[str], list[str]]:
    max_workers = validate_max_workers(args.max_workers)
    batch_indices: list[int] = []
    batch_model_artifacts: list[Path] = []
    batch_service_selections: list[str] = []
    warnings: list[str] = []
    query_manifests: list[str] = []

    for index, candidate in enumerate(candidates[:selected_count]):
        if not isinstance(candidate, dict):
            raise WorkflowError(f"candidates[{index}] 必须是对象")
        model_artifact_path = resolve_reference(
            candidate.get("model_artifact"),
            f"candidates[{index}].model_artifact",
            input_path.parent,
        )
        verified = load_model_resolution(
            model_artifact_path,
            expected_domain="capacity",
            allowed_scenarios={"cloud-reclaim"},
        )
        raw_model = candidate.get("model")
        if raw_model is not None and (
            not isinstance(raw_model, str)
            or raw_model.strip() != verified.model
        ):
            raise WorkflowError(
                f"candidates[{index}].model 与 model_artifact 不一致"
            )
        candidate["model"] = verified.model
        candidate["model_artifact"] = str(model_artifact_path)

        isvc_input = candidate.get("isvc")
        if isvc_input is not None and not isinstance(isvc_input, dict):
            raise WorkflowError(f"candidates[{index}].isvc 必须是对象")
        isvc_input = isvc_input or {}
        if (
            "single_instance_gpu_cards" in isvc_input
            or "single_instance_gpu_cards_by_type" in isvc_input
        ):
            raise WorkflowError(
                f"candidates[{index}].isvc 不得人工填写卡数；"
                "请提供 artifact、service_name，或让 Workflow 查询 API"
            )
        artifact_value = isvc_input.get("artifact")
        if artifact_value is not None:
            artifact_path = resolve_reference(
                artifact_value,
                f"candidates[{index}].isvc.artifact",
                input_path.parent,
            )
            candidate["isvc"] = {**isvc_input, "artifact": str(artifact_path)}
            continue

        service_name = isvc_input.get("service_name")
        if service_name is not None and (
            not isinstance(service_name, str) or not service_name.strip()
        ):
            raise WorkflowError(
                f"candidates[{index}].isvc.service_name 必须是非空字符串"
            )
        batch_indices.append(index)
        batch_model_artifacts.append(model_artifact_path)
        if service_name is not None:
            batch_service_selections.append(
                f"{verified.model}={service_name.strip()}"
            )

    batch_manifest_path: Path | None = None
    tasks: dict[Any, tuple[str, int | None, Path]] = {}
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        if batch_model_artifacts:
            batch_output_dir = output_dir / "isvc-batch"
            batch_manifest_path = batch_output_dir / "manifest.json"
            command = [
                sys.executable,
                "-B",
                str(ISVC_SCRIPT),
                "query-models",
            ]
            for model_artifact in batch_model_artifacts:
                command.extend(["--model-artifact", str(model_artifact)])
            for selection in batch_service_selections:
                command.extend(["--service-selection", selection])
            command.extend(
                [
                    "--pool",
                    "online",
                    "--timeout",
                    str(args.isvc_timeout),
                    "--max-workers",
                    str(max_workers),
                    "--output-dir",
                    str(batch_output_dir),
                    "--output",
                    str(batch_manifest_path),
                ]
            )
            if args.isvc_endpoint:
                command.extend(["--endpoint", args.isvc_endpoint])
            if args.isvc_fixture:
                command.extend(["--fixture", args.isvc_fixture])
            future = executor.submit(
                run_artifact_command,
                command,
                batch_manifest_path,
                "iSvc 批量查询",
            )
            tasks[future] = ("batch", None, batch_manifest_path)

        for future in as_completed(tasks):
            future.result()

    if batch_manifest_path is not None:
        query_manifests.append(str(batch_manifest_path))
        manifest = load_object(batch_manifest_path)
        artifact_group = manifest.get("artifacts")
        items = (
            artifact_group.get("isvc", [])
            if isinstance(artifact_group, dict)
            else []
        )
        by_index = {
            int(item["index"]): item
            for item in items
            if isinstance(item, dict)
            and isinstance(item.get("index"), int)
            and isinstance(item.get("artifact"), str)
        }
        for local_index, candidate_index in enumerate(batch_indices):
            item = by_index.get(local_index)
            if item is None:
                warnings.append(
                    f"{candidates[candidate_index]['model']} iSvc 批量结果缺失"
                )
                candidates[candidate_index]["isvc"] = {}
                continue
            artifact_path = Path(str(item["artifact"])).expanduser().resolve()
            candidates[candidate_index]["isvc"] = {
                "artifact": str(artifact_path)
            }
            if item.get("status") != "success":
                warnings.append(
                    f"{candidates[candidate_index]['model']} iSvc 查询状态="
                    f"{item.get('status', 'error')}"
                )
    return warnings, query_manifests


def run_cloud_reclaim(
    args: argparse.Namespace,
    *,
    explicit_models: bool = False,
) -> dict[str, Any]:
    if not 1 <= args.isvc_timeout <= 600:
        raise WorkflowError("isvc-timeout 必须在 1～600 秒之间")
    validate_max_workers(args.max_workers)
    input_path = Path(args.input).expanduser().resolve()
    source = load_object(input_path)
    output_dir = Path(args.output_dir).expanduser().resolve()
    normalized = copy.deepcopy(source)
    detail_level = normalized.get("detail_level", "machines")
    if detail_level not in {"instances", "cards", "machines"}:
        raise WorkflowError(
            "detail_level 必须是 instances、cards 或 machines"
        )
    normalized["detail_level"] = detail_level
    candidates = normalized.get("candidates")
    if explicit_models:
        if normalized.get("policy") is not None:
            raise WorkflowError(
                "cloud-reclaim-explicit 不接受 policy；"
                "不得同时使用显式模型和 Top P"
            )
        selected_models = validate_explicit_candidate_selection(
            normalized.get("selection"), candidates
        )
        selected_count = len(selected_models)
        workflow_scenario = "cloud-reclaim-explicit"
    else:
        if normalized.get("selection") is not None:
            raise WorkflowError(
                "cloud-reclaim 不接受 selection；"
                "用户指定模型时请使用 cloud-reclaim-explicit"
            )
        _, top_p, _ = validate_candidate_prefix(
            normalized.get("policy"), candidates
        )
        selected_count = top_p
        workflow_scenario = "cloud-reclaim"
    assert isinstance(candidates, list)

    source_window: dict[str, Any] | None = None
    model_artifacts: list[dict[str, str]] = []
    capacity_artifacts: list[dict[str, str]] = []
    kconf_artifacts: list[dict[str, str]] = []
    isvc_artifacts: list[dict[str, str]] = []
    workflow_warnings: list[str] = []
    if detail_level == "instances":
        isvc_preparation_warnings: list[str] = []
        isvc_query_manifests: list[str] = []
    else:
        (
            isvc_preparation_warnings,
            isvc_query_manifests,
        ) = prepare_isvc_artifacts(
            candidates,
            selected_count,
            input_path=input_path,
            output_dir=output_dir,
            args=args,
        )
    workflow_warnings.extend(isvc_preparation_warnings)
    for index, candidate in enumerate(candidates[:selected_count]):
        if not isinstance(candidate, dict):
            raise WorkflowError(f"candidates[{index}] 必须是对象")
        model_artifact_value = candidate.get("model_artifact")
        if model_artifact_value is None:
            raise WorkflowError(
                f"candidates[{index}].model_artifact 必须指向成功的"
                " model-resolution Artifact"
            )
        model_artifact_path = resolve_reference(
            model_artifact_value,
            f"candidates[{index}].model_artifact",
            input_path.parent,
        )
        verified_model = load_model_resolution(
            model_artifact_path,
            expected_domain="capacity",
            allowed_scenarios={"cloud-reclaim"},
        )
        raw_model = candidate.get("model")
        if raw_model is not None and (
            not isinstance(raw_model, str)
            or raw_model.strip() != verified_model.model
        ):
            raise WorkflowError(
                f"candidates[{index}].model 与 model_artifact 不一致"
            )
        model = verified_model.model
        candidate["model"] = model
        candidate["model_artifact"] = str(model_artifact_path)
        model_artifacts.append(
            {"model": model, "artifact": str(model_artifact_path)}
        )
        cloud = candidate.get("cloud")
        if not isinstance(cloud, dict):
            raise WorkflowError(f"candidates[{index}].cloud 必须是对象")
        artifact_value = cloud.get("headroom_artifact")
        if artifact_value is not None:
            artifact_path = resolve_reference(
                artifact_value,
                f"candidates[{index}].cloud.headroom_artifact",
                input_path.parent,
            )
            cloud_artifact = load_object(artifact_path)
            cloud_query = cloud_artifact.get("query")
            if not isinstance(cloud_query, dict):
                raise WorkflowError("云上容量 Artifact 缺少 query")
            validate_embedded_model_resolution(
                cloud_query.get("model_resolution"),
                expected_model=model,
                expected_domain="capacity",
                expected_scenario="cloud-reclaim",
                expected_artifact=model_artifact_path,
                field="云上容量 Artifact query.model_resolution",
            )
            try:
                (
                    window,
                    capacity_minute_samples,
                    usage_minute_samples,
                ) = load_cloud_reclaim_handoff(
                    artifact_path,
                    verified_model,
                    model_artifact_path,
                )
            except WorkflowError as exc:
                candidate["cloud"] = {
                    "provider": "public",
                    "priority": "在线",
                }
                workflow_warnings.append(
                    f"{model} 云上容量证据不可用：{exc}"
                )
            else:
                if source_window is None:
                    source_window = window
                elif source_window != window:
                    raise WorkflowError("所有候选的云上容量窗口必须一致")
                candidate["cloud"] = {
                    "provider": "public",
                    "priority": "在线",
                    "capacity_minute_samples": capacity_minute_samples,
                    "usage_minute_samples": usage_minute_samples,
                }
            capacity_artifacts.append(
                {
                    "model": model.strip(),
                    "artifact": str(artifact_path),
                    "status": str(cloud_artifact.get("status", "error")),
                }
            )

        kconf_input = candidate.get("kconf")
        if not isinstance(kconf_input, dict):
            raise WorkflowError(f"candidates[{index}].kconf 必须是对象")
        kconf_artifact_value = kconf_input.get("artifact")
        if kconf_artifact_value is not None:
            if "single_instance_capacity_tpm" in kconf_input:
                raise WorkflowError(
                    f"candidates[{index}].kconf.artifact 与"
                    " single_instance_capacity_tpm 不得同时使用"
                )
            kconf_path = resolve_reference(
                kconf_artifact_value,
                f"candidates[{index}].kconf.artifact",
                input_path.parent,
            )
            kconf_artifact = load_object(kconf_path)
            kconf_query = kconf_artifact.get("query")
            if not isinstance(kconf_query, dict):
                raise WorkflowError("KConf Artifact 缺少 query")
            validate_embedded_model_resolution(
                kconf_query.get("model_resolution"),
                expected_model=model,
                expected_domain="capacity",
                expected_scenario="cloud-reclaim",
                expected_artifact=model_artifact_path,
                field="KConf Artifact query.model_resolution",
            )
            try:
                candidate["kconf"] = load_kconf_handoff(
                    kconf_path, model.strip()
                )
            except KconfError as exc:
                candidate["kconf"] = {}
                workflow_warnings.append(
                    f"{model.strip()} KConf 证据不可用：{exc}"
                )
            kconf_artifacts.append(
                {
                    "model": model.strip(),
                    "artifact": str(kconf_path),
                    "status": str(kconf_artifact.get("status", "error")),
                }
            )

        isvc_input = candidate.get("isvc")
        if isvc_input is not None and not isinstance(isvc_input, dict):
            raise WorkflowError(f"candidates[{index}].isvc 必须是对象")
        isvc_input = isvc_input or {}
        if (
            "single_instance_gpu_cards" in isvc_input
            or "single_instance_gpu_cards_by_type" in isvc_input
        ):
            raise WorkflowError(
                f"candidates[{index}].isvc 不得人工填写卡数；"
                "请提供 artifact、service_name，或让 Workflow 查询 API"
            )
        service_name = isvc_input.get("service_name")
        if service_name is not None and (
            not isinstance(service_name, str) or not service_name.strip()
        ):
            raise WorkflowError(
                f"candidates[{index}].isvc.service_name 必须是非空字符串"
            )
        artifact_value = isvc_input.get("artifact")
        if artifact_value is None:
            candidate.pop("isvc", None)
            if detail_level != "instances":
                workflow_warnings.append(
                    f"{model.strip()} iSvc 证据未生成；"
                    "本次只计算理论可回收实例数"
                )
            continue
        isvc_path = resolve_reference(
            artifact_value,
            f"candidates[{index}].isvc.artifact",
            input_path.parent,
        )

        isvc_result = load_object(isvc_path)
        isvc_query = isvc_result.get("query")
        if not isinstance(isvc_query, dict):
            raise WorkflowError("iSvc Artifact 缺少 query")
        validate_embedded_model_resolution(
            isvc_query.get("model_resolution"),
            expected_model=model,
            expected_domain="capacity",
            expected_scenario="cloud-reclaim",
            expected_artifact=model_artifact_path,
            field="iSvc Artifact query.model_resolution",
        )
        isvc_artifacts.append(
            {
                "model": model.strip(),
                "artifact": str(isvc_path),
                "status": str(isvc_result.get("status", "error")),
            }
        )
        try:
            candidate["isvc"] = load_capacity_handoff(
                isvc_path, model.strip()
            )
        except IsvcError as exc:
            candidate.pop("isvc", None)
            workflow_warnings.append(f"{model.strip()} iSvc 证据不可用：{exc}")
        workflow_warnings.extend(
            f"{model.strip()} iSvc：{item}"
            for item in isvc_result.get("warnings", [])
            if isinstance(item, str)
        )
        workflow_warnings.extend(
            f"{model.strip()} iSvc：{item}"
            for item in isvc_result.get("errors", [])
            if isinstance(item, str)
        )
    if source_window is not None:
        normalized["window"] = source_window

    normalized_input_path = output_dir / f"{workflow_scenario}-input.json"
    write_artifact(str(normalized_input_path), normalized)
    result_path = output_dir / f"{workflow_scenario}.json"
    run_cli(
        [
            sys.executable,
            "-B",
            str(CAPACITY_SCRIPT),
            "cloud-reclaim",
            "--input",
            str(normalized_input_path),
            "--output",
            str(result_path),
        ],
        "容量域 cloud-reclaim",
    )
    result = load_object(result_path)
    result_status = str(result.get("status", "error"))
    manifest_status = (
        "partial"
        if result_status == "success" and workflow_warnings
        else result_status
    )
    return {
        "schema_version": SCHEMA_VERSION,
        "domain": "workflow",
        "scenario": workflow_scenario,
        "status": manifest_status,
        "generated_at": utc_now(),
        "summary": result.get("summary", {}),
        "artifacts": {
            "model_resolution": model_artifacts,
            "cloud_capacity": capacity_artifacts,
            "kconf": kconf_artifacts,
            "isvc": isvc_artifacts,
            "isvc_query_manifests": isvc_query_manifests,
            "normalized_input": str(normalized_input_path),
            "cloud_reclaim": str(result_path),
        },
        "warnings": workflow_warnings + result.get("warnings", []),
        "errors": result.get("errors", []),
    }


def absolutize_candidate_references(
    candidates: Any,
    base: Path,
    gpu_type: str,
) -> list[dict[str, Any]]:
    if not isinstance(candidates, list):
        raise WorkflowError(f"candidates_by_gpu.{gpu_type} 必须是数组")
    normalized: list[dict[str, Any]] = []
    for index, raw_candidate in enumerate(candidates):
        if not isinstance(raw_candidate, dict):
            raise WorkflowError(
                f"candidates_by_gpu.{gpu_type}[{index}] 必须是对象"
            )
        candidate = copy.deepcopy(raw_candidate)
        model_artifact = candidate.get("model_artifact")
        if model_artifact is not None:
            candidate["model_artifact"] = str(
                resolve_reference(
                    model_artifact,
                    (
                        f"candidates_by_gpu.{gpu_type}[{index}]"
                        ".model_artifact"
                    ),
                    base,
                )
            )
        for section, artifact_field in (
            ("cloud", "headroom_artifact"),
            ("kconf", "artifact"),
            ("isvc", "artifact"),
        ):
            value = candidate.get(section)
            if value is None:
                continue
            if not isinstance(value, dict):
                raise WorkflowError(
                    f"candidates_by_gpu.{gpu_type}[{index}].{section} "
                    "必须是对象"
                )
            artifact = value.get(artifact_field)
            if artifact is not None:
                value[artifact_field] = str(
                    resolve_reference(
                        artifact,
                        (
                            f"candidates_by_gpu.{gpu_type}[{index}]."
                            f"{section}.{artifact_field}"
                        ),
                        base,
                    )
                )
        normalized.append(candidate)
    return normalized


def merge_number_totals(
    summaries: list[dict[str, Any]],
    field: str,
) -> int | float | None:
    values = [summary.get(field) for summary in summaries]
    if any(
        isinstance(value, bool) or not isinstance(value, (int, float))
        for value in values
    ):
        return None
    total = sum(values)
    return round(total, 4) if isinstance(total, float) else total


def merge_card_type_totals(
    summaries: list[dict[str, Any]],
    field: str,
) -> dict[str, int | float] | None:
    merged: dict[str, int | float] = {}
    for summary in summaries:
        value = summary.get(field)
        if not isinstance(value, dict):
            return None
        for card_type, count in value.items():
            if (
                not isinstance(card_type, str)
                or not card_type
                or isinstance(count, bool)
                or not isinstance(count, (int, float))
            ):
                return None
            merged[card_type] = merged.get(card_type, 0) + count
    return {
        card_type: round(value, 4) if isinstance(value, float) else value
        for card_type, value in sorted(merged.items())
    }


def run_cloud_reclaim_all(args: argparse.Namespace) -> dict[str, Any]:
    if not 1 <= args.isvc_timeout <= 600:
        raise WorkflowError("isvc-timeout 必须在 1～600 秒之间")
    max_workers = validate_max_workers(args.max_workers)
    input_path = Path(args.input).expanduser().resolve()
    source = load_object(input_path)
    detail_level = source.get("detail_level", "machines")
    if detail_level not in {"instances", "cards", "machines"}:
        raise WorkflowError(
            "detail_level 必须是 instances、cards 或 machines"
        )
    if "policy" in source or "candidates" in source:
        raise WorkflowError(
            "cloud-reclaim-all 不接受顶层 policy 或 candidates；"
            "请使用 candidates_by_gpu"
        )
    candidates_by_gpu = source.get("candidates_by_gpu")
    if not isinstance(candidates_by_gpu, dict):
        raise WorkflowError("candidates_by_gpu 必须是对象")

    plan = default_all_model_plan()
    expected_gpu_types = [item["gpu_type"] for item in plan]
    if set(candidates_by_gpu) != set(expected_gpu_types):
        raise WorkflowError(
            "candidates_by_gpu 必须且只能包含 "
            + "、".join(expected_gpu_types)
        )

    output_dir = Path(args.output_dir).expanduser().resolve()
    shared_source = copy.deepcopy(source)
    shared_source.pop("candidates_by_gpu", None)
    group_jobs: list[dict[str, Any]] = []
    all_candidates: list[dict[str, Any]] = []
    for position, plan_item in enumerate(plan, start=1):
        gpu_type = str(plan_item["gpu_type"])
        top_p = int(plan_item["top_p"])
        candidates = candidates_by_gpu.get(gpu_type)
        if not isinstance(candidates, list) or len(candidates) != top_p:
            raise WorkflowError(
                f"candidates_by_gpu.{gpu_type} 必须完整覆盖全部 "
                f"{top_p} 个白名单模型"
            )
        normalized_candidates = absolutize_candidate_references(
            candidates,
            input_path.parent,
            gpu_type,
        )
        validate_candidate_prefix(
            {"gpu_type": gpu_type, "top_p": top_p},
            normalized_candidates,
        )
        group_source = copy.deepcopy(shared_source)
        group_source["policy"] = {
            "gpu_type": gpu_type,
            "top_p": top_p,
        }
        group_source["candidates"] = normalized_candidates

        group_dir = output_dir / f"{position:02d}-{gpu_type.lower()}"
        group_input_path = group_dir / "workflow-input.json"
        group_manifest_path = group_dir / "workflow.json"
        all_candidates.extend(normalized_candidates)
        group_jobs.append(
            {
                "position": position,
                "gpu_type": gpu_type,
                "source": group_source,
                "dir": group_dir,
                "input": group_input_path,
                "manifest": group_manifest_path,
            }
        )

    if detail_level == "instances":
        shared_isvc_warnings: list[str] = []
        shared_isvc_manifests: list[str] = []
    else:
        (
            shared_isvc_warnings,
            shared_isvc_manifests,
        ) = prepare_isvc_artifacts(
            all_candidates,
            len(all_candidates),
            input_path=input_path,
            output_dir=output_dir / "shared-isvc",
            args=args,
        )

    def run_group(job: dict[str, Any]) -> tuple[int, dict[str, Any], dict[str, str]]:
        write_artifact(str(job["input"]), job["source"])
        group_args = argparse.Namespace(
            input=str(job["input"]),
            output_dir=str(job["dir"]),
            isvc_endpoint=args.isvc_endpoint,
            isvc_timeout=args.isvc_timeout,
            isvc_fixture=args.isvc_fixture,
            max_workers=max_workers,
            output=str(job["manifest"]),
        )
        group_manifest = run_cloud_reclaim(group_args)
        write_artifact(str(job["manifest"]), group_manifest)
        return (
            int(job["position"]),
            group_manifest,
            {
                "gpu_type": str(job["gpu_type"]),
                "artifact": str(job["manifest"]),
            },
        )

    completed_groups: dict[
        int, tuple[dict[str, Any], dict[str, str]]
    ] = {}
    with ThreadPoolExecutor(
        max_workers=min(max_workers, len(group_jobs))
    ) as executor:
        futures = {executor.submit(run_group, job): job for job in group_jobs}
        for future in as_completed(futures):
            position, manifest, artifact = future.result()
            completed_groups[position] = (manifest, artifact)
    group_manifests = [
        completed_groups[position][0]
        for position in range(1, len(group_jobs) + 1)
    ]
    group_manifest_artifacts = [
        completed_groups[position][1]
        for position in range(1, len(group_jobs) + 1)
    ]

    group_summaries = [
        manifest.get("summary", {}) for manifest in group_manifests
    ]
    if any(not isinstance(summary, dict) for summary in group_summaries):
        raise WorkflowError("卡型分组 Workflow Manifest 缺少 summary")
    windows = [summary.get("window") for summary in group_summaries]
    if not windows or not isinstance(windows[0], dict):
        raise WorkflowError("卡型分组结果缺少业务窗口")
    if any(window != windows[0] for window in windows[1:]):
        raise WorkflowError("X60 与 X40 必须使用同一业务窗口")

    flattened_candidates: list[dict[str, Any]] = []
    group_results: list[dict[str, Any]] = []
    warnings: list[str] = list(shared_isvc_warnings)
    errors: list[str] = []
    for plan_item, manifest, artifact in zip(
        plan, group_manifests, group_manifest_artifacts
    ):
        gpu_type = str(plan_item["gpu_type"])
        summary = manifest["summary"]
        for candidate in summary.get("candidates", []):
            if not isinstance(candidate, dict):
                raise WorkflowError(f"{gpu_type} 分组候选结果必须是对象")
            tagged_candidate = copy.deepcopy(candidate)
            tagged_candidate["policy_gpu_type"] = gpu_type
            flattened_candidates.append(tagged_candidate)
        group_results.append(
            {
                "gpu_type": gpu_type,
                "status": manifest.get("status"),
                "manifest": artifact["artifact"],
                "summary": summary,
            }
        )
        warnings.extend(
            f"{gpu_type}: {warning}"
            for warning in manifest.get("warnings", [])
        )
        errors.extend(
            f"{gpu_type}: {error}" for error in manifest.get("errors", [])
        )

    statuses = [
        str(manifest.get("status", "error")) for manifest in group_manifests
    ]
    if all(item == "success" for item in statuses):
        status = "success"
    elif all(item == "error" for item in statuses):
        status = "error"
    else:
        status = "partial"
    instances_total = merge_number_totals(
        group_summaries, "reclaimable_instances_total"
    )
    instances_partial_sum = merge_number_totals(
        group_summaries, "reclaimable_instances_partial_sum"
    )
    gpu_cards_complete = all(
        summary.get("gpu_card_savings_complete") is True
        for summary in group_summaries
    )
    gpu_card_types_complete = gpu_cards_complete and all(
        summary.get("gpu_card_type_savings_complete") is True
        for summary in group_summaries
    )
    gpu_cards_total = (
        merge_number_totals(group_summaries, "reclaimable_gpu_cards_total")
        if gpu_cards_complete
        else None
    )
    machine_equivalents_total = (
        merge_number_totals(
            group_summaries,
            "reclaimable_8_card_machine_equivalents_total",
        )
        if gpu_cards_complete
        else None
    )
    gpu_cards_by_type = (
        merge_card_type_totals(
            group_summaries, "reclaimable_gpu_cards_total_by_type"
        )
        if gpu_card_types_complete
        else None
    )
    machine_equivalents_by_type = (
        merge_card_type_totals(
            group_summaries,
            "reclaimable_8_card_machine_equivalents_total_by_type",
        )
        if gpu_card_types_complete
        else None
    )
    return {
        "schema_version": SCHEMA_VERSION,
        "domain": "workflow",
        "scenario": "cloud-reclaim-all",
        "status": status,
        "generated_at": utc_now(),
        "summary": {
            "decision": (
                "insufficient_data"
                if instances_total is None
                else "cloud_reclaim_candidates_available"
                if instances_total is not None and instances_total > 0
                else "no_reclaimable_instance"
            ),
            "window": windows[0],
            "requested_detail": detail_level,
            "top_p_policy_source": TOP_P_POLICY_SOURCE,
            "top_p_policy_version": TOP_P_POLICY_VERSION,
            "gpu_type_order": expected_gpu_types,
            "plan": plan,
            "evaluated_candidate_count": len(flattened_candidates),
            "candidates": flattened_candidates,
            "groups": group_results,
            "reclaimable_instances_total": instances_total,
            "reclaimable_instances_partial_sum": instances_partial_sum,
            "reclaimable_instances_capped_by_current_deployment": False,
            "max_workers": max_workers,
            "group_execution": "bounded_parallel_input_order_output",
            "gpu_card_savings_complete": gpu_cards_complete,
            "gpu_card_type_savings_complete": gpu_card_types_complete,
            "reclaimable_gpu_cards_total": gpu_cards_total,
            "reclaimable_gpu_cards_total_by_type": gpu_cards_by_type,
            "reclaimable_8_card_machine_equivalents_total": (
                machine_equivalents_total
            ),
            "reclaimable_8_card_machine_equivalents_total_by_type": (
                machine_equivalents_by_type
            ),
            "write_performed": False,
        },
        "artifacts": {
            "group_manifests": group_manifest_artifacts,
            "shared_isvc_manifests": shared_isvc_manifests,
        },
        "warnings": warnings,
        "errors": errors,
    }


