#!/usr/bin/env python3
"""Stable public exception types shared by workflow entry points."""


class WorkflowError(ValueError):
    """Raised when a workflow input is invalid."""
