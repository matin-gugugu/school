#!/usr/bin/env python3
"""Stable, compact report projection for capacity-analysis results."""

from __future__ import annotations

import copy
import math
from typing import Any


FIELDS_BY_SCENARIO = {
    "supply-profile": (
        "model",
        "observed_at",
        "decision",
        "providers",
        "provider_scope",
        "installed_capacity_tpm",
        "current_30m_capacity_average_tpm",
        "current_30m_capacity_average_by_provider",
        "current_30m_capacity_window_start_minute",
        "current_30m_capacity_window_end_exclusive",
    ),
    "traffic-profile": (
        "model",
        "observed_at",
        "decision",
        "providers",
        "provider_scope",
        "current_10m_usage_average_tpm",
        "current_10m_usage_average_by_provider",
        "current_10m_provider_shares_reportable",
        "current_10m_usage_window_start_minute",
        "current_10m_usage_window_end_exclusive",
    ),
    "headroom": (
        "model",
        "observed_at",
        "decision",
        "detail_level",
        "providers",
        "provider_scope",
        "previous_day_capacity_p90_tpm",
        "previous_day_traffic_p90_tpm",
        "reserve_ratio",
        "reserved_tpm",
        "raw_headroom_tpm",
        "usable_headroom_tpm",
        "incremental_demand_tpm",
        "deficit_tpm",
        "single_instance_capacity_tpm",
        "required_additional_instances",
        "single_instance_gpu_cards_by_type",
        "required_additional_gpu_cards",
        "required_additional_gpu_cards_by_type",
        "required_additional_8_card_machine_equivalents_by_type",
        "available_resource_machines_by_type",
        "resource_shortage_8_card_machine_equivalents_by_type",
    ),
}


def _required_metrics(scenario: str, detail: str, summary: dict[str, Any]) -> list[str]:
    if scenario == "supply-profile":
        return ["installed_capacity_tpm"]
    if scenario == "traffic-profile":
        return ["current_10m_usage_average_tpm"]
    required = ["usable_headroom_tpm"]
    if detail == "headroom":
        return required
    required.extend(["deficit_tpm", "decision"])
    deficit = summary.get("deficit_tpm")
    if not isinstance(deficit, (int, float)) or isinstance(deficit, bool) or deficit <= 0:
        return required
    if detail in {"instances", "cards", "resources"}:
        required.append("required_additional_instances")
    if detail in {"cards", "resources"}:
        required.extend(
            ["required_additional_gpu_cards", "required_additional_gpu_cards_by_type"]
        )
    if detail == "resources":
        required.extend(
            [
                "available_resource_machines_by_type",
                "resource_shortage_8_card_machine_equivalents_by_type",
            ]
        )
    return required


def _project_model(
    *,
    scenario: str,
    detail: str,
    model: Any,
    row: dict[str, Any],
) -> dict[str, Any]:
    summary = row.get("summary")
    if not isinstance(summary, dict):
        summary = {}
    metrics = {
        field: summary[field]
        for field in FIELDS_BY_SCENARIO.get(scenario, ())
        if field in summary and summary[field] is not None
    }
    required = _required_metrics(scenario, detail, summary)
    missing = [field for field in required if summary.get(field) is None]
    source_status = row.get("status")
    evidence_status = row.get("_evidence_status")
    evidence_complete = evidence_status == "success" and source_status != "error"
    requested_result_complete = (
        evidence_status == "success"
        and source_status == "success"
        and not missing
    )
    if requested_result_complete:
        status = "success"
        reason_code = "OK"
    elif evidence_status == "error" or source_status == "error":
        status = "error"
        evidence_reason = row.get("_evidence_reason_code")
        reason_code = (
            evidence_reason
            if isinstance(evidence_reason, str) and evidence_reason != "OK"
            else "EVIDENCE_MISSING"
        )
    else:
        status = "partial"
        reason_code = "EVIDENCE_MISSING"
    return {
        "model": summary.get("model") or model,
        "status": status,
        "reason_code": reason_code,
        "evidence_status": evidence_status,
        "requested_result_complete": requested_result_complete,
        "missing_requested_metrics": missing,
        "metrics": metrics,
        "quotable_metrics": sorted(metrics) if evidence_complete else [],
        "evidence_artifacts": {
            key: row[key]
            for key in ("artifact", "kconf_artifact", "isvc_artifact")
            if isinstance(row.get(key), str) and row[key]
        },
        "evidence_ids": {
            key: row[key]
            for key in (
                "evidence_id",
                "kconf_evidence_id",
                "isvc_evidence_id",
            )
            if isinstance(row.get(key), str) and row[key]
        },
    }


def _redundancy_overview(
    model_reports: list[dict[str, Any]],
    request: dict[str, Any],
) -> dict[str, Any]:
    redundant: list[dict[str, Any]] = []
    no_redundancy: list[dict[str, Any]] = []
    incomplete: list[dict[str, Any]] = []
    for model_report in model_reports:
        metrics = model_report["metrics"]
        headroom = metrics.get("usable_headroom_tpm")
        numeric_headroom = (
            isinstance(headroom, (int, float))
            and not isinstance(headroom, bool)
            and math.isfinite(float(headroom))
        )
        if not model_report["requested_result_complete"] or not numeric_headroom:
            incomplete.append(
                {
                    "model": model_report["model"],
                    "status": model_report["status"],
                    "reason_code": model_report["reason_code"],
                }
            )
            continue
        item = {
            "model": model_report["model"],
            "usable_headroom_tpm": headroom,
        }
        if headroom > 0:
            redundant.append(item)
        else:
            no_redundancy.append(item)

    redundant.sort(
        key=lambda item: (-float(item["usable_headroom_tpm"]), str(item["model"]))
    )
    no_redundancy.sort(key=lambda item: str(item["model"]))
    incomplete.sort(key=lambda item: str(item["model"]))
    return {
        "definition": "usable_headroom_tpm > 0",
        "model_scope": copy.deepcopy(request.get("model_scope")),
        "providers": copy.deepcopy(request.get("providers", [])),
        "provider_scope": request.get("provider_scope"),
        "evaluated_model_count": len(redundant) + len(no_redundancy),
        "redundant_model_count": len(redundant),
        "no_redundancy_model_count": len(no_redundancy),
        "incomplete_model_count": len(incomplete),
        "scan_complete": bool(model_reports) and not incomplete,
        "redundant_models": redundant,
        "no_redundancy_models": no_redundancy,
        "incomplete_models": incomplete,
    }


def build_report_tasks(tasks: list[Any]) -> list[dict[str, Any]]:
    report_tasks: list[dict[str, Any]] = []
    for task in tasks:
        if not isinstance(task, dict):
            raise ValueError("容量结果包含非法任务")
        scenario = str(task.get("scenario", ""))
        request = task.get("request") if isinstance(task.get("request"), dict) else {}
        detail = str(request.get("detail_level") or scenario)
        models = task.get("models") if isinstance(task.get("models"), list) else []
        rows = task.get("results") if isinstance(task.get("results"), list) else []
        model_reports = [
            _project_model(
                scenario=scenario,
                detail=detail,
                model=models[index] if index < len(models) else None,
                row=row if isinstance(row, dict) else {},
            )
            for index, row in enumerate(rows)
        ]
        complete = bool(model_reports) and all(
            model["requested_result_complete"] for model in model_reports
        )
        if complete:
            status = "success"
            reason_code = "OK"
        elif model_reports and all(
            model["status"] == "error" for model in model_reports
        ):
            status = "error"
            reason_code = "EVIDENCE_MISSING"
        else:
            status = "partial"
            reason_code = "EVIDENCE_MISSING"
        report_task = {
            "task_id": task.get("task_id"),
            "scenario": scenario,
            "requested_detail": detail,
            "status": status,
            "complete": complete,
            "reason_code": reason_code,
            "models": model_reports,
        }
        if scenario == "headroom":
            report_task["redundancy_overview"] = _redundancy_overview(
                model_reports, request
            )
        report_tasks.append(report_task)
    return report_tasks
