#!/usr/bin/env python3
"""Canonical workflow outcome, source evidence and checkpoint primitives."""

from __future__ import annotations

import copy
import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping


CORE_SCHEMA_VERSION = "2.0"
EVIDENCE_SCHEMA_VERSION = "2.1"
LEGACY_EVIDENCE_SCHEMA_VERSION = "2.0"

EVIDENCE_STATES = {"OK", "PARTIAL", "NO_DATA", "FAILED"}
REQUEST_STATES = {"COMPLETE", "PARTIAL", "NEEDS_INPUT", "FAILED"}

_INPUT_ACTION_TYPES = {
    "tool_call",
    "request_model_confirmation",
    "request_isvc_service_confirmation",
    "request_device_type",
}


class WorkflowCoreError(ValueError):
    """Raised when a canonical workflow object is inconsistent."""


def _is_input_action(action: Any) -> bool:
    return isinstance(action, Mapping) and action.get("type") in _INPUT_ACTION_TYPES


@dataclass(frozen=True)
class WorkflowOutcome:
    """Separate acquired-evidence state from requested-result state."""

    evidence_state: str
    request_state: str
    reason_code: str
    next_action: Any = "NONE"

    def __post_init__(self) -> None:
        if self.evidence_state not in EVIDENCE_STATES:
            raise WorkflowCoreError(
                "evidence_state 必须是 " + "、".join(sorted(EVIDENCE_STATES))
            )
        if self.request_state not in REQUEST_STATES:
            raise WorkflowCoreError(
                "request_state 必须是 " + "、".join(sorted(REQUEST_STATES))
            )
        if not isinstance(self.reason_code, str) or not self.reason_code.strip():
            raise WorkflowCoreError("reason_code 必须是非空字符串")
        if self.request_state == "COMPLETE" and self.evidence_state not in {
            "OK",
            "NO_DATA",
        }:
            raise WorkflowCoreError("COMPLETE 必须建立在 OK 或 NO_DATA 证据之上")
        if self.request_state == "FAILED" and self.evidence_state != "FAILED":
            raise WorkflowCoreError("FAILED 请求必须对应 FAILED 证据")
        if self.request_state == "NEEDS_INPUT" and not _is_input_action(
            self.next_action
        ):
            raise WorkflowCoreError("NEEDS_INPUT 必须包含可恢复的输入动作")

    @classmethod
    def from_legacy(
        cls,
        *,
        status: str,
        complete: bool,
        reason_code: str,
        next_action: Any,
    ) -> "WorkflowOutcome":
        evidence_state = (
            "NO_DATA"
            if reason_code == "NO_ROWS" and status != "error"
            else {
                "success": "OK",
                "partial": "PARTIAL",
                "error": "FAILED",
            }.get(status)
        )
        if evidence_state is None:
            raise WorkflowCoreError(
                "legacy status 必须是 success、partial 或 error"
            )
        request_state = (
            "COMPLETE"
            if complete
            else "FAILED"
            if status == "error"
            else "NEEDS_INPUT"
            if _is_input_action(next_action)
            else "PARTIAL"
        )
        return cls(
            evidence_state=evidence_state,
            request_state=request_state,
            reason_code=reason_code,
            next_action=copy.deepcopy(next_action),
        )

    @property
    def legacy_status(self) -> str:
        if self.evidence_state == "FAILED":
            return "error"
        if self.evidence_state == "PARTIAL":
            return "partial"
        if self.evidence_state == "NO_DATA" and self.request_state != "COMPLETE":
            return "partial"
        return "success"

    @property
    def complete(self) -> bool:
        return self.request_state == "COMPLETE"

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema_version": CORE_SCHEMA_VERSION,
            "evidence_state": self.evidence_state,
            "request_state": self.request_state,
            "reason_code": self.reason_code,
            "next_action": copy.deepcopy(self.next_action),
        }


def apply_outcome(artifact: dict[str, Any], outcome: WorkflowOutcome) -> None:
    """Write the canonical outcome and its legacy compatibility projection."""

    artifact["outcome"] = outcome.as_dict()
    artifact["status"] = outcome.legacy_status
    artifact["complete"] = outcome.complete
    artifact["reason_code"] = outcome.reason_code
    artifact["next_action"] = copy.deepcopy(outcome.next_action)


def validate_outcome_projection(artifact: Mapping[str, Any]) -> WorkflowOutcome:
    raw = artifact.get("outcome")
    if raw is None:
        return WorkflowOutcome.from_legacy(
            status=str(artifact.get("status")),
            complete=artifact.get("complete") is True,
            reason_code=str(artifact.get("reason_code") or "UNCLASSIFIED_ERROR"),
            next_action=artifact.get("next_action", "NONE"),
        )
    if not isinstance(raw, Mapping) or raw.get("schema_version") != CORE_SCHEMA_VERSION:
        raise WorkflowCoreError("outcome 缺少有效 schema_version")
    outcome = WorkflowOutcome(
        evidence_state=str(raw.get("evidence_state")),
        request_state=str(raw.get("request_state")),
        reason_code=str(raw.get("reason_code")),
        next_action=copy.deepcopy(raw.get("next_action", "NONE")),
    )
    expected = {
        "status": outcome.legacy_status,
        "complete": outcome.complete,
        "reason_code": outcome.reason_code,
        "next_action": outcome.next_action,
    }
    for field, value in expected.items():
        if artifact.get(field) != value:
            raise WorkflowCoreError(f"{field} 与 canonical outcome 不一致")
    return outcome


def _valid_digest(value: Any) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(character in "0123456789abcdef" for character in value.lower())
    )


def evidence_id(*, source: str, content_digest: str) -> str:
    """Return a location-independent ID for accepted source bytes."""

    digest = hashlib.sha256(
        f"{source}\0{content_digest}".encode("utf-8")
    ).hexdigest()
    return f"ev-{digest[:20]}"


def _legacy_path_evidence_id(path: str | Path, digest: str) -> str:
    resolved = str(Path(path).expanduser().resolve())
    identity = hashlib.sha256(f"{resolved}\0{digest}".encode("utf-8")).hexdigest()
    return f"ev-{identity[:20]}"


def _artifact_evidence_state(artifact: Mapping[str, Any]) -> str:
    status = artifact.get("status")
    summary = artifact.get("summary")
    if status == "error":
        return "FAILED"
    if artifact.get("reason_code") == "NO_ROWS" or (
        status == "success"
        and isinstance(summary, Mapping)
        and summary.get("candidate_count") == 0
    ):
        return "NO_DATA"
    if status == "partial":
        return "PARTIAL"
    return "OK" if status in {None, "success"} else "PARTIAL"


def _query_identity(artifact: Mapping[str, Any]) -> dict[str, Any]:
    identity: dict[str, Any] = {}
    query = artifact.get("query")
    if isinstance(query, Mapping):
        identity["query"] = copy.deepcopy(dict(query))
    source_input = artifact.get("input")
    if isinstance(source_input, Mapping):
        request = {
            key: copy.deepcopy(source_input[key])
            for key in ("model", "window", "filters", "policy", "demand")
            if key in source_input
        }
        if request:
            identity["request"] = request
    if not identity:
        identity = {
            key: artifact[key]
            for key in ("domain", "scenario")
            if isinstance(artifact.get(key), str) and artifact[key]
        }
    return identity


def _minimal_payload(artifact: Mapping[str, Any]) -> dict[str, Any]:
    summary = artifact.get("summary")
    if not isinstance(summary, Mapping):
        return {}
    return {
        str(key): copy.deepcopy(value)
        for key, value in summary.items()
        if (key in {"decision", "model"} or str(key).endswith("_count"))
        and (value is None or isinstance(value, (str, int, float, bool)))
    }


@dataclass(frozen=True)
class SourceEvidence:
    evidence_id: str
    source: str
    query_identity: Mapping[str, Any]
    state: str
    minimal_payload: Mapping[str, Any]
    content_digest: str
    locations: tuple[str, ...]
    roles: tuple[str, ...]

    def __post_init__(self) -> None:
        if not self.source or self.state not in EVIDENCE_STATES:
            raise WorkflowCoreError("SourceEvidence 的 source 或 state 无效")
        if not _valid_digest(self.content_digest):
            raise WorkflowCoreError("SourceEvidence.content_digest 必须是 SHA-256")
        if not isinstance(self.query_identity, Mapping) or not isinstance(
            self.minimal_payload, Mapping
        ):
            raise WorkflowCoreError("SourceEvidence 查询身份和最小结果必须是对象")
        if not self.locations or not self.roles:
            raise WorkflowCoreError("SourceEvidence 必须包含位置和角色")
        if self.evidence_id != evidence_id(
            source=self.source,
            content_digest=self.content_digest,
        ):
            raise WorkflowCoreError("SourceEvidence.evidence_id 与内容摘要不一致")

    def as_dict(self) -> dict[str, Any]:
        return {
            "evidence_id": self.evidence_id,
            "source": self.source,
            "query_identity": copy.deepcopy(dict(self.query_identity)),
            "state": self.state,
            "minimal_payload": copy.deepcopy(dict(self.minimal_payload)),
            "content_digest": self.content_digest,
            "locations": list(self.locations),
            "roles": list(self.roles),
        }


def source_evidence_from_artifact(
    *,
    artifact: Mapping[str, Any],
    path: str | Path,
    content_digest: str,
    role: str,
    source: str | None = None,
) -> SourceEvidence:
    resolved_source = source or artifact.get("artifact_type")
    if not isinstance(resolved_source, str) or not resolved_source:
        domain = artifact.get("domain")
        scenario = artifact.get("scenario")
        resolved_source = (
            f"{domain}/{scenario}"
            if isinstance(domain, str) and isinstance(scenario, str)
            else role
        )
    return SourceEvidence(
        evidence_id=evidence_id(
            source=resolved_source,
            content_digest=content_digest,
        ),
        source=resolved_source,
        query_identity=_query_identity(artifact),
        state=_artifact_evidence_state(artifact),
        minimal_payload=_minimal_payload(artifact),
        content_digest=content_digest,
        locations=(str(Path(path).expanduser().resolve()),),
        roles=(role,),
    )


def _legacy_source_evidence(parent: Mapping[str, Any], index: int) -> SourceEvidence:
    role = parent.get("role")
    path = parent.get("path")
    digest = parent.get("sha256")
    if not isinstance(role, str) or not isinstance(path, str) or not _valid_digest(digest):
        raise WorkflowCoreError(f"parents[{index}] 缺少有效 role、path 或 sha256")
    source = str(parent.get("artifact_type") or "legacy_artifact")
    return SourceEvidence(
        evidence_id=evidence_id(source=source, content_digest=digest),
        source=source,
        query_identity={},
        state="OK",
        minimal_payload={},
        content_digest=digest,
        locations=(str(Path(path).expanduser().resolve()),),
        roles=(role,),
    )


def _source_evidence_from_parent(
    parent: Mapping[str, Any], index: int
) -> SourceEvidence:
    raw = parent.get("source_evidence")
    if raw is None:
        return _legacy_source_evidence(parent, index)
    if not isinstance(raw, Mapping):
        raise WorkflowCoreError(f"parents[{index}].source_evidence 必须是对象")
    item = SourceEvidence(
        evidence_id=str(raw.get("evidence_id")),
        source=str(raw.get("source")),
        query_identity=raw.get("query_identity"),
        state=str(raw.get("state")),
        minimal_payload=raw.get("minimal_payload"),
        content_digest=str(raw.get("content_digest")),
        locations=tuple(raw.get("locations") or ()),
        roles=tuple(raw.get("roles") or ()),
    )
    resolved = str(Path(str(parent.get("path"))).expanduser().resolve())
    if (
        parent.get("sha256") != item.content_digest
        or resolved not in item.locations
        or parent.get("role") not in item.roles
    ):
        raise WorkflowCoreError(f"parents[{index}] 与 source_evidence 不一致")
    return item


def build_evidence_index(
    parents: Iterable[Mapping[str, Any]],
) -> dict[str, Any]:
    grouped: dict[str, dict[str, Any]] = {}
    order: list[str] = []
    for index, parent in enumerate(parents):
        if parent.get("lineage_only") is True and parent.get("source_evidence") is None:
            continue
        item = _source_evidence_from_parent(parent, index)
        existing = grouped.get(item.evidence_id)
        if existing is None:
            order.append(item.evidence_id)
            grouped[item.evidence_id] = item.as_dict()
            continue
        if existing["source"] != item.source or existing["content_digest"] != item.content_digest:
            raise WorkflowCoreError("同一 evidence_id 对应了不同内容")
        for field, values in (("locations", item.locations), ("roles", item.roles)):
            existing[field].extend(value for value in values if value not in existing[field])
    return {
        "schema_version": EVIDENCE_SCHEMA_VERSION,
        "items": [copy.deepcopy(grouped[item_id]) for item_id in order],
    }


def _validated_evidence_items(artifact: Mapping[str, Any]) -> list[dict[str, Any]]:
    index = artifact.get("evidence_index")
    if not isinstance(index, Mapping) or index.get("schema_version") not in {
        LEGACY_EVIDENCE_SCHEMA_VERSION,
        EVIDENCE_SCHEMA_VERSION,
    }:
        raise WorkflowCoreError("Artifact 缺少 canonical evidence_index")
    raw_items = index.get("items")
    if not isinstance(raw_items, list):
        raise WorkflowCoreError("evidence_index.items 必须是数组")
    items: list[dict[str, Any]] = []
    seen: set[str] = set()
    for position, raw in enumerate(raw_items):
        if not isinstance(raw, Mapping):
            raise WorkflowCoreError(f"evidence_index.items[{position}] 必须是对象")
        item_id = raw.get("evidence_id")
        roles = raw.get("roles")
        if not isinstance(item_id, str) or item_id in seen:
            raise WorkflowCoreError("evidence_index 包含无效或重复 evidence_id")
        if not isinstance(roles, list) or not roles:
            raise WorkflowCoreError(f"evidence_index.items[{position}] 缺少 roles")
        seen.add(item_id)
        if index.get("schema_version") == LEGACY_EVIDENCE_SCHEMA_VERSION:
            path = raw.get("path")
            digest = raw.get("sha256")
            if (
                not isinstance(path, str)
                or not _valid_digest(digest)
                or item_id != _legacy_path_evidence_id(path, digest)
            ):
                raise WorkflowCoreError(
                    f"evidence_index.items[{position}] 的 legacy 内容无效"
                )
            locations = [path]
        else:
            item = SourceEvidence(
                evidence_id=item_id,
                source=str(raw.get("source")),
                query_identity=raw.get("query_identity"),
                state=str(raw.get("state")),
                minimal_payload=raw.get("minimal_payload"),
                content_digest=str(raw.get("content_digest")),
                locations=tuple(raw.get("locations") or ()),
                roles=tuple(roles),
            )
            locations = list(item.locations)
        items.append(
            {
                "evidence_id": item_id,
                "roles": roles,
                "locations": [
                    str(Path(value).expanduser().resolve()) for value in locations
                ],
            }
        )
    return items


def evidence_paths_by_role(artifact: Mapping[str, Any]) -> dict[str, set[Path]]:
    result: dict[str, set[Path]] = {}
    for item in _validated_evidence_items(artifact):
        paths = {Path(value) for value in item["locations"]}
        for role in item["roles"]:
            result.setdefault(str(role), set()).update(paths)
    return result


def evidence_ids_by_role(artifact: Mapping[str, Any]) -> dict[str, set[str]]:
    result: dict[str, set[str]] = {}
    for item in _validated_evidence_items(artifact):
        for role in item["roles"]:
            result.setdefault(str(role), set()).add(item["evidence_id"])
    return result


def evidence_id_for_location(
    artifact: Mapping[str, Any], path: str | Path, *, role: str
) -> str:
    resolved = str(Path(path).expanduser().resolve())
    matches = [
        item["evidence_id"]
        for item in _validated_evidence_items(artifact)
        if role in item["roles"] and resolved in item["locations"]
    ]
    if len(matches) != 1:
        raise WorkflowCoreError(
            f"{role} 路径必须唯一对应一个 canonical evidence_id"
        )
    return matches[0]


def validate_evidence_reference(
    artifact: Mapping[str, Any],
    evidence_reference: str,
    *,
    role: str,
    compatibility_path: str | Path | None = None,
) -> None:
    if evidence_reference not in evidence_ids_by_role(artifact).get(role, set()):
        raise WorkflowCoreError(f"{role} evidence_id 不在 canonical evidence_index 中")
    if compatibility_path is not None and evidence_reference != evidence_id_for_location(
        artifact, compatibility_path, role=role
    ):
        raise WorkflowCoreError(f"{role} evidence_id 与兼容路径不一致")


def checkpoint_for(
    *, run_id: str, stage: str, outcome: WorkflowOutcome
) -> dict[str, Any] | None:
    if outcome.request_state != "NEEDS_INPUT":
        return None
    return {
        "schema_version": CORE_SCHEMA_VERSION,
        "run_id": run_id,
        "stage": stage,
        "state": "NEEDS_INPUT",
        "reason_code": outcome.reason_code,
        "pending_action": copy.deepcopy(outcome.next_action),
    }


def validate_checkpoint_projection(artifact: Mapping[str, Any]) -> None:
    if artifact.get("outcome") is None and artifact.get("checkpoint") is None:
        return
    outcome = validate_outcome_projection(artifact)
    checkpoint = artifact.get("checkpoint")
    if outcome.request_state != "NEEDS_INPUT":
        if checkpoint is not None:
            raise WorkflowCoreError("非暂停结果不得包含 checkpoint")
        return
    if not isinstance(checkpoint, Mapping):
        raise WorkflowCoreError("NEEDS_INPUT 结果缺少 checkpoint")
    expected = checkpoint_for(
        run_id=str(artifact.get("run_id")),
        stage=str(artifact.get("stage")),
        outcome=outcome,
    )
    if checkpoint != expected:
        raise WorkflowCoreError("checkpoint 与 canonical outcome 不一致")
