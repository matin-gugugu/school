#!/usr/bin/env python3
"""Deterministic cloud-cost formulas for the reclaim workflow."""

from __future__ import annotations

import copy
from decimal import Decimal, InvalidOperation
from typing import Any


COST_UNIT = "source_true_usage_cost_unit"
COST_FORMULA = (
    "cloud_reclaimable_tpm / previous_day_cloud_traffic_p90_tpm "
    "* previous_day_billable_usage_cost"
)


class CostMetricError(ValueError):
    """Raised when cost evidence cannot be consumed safely."""


def non_negative_decimal(value: Any, field: str) -> Decimal:
    if isinstance(value, bool) or value is None:
        raise CostMetricError(f"{field} 必须是非负有限数字")
    try:
        number = Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise CostMetricError(f"{field} 必须是非负有限数字") from exc
    if not number.is_finite() or number < 0:
        raise CostMetricError(f"{field} 必须是非负有限数字")
    return number


def json_number(value: Decimal) -> int | float:
    normalized = value.normalize()
    if normalized == normalized.to_integral_value():
        return int(normalized)
    return float(normalized)


def estimate_incremental_cloud_daily_cost(
    *,
    cloud_reclaimable_tpm: Any,
    previous_day_cloud_traffic_p90_tpm: Any,
    previous_day_billable_usage_cost: Any,
) -> dict[str, Any]:
    """Estimate the incremental daily cloud cost using exact decimal math."""

    reclaimable = non_negative_decimal(
        cloud_reclaimable_tpm, "cloud_reclaimable_tpm"
    )
    traffic = non_negative_decimal(
        previous_day_cloud_traffic_p90_tpm,
        "previous_day_cloud_traffic_p90_tpm",
    )
    cost = non_negative_decimal(
        previous_day_billable_usage_cost,
        "previous_day_billable_usage_cost",
    )
    if traffic == 0:
        return {
            "status": "partial",
            "reason_code": "ZERO_COST_BASIS_TRAFFIC",
            "cloud_reclaim_to_traffic_ratio": None,
            "estimated_incremental_cloud_daily_cost": None,
            "estimated_projected_cloud_daily_cost": None,
        }

    ratio = reclaimable / traffic
    incremental = ratio * cost
    return {
        "status": "success",
        "reason_code": "OK",
        "cloud_reclaim_to_traffic_ratio": json_number(ratio),
        "estimated_incremental_cloud_daily_cost": json_number(incremental),
        "estimated_projected_cloud_daily_cost": json_number(cost + incremental),
    }


def _cost_rows(cost_artifact: dict[str, Any]) -> dict[str, dict[str, Any]]:
    if cost_artifact.get("domain") != "cost":
        raise CostMetricError("成本 Artifact 的 domain 必须是 cost")
    if cost_artifact.get("scenario") != "cloud-daily-billing":
        raise CostMetricError(
            "成本 Artifact 的 scenario 必须是 cloud-daily-billing"
        )
    if cost_artifact.get("status") not in {"success", "partial"}:
        return {}
    summary = cost_artifact.get("summary")
    rows = summary.get("models") if isinstance(summary, dict) else None
    if not isinstance(rows, list):
        raise CostMetricError("成本 Artifact 缺少 summary.models")
    indexed: dict[str, dict[str, Any]] = {}
    for index, row in enumerate(rows):
        if not isinstance(row, dict):
            raise CostMetricError(f"成本 models[{index}] 必须是对象")
        model = row.get("model_name")
        if not isinstance(model, str) or not model or model in indexed:
            raise CostMetricError("成本 Artifact 包含空、重复模型")
        indexed[model] = row
    return indexed


def apply_cloud_cost_estimates(
    summary: dict[str, Any],
    *,
    cost_artifact: dict[str, Any] | None,
    cost_mode: str,
) -> tuple[dict[str, Any], bool | None, list[str]]:
    """Attach independent cost estimates without changing capacity results."""

    if cost_mode not in {"required", "fixture_replay_skipped"}:
        raise CostMetricError("cost_mode 无效")
    enriched = copy.deepcopy(summary)
    enriched["cloud_cost_estimation_mode"] = cost_mode
    if cost_mode == "fixture_replay_skipped":
        enriched.update(
            {
                "cloud_cost_estimation_complete": None,
                "cloud_cost_unit": None,
                "previous_day_billable_usage_cost_partial_sum": None,
                "previous_day_billable_usage_cost_total": None,
                "estimated_incremental_cloud_daily_cost_partial_sum": None,
                "estimated_incremental_cloud_daily_cost_total": None,
                "estimated_projected_cloud_daily_cost_total": None,
            }
        )
        return enriched, None, [
            "离线 fixture 回放未提供成本 fixture，已跳过云上成本估算"
        ]

    if cost_artifact is None:
        indexed: dict[str, dict[str, Any]] = {}
    else:
        indexed = _cost_rows(cost_artifact)
    candidates = enriched.get("candidates")
    if not isinstance(candidates, list):
        raise CostMetricError("容量结果缺少 candidates")

    warnings: list[str] = []
    previous_cost_partial = Decimal(0)
    incremental_partial = Decimal(0)
    projected_partial = Decimal(0)
    cost_evidence_successful = 0
    successful = 0
    for index, candidate in enumerate(candidates):
        if not isinstance(candidate, dict):
            raise CostMetricError(f"candidates[{index}] 必须是对象")
        model = candidate.get("model")
        row = indexed.get(str(model))
        candidate["cloud_cost_unit"] = COST_UNIT
        candidate["cloud_cost_formula"] = COST_FORMULA
        candidate["previous_day_billable_usage_cost"] = (
            None if row is None else row.get("billable_usage_cost")
        )
        candidate["cloud_cost_basis_traffic_p90_tpm"] = candidate.get(
            "previous_day_cloud_traffic_p90_tpm"
        )
        if row is not None and row.get("status") == "success":
            previous_cost_partial += non_negative_decimal(
                row.get("billable_usage_cost"),
                "previous_day_billable_usage_cost",
            )
            cost_evidence_successful += 1
        if row is None or row.get("status") != "success":
            estimate = {
                "status": "partial",
                "reason_code": "COST_EVIDENCE_MISSING",
                "cloud_reclaim_to_traffic_ratio": None,
                "estimated_incremental_cloud_daily_cost": None,
                "estimated_projected_cloud_daily_cost": None,
            }
        else:
            try:
                estimate = estimate_incremental_cloud_daily_cost(
                    cloud_reclaimable_tpm=candidate.get(
                        "cloud_reclaimable_tpm"
                    ),
                    previous_day_cloud_traffic_p90_tpm=candidate.get(
                        "previous_day_cloud_traffic_p90_tpm"
                    ),
                    previous_day_billable_usage_cost=row.get(
                        "billable_usage_cost"
                    ),
                )
            except CostMetricError:
                estimate = {
                    "status": "partial",
                    "reason_code": "CAPACITY_EVIDENCE_MISSING",
                    "cloud_reclaim_to_traffic_ratio": None,
                    "estimated_incremental_cloud_daily_cost": None,
                    "estimated_projected_cloud_daily_cost": None,
                }
        candidate["cloud_cost_estimation_status"] = estimate["status"]
        candidate["cloud_cost_estimation_reason_code"] = estimate["reason_code"]
        candidate["cloud_reclaim_to_traffic_ratio"] = estimate[
            "cloud_reclaim_to_traffic_ratio"
        ]
        candidate["estimated_incremental_cloud_daily_cost"] = estimate[
            "estimated_incremental_cloud_daily_cost"
        ]
        candidate["estimated_projected_cloud_daily_cost"] = estimate[
            "estimated_projected_cloud_daily_cost"
        ]
        if estimate["status"] == "success":
            successful += 1
            incremental_partial += non_negative_decimal(
                estimate["estimated_incremental_cloud_daily_cost"],
                "estimated_incremental_cloud_daily_cost",
            )
            projected_partial += non_negative_decimal(
                estimate["estimated_projected_cloud_daily_cost"],
                "estimated_projected_cloud_daily_cost",
            )
        else:
            warnings.append(
                f"{model}: 云上成本估算不完整（{estimate['reason_code']}）"
            )

    complete = successful == len(candidates)
    enriched.update(
        {
            "cloud_cost_estimation_complete": complete,
            "cloud_cost_unit": COST_UNIT,
            "cloud_cost_estimated_candidate_count": successful,
            "previous_day_billable_usage_cost_partial_sum": json_number(
                previous_cost_partial
            ),
            "previous_day_billable_usage_cost_total": (
                json_number(previous_cost_partial)
                if cost_evidence_successful == len(candidates)
                else None
            ),
            "estimated_incremental_cloud_daily_cost_partial_sum": json_number(
                incremental_partial
            ),
            "estimated_incremental_cloud_daily_cost_total": (
                json_number(incremental_partial) if complete else None
            ),
            "estimated_projected_cloud_daily_cost_partial_sum": json_number(
                projected_partial
            ),
            "estimated_projected_cloud_daily_cost_total": (
                json_number(projected_partial) if complete else None
            ),
        }
    )
    if not complete:
        warnings.append(
            "部分模型成本证据不完整；成本总量返回 null，partial_sum 仅为完整模型小计"
        )
    return enriched, complete, warnings
