#!/usr/bin/env python3
"""Single resource-domain CLI with internally routed query scenarios."""

from __future__ import annotations

import argparse
import json
import math
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Iterable

from artifact_contract import annotate_outcome
from model_contract import resolve_single_model
from model_resolver import (
    candidate_recall_rank,
    comparison_key as model_comparison_key,
)
from runtime import query_or_fixture, utc_now, write_artifact


TABLE = "kce_server.machine_snapshot_prod"
SCRIPT_VERSION = "1.2.0"
POD_TABLE = "kce_server.kce_ai_infra_pods"
DEFAULT_CLUSTER = "kce-ai-infra-bjzey1-hb1az3"
DEFAULT_WINDOW_SECONDS = 3600
MODEL_HOLDINGS_DEFAULT_WINDOW_SECONDS = 300
MODEL_CANDIDATE_LIMIT = 20
MAX_BATCH_MODEL_INPUTS = 20
DEFAULT_MAX_WORKERS = 4
MAX_MAX_WORKERS = 8
CARDS_PER_MACHINE = 8
GPU_MODELS = {"X60": "X60*8", "X50": "X50*8", "X40": "X40*8"}
MODEL_TO_GPU = {model: gpu for gpu, model in GPU_MODELS.items()}
POD_GPU_TYPES = {
    "X60": ("X60", "X60卡"),
    "X50": ("X50", "X50卡"),
    "X40": ("X40", "X40卡"),
}
POD_GPU_TO_GPU = {
    raw_gpu: gpu
    for gpu, raw_values in POD_GPU_TYPES.items()
    for raw_gpu in raw_values
}
ALL_GPUS = ("X60", "X50", "X40")
IDLE_POOLS = ("wanqing-common", "wanqing-multi-machine", "wanqing-buffer")
QA_POOLS = ("wanqing-qa",)
SYSTEM_DEV_POOLS = ("wanqing-test",)
OVERVIEW_EXCLUDED_POOLS = ("langbridge-training", "wanqing-fix")
MODEL_HOLDINGS_EXCLUDED_POOLS = ("wanqing-test", "langbridge-training")
MODEL_HOLDINGS_EXCLUDED_NAMES = ("unknown",)
MODEL_HOLDINGS_EXCLUDED_SUBSTRINGS = ("test", "zhipu", "private")
MODEL_HOLDINGS_SCOPES = ("regular", "launch-validation")
LAUNCH_VALIDATION_REQUIRED_SUBSTRING = "test"
LAUNCH_VALIDATION_EXCLUDED_SUBSTRINGS = ("private",)
RESOURCE_DASHBOARD_URL = (
    "https://kwaibi.corp.kuaishou.com/pc/dashboard/preview"
    "?dashboardId=2115499&sheetId=273865"
)
OFFLINE_LABEL = "llm-inference-pool=offline"
SYSTEM_DEV_QA_RESERVED_MACHINES = {"X60": 6, "X50": 0, "X40": 0}
SAFE_TOKEN = re.compile(r"^[A-Za-z0-9_.:-]+$")


def add_query_options(
    parser: argparse.ArgumentParser,
    default_gpus: Iterable[str],
    default_window_seconds: int = DEFAULT_WINDOW_SECONDS,
    fixture_action: str | None = None,
) -> None:
    parser.add_argument(
        "--gpu",
        action="append",
        choices=tuple(GPU_MODELS),
        help="GPU 型号，可重复传入",
    )
    parser.add_argument("--cluster", default=DEFAULT_CLUSTER, help="集群名称")
    parser.add_argument(
        "--window-seconds",
        type=int,
        default=default_window_seconds,
        help=f"查询窗口秒数，默认 {default_window_seconds} 秒",
    )
    parser.add_argument("--output", required=True, help="完整 JSON Artifact 输出路径")
    fixture_options: dict[str, Any] = {}
    if fixture_action is not None:
        fixture_options["action"] = fixture_action
    parser.add_argument(
        "--fixture",
        help="读取 ClickHouse JSON fixture，不访问网络",
        **fixture_options,
    )
    parser.add_argument("--timeout", type=float, default=30.0, help="请求超时秒数")
    parser.set_defaults(default_gpus=tuple(default_gpus))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="直接查询 ClickHouse 的万擎资源域统一入口。"
    )
    commands = parser.add_subparsers(dest="scenario", required=True)

    overview = commands.add_parser("overview", help="GPU 总量、用量和余量")
    add_query_options(overview, ALL_GPUS)
    overview.add_argument(
        "--include-all-pools",
        action="store_true",
        help="不排除 langbridge-training 和 wanqing-fix",
    )

    idle = commands.add_parser("idle", help="线上空闲资源与碎片")
    add_query_options(idle, ALL_GPUS)
    idle.add_argument("--pool", action="append", help="空闲资源池，可重复传入")
    idle.add_argument(
        "--fragment-threshold",
        type=int,
        default=4,
        help="单机至少剩余多少卡才计入，默认 4",
    )

    pool = commands.add_parser("pool", help="指定资源池")
    add_query_options(pool, ALL_GPUS)
    pool.add_argument(
        "--pool", action="append", required=True, help="资源池标签，可重复传入"
    )

    system_dev = commands.add_parser("system-dev", help="系统软件开发机")
    add_query_options(system_dev, ALL_GPUS)
    system_dev.add_argument(
        "--pool", action="append", help="开发机资源池标签，可重复传入"
    )

    available = commands.add_parser("available", help="实际可用机器综合计算")
    add_query_options(available, ("X60", "X50"))
    available.add_argument(
        "--system-dev-pool",
        action="append",
        help="开发机资源池标签，可重复传入",
    )
    available.add_argument(
        "--idle-pool", action="append", help="空闲资源池，可重复传入"
    )
    available.add_argument(
        "--qa-pool", action="append", help="QA 资源池，可重复传入"
    )
    available.add_argument(
        "--fragment-threshold",
        type=int,
        default=4,
        help="单机至少剩余多少卡才计入，默认 4",
    )

    model_candidates = commands.add_parser(
        "list-models",
        help="按内部模型持有量口径发现真实 modelServiceName 候选",
    )
    add_query_options(
        model_candidates,
        ALL_GPUS,
        default_window_seconds=MODEL_HOLDINGS_DEFAULT_WINDOW_SECONDS,
    )
    model_candidates.add_argument(
        "--model-input", required=True, help="用户提供的原始模型表达"
    )
    model_candidates.add_argument(
        "--model-scope",
        choices=MODEL_HOLDINGS_SCOPES,
        default="regular",
        help="模型范围；默认 regular，验证中使用 launch-validation",
    )
    model_candidates.add_argument(
        "--from",
        dest="from_ts",
        type=int,
        help="候选发现起点 Unix 秒，包含边界；必须与 --to 同时传入",
    )
    model_candidates.add_argument(
        "--to",
        dest="to_ts",
        type=int,
        help="候选发现终点 Unix 秒，包含边界；必须与 --from 同时传入",
    )
    model_candidates.add_argument(
        "--service-type",
        choices=("online", "offline"),
        help="常规模型只发现在线或离线候选；默认两者都查",
    )

    model_candidates_batch = commands.add_parser(
        "list-models-batch",
        help="共享一个资源窗口，有界并发发现多个 modelServiceName 候选",
    )
    add_query_options(
        model_candidates_batch,
        ALL_GPUS,
        default_window_seconds=MODEL_HOLDINGS_DEFAULT_WINDOW_SECONDS,
        fixture_action="append",
    )
    model_candidates_batch.add_argument(
        "--model-input",
        action="append",
        required=True,
        help="用户提供的模型表达；按用户输入顺序重复传入",
    )
    model_candidates_batch.add_argument(
        "--model-scope",
        choices=MODEL_HOLDINGS_SCOPES,
        default="regular",
        help="模型范围；默认 regular，验证中使用 launch-validation",
    )
    model_candidates_batch.add_argument(
        "--from",
        dest="from_ts",
        type=int,
        help="候选发现起点 Unix 秒，包含边界；必须与 --to 同时传入",
    )
    model_candidates_batch.add_argument(
        "--to",
        dest="to_ts",
        type=int,
        help="候选发现终点 Unix 秒，包含边界；必须与 --from 同时传入",
    )
    model_candidates_batch.add_argument(
        "--service-type",
        choices=("online", "offline"),
        help="常规模型只发现在线或离线候选；默认两者都查",
    )
    model_candidates_batch.add_argument(
        "--max-workers",
        type=int,
        default=DEFAULT_MAX_WORKERS,
        help=f"最大并发数，默认 {DEFAULT_MAX_WORKERS}",
    )
    model_candidates_batch.add_argument(
        "--output-dir", required=True, help="逐模型候选 Artifact 输出目录"
    )

    model_holdings = commands.add_parser(
        "model-holdings",
        help="查询内部模型持有的 GPU 卡数和等效机器数",
    )
    add_query_options(
        model_holdings,
        ALL_GPUS,
        default_window_seconds=MODEL_HOLDINGS_DEFAULT_WINDOW_SECONDS,
    )
    model_holdings.add_argument(
        "--model-artifact",
        action="append",
        help=(
            "成功的 model-resolution Artifact；生产查询必填，"
            "多模型时可重复传入"
        ),
    )
    model_holdings.add_argument(
        "--capacity-model-artifact",
        action="append",
        help=(
            "仅供云上容量回收 Workflow 使用：复用已成功解析的 "
            "capacity/cloud-reclaim 精确模型 Artifact；多模型时可重复传入"
        ),
    )
    model_holdings.add_argument(
        "--model",
        action="append",
        help=(
            "兼容的 modelServiceName 精确值；只允许 fixture，"
            "或用于校验其值与 --model-artifact 一致"
        ),
    )
    model_holdings.add_argument(
        "--model-scope",
        choices=MODEL_HOLDINGS_SCOPES,
        default="regular",
        help="模型范围；默认 regular，验证中使用 launch-validation",
    )
    model_holdings.add_argument(
        "--from",
        dest="from_ts",
        type=int,
        help="查询起点 Unix 秒，包含边界；必须与 --to 同时传入",
    )
    model_holdings.add_argument(
        "--to",
        dest="to_ts",
        type=int,
        help="查询终点 Unix 秒，包含边界；必须与 --from 同时传入",
    )
    model_holdings.add_argument(
        "--minute-start",
        dest="minute_starts",
        action="append",
        type=int,
        help=(
            "离散自然分钟起点 Unix 秒，可重复传入；"
            "与 --from/--to 互斥"
        ),
    )
    model_holdings.add_argument(
        "--service-type",
        choices=("online", "offline"),
        help="只查询在线或离线服务；默认同时返回",
    )

    inspect = commands.add_parser("inspect", help="渐进读取已有 Artifact")
    inspect.add_argument("artifact", help="Artifact JSON 路径")
    inspect.add_argument(
        "--section",
        choices=("summary", "query", "evidence"),
        default="summary",
        help="读取区块，默认 summary",
    )
    inspect.add_argument(
        "--limit", type=int, default=20, help="列表最多展示元素数，默认 20"
    )
    return parser


def validate_token(value: str, field: str) -> str:
    value = str(value).strip()
    if not value or not SAFE_TOKEN.fullmatch(value):
        raise ValueError(f"{field} 包含不允许的字符：{value!r}")
    return value


def validate_pools(values: Iterable[str]) -> list[str]:
    pools = list(dict.fromkeys(validate_token(value, "resource pool") for value in values))
    if not pools:
        raise ValueError("至少提供一个资源池标签")
    return pools


def validate_query_args(args: argparse.Namespace) -> None:
    if not 60 <= args.window_seconds <= 86400:
        raise ValueError("window-seconds 必须在 60～86400 之间")
    if not 1 <= args.timeout <= 600:
        raise ValueError("timeout 必须在 1～600 秒之间")
    validate_token(args.cluster, "cluster")
    if hasattr(args, "fragment_threshold") and not 1 <= args.fragment_threshold <= 8:
        raise ValueError("fragment-threshold 必须在 1～8 之间")
    if hasattr(args, "from_ts"):
        if (args.from_ts is None) != (args.to_ts is None):
            raise ValueError("--from 和 --to 必须同时传入")
        minute_starts = list(getattr(args, "minute_starts", None) or [])
        if minute_starts and args.from_ts is not None:
            raise ValueError("--minute-start 与 --from/--to 不能同时传入")
        if len(minute_starts) > 100:
            raise ValueError("--minute-start 最多传入 100 个")
        if len(set(minute_starts)) != len(minute_starts):
            raise ValueError("--minute-start 不能重复")
        for minute_start in minute_starts:
            if minute_start < 0 or minute_start % 60 != 0:
                raise ValueError(
                    "--minute-start 必须是对齐自然分钟的非负 Unix 秒"
                )
        if args.from_ts is not None:
            if args.from_ts > args.to_ts:
                raise ValueError("from 必须小于等于 to")
            duration = args.to_ts - args.from_ts + 1
            if not 60 <= duration <= 86400:
                raise ValueError("显式查询窗口必须在 60～86400 秒之间")
    if (
        hasattr(args, "model_scope")
        and args.model_scope == "launch-validation"
        and args.service_type is not None
    ):
        raise ValueError(
            "launch-validation 口径不区分 online/offline，"
            "不能传 --service-type"
        )


def selected_gpus(args: argparse.Namespace) -> list[str]:
    return list(dict.fromkeys(args.gpu or args.default_gpus))


def validate_model_name(value: str, model_scope: str) -> str:
    model = str(value).strip()
    if not model:
        raise ValueError("model 不能为空")
    if len(model) > 256:
        raise ValueError("model 长度不能超过 256")
    if any(ord(character) < 32 for character in model):
        raise ValueError("model 不能包含控制字符")
    lowered = model.lower()
    if model_scope == "launch-validation":
        if (
            LAUNCH_VALIDATION_REQUIRED_SUBSTRING not in lowered
            or any(
                fragment in lowered
                for fragment in LAUNCH_VALIDATION_EXCLUDED_SUBSTRINGS
            )
        ):
            raise ValueError(f"model 不符合上线验证中口径：{model}")
    elif lowered in MODEL_HOLDINGS_EXCLUDED_NAMES or any(
        fragment in lowered for fragment in MODEL_HOLDINGS_EXCLUDED_SUBSTRINGS
    ):
        raise ValueError(f"model 被常规模型口径排除：{model}")
    return model


def selected_models(args: argparse.Namespace) -> list[str]:
    raw_models = list(
        dict.fromkeys(
            validate_model_name(value, args.model_scope)
            for value in (args.model or [])
        )
    )
    artifact_paths = list(args.model_artifact or [])
    capacity_artifact_paths = list(
        getattr(args, "capacity_model_artifact", None) or []
    )
    if artifact_paths and capacity_artifact_paths:
        raise ValueError(
            "--model-artifact 与 --capacity-model-artifact 不得同时使用"
        )
    model_resolutions: list[dict[str, Any]] = []
    artifact_models: list[str] = []
    for artifact_path in artifact_paths:
        verified = resolve_single_model(
            artifact_path=artifact_path,
            raw_model=None,
            expected_domain="resource",
            allowed_scenarios={"model-holdings"},
        )
        artifact_models.append(
            validate_model_name(verified.model, args.model_scope)
        )
        model_resolutions.append(verified.evidence)
    for artifact_path in capacity_artifact_paths:
        verified = resolve_single_model(
            artifact_path=artifact_path,
            raw_model=None,
            expected_domain="capacity",
            allowed_scenarios={"cloud-reclaim"},
        )
        artifact_models.append(
            validate_model_name(verified.model, args.model_scope)
        )
        model_resolutions.append(
            {
                **verified.evidence,
                "handoff_usage": "cloud_reclaim_resource_alignment",
                "consumer_domain": "resource",
                "consumer_scenario": "model-holdings",
            }
        )
    artifact_models = list(dict.fromkeys(artifact_models))

    if artifact_models and raw_models != [] and raw_models != artifact_models:
        raise ValueError(
            "--model 与 --model-artifact 解析出的精确模型列表不一致"
        )
    if artifact_models:
        models = artifact_models
    elif raw_models:
        if not args.fixture:
            raise ValueError(
                "生产 model-holdings 查询必须传入成功的 "
                "--model-artifact；裸 --model 仅允许 fixture 离线验证"
            )
        models = raw_models
        model_resolutions = [
            {
                "mode": "fixture_unverified",
                "artifact": None,
                "user_input": model,
                "resolved_model": model,
                "match_method": None,
                "target_domain": "resource",
                "target_scenario": None,
            }
            for model in models
        ]
    else:
        raise ValueError(
            "资源占用量查询必须指定具体模型，请传入 --model-artifact；"
            f"万擎资源看板：{RESOURCE_DASHBOARD_URL}"
        )
    if len(models) > 20:
        raise ValueError("model 最多传入 20 个")
    args.model_resolution_evidence = model_resolutions
    return models


def sql_string(value: str) -> str:
    return "'" + value.replace("\\", "\\\\").replace("'", "\\'") + "'"


def sql_array(values: Iterable[str]) -> str:
    return "[" + ", ".join(sql_string(value) for value in values) + "]"


def sql_integer_array(values: Iterable[int]) -> str:
    return "[" + ", ".join(str(int(value)) for value in values) + "]"


def latest_snapshot_sql(
    args: argparse.Namespace,
    include_pools: Iterable[str] | None = None,
    exclude_pools: Iterable[str] | None = None,
) -> str:
    models = [GPU_MODELS[gpu] for gpu in selected_gpus(args)]
    conditions = [
        f"timestamp >= toUnixTimestamp(now()) - {args.window_seconds}",
        f"clusterName = {sql_string(args.cluster)}",
        f"gpuModel IN {sql_array(models)}",
    ]
    if include_pools:
        conditions.append(
            f"hasAny(resourcePoolLabelKeys, {sql_array(include_pools)})"
        )
    if exclude_pools:
        conditions.append(
            f"NOT hasAny(resourcePoolLabelKeys, {sql_array(exclude_pools)})"
        )
    where = "\n    AND ".join(conditions)
    return f"""SELECT
    name,
    gpuModel,
    suitName,
    nGpuAllocatable,
    nGpuRequest,
    greatest(nGpuAllocatable - nGpuRequest, 0) AS gpu_remaining,
    resourcePoolLabelKeys,
    timestamp
  FROM {TABLE}
  WHERE {where}
  ORDER BY timestamp DESC
  LIMIT 1 BY name"""


def as_int(value: Any) -> int:
    return 0 if value in (None, "") else int(float(value))


def gpu_label(value: Any) -> str:
    return MODEL_TO_GPU.get(str(value), str(value))


def aggregate_sql(latest: str) -> str:
    return f"""SELECT
  gpuModel,
  count() AS machine_count,
  sum(nGpuAllocatable) AS gpu_total,
  sum(nGpuRequest) AS gpu_used,
  sum(gpu_remaining) AS gpu_remaining
FROM (
  {latest}
)
GROUP BY gpuModel
ORDER BY gpuModel"""


def model_holdings_window(args: argparse.Namespace) -> tuple[int, int]:
    if args.from_ts is not None:
        return args.from_ts, args.to_ts
    to_ts = int(time.time())
    return to_ts - args.window_seconds + 1, to_ts


def model_holdings_sql(
    args: argparse.Namespace,
    models: list[str],
    from_ts: int,
    to_ts: int,
    minute_starts: list[int] | None = None,
) -> str:
    gpu_values = [
        raw_gpu
        for gpu in selected_gpus(args)
        for raw_gpu in POD_GPU_TYPES[gpu]
    ]
    service_expression = (
        "CASE\n"
        f"        WHEN hasAny(labels, {sql_array((OFFLINE_LABEL,))}) = 1 "
        "THEN 'offline'\n"
        "        ELSE 'online'\n"
        "    END"
    )
    time_condition = (
        "toInt64(intDiv(timestamp, 60) * 60) IN "
        f"{sql_integer_array(minute_starts)}"
        if minute_starts
        else f"timestamp >= {from_ts}\n        AND timestamp <= {to_ts}"
    )
    conditions = [
        time_condition,
        f"clusterName = {sql_string(args.cluster)}",
        f"resourcePool NOT IN {sql_array(MODEL_HOLDINGS_EXCLUDED_POOLS)}",
        f"GPUType IN {sql_array(gpu_values)}",
    ]
    if models:
        conditions.append(f"modelServiceName IN {sql_array(models)}")

    select_fields = [
        "modelServiceName AS model_name",
        "GPUType AS gpu_type",
    ]
    group_fields = ["modelServiceName", "GPUType"]
    if minute_starts:
        select_fields.insert(
            0,
            "toInt64(intDiv(timestamp, 60) * 60) AS minute_start",
        )
        group_fields.insert(0, "minute_start")
    if args.model_scope == "launch-validation":
        conditions.extend(
            [
                "modelServiceName LIKE '%test%'",
                "modelServiceName NOT LIKE '%private%'",
            ]
        )
    else:
        conditions.extend(
            [
                (
                    "modelServiceName NOT IN "
                    f"{sql_array(MODEL_HOLDINGS_EXCLUDED_NAMES)}"
                ),
                "modelServiceName NOT LIKE '%test%'",
                "modelServiceName NOT LIKE '%zhipu%'",
                "modelServiceName NOT LIKE '%private%'",
            ]
        )
        select_fields.append(f"{service_expression} AS service_type")
        group_fields.append("service_type")
        if args.service_type == "offline":
            conditions.append(
                f"hasAny(labels, {sql_array((OFFLINE_LABEL,))}) = 1"
            )
        elif args.service_type == "online":
            conditions.append(
                f"hasAny(labels, {sql_array((OFFLINE_LABEL,))}) = 0"
            )

    where = "\n    AND ".join(conditions)
    select_clause = ",\n    ".join(select_fields)
    group_clause = ", ".join(group_fields)
    order_clause = (
        "minute_start, gpu_cards DESC"
        if minute_starts
        else "gpu_cards DESC"
    )
    return f"""SELECT
    {select_clause},
    sum(gpuRequestNum) AS gpu_cards
FROM {POD_TABLE}
WHERE
    {where}
GROUP BY {group_clause}
ORDER BY {order_clause}
LIMIT 100000"""


def model_key_sql(field: str) -> str:
    return (
        "lowerUTF8("
        f"replaceAll(replaceAll(replaceAll({field}, ' ', ''), '-', ''), '_', '')"
        ")"
    )


def model_candidates_sql(
    args: argparse.Namespace,
    model_input: str,
    from_ts: int,
    to_ts: int,
) -> str:
    input_key = model_comparison_key(model_input)
    if not input_key:
        raise ValueError("model-input 规范化后不能为空")
    family_prefix = input_key[:2]
    gpu_values = [
        raw_gpu
        for gpu in selected_gpus(args)
        for raw_gpu in POD_GPU_TYPES[gpu]
    ]
    service_expression = (
        "CASE "
        f"WHEN hasAny(labels, {sql_array((OFFLINE_LABEL,))}) = 1 "
        "THEN 'offline' ELSE 'online' END"
    )
    conditions = [
        f"timestamp >= {from_ts}",
        f"timestamp <= {to_ts}",
        f"clusterName = {sql_string(args.cluster)}",
        f"resourcePool NOT IN {sql_array(MODEL_HOLDINGS_EXCLUDED_POOLS)}",
        f"GPUType IN {sql_array(gpu_values)}",
        "modelServiceName != ''",
    ]
    if args.model_scope == "launch-validation":
        conditions.extend(
            [
                "modelServiceName LIKE '%test%'",
                "modelServiceName NOT LIKE '%private%'",
            ]
        )
    else:
        conditions.extend(
            [
                (
                    "modelServiceName NOT IN "
                    f"{sql_array(MODEL_HOLDINGS_EXCLUDED_NAMES)}"
                ),
                "modelServiceName NOT LIKE '%test%'",
                "modelServiceName NOT LIKE '%zhipu%'",
                "modelServiceName NOT LIKE '%private%'",
            ]
        )
        if args.service_type is not None:
            conditions.append(
                f"({service_expression}) = {sql_string(args.service_type)}"
            )
    source_key = model_key_sql("modelServiceName")
    conditions.append(
        "("
        f"model_key = {sql_string(input_key)} "
        f"OR startsWith(model_key, {sql_string(input_key)}) "
        f"OR startsWith({sql_string(input_key)}, model_key)"
        + (
            f" OR startsWith(model_key, {sql_string(family_prefix)})"
            if len(input_key) >= 2
            else ""
        )
        + ")"
    )
    where = "\n    AND ".join(conditions)
    strong_prefix_order = (
        f"(startsWith(model_key, {sql_string(input_key)}) "
        f"OR startsWith({sql_string(input_key)}, model_key)) DESC"
    )
    return f"""WITH {source_key} AS model_key
SELECT
    modelServiceName AS model,
    max(timestamp) AS last_seen_epoch_seconds
FROM {POD_TABLE}
WHERE
    {where}
GROUP BY model
ORDER BY
    model_key = {sql_string(input_key)} DESC,
    {strong_prefix_order},
    last_seen_epoch_seconds DESC,
    model
LIMIT {MODEL_CANDIDATE_LIMIT}"""


def standard_resource_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {
            "gpu_type": gpu_label(row.get("gpuModel")),
            "machine_count": as_int(row.get("machine_count")),
            "gpu_total_cards": as_int(row.get("gpu_total")),
            "gpu_used_cards": as_int(row.get("gpu_used")),
            "gpu_remaining_cards": as_int(row.get("gpu_remaining")),
        }
        for row in rows
    ]


def resource_row_outcome(
    args: argparse.Namespace, rows: list[dict[str, Any]]
) -> tuple[str, list[str]]:
    expected = selected_gpus(args)
    returned: list[str] = []
    for index, row in enumerate(rows):
        if not isinstance(row, dict):
            raise ValueError(f"resources[{index}] 必须是对象")
        gpu_type = str(row.get("gpu_type", ""))
        if gpu_type not in expected:
            raise ValueError(f"ClickHouse 返回未请求的 GPU 型号：{gpu_type!r}")
        if gpu_type in returned:
            raise ValueError(f"ClickHouse 返回重复 GPU 型号：{gpu_type}")
        for field, value in row.items():
            if (
                field == "machine_count"
                or field.endswith("_cards")
                or field.endswith("_machines")
            ) and (
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(float(value))
                or value < 0
            ):
                raise ValueError(
                    f"ClickHouse 返回非法非负资源数：{gpu_type}.{field}"
                )
        returned.append(gpu_type)
    missing = [gpu_type for gpu_type in expected if gpu_type not in returned]
    return ("partial" if missing else "success"), missing


def model_holdings_summary(
    rows: list[dict[str, Any]],
    split_service_type: bool,
) -> list[dict[str, Any]]:
    breakdown_totals: dict[tuple[str, str, str], int] = {}
    for row in rows:
        model_name = str(row.get("model_name", "")).strip()
        if not model_name:
            raise ValueError("ClickHouse 结果缺少 model_name")
        gpu_type = POD_GPU_TO_GPU.get(
            str(row.get("gpu_type", "")).strip(),
            str(row.get("gpu_type", "")).strip(),
        )
        if gpu_type not in POD_GPU_TYPES:
            raise ValueError(f"ClickHouse 返回未知 GPUType：{gpu_type!r}")
        service_type = ""
        if split_service_type:
            service_type = str(row.get("service_type", "")).strip()
            if service_type not in {"online", "offline"}:
                raise ValueError(
                    f"ClickHouse 返回未知 service_type：{service_type!r}"
                )
        gpu_cards = as_int(row.get("gpu_cards"))
        if gpu_cards < 0:
            raise ValueError("ClickHouse 返回负数 gpu_cards")
        key = (model_name, gpu_type, service_type)
        breakdown_totals[key] = breakdown_totals.get(key, 0) + gpu_cards

    models: dict[str, dict[str, Any]] = {}
    for (model_name, gpu_type, service_type), gpu_cards in breakdown_totals.items():
        model = models.setdefault(
            model_name,
            {
                "model_name": model_name,
                "gpu_cards": 0,
                "equivalent_machines": 0.0,
                "breakdown": [],
            },
        )
        model["gpu_cards"] += gpu_cards
        breakdown = {
            "gpu_type": gpu_type,
            "gpu_cards": gpu_cards,
            "equivalent_machines": gpu_cards / CARDS_PER_MACHINE,
        }
        if split_service_type:
            breakdown["service_type"] = service_type
        model["breakdown"].append(breakdown)

    result = list(models.values())
    for model in result:
        model["equivalent_machines"] = (
            model["gpu_cards"] / CARDS_PER_MACHINE
        )
        model["breakdown"].sort(
            key=lambda row: (
                -row["gpu_cards"],
                row["gpu_type"],
                row.get("service_type", ""),
            )
        )
    result.sort(key=lambda row: (-row["gpu_cards"], row["model_name"]))
    return result


def model_holdings_minute_samples(
    rows: list[dict[str, Any]],
    split_service_type: bool,
) -> list[dict[str, Any]]:
    totals: dict[tuple[int, str, str, str], int] = {}
    for index, row in enumerate(rows):
        raw_minute = row.get("minute_start")
        if raw_minute is None:
            raise ValueError(
                f"ClickHouse 结果第 {index} 行缺少 minute_start"
            )
        minute_start = as_int(raw_minute)
        if minute_start < 0 or minute_start % 60 != 0:
            raise ValueError("ClickHouse 返回未对齐自然分钟的 minute_start")
        model_name = str(row.get("model_name", "")).strip()
        if not model_name:
            raise ValueError("ClickHouse 结果缺少 model_name")
        raw_gpu_type = str(row.get("gpu_type", "")).strip()
        gpu_type = POD_GPU_TO_GPU.get(raw_gpu_type, raw_gpu_type)
        if gpu_type not in POD_GPU_TYPES:
            raise ValueError(f"ClickHouse 返回未知 GPUType：{gpu_type!r}")
        service_type = ""
        if split_service_type:
            service_type = str(row.get("service_type", "")).strip()
            if service_type not in {"online", "offline"}:
                raise ValueError(
                    f"ClickHouse 返回未知 service_type：{service_type!r}"
                )
        gpu_cards = as_int(row.get("gpu_cards"))
        if gpu_cards < 0:
            raise ValueError("ClickHouse 返回负数 gpu_cards")
        key = (minute_start, model_name, gpu_type, service_type)
        totals[key] = totals.get(key, 0) + gpu_cards

    samples = []
    for (
        minute_start,
        model_name,
        gpu_type,
        service_type,
    ), gpu_cards in totals.items():
        sample = {
            "minute_start": minute_start,
            "model_name": model_name,
            "gpu_type": gpu_type,
            "gpu_cards": gpu_cards,
            "equivalent_machines": gpu_cards / CARDS_PER_MACHINE,
        }
        if split_service_type:
            sample["service_type"] = service_type
        samples.append(sample)
    samples.sort(
        key=lambda row: (
            row["minute_start"],
            row["model_name"],
            row["gpu_type"],
            row.get("service_type", ""),
        )
    )
    return samples


def artifact(
    args: argparse.Namespace,
    status: str,
    query: dict[str, Any],
    summary: dict[str, Any],
    result: dict[str, Any],
    handoffs: dict[str, Any] | None = None,
) -> dict[str, Any]:
    value = {
        "schema_version": "1.0",
        "script_version": SCRIPT_VERSION,
        "domain": "resource",
        "scenario": (
            "model-candidates" if args.scenario == "list-models" else args.scenario
        ),
        "status": status,
        "generated_at": utc_now(),
        "query": {
            "cluster": args.cluster,
            "window_seconds": args.window_seconds,
            "gpu_types": selected_gpus(args),
            "source": "fixture" if args.fixture else "clickhouse",
            **(
                {
                    "model_resolution": getattr(
                        args, "model_resolution_evidence", []
                    )
                }
                if args.scenario == "model-holdings"
                else {}
            ),
            **query,
        },
        "summary": summary,
        "handoffs": handoffs or {},
        "evidence": {
            "clickhouse_meta": result.get("meta", []),
            "clickhouse_rows": result.get("data", []),
            "row_count": result.get("rows", len(result.get("data", []))),
            "statistics": result.get("statistics"),
        },
        "warnings": [],
        "errors": [],
    }
    missing_gpu_types = summary.get("missing_gpu_types")
    missing_models = summary.get("missing_models")
    missing_minutes = summary.get("missing_minutes")
    if isinstance(missing_gpu_types, list) and missing_gpu_types:
        value["warnings"].append(
            "查询窗口内以下 GPU 型号无返回记录："
            + ", ".join(str(item) for item in missing_gpu_types)
        )
    if isinstance(missing_models, list) and missing_models:
        value["warnings"].append(
            "查询窗口内以下模型无返回记录："
            + ", ".join(str(item) for item in missing_models)
        )
    if isinstance(missing_minutes, list) and missing_minutes:
        value["warnings"].append(
            f"查询窗口缺少 {len(missing_minutes)} 个自然分钟样本"
        )
    no_rows = bool(missing_gpu_types) or bool(missing_models)
    annotate_outcome(
        value,
        complete=status == "success",
        reason_code=(
            "OK"
            if status == "success"
            else "NO_ROWS"
            if no_rows
            else "EVIDENCE_MISSING"
        ),
        next_action="NONE" if status == "success" else "STOP",
    )
    return value


def save_and_print(
    args: argparse.Namespace,
    status: str,
    query: dict[str, Any],
    summary: dict[str, Any],
    result: dict[str, Any],
    handoffs: dict[str, Any] | None = None,
) -> int:
    value = artifact(args, status, query, summary, result, handoffs)
    output = write_artifact(args.output, value)
    print(
        json.dumps(
            {
                "status": status,
                "reason_code": value["reason_code"],
                "complete": value["complete"],
                **summary,
                "artifact": str(output),
                "warnings": value["warnings"],
                "errors": value["errors"],
                "next_action": value["next_action"],
            },
            ensure_ascii=False,
        )
    )
    return 0


def run_overview(args: argparse.Namespace) -> int:
    excluded = [] if args.include_all_pools else list(OVERVIEW_EXCLUDED_POOLS)
    sql = aggregate_sql(
        latest_snapshot_sql(args, exclude_pools=excluded or None)
    )
    result = query_or_fixture(sql, args.timeout, args.fixture)
    rows = standard_resource_rows(result["data"])
    for row in rows:
        row["gpu_total_equivalent_machines"] = (
            row["gpu_total_cards"] / CARDS_PER_MACHINE
        )
        row["gpu_used_equivalent_machines"] = (
            row["gpu_used_cards"] / CARDS_PER_MACHINE
        )
        row["gpu_remaining_equivalent_machines"] = (
            row["gpu_remaining_cards"] / CARDS_PER_MACHINE
        )
    status, missing = resource_row_outcome(args, rows)
    return save_and_print(
        args,
        status,
        {"excluded_pools": excluded, "sql": sql},
        {"resources": rows, "missing_gpu_types": missing},
        result,
    )


def run_idle(args: argparse.Namespace) -> int:
    pools = validate_pools(args.pool or IDLE_POOLS)
    latest = latest_snapshot_sql(args, include_pools=pools)
    threshold = args.fragment_threshold
    sql = f"""SELECT
  gpuModel,
  count() AS total_pool_machines,
  countIf(gpu_remaining >= {threshold}) AS non_fragment_machine_count,
  sumIf(gpu_remaining, gpu_remaining >= {threshold}) AS valid_gpu_remaining,
  intDiv(sumIf(gpu_remaining, gpu_remaining >= {threshold}), 8) AS equivalent_idle_machines,
  countIf(gpu_remaining = 8) AS fully_idle_physical_machines
FROM (
  {latest}
)
GROUP BY gpuModel
ORDER BY gpuModel"""
    result = query_or_fixture(sql, args.timeout, args.fixture)
    rows = [
        {
            "gpu_type": gpu_label(row.get("gpuModel")),
            "total_pool_machines": as_int(row.get("total_pool_machines")),
            "non_fragment_machine_count": as_int(
                row.get("non_fragment_machine_count")
            ),
            "valid_gpu_remaining_cards": as_int(row.get("valid_gpu_remaining")),
            "equivalent_idle_machines": as_int(
                row.get("equivalent_idle_machines")
            ),
            "fully_idle_physical_machines": as_int(
                row.get("fully_idle_physical_machines")
            ),
        }
        for row in result["data"]
    ]
    status, missing = resource_row_outcome(args, rows)
    return save_and_print(
        args,
        status,
        {
            "pools": pools,
            "fragment_threshold": threshold,
            "sql": sql,
        },
        {
            "resources": rows,
            "missing_gpu_types": missing,
            "metric_note": (
                "equivalent_idle_machines=floor(valid remaining cards/8); "
                "it is not the count of fully idle physical hosts"
            ),
        },
        result,
    )


def run_pool(args: argparse.Namespace) -> int:
    pools = validate_pools(args.pool)
    sql = aggregate_sql(latest_snapshot_sql(args, include_pools=pools))
    result = query_or_fixture(sql, args.timeout, args.fixture)
    rows = standard_resource_rows(result["data"])
    status, missing = resource_row_outcome(args, rows)
    return save_and_print(
        args,
        status,
        {"pools": pools, "sql": sql},
        {"pools": pools, "resources": rows, "missing_gpu_types": missing},
        result,
    )


def configured_dev_pools(values: list[str] | None) -> list[str]:
    if values:
        return validate_pools(values)
    raw = os.environ.get("WANQING_SYSTEM_DEV_POOLS", "")
    configured = [value.strip() for value in raw.split(",") if value.strip()]
    return validate_pools(configured or SYSTEM_DEV_POOLS)


def run_system_dev(args: argparse.Namespace) -> int:
    pools = configured_dev_pools(args.pool)
    sql = aggregate_sql(latest_snapshot_sql(args, include_pools=pools))
    result = query_or_fixture(sql, args.timeout, args.fixture)
    rows = standard_resource_rows(result["data"])
    status, missing = resource_row_outcome(args, rows)
    return save_and_print(
        args,
        status,
        {"system_dev_pools": pools, "sql": sql},
        {
            "system_dev_pools": pools,
            "resources": rows,
            "missing_gpu_types": missing,
        },
        result,
    )


def run_available(args: argparse.Namespace) -> int:
    dev_pools = configured_dev_pools(args.system_dev_pool)
    idle_pools = validate_pools(args.idle_pool or IDLE_POOLS)
    qa_pools = validate_pools(args.qa_pool or QA_POOLS)
    dev_expression = (
        f"countIf(hasAny(resourcePoolLabelKeys, {sql_array(dev_pools)}))"
    )
    threshold = args.fragment_threshold
    latest = latest_snapshot_sql(args)
    sql = f"""SELECT
  gpuModel,
  {dev_expression} AS system_dev_machines,
  intDiv(
    sumIf(
      gpu_remaining,
      hasAny(resourcePoolLabelKeys, {sql_array(idle_pools)})
        AND gpu_remaining >= {threshold}
    ),
    8
  ) AS equivalent_idle_machines,
  countIf(hasAny(resourcePoolLabelKeys, {sql_array(qa_pools)})) AS qa_machines
FROM (
  {latest}
)
GROUP BY gpuModel
ORDER BY gpuModel"""
    result = query_or_fixture(sql, args.timeout, args.fixture)
    rows = []
    for row in result["data"]:
        gpu_type = gpu_label(row.get("gpuModel"))
        dev = as_int(row.get("system_dev_machines"))
        idle = as_int(row.get("equivalent_idle_machines"))
        qa = as_int(row.get("qa_machines"))
        reserved = SYSTEM_DEV_QA_RESERVED_MACHINES.get(gpu_type, 0)
        gross_available = dev + idle + qa
        reservation_deficit = max(0, reserved - gross_available)
        rows.append(
            {
                "gpu_type": gpu_type,
                "system_dev_machines": dev,
                "equivalent_idle_machines": idle,
                "qa_machines": qa,
                "system_dev_qa_reserved_machines": reserved,
                "actual_available_machines": max(0, gross_available - reserved),
                "reservation_deficit_machines": reservation_deficit,
            }
        )
    status, missing = resource_row_outcome(args, rows)
    return save_and_print(
        args,
        status,
        {
            "system_dev_pools": dev_pools,
            "idle_pools": idle_pools,
            "qa_pools": qa_pools,
            "fragment_threshold": threshold,
            "system_dev_qa_reserved_machines_by_gpu": {
                gpu: SYSTEM_DEV_QA_RESERVED_MACHINES[gpu]
                for gpu in selected_gpus(args)
            },
            "sql": sql,
        },
        {
            "resources": rows,
            "formula": (
                "actual_available = max(0, system_dev + equivalent_idle + qa "
                "- system_dev_qa_reserved)"
            ),
            "reservation_note": (
                "system-dev and QA jointly keep 6 X60 machines in steady "
                "state; this is a fixed reservation, not a correction"
            ),
            "missing_components": [
                f"gpu_type:{gpu_type}" for gpu_type in missing
            ],
            "missing_gpu_types": missing,
        },
        result,
    )


def validate_model_input(value: Any) -> str:
    model_input = str(value).strip()
    if not model_input:
        raise ValueError("model-input 不能为空")
    if len(model_input) > 256:
        raise ValueError("model-input 长度不能超过 256")
    if any(ord(character) < 32 for character in model_input):
        raise ValueError("model-input 不能包含控制字符")
    return model_input


def validate_max_workers(value: int) -> int:
    if not 1 <= value <= MAX_MAX_WORKERS:
        raise ValueError(f"max-workers 必须在 1～{MAX_MAX_WORKERS} 之间")
    return value


def model_candidates_artifact(
    args: argparse.Namespace,
    *,
    model_input: str | None = None,
    resolved_window: tuple[int, int] | None = None,
    generated_at: str | None = None,
) -> dict[str, Any]:
    model_input = validate_model_input(
        args.model_input if model_input is None else model_input
    )
    from_ts, to_ts = resolved_window or model_holdings_window(args)
    sql = model_candidates_sql(args, model_input, from_ts, to_ts)
    result = query_or_fixture(sql, args.timeout, args.fixture)
    by_model: dict[str, dict[str, Any]] = {}
    for index, row in enumerate(result["data"]):
        if not isinstance(row, dict):
            raise ValueError(f"data[{index}] 必须是对象")
        model = str(row.get("model", "")).strip()
        if not model or len(model) > 256:
            raise ValueError(f"data[{index}].model 无效")
        if any(ord(character) < 32 for character in model):
            raise ValueError(f"data[{index}].model 不能包含控制字符")
        raw_last_seen = row.get("last_seen_epoch_seconds")
        if isinstance(raw_last_seen, bool):
            raise ValueError(
                f"data[{index}].last_seen_epoch_seconds 必须是非负整数"
            )
        try:
            last_seen_number = float(raw_last_seen)
        except (TypeError, ValueError) as exc:
            raise ValueError(
                f"data[{index}].last_seen_epoch_seconds 必须是非负整数"
            ) from exc
        if (
            not math.isfinite(last_seen_number)
            or not last_seen_number.is_integer()
            or last_seen_number < 0
        ):
            raise ValueError(
                f"data[{index}].last_seen_epoch_seconds 必须是非负整数"
            )
        last_seen = int(last_seen_number)
        current = by_model.get(model)
        if current is None or last_seen > current["last_seen_epoch_seconds"]:
            by_model[model] = {
                "model": model,
                "source": "resource_model_holdings",
                "last_seen_epoch_seconds": last_seen,
            }
    input_key = model_comparison_key(model_input)
    candidates = sorted(
        by_model.values(),
        key=lambda item: (
            candidate_recall_rank(item["model"], model_input),
            -item["last_seen_epoch_seconds"],
            item["model"],
        ),
    )[:MODEL_CANDIDATE_LIMIT]
    handoff = {
        "model_candidates": {
            "status": "ready",
            "anchor_source": "resource_model_holdings",
            "model_field": "modelServiceName",
            "candidates": candidates,
        }
    }
    value = artifact(
        args,
        "success",
        {
            "anchor_source": "resource_model_holdings",
            "table": POD_TABLE,
            "model_input": model_input,
            "comparison_key": input_key,
            "model_scope": args.model_scope,
            "service_type": (
                "not_applicable"
                if args.model_scope == "launch-validation"
                else args.service_type or "all"
            ),
            "window": {
                "from_epoch_seconds": from_ts,
                "to_epoch_seconds": to_ts,
            },
            "excluded_pools": list(MODEL_HOLDINGS_EXCLUDED_POOLS),
            "candidate_limit": MODEL_CANDIDATE_LIMIT,
            "match_basis": (
                "comparison_key_equal_then_bidirectional_prefix_then_"
                "two_character_family"
            ),
            "sql": sql,
        },
        {
            "decision": "model_candidates_ready",
            "candidate_count": len(candidates),
            "candidates": candidates,
            "write_performed": False,
        },
        result,
        handoff,
    )
    if generated_at is not None:
        value["generated_at"] = generated_at
    return value


def run_model_candidates(args: argparse.Namespace) -> int:
    value = model_candidates_artifact(args)
    output = write_artifact(args.output, value)
    print(
        json.dumps(
            {
                "status": value["status"],
                **value["summary"],
                "artifact": str(output),
            },
            ensure_ascii=False,
        )
    )
    return 0


def resource_candidate_item_args(
    args: argparse.Namespace,
    model_input: str,
    fixture: str | None,
) -> argparse.Namespace:
    values = dict(vars(args))
    values.update(
        {
            "scenario": "list-models",
            "model_input": model_input,
            "fixture": fixture,
        }
    )
    return argparse.Namespace(**values)


def resource_candidate_error_artifact(
    *,
    args: argparse.Namespace,
    model_input: str,
    index: int,
    resolved_window: tuple[int, int],
    generated_at: str,
    error: Exception,
) -> dict[str, Any]:
    from_ts, to_ts = resolved_window
    return {
        "schema_version": "1.0",
        "domain": "resource",
        "scenario": "model-candidates",
        "status": "error",
        "generated_at": generated_at,
        "query": {
            "anchor_source": "resource_model_holdings",
            "model_input": model_input,
            "cluster": args.cluster,
            "window_seconds": args.window_seconds,
            "window": {
                "from_epoch_seconds": from_ts,
                "to_epoch_seconds": to_ts,
            },
            "batch": {
                "enabled": True,
                "model_index": index,
                "model_count": len(args.model_input),
                "shared_window": True,
            },
        },
        "summary": {
            "decision": "model_candidate_query_failed",
            "candidate_count": 0,
            "candidates": [],
            "write_performed": False,
        },
        "handoffs": {},
        "evidence": {},
        "warnings": [],
        "errors": [str(error)],
    }


def run_model_candidates_batch(args: argparse.Namespace) -> int:
    max_workers = validate_max_workers(args.max_workers)
    model_inputs = [validate_model_input(value) for value in args.model_input]
    if not 2 <= len(model_inputs) <= MAX_BATCH_MODEL_INPUTS:
        raise ValueError(
            f"list-models-batch 必须提供 2～{MAX_BATCH_MODEL_INPUTS} 个 "
            "--model-input"
        )
    if len(set(model_inputs)) != len(model_inputs):
        raise ValueError("批量 model-input 不得重复")
    fixtures = list(args.fixture or [])
    if fixtures and len(fixtures) != len(model_inputs):
        raise ValueError(
            "批量 fixture 必须按 model-input 顺序逐一提供，数量必须一致"
        )

    resolved_window = model_holdings_window(args)
    generated_at = utc_now()
    output_dir = Path(args.output_dir).expanduser().resolve()

    def query_one(index: int) -> tuple[int, dict[str, Any], Path]:
        model_input = model_inputs[index]
        fixture = fixtures[index] if fixtures else None
        item_args = resource_candidate_item_args(args, model_input, fixture)
        try:
            value = model_candidates_artifact(
                item_args,
                model_input=model_input,
                resolved_window=resolved_window,
                generated_at=generated_at,
            )
            value["query"]["batch"] = {
                "enabled": True,
                "model_index": index,
                "model_count": len(model_inputs),
                "shared_window": True,
            }
        except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as exc:
            value = resource_candidate_error_artifact(
                args=args,
                model_input=model_input,
                index=index,
                resolved_window=resolved_window,
                generated_at=generated_at,
                error=exc,
            )
        output_path = output_dir / f"candidates-{index + 1:03d}.json"
        write_artifact(str(output_path), value)
        return index, value, output_path

    completed_by_index: dict[int, tuple[dict[str, Any], Path]] = {}
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(query_one, index): index
            for index in range(len(model_inputs))
        }
        for future in as_completed(futures):
            index, value, output_path = future.result()
            completed_by_index[index] = (value, output_path)

    items: list[dict[str, Any]] = []
    statuses: list[str] = []
    warnings: list[str] = []
    errors: list[str] = []
    for index, model_input in enumerate(model_inputs):
        value, output_path = completed_by_index[index]
        item_status = str(value.get("status", "error"))
        statuses.append(item_status)
        items.append(
            {
                "index": index,
                "model_input": model_input,
                "status": item_status,
                "artifact": str(output_path),
                "summary": value.get("summary", {}),
            }
        )
        warnings.extend(
            f"{model_input}: {item}"
            for item in value.get("warnings", [])
            if isinstance(item, str)
        )
        errors.extend(
            f"{model_input}: {item}"
            for item in value.get("errors", [])
            if isinstance(item, str)
        )

    if all(status == "success" for status in statuses):
        status = "success"
        decision = "model_candidates_batch_ready"
        handoff_status = "ready"
    elif all(status == "error" for status in statuses):
        status = "error"
        decision = "model_candidates_batch_failed"
        handoff_status = "blocked"
    else:
        status = "partial"
        decision = "model_candidates_batch_partial"
        handoff_status = "partial"
    from_ts, to_ts = resolved_window
    manifest = {
        "schema_version": "1.0",
        "domain": "resource",
        "scenario": "model-candidates-batch",
        "status": status,
        "generated_at": generated_at,
        "query": {
            "anchor_source": "resource_model_holdings",
            "model_inputs": model_inputs,
            "cluster": args.cluster,
            "gpu_types": selected_gpus(args),
            "model_scope": args.model_scope,
            "service_type": (
                "not_applicable"
                if args.model_scope == "launch-validation"
                else args.service_type or "all"
            ),
            "window": {
                "from_epoch_seconds": from_ts,
                "to_epoch_seconds": to_ts,
            },
            "max_workers": max_workers,
            "execution": "bounded_parallel_input_order_output",
        },
        "summary": {
            "decision": decision,
            "input_count": len(model_inputs),
            "successful_input_count": statuses.count("success"),
            "failed_input_count": statuses.count("error"),
            "max_workers": max_workers,
            "shared_window": {
                "from_epoch_seconds": from_ts,
                "to_epoch_seconds": to_ts,
            },
            "remote_query_count": 0 if fixtures else len(model_inputs),
            "write_performed": False,
        },
        "artifacts": {"model_candidates": items},
        "handoffs": {
            "model_candidate_artifacts": {
                "status": handoff_status,
                "artifacts": [item["artifact"] for item in items],
            }
        },
        "warnings": warnings,
        "errors": errors,
    }
    output = write_artifact(args.output, manifest)
    print(
        json.dumps(
            {
                "status": status,
                "artifact": str(output),
                "summary": manifest["summary"],
                "warnings": warnings,
            },
            ensure_ascii=False,
        )
    )
    return 0 if status != "error" else 1


def run_model_holdings(args: argparse.Namespace) -> int:
    models = selected_models(args)
    minute_starts = list(args.minute_starts or [])
    is_launch_validation = args.model_scope == "launch-validation"
    if minute_starts:
        sql = model_holdings_sql(
            args,
            models,
            min(minute_starts),
            max(minute_starts) + 59,
            minute_starts,
        )
        result = query_or_fixture(sql, args.timeout, args.fixture)
        samples = model_holdings_minute_samples(
            result["data"],
            split_service_type=not is_launch_validation,
        )
        returned_minutes = sorted(
            {int(sample["minute_start"]) for sample in samples}
        )
        missing_minutes = [
            minute_start
            for minute_start in minute_starts
            if minute_start not in set(returned_minutes)
        ]
        status = "partial" if missing_minutes else "success"
        return save_and_print(
            args,
            status,
            {
                "table": POD_TABLE,
                "models": models,
                "model_scope": args.model_scope,
                "window_seconds": None,
                "requested_minute_starts": minute_starts,
                "service_type": (
                    "not_applicable"
                    if is_launch_validation
                    else args.service_type or "all"
                ),
                "excluded_pools": list(MODEL_HOLDINGS_EXCLUDED_POOLS),
                "cards_per_machine": CARDS_PER_MACHINE,
                "sql": sql,
            },
            {
                "requested_minute_count": len(minute_starts),
                "returned_minute_count": len(returned_minutes),
                "missing_minutes": missing_minutes,
                "minute_samples": samples,
                "machine_basis": "8_card_equivalent",
                "metric_note": (
                    "equivalent_machines=gpu_cards/8; it is an 8-card "
                    "equivalent, not a distinct physical-host count"
                ),
            },
            result,
        )

    from_ts, to_ts = model_holdings_window(args)
    sql = model_holdings_sql(args, models, from_ts, to_ts)
    result = query_or_fixture(sql, args.timeout, args.fixture)
    model_rows = model_holdings_summary(
        result["data"],
        split_service_type=not is_launch_validation,
    )
    returned_models = {
        str(row.get("model_name")) for row in model_rows if isinstance(row, dict)
    }
    missing_models = [model for model in models if model not in returned_models]
    status = "partial" if missing_models else "success"
    return save_and_print(
        args,
        status,
        {
            "table": POD_TABLE,
            "models": models,
            "model_scope": args.model_scope,
            "from_inclusive": from_ts,
            "to_inclusive": to_ts,
            "window_seconds": to_ts - from_ts + 1,
            "service_type": (
                "not_applicable"
                if is_launch_validation
                else args.service_type or "all"
            ),
            "excluded_pools": list(MODEL_HOLDINGS_EXCLUDED_POOLS),
            "excluded_model_names": (
                [] if is_launch_validation
                else list(MODEL_HOLDINGS_EXCLUDED_NAMES)
            ),
            "required_model_substrings": (
                [LAUNCH_VALIDATION_REQUIRED_SUBSTRING]
                if is_launch_validation else []
            ),
            "excluded_model_substrings": (
                list(LAUNCH_VALIDATION_EXCLUDED_SUBSTRINGS)
                if is_launch_validation
                else list(MODEL_HOLDINGS_EXCLUDED_SUBSTRINGS)
            ),
            "cards_per_machine": CARDS_PER_MACHINE,
            "sql": sql,
        },
        {
            "models": model_rows,
            "missing_models": missing_models,
            "metric_note": (
                "equivalent_machines=gpu_cards/8; it is an 8-card "
                "equivalent, not a distinct physical-host count"
            ),
        },
        result,
    )


def bounded(value: Any, limit: int) -> Any:
    if isinstance(value, list):
        return [bounded(item, limit) for item in value[:limit]]
    if isinstance(value, dict):
        return {key: bounded(child, limit) for key, child in value.items()}
    return value


def run_inspect(args: argparse.Namespace) -> int:
    if not 1 <= args.limit <= 100:
        raise ValueError("limit 必须在 1～100 之间")
    value = json.loads(Path(args.artifact).read_text(encoding="utf-8"))
    if not isinstance(value, dict) or args.section not in value:
        raise ValueError(f"Artifact 不包含 {args.section} 区块")
    print(json.dumps(bounded(value[args.section], args.limit), ensure_ascii=False))
    return 0


RUNNERS = {
    "overview": run_overview,
    "idle": run_idle,
    "pool": run_pool,
    "system-dev": run_system_dev,
    "available": run_available,
    "list-models": run_model_candidates,
    "list-models-batch": run_model_candidates_batch,
    "model-holdings": run_model_holdings,
    "inspect": run_inspect,
}


def main() -> int:
    args = build_parser().parse_args()
    try:
        if args.scenario != "inspect":
            validate_query_args(args)
        return RUNNERS[args.scenario](args)
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as exc:
        if args.scenario == "inspect":
            print(json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False))
            return 1
        reason_code = (
            "QUERY_FAILED"
            if isinstance(exc, (OSError, RuntimeError, json.JSONDecodeError))
            else "INVALID_INPUT"
        )
        value = {
            "schema_version": "1.0",
            "script_version": SCRIPT_VERSION,
            "domain": "resource",
            "scenario": args.scenario,
            "status": "error",
            "generated_at": utc_now(),
            "query": {
                "cluster": getattr(args, "cluster", None),
                "window_seconds": getattr(args, "window_seconds", None),
                "gpu_types": selected_gpus(args),
                "source": "fixture" if getattr(args, "fixture", None) else "clickhouse",
            },
            "summary": {
                "decision": (
                    "query_failed" if reason_code == "QUERY_FAILED" else "invalid_input"
                ),
                "write_performed": False,
            },
            "handoffs": {},
            "evidence": {},
            "warnings": [],
            "errors": [str(exc)],
        }
        annotate_outcome(
            value,
            complete=False,
            reason_code=reason_code,
            next_action="STOP",
        )
        output = write_artifact(args.output, value)
        print(
            json.dumps(
                {
                    "status": "error",
                    "reason_code": reason_code,
                    "complete": False,
                    "error": str(exc),
                    "artifact": str(output),
                    "summary": value["summary"],
                    "errors": value["errors"],
                    "next_action": "STOP",
                },
                ensure_ascii=False,
            )
        )
        return 1


if __name__ == "__main__":
    sys.exit(main())
