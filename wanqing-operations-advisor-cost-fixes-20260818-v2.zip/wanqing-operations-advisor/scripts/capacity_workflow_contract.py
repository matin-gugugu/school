#!/usr/bin/env python3
"""Shared request contract for production capacity-analysis workflows."""

from __future__ import annotations

from difflib import get_close_matches
from typing import Any


REQUEST_SCHEMA_VERSION = "1.1"
DEFAULT_REQUEST_SCHEMA_VERSION = "1.0"
SUPPORTED_REQUEST_SCHEMA_VERSIONS = {"1.0", REQUEST_SCHEMA_VERSION}
MAX_TASKS = 20
MAX_MODELS_PER_TASK = 20
MAX_TOTAL_MODEL_INPUTS = 100

SCENARIOS = {"supply-profile", "traffic-profile", "headroom"}
DETAIL_LEVELS = {"headroom", "decision", "instances", "cards", "resources"}
PROVIDER_SCOPES = {
    frozenset({"public"}): "cloud",
    frozenset({"internal"}): "self_deployed",
    frozenset({"public", "internal"}): "mixed",
}
DEFAULT_LOOKBACK = {
    "supply-profile": 2160,
    "traffic-profile": 960,
}

TOP_LEVEL_FIELDS = {"schema_version", "tasks"}
COMMON_TASK_FIELDS = {
    "task_id",
    "scenario",
    "model_inputs",
    "providers",
    "provider_scope",
    "priority",
    "timezone",
    "window_relation",
    "lookback_seconds",
    "from",
    "to",
    "selected_models",
    "service_selections",
}
V1_1_TASK_FIELDS = {"model_scope"}
HEADROOM_ONLY_FIELDS = {
    "incremental_tpm",
    "reserve_ratio",
    "detail_level",
    "resource_artifact",
}


def _unknown_field_message(path: str, field: str, allowed: set[str]) -> str:
    matches = get_close_matches(field, sorted(allowed), n=1, cutoff=0.65)
    suggestion = f"；是否想写 {matches[0]}" if matches else ""
    return f"{path} 包含未知字段 {field}{suggestion}"


def validate_request_schema(request: Any) -> None:
    """Reject unknown or structurally invalid request fields before normalization."""

    if not isinstance(request, dict):
        raise ValueError("容量分析请求必须是对象")
    unknown = set(request) - TOP_LEVEL_FIELDS
    if unknown:
        field = sorted(unknown)[0]
        raise ValueError(_unknown_field_message("请求", field, TOP_LEVEL_FIELDS))
    version = request.get("schema_version", DEFAULT_REQUEST_SCHEMA_VERSION)
    if version not in SUPPORTED_REQUEST_SCHEMA_VERSIONS:
        raise ValueError(
            "schema_version 必须是 "
            + " 或 ".join(sorted(SUPPORTED_REQUEST_SCHEMA_VERSIONS))
            + f"，实际为 {version!r}"
        )
    tasks = request.get("tasks")
    if not isinstance(tasks, list) or not tasks:
        raise ValueError("请求必须包含非空 tasks 数组")
    if len(tasks) > MAX_TASKS:
        raise ValueError(f"tasks 最多包含 {MAX_TASKS} 个任务")
    total_model_inputs = 0
    for index, raw in enumerate(tasks):
        if not isinstance(raw, dict):
            raise ValueError(f"tasks[{index}] 必须是对象")
        scenario = raw.get("scenario")
        # Field spelling belongs to the schema layer; scenario-specific
        # applicability is validated by the normalizer with a clearer error.
        allowed = set(COMMON_TASK_FIELDS | HEADROOM_ONLY_FIELDS)
        if version == REQUEST_SCHEMA_VERSION:
            allowed.update(V1_1_TASK_FIELDS)
        unknown = set(raw) - allowed
        if unknown:
            field = sorted(unknown)[0]
            raise ValueError(
                _unknown_field_message(f"tasks[{index}]", field, allowed)
            )
        model_inputs = raw.get("model_inputs")
        if isinstance(model_inputs, list):
            if len(model_inputs) > MAX_MODELS_PER_TASK:
                raise ValueError(
                    f"tasks[{index}].model_inputs 最多包含 "
                    f"{MAX_MODELS_PER_TASK} 个模型表达"
                )
            total_model_inputs += len(model_inputs)
    if total_model_inputs > MAX_TOTAL_MODEL_INPUTS:
        raise ValueError(
            "请求中 model_inputs 总数不能超过 "
            f"{MAX_TOTAL_MODEL_INPUTS}"
        )


def parse_indexed_selections(
    value: Any,
    *,
    field: str,
    item_count: int,
    text_validator: Any,
) -> dict[int, str]:
    """Normalize a JSON object whose keys are zero-based model-input indexes."""

    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ValueError(f"{field} 必须是对象")
    selections: dict[int, str] = {}
    for raw_position, raw_value in value.items():
        if isinstance(raw_position, bool):
            raise ValueError(f"{field} 的 key 必须是规范化模型下标")
        position_text = str(raw_position)
        if not (
            position_text == "0"
            or (
                position_text.isdigit()
                and not position_text.startswith("0")
            )
        ):
            raise ValueError(
                f"{field} 的 key 必须是无前导零的非负整数下标"
            )
        position = int(position_text)
        if position < 0 or position >= item_count:
            raise ValueError(f"{field} 下标越界：{position}")
        selections[position] = text_validator(raw_value, f"{field}[{position}]")
    return selections


def parse_named_selections(
    values: list[str] | None,
    *,
    option_name: str,
) -> dict[str, str]:
    """Parse repeated MODEL=VALUE CLI selections with duplicate protection."""

    selections: dict[str, str] = {}
    for index, item in enumerate(values or []):
        if "=" not in item:
            raise ValueError(
                f"{option_name}[{index}] 必须使用 MODEL=VALUE 格式"
            )
        raw_model, raw_value = item.split("=", 1)
        model = raw_model.strip()
        selected = raw_value.strip()
        if not model or not selected:
            raise ValueError(
                f"{option_name}[{index}] 必须使用非空 MODEL=VALUE"
            )
        if (
            len(model) > 256
            or len(selected) > 256
            or any(ord(character) < 32 for character in model + selected)
        ):
            raise ValueError(
                f"{option_name}[{index}] 的 MODEL 和 VALUE 必须是不超过 256 字符的安全文本"
            )
        if model in selections:
            raise ValueError(f"{option_name} 模型重复：{model}")
        selections[model] = selected
    return selections
