#!/usr/bin/env python3
"""Shared validation for verified model-resolution Artifacts."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


MAX_MODEL_LENGTH = 256
MODEL_RESOLUTION_ANCHORS = {
    ("capacity", "supply-profile"): "capacity",
    ("capacity", "traffic-profile"): "usage",
    ("capacity", "headroom"): "capacity",
    ("capacity", "cloud-reclaim"): "capacity",
    ("resource", "model-holdings"): "resource_model_holdings",
}
TARGET_SCENARIOS = {
    domain: {
        scenario
        for route_domain, scenario in MODEL_RESOLUTION_ANCHORS
        if route_domain == domain
    }
    for domain in {domain for domain, _ in MODEL_RESOLUTION_ANCHORS}
}
CAPACITY_QUERY_SOURCES = {
    "supply-profile": frozenset({"capacity"}),
    "traffic-profile": frozenset({"usage"}),
    "headroom": frozenset({"capacity", "usage"}),
    "cloud-reclaim": frozenset({"capacity", "usage"}),
}
if set(CAPACITY_QUERY_SOURCES) != TARGET_SCENARIOS["capacity"]:
    raise RuntimeError("容量查询源契约必须覆盖全部 capacity 目标场景")


class ModelContractError(ValueError):
    """Raised when exact-model provenance is missing or inconsistent."""


@dataclass(frozen=True)
class VerifiedModel:
    model: str
    evidence: dict[str, Any]


def bounded_model(value: Any, field: str = "model") -> str:
    if not isinstance(value, str):
        raise ModelContractError(f"{field} 必须是字符串")
    model = value.strip()
    if not model:
        raise ModelContractError(f"{field} 不能为空")
    if len(model) > MAX_MODEL_LENGTH:
        raise ModelContractError(f"{field} 长度不能超过 {MAX_MODEL_LENGTH}")
    if any(ord(character) < 32 for character in model):
        raise ModelContractError(f"{field} 不能包含控制字符")
    return model


def _mapping(value: Any, field: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ModelContractError(f"模型解析 Artifact 缺少 {field}")
    return value


def expected_anchor_source(target_domain: str, target_scenario: str) -> str:
    try:
        return MODEL_RESOLUTION_ANCHORS[(target_domain, target_scenario)]
    except KeyError as exc:
        raise ModelContractError(
            "不支持的模型解析目标："
            f"domain={target_domain}, scenario={target_scenario}"
        ) from exc


def trusted_scope_resolution_artifact(
    *,
    model: str,
    target_domain: str,
    target_scenario: str,
    scope_artifact: str | Path,
    resolved_at: str,
    scope_source: str,
    scope_version: str,
) -> dict[str, Any]:
    """Build a verified model handoff from a versioned trusted model scope.

    This is intentionally narrower than accepting a bare model string.  The
    caller must persist the authoritative scope Artifact and include it in the
    parent provenance chain.  Static cloud-reclaim and capacity candidate
    policies use this path instead of accepting an unverified model string.
    """

    resolved_model = bounded_model(model)
    domain = bounded_model(target_domain, "target_domain")
    scenario = bounded_model(target_scenario, "target_scenario")
    anchor_source = expected_anchor_source(domain, scenario)
    source = bounded_model(scope_source, "scope_source")
    version = bounded_model(scope_version, "scope_version")
    scope_path = Path(scope_artifact).expanduser().resolve()
    return {
        "schema_version": "1.1",
        "script_version": "1.0.0",
        "domain": "common",
        "scenario": "model-resolution",
        "status": "success",
        "generated_at": resolved_at,
        "query": {
            "user_input": resolved_model,
            "target_domain": domain,
            "target_scenario": scenario,
            "anchor_source": anchor_source,
            "resolution_source": "trusted_model_scope",
            "scope_artifact": str(scope_path),
            "scope_source": source,
            "scope_version": version,
        },
        "summary": {
            "decision": "resolved",
            "user_input": resolved_model,
            "resolved_model": resolved_model,
            "match_method": "trusted_model_scope",
            "candidate_count": 1,
            "matched_candidate_count": 1,
            "candidates": [resolved_model],
            "write_performed": False,
        },
        "handoffs": {
            "model": {
                "status": "ready",
                "model": resolved_model,
                "user_input": resolved_model,
                "match_method": "trusted_model_scope",
                "target_domain": domain,
                "target_scenario": scenario,
                "anchor_source": anchor_source,
                "resolved_at": resolved_at,
            }
        },
        "warnings": [],
        "errors": [],
    }


def load_model_resolution(
    path_value: str | Path,
    *,
    expected_domain: str | None = None,
    allowed_scenarios: Iterable[str] | None = None,
) -> VerifiedModel:
    path = Path(path_value).expanduser().resolve()
    with path.open(encoding="utf-8") as handle:
        artifact = json.load(handle)
    if not isinstance(artifact, dict):
        raise ModelContractError("模型解析 Artifact 必须是 JSON 对象")
    if artifact.get("domain") != "common":
        raise ModelContractError("模型解析 Artifact 的 domain 必须是 common")
    if artifact.get("scenario") != "model-resolution":
        raise ModelContractError(
            "模型解析 Artifact 的 scenario 必须是 model-resolution"
        )
    if artifact.get("status") != "success":
        raise ModelContractError("模型解析 Artifact 的 status 必须是 success")

    summary = _mapping(artifact.get("summary"), "summary")
    if summary.get("decision") != "resolved":
        raise ModelContractError("模型解析 Artifact 的 decision 必须是 resolved")
    handoffs = _mapping(artifact.get("handoffs"), "handoffs")
    handoff = _mapping(handoffs.get("model"), "handoffs.model")
    if handoff.get("status") != "ready":
        raise ModelContractError("模型解析 Artifact 的 model 交接尚未 ready")

    model = bounded_model(handoff.get("model"), "handoffs.model.model")
    if summary.get("resolved_model") != model:
        raise ModelContractError("summary.resolved_model 与 model 交接不一致")
    target_domain = bounded_model(
        handoff.get("target_domain"), "handoffs.model.target_domain"
    )
    target_scenario = bounded_model(
        handoff.get("target_scenario"), "handoffs.model.target_scenario"
    )
    query = _mapping(artifact.get("query"), "query")
    if query.get("target_domain") != target_domain:
        raise ModelContractError("query.target_domain 与 model 交接不一致")
    if query.get("target_scenario") != target_scenario:
        raise ModelContractError("query.target_scenario 与 model 交接不一致")
    if expected_domain is not None and target_domain != expected_domain:
        raise ModelContractError(
            f"模型解析目标领域必须是 {expected_domain}；收到 {target_domain}"
        )
    allowed = set(allowed_scenarios or ())
    if allowed and target_scenario not in allowed:
        raise ModelContractError(
            "模型解析目标场景不适用于当前命令；收到 " + target_scenario
        )
    expected_anchor = expected_anchor_source(target_domain, target_scenario)
    query_anchor = bounded_model(
        query.get("anchor_source"), "query.anchor_source"
    )
    handoff_anchor = bounded_model(
        handoff.get("anchor_source"), "handoffs.model.anchor_source"
    )
    if query_anchor != handoff_anchor:
        raise ModelContractError("query.anchor_source 与 model 交接不一致")
    if query_anchor != expected_anchor:
        raise ModelContractError(
            f"{target_domain}/{target_scenario} 必须使用"
            f" anchor_source={expected_anchor}；收到 {query_anchor}"
        )

    user_input = bounded_model(
        handoff.get("user_input"), "handoffs.model.user_input"
    )
    match_method = bounded_model(
        handoff.get("match_method"), "handoffs.model.match_method"
    )
    return VerifiedModel(
        model=model,
        evidence={
            "mode": "verified_artifact",
            "artifact": str(path),
            "user_input": user_input,
            "resolved_model": model,
            "match_method": match_method,
            "target_domain": target_domain,
            "target_scenario": target_scenario,
            "anchor_source": handoff_anchor,
            "resolved_at": handoff.get("resolved_at"),
        },
    )


def resolve_single_model(
    *,
    artifact_path: str | Path | None,
    raw_model: str | None,
    expected_domain: str,
    allowed_scenarios: Iterable[str],
    allow_unverified: bool = False,
    unverified_mode: str = "fixture_unverified",
) -> VerifiedModel:
    if artifact_path is not None:
        verified = load_model_resolution(
            artifact_path,
            expected_domain=expected_domain,
            allowed_scenarios=allowed_scenarios,
        )
        if raw_model is not None and bounded_model(raw_model) != verified.model:
            raise ModelContractError(
                "--model 与 --model-artifact 解析出的精确模型名不一致"
            )
        return verified
    if raw_model is None:
        raise ModelContractError("必须传入 --model-artifact")
    model = bounded_model(raw_model)
    if not allow_unverified:
        raise ModelContractError(
            "生产模型查询必须传入成功的 --model-artifact；"
            "裸 --model 仅允许 fixture 离线验证"
        )
    if unverified_mode not in {"fixture_unverified", "replay_unverified"}:
        raise ModelContractError("不支持的未校验模型证据模式")
    return VerifiedModel(
        model=model,
        evidence={
            "mode": unverified_mode,
            "artifact": None,
            "user_input": model,
            "resolved_model": model,
            "match_method": None,
            "target_domain": expected_domain,
            "target_scenario": None,
        },
    )


def validate_embedded_model_resolution(
    value: Any,
    *,
    expected_model: str,
    expected_domain: str,
    expected_scenario: str,
    expected_artifact: str | Path,
    field: str,
) -> dict[str, Any]:
    evidence = _mapping(value, field)
    if evidence.get("mode") != "verified_artifact":
        raise ModelContractError(f"{field}.mode 必须是 verified_artifact")
    model = bounded_model(
        evidence.get("resolved_model"), f"{field}.resolved_model"
    )
    if model != expected_model:
        raise ModelContractError(f"{field}.resolved_model 与候选模型不一致")
    target_domain = bounded_model(
        evidence.get("target_domain"), f"{field}.target_domain"
    )
    target_scenario = bounded_model(
        evidence.get("target_scenario"), f"{field}.target_scenario"
    )
    if target_domain != expected_domain or target_scenario != expected_scenario:
        raise ModelContractError(f"{field} 的目标领域或场景不一致")
    anchor_source = bounded_model(
        evidence.get("anchor_source"), f"{field}.anchor_source"
    )
    expected_anchor = expected_anchor_source(target_domain, target_scenario)
    if anchor_source != expected_anchor:
        raise ModelContractError(
            f"{field}.anchor_source 必须是 {expected_anchor}"
        )
    artifact_value = bounded_model(
        evidence.get("artifact"), f"{field}.artifact"
    )
    artifact_path = Path(artifact_value).expanduser().resolve()
    expected_path = Path(expected_artifact).expanduser().resolve()
    if artifact_path != expected_path:
        raise ModelContractError(f"{field}.artifact 不是当前候选模型 Artifact")
    return dict(evidence)
