#!/usr/bin/env python3
"""Versioned model-selection policy shared by capacity workflows."""

from __future__ import annotations

from typing import Any


POLICY_SOURCE = "skill_static_policy"
POLICY_VERSION = "1"
CANDIDATE_POLICY_SOURCE = POLICY_SOURCE
CANDIDATE_POLICY_VERSION = POLICY_VERSION
DEFAULT_CLOUD_RECLAIM_GPU_ORDER = ("X60", "X40")
CANDIDATE_MODELS_BY_GPU: dict[str, tuple[str, ...]] = {
    "X60": (
        "qwen3.5-397b-a17b",
        "deepseek-v3",
        "deepseek-v3.1",
        "kimi-k2.5",
        "deepseek-v3.2",
        "kimi-k2.6",
        "deepseek-v4-flash",
        "deepseek-v4-pro",
        "glm-5.2",
    ),
    "X40": (
        "qwen3-vl-32b-instruct",
        "qwen3-235b-a22b-instruct-2507",
        "qwen3-32b",
    ),
}
# Backward-compatible name used by the cloud-reclaim workflow and callers.
TOP_P_MODELS_BY_GPU = CANDIDATE_MODELS_BY_GPU


class TopPPolicyError(ValueError):
    """Raised when a cloud-reclaim Top P selection violates policy."""


class ExplicitModelSelectionError(ValueError):
    """Raised when an explicit-model cloud-reclaim selection is invalid."""


def default_all_model_plan() -> list[dict[str, Any]]:
    """Return the deterministic two-GPU full-whitelist reclaim plan."""
    seen_models: set[str] = set()
    plan: list[dict[str, Any]] = []
    for gpu_type in DEFAULT_CLOUD_RECLAIM_GPU_ORDER:
        models = list(TOP_P_MODELS_BY_GPU[gpu_type])
        duplicates = sorted(seen_models & set(models))
        if duplicates:
            raise TopPPolicyError(
                "默认双卡型全量策略不允许模型跨卡型重复："
                + ", ".join(duplicates)
            )
        seen_models.update(models)
        plan.append(
            {
                "gpu_type": gpu_type,
                "top_p": len(models),
                "models": models,
            }
        )
    return plan


def default_candidate_models() -> list[str]:
    """Return the deterministic all-GPU candidate scope in policy order."""

    return [
        model
        for item in default_all_model_plan()
        for model in item["models"]
    ]


def selected_models(gpu_type: Any, top_p: Any) -> list[str]:
    if not isinstance(gpu_type, str) or gpu_type not in TOP_P_MODELS_BY_GPU:
        raise TopPPolicyError("policy.gpu_type 仅支持 X60 或 X40")
    if isinstance(top_p, bool) or not isinstance(top_p, int) or top_p < 1:
        raise TopPPolicyError("policy.top_p 必须是正整数")
    ordered = TOP_P_MODELS_BY_GPU[gpu_type]
    if top_p > len(ordered):
        raise TopPPolicyError(
            f"policy.top_p 不能超过 {gpu_type} 白名单模型数 {len(ordered)}"
        )
    return list(ordered[:top_p])


def validate_candidate_prefix(
    policy: Any,
    candidates: Any,
) -> tuple[str, int, list[str]]:
    if not isinstance(policy, dict):
        raise TopPPolicyError("policy 必须是对象")
    gpu_type = policy.get("gpu_type")
    top_p = policy.get("top_p")
    expected = selected_models(gpu_type, top_p)
    if not isinstance(candidates, list) or len(candidates) < len(expected):
        raise TopPPolicyError("candidates 必须覆盖 policy.top_p")
    actual: list[str] = []
    for index, candidate in enumerate(candidates[: len(expected)]):
        if not isinstance(candidate, dict):
            raise TopPPolicyError(f"candidates[{index}] 必须是对象")
        model = candidate.get("model")
        if not isinstance(model, str) or not model.strip():
            raise TopPPolicyError(f"candidates[{index}].model 必须是非空字符串")
        actual.append(model.strip())
    if actual != expected:
        raise TopPPolicyError(
            f"{gpu_type} Top {top_p} 候选必须按固定顺序为 "
            + ", ".join(expected)
        )
    return str(gpu_type), int(top_p), expected


def validate_explicit_candidate_selection(
    selection: Any,
    candidates: Any,
) -> list[str]:
    """Validate user-selected models without applying Top P prefix rules."""
    if not isinstance(selection, dict):
        raise ExplicitModelSelectionError("selection 必须是对象")
    if selection.get("mode") != "explicit_models":
        raise ExplicitModelSelectionError(
            "selection.mode 必须是 explicit_models"
        )
    if selection.get("source") != "user_explicit":
        raise ExplicitModelSelectionError(
            "selection.source 必须是 user_explicit"
        )
    requested = selection.get("models")
    if not isinstance(requested, list) or not requested:
        raise ExplicitModelSelectionError(
            "selection.models 必须是非空模型数组"
        )

    requested_models: list[str] = []
    for index, model in enumerate(requested):
        if not isinstance(model, str) or not model.strip():
            raise ExplicitModelSelectionError(
                f"selection.models[{index}] 必须是非空字符串"
            )
        requested_models.append(model.strip())
    if len(requested_models) != len(set(requested_models)):
        raise ExplicitModelSelectionError("selection.models 不得包含重复模型")

    if not isinstance(candidates, list) or len(candidates) != len(
        requested_models
    ):
        raise ExplicitModelSelectionError(
            "candidates 必须与 selection.models 数量完全一致"
        )
    actual_models: list[str] = []
    for index, candidate in enumerate(candidates):
        if not isinstance(candidate, dict):
            raise ExplicitModelSelectionError(
                f"candidates[{index}] 必须是对象"
            )
        model = candidate.get("model")
        if not isinstance(model, str) or not model.strip():
            raise ExplicitModelSelectionError(
                f"candidates[{index}].model 必须是非空字符串"
            )
        actual_models.append(model.strip())
    if actual_models != requested_models:
        raise ExplicitModelSelectionError(
            "candidates 模型及顺序必须与 selection.models 完全一致"
        )
    return requested_models
