#!/usr/bin/env python3
"""Resolve a user-provided model expression to one verified exact model name."""

from __future__ import annotations

import argparse
import difflib
import json
import sys
import unicodedata
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

from artifact_contract import annotate_outcome, terminal_brief
from model_contract import TARGET_SCENARIOS, expected_anchor_source
from runtime import utc_now, write_artifact


SCHEMA_VERSION = "1.0"
SCRIPT_VERSION = "0.6.0"
MAX_MODEL_LENGTH = 256
MAX_CANDIDATES = 100
DEFAULT_SUGGESTION_LIMIT = 10
DEFAULT_MAX_WORKERS = 4
MAX_MAX_WORKERS = 8
MAX_BATCH_MODEL_INPUTS = 20
TYPO_SIMILARITY_THRESHOLD = 0.72


class ResolutionError(ValueError):
    """Raised when model-resolution input is invalid."""


def bounded_text(value: Any, field: str) -> str:
    if not isinstance(value, str):
        raise ResolutionError(f"{field} 必须是字符串")
    text = value.strip()
    if not text:
        raise ResolutionError(f"{field} 不能为空")
    if len(text) > MAX_MODEL_LENGTH:
        raise ResolutionError(f"{field} 长度不能超过 {MAX_MODEL_LENGTH}")
    if any(ord(character) < 32 for character in text):
        raise ResolutionError(f"{field} 不能包含控制字符")
    return text


def bounded_path_text(value: Any, field: str) -> str:
    if not isinstance(value, str):
        raise ResolutionError(f"{field} 必须是字符串")
    text = value.strip()
    if not text:
        raise ResolutionError(f"{field} 不能为空")
    if len(text) > 4096:
        raise ResolutionError(f"{field} 长度不能超过 4096")
    if any(ord(character) < 32 for character in text):
        raise ResolutionError(f"{field} 不能包含控制字符")
    return text


def normalized_name(value: str) -> str:
    """Normalize width, surrounding whitespace, and case only."""

    return unicodedata.normalize("NFKC", value).strip().casefold()


def comparison_key(value: str) -> str:
    """Remove only proven formatting separators; preserve version punctuation."""

    normalized = normalized_name(value)
    return "".join(
        character
        for character in normalized
        if not character.isspace() and character not in {"-", "_"}
    )


def candidate_recall_rank(candidate_name: str, user_input: str) -> int:
    """Rank strong identity matches ahead of broad family recall."""

    candidate_key = comparison_key(candidate_name)
    input_key = comparison_key(user_input)
    if candidate_key == input_key:
        return 0
    if candidate_key.startswith(input_key) or input_key.startswith(candidate_key):
        return 1
    return 2


def load_candidate_artifact(path_value: str) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    path = Path(path_value).expanduser().resolve()
    with path.open(encoding="utf-8") as handle:
        artifact = json.load(handle)
    if not isinstance(artifact, dict):
        raise ResolutionError("模型候选 Artifact 必须是 JSON 对象")
    if artifact.get("scenario") != "model-candidates":
        raise ResolutionError("模型候选 Artifact 的 scenario 必须是 model-candidates")
    if artifact.get("status") != "success":
        raise ResolutionError("模型候选 Artifact 的 status 必须是 success")
    handoffs = artifact.get("handoffs")
    if not isinstance(handoffs, dict):
        raise ResolutionError("模型候选 Artifact 缺少 handoffs")
    handoff = handoffs.get("model_candidates")
    if not isinstance(handoff, dict) or handoff.get("status") != "ready":
        raise ResolutionError("模型候选 Artifact 的 model_candidates 交接尚未 ready")
    raw_candidates = handoff.get("candidates")
    if not isinstance(raw_candidates, list):
        raise ResolutionError("model_candidates.candidates 必须是数组")
    if len(raw_candidates) > MAX_CANDIDATES:
        raise ResolutionError(f"模型候选最多允许 {MAX_CANDIDATES} 个")

    candidates: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, raw_candidate in enumerate(raw_candidates):
        if isinstance(raw_candidate, str):
            candidate = {"model": raw_candidate}
        elif isinstance(raw_candidate, dict):
            candidate = dict(raw_candidate)
        else:
            raise ResolutionError(f"candidates[{index}] 必须是字符串或对象")
        model = bounded_text(candidate.get("model"), f"candidates[{index}].model")
        if model in seen:
            continue
        seen.add(model)
        candidate["model"] = model
        candidates.append(candidate)
    return artifact, candidates


def validate_resolution_target(
    source_artifact: dict[str, Any],
    target_domain: str,
    target_scenario: str,
) -> None:
    source_domain = bounded_text(
        source_artifact.get("domain"), "候选 Artifact domain"
    )
    if source_domain not in TARGET_SCENARIOS:
        raise ResolutionError("候选 Artifact domain 仅支持 capacity 或 resource")
    if target_domain != source_domain:
        raise ResolutionError(
            "target-domain 必须与候选 Artifact domain 一致；"
            f"收到 target={target_domain}, source={source_domain}"
        )
    if target_scenario not in TARGET_SCENARIOS[target_domain]:
        raise ResolutionError(
            f"target-scenario 不适用于 {target_domain}：{target_scenario}"
        )
    expected_anchor = expected_anchor_source(target_domain, target_scenario)
    query = source_artifact.get("query")
    if not isinstance(query, dict):
        raise ResolutionError("候选 Artifact 缺少 query")
    query_anchor = bounded_text(
        query.get("anchor_source"), "候选 Artifact query.anchor_source"
    )
    handoffs = source_artifact.get("handoffs")
    if not isinstance(handoffs, dict):
        raise ResolutionError("候选 Artifact 缺少 handoffs")
    handoff = handoffs.get("model_candidates")
    if not isinstance(handoff, dict):
        raise ResolutionError("候选 Artifact 缺少 model_candidates 交接")
    handoff_anchor = bounded_text(
        handoff.get("anchor_source"),
        "候选 Artifact handoffs.model_candidates.anchor_source",
    )
    if query_anchor != handoff_anchor:
        raise ResolutionError("候选 Artifact 的 anchor_source 前后不一致")
    if query_anchor != expected_anchor:
        raise ResolutionError(
            f"{target_domain}/{target_scenario} 必须使用"
            f" anchor_source={expected_anchor}；收到 {query_anchor}"
        )


def candidate_view(candidate: dict[str, Any], method: str, score: float | None = None) -> dict[str, Any]:
    result = {
        key: value
        for key, value in candidate.items()
        if key in {"model", "source", "last_seen_epoch_seconds", "last_seen_at"}
    }
    result["match_method"] = method
    if score is not None:
        result["similarity"] = round(score, 4)
    return result


def automatic_matches(
    user_input: str,
    candidates: list[dict[str, Any]],
) -> tuple[str | None, list[dict[str, Any]]]:
    exact = [candidate for candidate in candidates if candidate["model"] == user_input]
    if exact:
        return "exact", exact

    normalized_input = normalized_name(user_input)
    case_matches = [
        candidate
        for candidate in candidates
        if normalized_name(candidate["model"]) == normalized_input
    ]
    if case_matches:
        return "case_insensitive_exact", case_matches

    key = comparison_key(user_input)
    separator_matches = [
        candidate
        for candidate in candidates
        if comparison_key(candidate["model"]) == key
    ]
    if separator_matches:
        return "separator_insensitive_exact", separator_matches
    return None, []


def suggestion_matches(
    user_input: str,
    candidates: list[dict[str, Any]],
    limit: int,
) -> list[dict[str, Any]]:
    input_key = comparison_key(user_input)
    ranked: list[tuple[int, int, str, dict[str, Any], str, float | None]] = []
    for candidate in candidates:
        candidate_key = comparison_key(candidate["model"])
        if not input_key or not candidate_key:
            continue
        method: str | None = None
        score: float | None = None
        rank = 99
        if candidate_key.startswith(input_key) or input_key.startswith(candidate_key):
            method = "prefix_suggestion"
            rank = 0
        elif input_key in candidate_key or candidate_key in input_key:
            method = "contains_suggestion"
            rank = 1
        else:
            score = difflib.SequenceMatcher(None, input_key, candidate_key).ratio()
            if score >= TYPO_SIMILARITY_THRESHOLD:
                method = "typo_suggestion"
                rank = 2
        if method is not None:
            ranked.append(
                (
                    rank,
                    abs(len(candidate_key) - len(input_key)),
                    candidate["model"],
                    candidate,
                    method,
                    score,
                )
            )
    ranked.sort(key=lambda item: (item[0], item[1], item[2]))
    return [
        candidate_view(candidate, method, score)
        for _, _, _, candidate, method, score in ranked[:limit]
    ]


def resolution_artifact(
    *,
    user_input: str,
    target_domain: str,
    target_scenario: str,
    source_path: str,
    source_artifact: dict[str, Any],
    candidates: list[dict[str, Any]],
    selected_model: str | None,
    suggestion_limit: int,
) -> dict[str, Any]:
    generated_at = utc_now()
    query = {
        "user_input": user_input,
        "normalized_input": normalized_name(user_input),
        "comparison_key": comparison_key(user_input),
        "target_domain": target_domain,
        "target_scenario": target_scenario,
        "candidate_artifact": str(Path(source_path).expanduser().resolve()),
        "anchor_source": source_artifact.get("query", {}).get("anchor_source"),
        "resolution_window": source_artifact.get("query", {}).get("window"),
    }
    summary: dict[str, Any] = {
        "decision": "model_not_found",
        "user_input": user_input,
        "resolved_model": None,
        "match_method": None,
        "candidate_count": len(candidates),
        "matched_candidate_count": 0,
        "candidates": [],
        "write_performed": False,
    }
    status = "partial"
    handoffs: dict[str, Any] = {}
    warnings: list[str] = []

    if selected_model is not None:
        selected_model = bounded_text(selected_model, "selected-model")
        selected = [
            candidate for candidate in candidates if candidate["model"] == selected_model
        ]
        if not selected:
            raise ResolutionError("selected-model 必须是候选 Artifact 中的精确模型名")
        method = "user_confirmation"
        matches = selected
    else:
        method, matches = automatic_matches(user_input, candidates)

    if method is not None and len(matches) == 1:
        resolved = matches[0]["model"]
        status = "success"
        summary.update(
            {
                "decision": "resolved",
                "resolved_model": resolved,
                "match_method": method,
                "matched_candidate_count": 1,
                "candidates": [candidate_view(matches[0], method)],
            }
        )
        handoffs["model"] = {
            "status": "ready",
            "model": resolved,
            "user_input": user_input,
            "match_method": method,
            "target_domain": target_domain,
            "target_scenario": target_scenario,
            "anchor_source": query["anchor_source"],
            "resolved_at": generated_at,
        }
    elif method is not None:
        summary.update(
            {
                "decision": "user_confirmation_required",
                "match_method": method,
                "matched_candidate_count": len(matches),
                "candidates": [candidate_view(candidate, method) for candidate in matches],
            }
        )
        warnings.append("多个真实模型在当前匹配等级下等价，不能自动选择")
    else:
        suggestions = suggestion_matches(user_input, candidates, suggestion_limit)
        if suggestions:
            summary.update(
                {
                    "decision": "user_confirmation_required",
                    "match_method": suggestions[0]["match_method"],
                    "matched_candidate_count": len(suggestions),
                    "candidates": suggestions,
                }
            )
            warnings.append("前缀、包含或拼写相似仅用于建议，不能自动选择")
        else:
            warnings.append("锚点数据源中没有找到可验证的模型候选")

    return {
        "schema_version": SCHEMA_VERSION,
        "script_version": SCRIPT_VERSION,
        "domain": "common",
        "scenario": "model-resolution",
        "status": status,
        "generated_at": generated_at,
        "query": query,
        "summary": summary,
        "handoffs": handoffs,
        "warnings": warnings,
        "errors": [],
    }


def load_candidate_manifest(
    path_value: str,
) -> tuple[Path, dict[str, Any], list[dict[str, Any]]]:
    path = Path(path_value).expanduser().resolve()
    with path.open(encoding="utf-8") as handle:
        manifest = json.load(handle)
    if not isinstance(manifest, dict):
        raise ResolutionError("模型候选批量 Manifest 必须是 JSON 对象")
    if manifest.get("scenario") != "model-candidates-batch":
        raise ResolutionError(
            "模型候选批量 Manifest 的 scenario 必须是 model-candidates-batch"
        )
    domain = manifest.get("domain")
    if domain not in TARGET_SCENARIOS:
        raise ResolutionError("模型候选批量 Manifest domain 仅支持 capacity 或 resource")
    artifacts = manifest.get("artifacts")
    if not isinstance(artifacts, dict):
        raise ResolutionError("模型候选批量 Manifest 缺少 artifacts")
    raw_items = artifacts.get("model_candidates")
    if not isinstance(raw_items, list):
        raise ResolutionError("artifacts.model_candidates 必须是数组")
    if not 2 <= len(raw_items) <= MAX_BATCH_MODEL_INPUTS:
        raise ResolutionError(
            f"模型候选批量 Manifest 必须包含 2～{MAX_BATCH_MODEL_INPUTS} 个项目"
        )
    items: list[dict[str, Any]] = []
    seen_inputs: set[str] = set()
    for index, raw_item in enumerate(raw_items):
        if not isinstance(raw_item, dict):
            raise ResolutionError(f"model_candidates[{index}] 必须是对象")
        if raw_item.get("index") != index:
            raise ResolutionError("模型候选批量 Manifest index 必须连续且保持输入顺序")
        model_input = bounded_text(
            raw_item.get("model_input"),
            f"model_candidates[{index}].model_input",
        )
        if model_input in seen_inputs:
            raise ResolutionError("模型候选批量 Manifest 的 model_input 不得重复")
        seen_inputs.add(model_input)
        artifact_path = bounded_path_text(
            raw_item.get("artifact"),
            f"model_candidates[{index}].artifact",
        )
        items.append(
            {
                "index": index,
                "model_input": model_input,
                "status": str(raw_item.get("status", "error")),
                "artifact": artifact_path,
            }
        )
    return path, manifest, items


def parse_batch_selections(
    values: list[str] | None,
    item_count: int,
) -> dict[int, str]:
    selections: dict[int, str] = {}
    for raw_value in values or []:
        if "=" not in raw_value:
            raise ResolutionError("selection 必须使用 INDEX=EXACT_MODEL 格式")
        raw_index, raw_model = raw_value.split("=", 1)
        try:
            index = int(raw_index)
        except ValueError as exc:
            raise ResolutionError("selection INDEX 必须是整数") from exc
        if not 0 <= index < item_count:
            raise ResolutionError("selection INDEX 超出候选项目范围")
        if index in selections:
            raise ResolutionError(f"selection INDEX 重复：{index}")
        selections[index] = bounded_text(raw_model, "selection model")
    return selections


def batch_resolution_error_artifact(
    *,
    model_input: str,
    index: int,
    item_count: int,
    target_domain: str,
    target_scenario: str,
    candidate_artifact: str,
    source_manifest: str,
    error: Exception,
) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "script_version": SCRIPT_VERSION,
        "domain": "common",
        "scenario": "model-resolution",
        "status": "error",
        "generated_at": utc_now(),
        "query": {
            "user_input": model_input,
            "target_domain": target_domain,
            "target_scenario": target_scenario,
            "candidate_artifact": candidate_artifact,
            "batch": {
                "enabled": True,
                "model_index": index,
                "model_count": item_count,
                "source_manifest": source_manifest,
            },
        },
        "summary": {
            "decision": "resolution_failed",
            "user_input": model_input,
            "resolved_model": None,
            "write_performed": False,
        },
        "handoffs": {},
        "warnings": [],
        "errors": [str(error)],
    }


def resolve_batch(args: argparse.Namespace) -> dict[str, Any]:
    if not 1 <= args.suggestion_limit <= 20:
        raise ResolutionError("suggestion-limit 必须在 1～20 之间")
    if not 1 <= args.max_workers <= MAX_MAX_WORKERS:
        raise ResolutionError(
            f"max-workers 必须在 1～{MAX_MAX_WORKERS} 之间"
        )
    target_domain = bounded_text(args.target_domain, "target-domain")
    target_scenario = bounded_text(args.target_scenario, "target-scenario")
    manifest_path, source_manifest, items = load_candidate_manifest(
        args.candidates_manifest
    )
    if source_manifest.get("domain") != target_domain:
        raise ResolutionError(
            "target-domain 必须与模型候选批量 Manifest domain 一致"
        )
    selections = parse_batch_selections(args.selection, len(items))
    source_query = source_manifest.get("query")
    if not isinstance(source_query, dict):
        raise ResolutionError("模型候选批量 Manifest 缺少 query")
    expected_anchor = bounded_text(
        source_query.get("anchor_source"),
        "模型候选批量 Manifest query.anchor_source",
    )
    expected_window = source_query.get("window")
    if not isinstance(expected_window, dict):
        raise ResolutionError("模型候选批量 Manifest query.window 必须是对象")
    output_dir = Path(args.output_dir).expanduser().resolve()

    def resolve_one(index: int) -> tuple[int, dict[str, Any], Path]:
        item = items[index]
        model_input = item["model_input"]
        candidate_path = str(Path(item["artifact"]).expanduser().resolve())
        try:
            source_artifact, candidates = load_candidate_artifact(candidate_path)
            validate_resolution_target(
                source_artifact, target_domain, target_scenario
            )
            query = source_artifact.get("query")
            if not isinstance(query, dict):
                raise ResolutionError("模型候选 Artifact 缺少 query")
            if query.get("model_input") != model_input:
                raise ResolutionError(
                    "模型候选 Artifact 的 model_input 与批量 Manifest 不一致"
                )
            if query.get("anchor_source") != expected_anchor:
                raise ResolutionError(
                    "模型候选 Artifact 的 anchor_source 与批量 Manifest 不一致"
                )
            if query.get("window") != expected_window:
                raise ResolutionError(
                    "模型候选 Artifact 的 window 与批量 Manifest 不一致"
                )
            value = resolution_artifact(
                user_input=model_input,
                target_domain=target_domain,
                target_scenario=target_scenario,
                source_path=candidate_path,
                source_artifact=source_artifact,
                candidates=candidates,
                selected_model=selections.get(index),
                suggestion_limit=args.suggestion_limit,
            )
            value["query"]["batch"] = {
                "enabled": True,
                "model_index": index,
                "model_count": len(items),
                "source_manifest": str(manifest_path),
            }
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            value = batch_resolution_error_artifact(
                model_input=model_input,
                index=index,
                item_count=len(items),
                target_domain=target_domain,
                target_scenario=target_scenario,
                candidate_artifact=candidate_path,
                source_manifest=str(manifest_path),
                error=exc,
            )
        output_path = output_dir / f"resolution-{index + 1:03d}.json"
        write_artifact(str(output_path), value)
        return index, value, output_path

    completed_by_index: dict[int, tuple[dict[str, Any], Path]] = {}
    with ThreadPoolExecutor(max_workers=args.max_workers) as executor:
        futures = {
            executor.submit(resolve_one, index): index
            for index in range(len(items))
        }
        for future in as_completed(futures):
            index, value, output_path = future.result()
            completed_by_index[index] = (value, output_path)

    artifact_items: list[dict[str, Any]] = []
    statuses: list[str] = []
    resolved_models: list[str] = []
    confirmations: list[dict[str, Any]] = []
    warnings: list[str] = []
    errors: list[str] = []
    for index, item in enumerate(items):
        value, output_path = completed_by_index[index]
        status = str(value.get("status", "error"))
        summary = value.get("summary", {})
        statuses.append(status)
        resolved_model = (
            summary.get("resolved_model") if isinstance(summary, dict) else None
        )
        if isinstance(resolved_model, str) and resolved_model:
            resolved_models.append(resolved_model)
        if (
            isinstance(summary, dict)
            and summary.get("decision") == "user_confirmation_required"
        ):
            confirmations.append(
                {
                    "index": index,
                    "model_input": item["model_input"],
                    "candidates": summary.get("candidates", []),
                }
            )
        artifact_items.append(
            {
                "index": index,
                "model_input": item["model_input"],
                "status": status,
                "resolved_model": resolved_model,
                "artifact": str(output_path),
                "summary": summary,
            }
        )
        warnings.extend(
            f"{item['model_input']}: {warning}"
            for warning in value.get("warnings", [])
            if isinstance(warning, str)
        )
        errors.extend(
            f"{item['model_input']}: {error}"
            for error in value.get("errors", [])
            if isinstance(error, str)
        )

    duplicate_models = sorted(
        model
        for model in set(resolved_models)
        if resolved_models.count(model) > 1
    )
    if duplicate_models:
        errors.append(
            "多个输入解析为同一精确模型：" + ", ".join(duplicate_models)
        )

    all_success = all(status == "success" for status in statuses)
    if all_success and not duplicate_models:
        status = "success"
        decision = "batch_resolved"
        handoff_status = "ready"
    elif all(status == "error" for status in statuses):
        status = "error"
        decision = "batch_resolution_failed"
        handoff_status = "blocked"
    else:
        status = "partial"
        decision = (
            "user_confirmation_required"
            if confirmations
            else "batch_resolution_incomplete"
        )
        handoff_status = "partial"
    handoff: dict[str, Any] = {
        "status": handoff_status,
        "artifacts": [item["artifact"] for item in artifact_items],
    }
    if handoff_status == "ready":
        handoff["models"] = resolved_models
    return {
        "schema_version": SCHEMA_VERSION,
        "script_version": SCRIPT_VERSION,
        "domain": "common",
        "scenario": "model-resolution-batch",
        "status": status,
        "generated_at": utc_now(),
        "query": {
            "candidate_manifest": str(manifest_path),
            "target_domain": target_domain,
            "target_scenario": target_scenario,
            "anchor_source": expected_anchor,
            "resolution_window": expected_window,
            "max_workers": args.max_workers,
            "execution": "bounded_parallel_input_order_output",
        },
        "summary": {
            "decision": decision,
            "input_count": len(items),
            "successful_input_count": statuses.count("success"),
            "partial_input_count": statuses.count("partial"),
            "failed_input_count": statuses.count("error"),
            "confirmation_required_count": len(confirmations),
            "confirmations": confirmations,
            "duplicate_resolved_models": duplicate_models,
            "max_workers": args.max_workers,
            "write_performed": False,
        },
        "artifacts": {"model_resolution": artifact_items},
        "handoffs": {"model_artifacts": handoff},
        "warnings": warnings,
        "errors": errors,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="将用户模型表达解析为真实精确模型名")
    commands = parser.add_subparsers(dest="command", required=True)
    resolve = commands.add_parser("resolve")
    resolve.add_argument("--input", required=True, help="用户提供的模型表达")
    resolve.add_argument(
        "--candidates-artifact",
        required=True,
        help="容量或资源领域脚本生成的 model-candidates Artifact",
    )
    resolve.add_argument("--target-domain", required=True, help="目标主领域")
    resolve.add_argument("--target-scenario", required=True, help="目标业务场景")
    resolve.add_argument(
        "--selected-model",
        help="用户从候选中确认的精确模型名",
    )
    resolve.add_argument(
        "--suggestion-limit",
        type=int,
        default=DEFAULT_SUGGESTION_LIMIT,
        help=f"最多返回多少候选建议，默认 {DEFAULT_SUGGESTION_LIMIT}",
    )
    resolve.add_argument("--output", required=True, help="模型解析 Artifact 输出路径")

    resolve_batch_parser = commands.add_parser(
        "resolve-batch",
        help="按候选 Manifest 输入顺序有界并发生成多个模型解析 Artifact",
    )
    resolve_batch_parser.add_argument(
        "--candidates-manifest",
        required=True,
        help="容量域或资源域 list-models-batch 生成的 Manifest",
    )
    resolve_batch_parser.add_argument(
        "--target-domain", required=True, help="目标主领域"
    )
    resolve_batch_parser.add_argument(
        "--target-scenario", required=True, help="目标业务场景"
    )
    resolve_batch_parser.add_argument(
        "--selection",
        action="append",
        help="用户确认的精确候选，使用 INDEX=EXACT_MODEL，可重复传入",
    )
    resolve_batch_parser.add_argument(
        "--suggestion-limit",
        type=int,
        default=DEFAULT_SUGGESTION_LIMIT,
        help=f"每个输入最多返回多少候选建议，默认 {DEFAULT_SUGGESTION_LIMIT}",
    )
    resolve_batch_parser.add_argument(
        "--max-workers",
        type=int,
        default=DEFAULT_MAX_WORKERS,
        help=f"最大并发数，默认 {DEFAULT_MAX_WORKERS}",
    )
    resolve_batch_parser.add_argument(
        "--output-dir", required=True, help="逐模型解析 Artifact 输出目录"
    )
    resolve_batch_parser.add_argument(
        "--output", required=True, help="批量模型解析 Manifest 输出路径"
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        if args.command == "resolve-batch":
            artifact = resolve_batch(args)
        else:
            if not 1 <= args.suggestion_limit <= 20:
                raise ResolutionError("suggestion-limit 必须在 1～20 之间")
            user_input = bounded_text(args.input, "input")
            target_domain = bounded_text(args.target_domain, "target-domain")
            target_scenario = bounded_text(
                args.target_scenario, "target-scenario"
            )
            source_artifact, candidates = load_candidate_artifact(
                args.candidates_artifact
            )
            validate_resolution_target(
                source_artifact, target_domain, target_scenario
            )
            artifact = resolution_artifact(
                user_input=user_input,
                target_domain=target_domain,
                target_scenario=target_scenario,
                source_path=args.candidates_artifact,
                source_artifact=source_artifact,
                candidates=candidates,
                selected_model=args.selected_model,
                suggestion_limit=args.suggestion_limit,
            )
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        artifact = {
            "schema_version": SCHEMA_VERSION,
            "script_version": SCRIPT_VERSION,
            "domain": "common",
            "scenario": (
                "model-resolution-batch"
                if args.command == "resolve-batch"
                else "model-resolution"
            ),
            "status": "error",
            "generated_at": utc_now(),
            "summary": {
                "decision": "resolution_failed",
                "resolved_model": None,
                "write_performed": False,
            },
            "handoffs": {},
            "warnings": [],
            "errors": [str(exc)],
        }
    annotate_outcome(artifact)
    try:
        output = write_artifact(args.output, artifact)
    except OSError as exc:
        print(json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False))
        return 1
    print(
        json.dumps(
            terminal_brief(artifact, output, flatten_summary=True),
            ensure_ascii=False,
        )
    )
    return 0 if artifact["status"] != "error" else 1


if __name__ == "__main__":
    sys.exit(main())
