#!/usr/bin/env python3
"""Run a fixed read-only query to verify DSC/IDP ClickHouse connectivity."""

from __future__ import annotations

import argparse
import json
import sys

from runtime import query_clickhouse, utc_now, write_artifact


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="使用固定的 SELECT 1 验证 ClickHouse 连接。"
    )
    parser.add_argument("--output", required=True, help="JSON Artifact 输出路径")
    parser.add_argument("--timeout", type=float, default=30.0, help="请求超时秒数")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if not 1 <= args.timeout <= 600:
        print(
            json.dumps(
                {"status": "error", "error": "timeout 必须在 1～600 秒之间"},
                ensure_ascii=False,
            )
        )
        return 1

    try:
        result = query_clickhouse("SELECT 1 AS ok", args.timeout)
        rows = result.get("data", [])
        ok = bool(rows and str(rows[0].get("ok")) == "1")
        status = "success" if ok else "error"
        value = {
            "schema_version": "1.0",
            "domain": "system",
            "scenario": "connection-check",
            "status": status,
            "generated_at": utc_now(),
            "summary": {"connected": ok},
            "evidence": {
                "clickhouse_meta": result.get("meta", []),
                "clickhouse_rows": rows,
                "row_count": result.get("rows", len(rows)),
                "statistics": result.get("statistics"),
            },
        }
        output = write_artifact(args.output, value)
        print(
            json.dumps(
                {"status": status, "connected": ok, "artifact": str(output)},
                ensure_ascii=False,
            )
        )
        return 0 if ok else 1
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False))
        return 1


if __name__ == "__main__":
    sys.exit(main())
