#!/usr/bin/env python3
"""Shared DSC-authenticated ClickHouse transport and local Artifact storage."""

from __future__ import annotations

import json
import os
import sys
import tempfile
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


SKILL_ROOT = Path(__file__).resolve().parent.parent
VENDOR_PATH = SKILL_ROOT / "vendor"
if VENDOR_PATH.is_dir():
    sys.path.insert(0, str(VENDOR_PATH))

# protobuf 3.20.1 contains a portable Python implementation. Force it so the
# bundled dependencies work across Agent hosts without platform-specific wheels.
os.environ.setdefault("PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION", "python")

DEFAULT_CONFIG_PATH = (
    SKILL_ROOT / "config" / "idp_auth_config.json"
)
DEFAULT_DSC_AUTH_GATEWAY = "http://dsc-auth.internal"
DSC_TOKEN_TTL_MILLISECONDS = 7 * 24 * 60 * 60 * 1000
CONFIG_ENVIRONMENT_VARIABLES = {
    "proxy": "WANQING_CLICKHOUSE_PROXY",
    "auth_principal": "WANQING_CLICKHOUSE_AUTH_PRINCIPAL",
    "auth_type": "WANQING_CLICKHOUSE_AUTH_TYPE",
    "auth_secret_key": "WANQING_CLICKHOUSE_AUTH_SECRET_KEY",
    "user": "WANQING_CLICKHOUSE_USER",
    "group_id": "WANQING_CLICKHOUSE_GROUP_ID",
}
REQUIRED_CONFIG_FIELDS = (
    "proxy",
    "auth_principal",
    "auth_type",
    "auth_secret_key",
    "user",
)


@dataclass(frozen=True)
class ClickHouseConfig:
    proxy: str
    auth_principal: str
    auth_type: str
    auth_secret_key: str
    user: str
    group_id: str | None

    @classmethod
    def from_mapping(cls, value: dict[str, Any], source: str) -> "ClickHouseConfig":
        missing = [
            field for field in REQUIRED_CONFIG_FIELDS
            if not str(value.get(field, "")).strip()
        ]
        if missing:
            raise RuntimeError(
                f"{source} 缺少必填配置：" + ", ".join(missing)
            )

        proxy = str(value["proxy"]).strip()
        parsed_proxy = urlparse(proxy)
        if parsed_proxy.scheme not in {"http", "https"} or not parsed_proxy.netloc:
            raise RuntimeError(f"{source} 中的 proxy 必须是有效的 HTTP(S) URL")

        return cls(
            proxy=proxy,
            auth_principal=str(value["auth_principal"]).strip(),
            auth_type=str(value["auth_type"]).strip(),
            auth_secret_key=str(value["auth_secret_key"]).strip(),
            user=str(value["user"]).strip(),
            group_id=str(value.get("group_id", "")).strip() or None,
        )

    @classmethod
    def from_environment(cls) -> "ClickHouseConfig":
        value = {
            field: os.environ.get(variable, "").strip()
            for field, variable in CONFIG_ENVIRONMENT_VARIABLES.items()
        }
        missing_variables = [
            CONFIG_ENVIRONMENT_VARIABLES[field]
            for field in REQUIRED_CONFIG_FIELDS
            if not value[field]
        ]
        if missing_variables:
            raise RuntimeError(
                "Agent 运行环境缺少 ClickHouse 配置变量："
                + ", ".join(missing_variables)
                + "；请由 Agent 管理员配置，不要在对话中发送凭证"
            )
        return cls.from_mapping(value, "Agent 环境变量")

    @classmethod
    def from_path(cls, path: Path) -> "ClickHouseConfig":
        try:
            mode = path.stat().st_mode
            if mode & 0o077:
                raise RuntimeError(
                    f"ClickHouse 配置文件权限过宽：{path}；请执行 chmod 600"
                )
            value = json.loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError as exc:
            raise RuntimeError(
                f"缺少 ClickHouse 配置文件：{path}；或使用 --fixture 离线验证"
            ) from exc
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"ClickHouse 配置文件不是合法 JSON：{path}") from exc

        if not isinstance(value, dict):
            raise RuntimeError("ClickHouse 配置文件必须是 JSON 对象")
        return cls.from_mapping(value, f"ClickHouse 配置文件 {path}")

    @classmethod
    def load(cls) -> "ClickHouseConfig":
        configured_path = os.environ.get("WANQING_CLICKHOUSE_CONFIG", "").strip()
        if configured_path:
            return cls.from_path(
                Path(configured_path).expanduser().resolve()
            )

        environment_configured = any(
            os.environ.get(variable, "").strip()
            for variable in CONFIG_ENVIRONMENT_VARIABLES.values()
        )
        if environment_configured:
            return cls.from_environment()
        if DEFAULT_CONFIG_PATH.is_file():
            return cls.from_path(DEFAULT_CONFIG_PATH)
        return cls.from_environment()


def configure_bundled_dsc_auth() -> None:
    gateway = (
        os.environ.get("WANQING_DSC_AUTH_GATEWAY", "").strip()
        or DEFAULT_DSC_AUTH_GATEWAY
    )
    parsed_gateway = urlparse(gateway)
    if (
        parsed_gateway.scheme not in {"http", "https"}
        or not parsed_gateway.netloc
    ):
        raise RuntimeError("WANQING_DSC_AUTH_GATEWAY 必须是有效的 HTTP(S) URL")

    try:
        from dsc.config import dsc_config, perf_log
    except ImportError as exc:
        raise RuntimeError(
            "Skill 内置 DSC 依赖不完整；请重新安装包含 vendor/ 的发布包"
        ) from exc

    # dsc-auth normally reads these stable production defaults through
    # infra-kconf. Inject them directly to keep the Skill self-contained and
    # disable degraded-token fallback so authentication failures stay explicit.
    dsc_config.gateway = lambda: gateway
    dsc_config.token_expire_time_scale_ratio = lambda: 1.5
    dsc_config.degrade_switch = lambda: False
    dsc_config.degrade_expire_milli_seconds = lambda: 7_200_000
    dsc_config.degrade_client_sign_key = lambda: "dsc-client-degrade"
    perf_log.perf_log = lambda *args, **kwargs: None


def get_dsc_token(config: ClickHouseConfig) -> str:
    configure_bundled_dsc_auth()
    try:
        from dsc.client import DscAccessTokenProvider
        from dsc.util.auth_res_type import AuthResourceType
    except ImportError as exc:
        raise RuntimeError(
            "Skill 内置 DSC 依赖不完整；请重新安装包含 vendor/ 的发布包"
        ) from exc

    try:
        token = DscAccessTokenProvider.get_token_with_tt(
            config.auth_principal,
            config.auth_secret_key,
            DSC_TOKEN_TTL_MILLISECONDS,
            AuthResourceType.ENGINE,
        )
    except Exception as exc:
        raise RuntimeError(
            f"生成 DSC Token 失败（{type(exc).__name__}）"
        ) from exc
    if not token:
        raise RuntimeError("DSC Token 服务返回空 Token")
    return str(token)


def query_clickhouse(sql: str, timeout: float) -> dict[str, Any]:
    try:
        import requests
    except ImportError as exc:
        raise RuntimeError(
            "Skill 内置 HTTP 依赖不完整；请重新安装包含 vendor/ 的发布包"
        ) from exc

    config = ClickHouseConfig.load()
    auth_token = get_dsc_token(config)

    query = sql.strip().rstrip(";")
    if not query.upper().endswith("FORMAT JSON"):
        query += "\nFORMAT JSON"

    headers = {
        "Content-Type": "text/plain; charset=utf-8",
        "Accept": "application/json",
        "Ks-Auth-Principal": config.auth_principal,
        "Ks-Auth-Token": auth_token,
        "Ks-Auth-Type": config.auth_type,
        "Ks-Auth-User": config.user,
        "Ks-Query-Id": str(uuid.uuid4()),
    }

    response = None
    try:
        response = requests.post(
            url=config.proxy,
            data=query.encode("utf-8"),
            headers=headers,
            timeout=timeout,
        )
        response.raise_for_status()
        body = response.text
    except requests.exceptions.Timeout as exc:
        raise RuntimeError(f"ClickHouse 请求超过 {timeout:g} 秒") from exc
    except requests.exceptions.RequestException as exc:
        detail = ""
        if response is not None and response.content:
            detail = response.content.decode("utf-8", errors="replace")[:500]
        suffix = f"：{detail}" if detail else ""
        raise RuntimeError(
            f"ClickHouse 请求失败（{type(exc).__name__}）{suffix}"
        ) from exc

    try:
        result = json.loads(body)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"ClickHouse 返回了非法 JSON：{body[:500]}") from exc
    return validate_clickhouse_result(result)


def validate_clickhouse_result(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict) or not isinstance(value.get("data"), list):
        raise ValueError("ClickHouse JSON 必须是包含 data 列表的对象")
    return value


def query_or_fixture(
    sql: str, timeout: float, fixture: str | None
) -> dict[str, Any]:
    if not fixture:
        return query_clickhouse(sql, timeout)
    with open(fixture, encoding="utf-8") as handle:
        return validate_clickhouse_result(json.load(handle))


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def write_artifact(path_value: str, value: dict[str, Any]) -> Path:
    path = Path(path_value).expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
        os.replace(temporary, path)
        os.chmod(path, 0o600)
    except BaseException:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise
    return path
