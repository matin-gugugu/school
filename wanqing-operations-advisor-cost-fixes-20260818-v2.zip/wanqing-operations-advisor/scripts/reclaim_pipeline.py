#!/usr/bin/env python3
"""Low-freedom two-stage cloud-reclaim pipeline."""

from __future__ import annotations

import argparse
import copy
import json
import sys
import uuid
from pathlib import Path
from typing import Any

from artifact_contract import (
    ArtifactContractError,
    add_provenance,
    annotate_outcome,
    artifact_reference,
    reason_code_for,
    validate_provenance,
)
from capacity_workflow_contract import parse_named_selections
from capacity_workflow_support import (
    WorkflowArtifactSupport,
    attach_evidence_id,
    build_isvc_batch_command,
    build_kconf_batch_command,
    parent_references,
    validate_evidence_id_binding,
    validate_kconf_next_action,
    validate_parent_path_bindings,
)
from model_contract import (
    ModelContractError,
    load_model_resolution,
    trusted_scope_resolution_artifact,
    validate_embedded_model_resolution,
)
from runtime import utc_now, write_artifact
from top_p_policy import (
    POLICY_SOURCE,
    POLICY_VERSION,
    TOP_P_MODELS_BY_GPU,
    default_all_model_plan,
    selected_models,
)


SCRIPT_VERSION = "2.6.0"
SCRIPT_ROOT = Path(__file__).resolve().parent
CAPACITY_SCRIPT = SCRIPT_ROOT / "capacity.py"
MODEL_RESOLVER_SCRIPT = SCRIPT_ROOT / "model_resolver.py"
KCONF_SCRIPT = SCRIPT_ROOT / "kconf.py"
ISVC_SCRIPT = SCRIPT_ROOT / "isvc.py"
RESOURCE_SCRIPT = SCRIPT_ROOT / "resource.py"
COST_SCRIPT = SCRIPT_ROOT / "cost.py"

PLAN_ARTIFACT_TYPE = "wanqing.cloud_reclaim.plan"
RESULT_ARTIFACT_TYPE = "wanqing.cloud_reclaim.result"
REPORT_ARTIFACT_TYPE = "wanqing.cloud_reclaim.report"
PRODUCER_SCRIPT = "workflow.py"
KCONF_TOOL = "kconf_single_config_data"
KCONF_KEY = "cloud.llmdevops.stability-capacity-by-instance"
KCONF_STAGE = "production"
PREPARE_REQUEST_ARTIFACT_TYPE = "wanqing.cloud_reclaim.request"
MAX_EXPLICIT_MODELS = 20
TRUSTED_POLICY_MODELS = frozenset(
    model for models in TOP_P_MODELS_BY_GPU.values() for model in models
)


class ReclaimPipelineError(ValueError):
    """Raised when a trusted pipeline stage cannot continue."""

    def __init__(self, message: str, reason_code: str = "INVALID_INPUT") -> None:
        super().__init__(message)
        self.reason_code = reason_code


_artifact_support = WorkflowArtifactSupport(ReclaimPipelineError)
load_object = _artifact_support.load_object
run_artifact_command = _artifact_support.run_artifact_command


def add_common_prepare_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--scope",
        choices=("all", "gpu", "explicit"),
        required=True,
        help="all=双卡型全量；gpu=单卡型策略；explicit=用户明确模型",
    )
    parser.add_argument("--gpu", choices=("X60", "X40"))
    parser.add_argument("--top-p", type=int)
    parser.add_argument(
        "--detail-level",
        choices=("instances", "cards", "machines"),
        default="machines",
        help="instances 只算实例；cards/machines 才查询 iSvc，默认 machines",
    )
    parser.add_argument(
        "--model-input",
        action="append",
        help="scope=explicit 时按用户顺序重复传入",
    )
    parser.add_argument(
        "--window-relation",
        choices=("previous_day",),
        default="previous_day",
        help="云上容量回收固定为 previous_day",
    )
    parser.add_argument("--timezone", default="Asia/Shanghai")
    parser.add_argument("--timeout", type=float, default=30.0)
    parser.add_argument("--isvc-timeout", type=float, default=30.0)
    parser.add_argument("--max-workers", type=int, default=4)
    parser.add_argument(
        "--candidate-fixture",
        action="append",
        help="仅用于离线测试；按 model-input 顺序重复传入",
    )
    parser.add_argument(
        "--capacity-fixture", help="仅用于离线测试的批量容量响应"
    )
    parser.add_argument(
        "--usage-fixture", help="仅用于离线测试的批量用量响应"
    )
    parser.add_argument("--isvc-fixture", help="仅用于离线测试的 iSvc 响应")
    parser.add_argument(
        "--resource-fixture",
        help="仅用于离线测试的资源域模型当前持有量响应",
    )
    parser.add_argument(
        "--cost-fixture",
        help="仅用于离线测试的前一天云上成本响应",
    )
    parser.add_argument(
        "--service-selection",
        action="append",
        default=[],
        help="逐模型 iSvc KSN 选择，格式 MODEL=SERVICE，可重复传入",
    )
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--output", required=True)


def add_finalize_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--plan-artifact", required=True)
    parser.add_argument("--kconf-tool-result", required=True)
    parser.add_argument(
        "--device-type",
        help="普通配置存在多卡型时，由用户明确选择后重新运行",
    )
    parser.add_argument(
        "--device-type-selection",
        action="append",
        default=[],
        help="逐模型 KConf 卡型选择，格式 MODEL=DEVICE，可重复传入",
    )
    parser.add_argument("--max-workers", type=int, default=4)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--output", required=True)


def add_report_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--output", required=True)


def select_scope(args: argparse.Namespace) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    model_inputs = list(args.model_input or [])
    if args.scope == "all":
        if args.gpu or args.top_p is not None or model_inputs:
            raise ReclaimPipelineError(
                "scope=all 不接受 --gpu、--top-p 或 --model-input"
            )
        entries = [
            {"model_input": model, "policy_gpu_type": item["gpu_type"]}
            for item in default_all_model_plan()
            for model in item["models"]
        ]
        selection = {
            "scope": "all",
            "plan": default_all_model_plan(),
        }
    elif args.scope == "gpu":
        if args.gpu is None:
            raise ReclaimPipelineError("scope=gpu 必须提供 --gpu")
        if model_inputs:
            raise ReclaimPipelineError("scope=gpu 不接受 --model-input")
        top_p = args.top_p or len(TOP_P_MODELS_BY_GPU[args.gpu])
        models = selected_models(args.gpu, top_p)
        entries = [
            {"model_input": model, "policy_gpu_type": args.gpu}
            for model in models
        ]
        selection = {
            "scope": "gpu",
            "gpu_type": args.gpu,
            "top_p": top_p,
            "models": models,
        }
    else:
        if args.gpu or args.top_p is not None:
            raise ReclaimPipelineError(
                "scope=explicit 不接受 --gpu 或 --top-p"
            )
        if not model_inputs:
            raise ReclaimPipelineError(
                "scope=explicit 至少提供一个 --model-input"
            )
        if len(model_inputs) > MAX_EXPLICIT_MODELS:
            raise ReclaimPipelineError(
                f"scope=explicit 最多提供 {MAX_EXPLICIT_MODELS} 个 --model-input"
            )
        if len(model_inputs) != len(set(model_inputs)):
            raise ReclaimPipelineError("--model-input 不得重复")
        entries = [{"model_input": value} for value in model_inputs]
        selection = {"scope": "explicit", "model_inputs": model_inputs}

    fixtures = list(args.candidate_fixture or [])
    if fixtures and len(fixtures) != len(entries):
        raise ReclaimPipelineError(
            "--candidate-fixture 数量必须与待解析模型数一致"
        )
    if not 1 <= args.max_workers <= 8:
        raise ReclaimPipelineError("--max-workers 必须在 1～8 之间")
    if not 1 <= args.timeout <= 600 or not 1 <= args.isvc_timeout <= 600:
        raise ReclaimPipelineError("timeout 必须在 1～600 秒之间")
    if args.detail_level == "instances" and args.service_selection:
        raise ReclaimPipelineError(
            "--detail-level instances 不接受 --service-selection"
        )
    return entries, selection


def write_prepare_request(
    args: argparse.Namespace,
    selection: dict[str, Any],
    output_dir: Path,
    run_id: str,
) -> Path:
    path = output_dir / "00-request.json"
    request = normalized_reclaim_request(args, selection)
    value = {
        "schema_version": "1.1",
        "script_version": SCRIPT_VERSION,
        "domain": "workflow",
        "scenario": "cloud-reclaim-request",
        "status": "success",
        "generated_at": utc_now(),
        "summary": {**request, "write_performed": False},
        "warnings": [],
        "errors": [],
    }
    annotate_outcome(value, complete=True, reason_code="OK", next_action="NONE")
    add_provenance(
        value,
        artifact_type=PREPARE_REQUEST_ARTIFACT_TYPE,
        producer_script=PRODUCER_SCRIPT,
        producer_version=SCRIPT_VERSION,
        run_id=run_id,
        stage="request_normalized",
    )
    write_artifact(str(path), value)
    return path.resolve()


def normalized_reclaim_request(
    args: argparse.Namespace,
    selection: dict[str, Any],
) -> dict[str, Any]:
    return {
        "selection": copy.deepcopy(selection),
        "detail_level": args.detail_level,
        "window_relation": args.window_relation,
        "timezone": args.timezone,
        "service_selections": sorted(args.service_selection or []),
    }


def validate_prepare_request(plan: dict[str, Any]) -> dict[str, Any]:
    embedded = plan.get("request")
    if isinstance(embedded, dict):
        selection = embedded.get("selection")
        detail_level = embedded.get("detail_level")
        relation = embedded.get("window_relation")
        timezone = embedded.get("timezone")
        service_selections = embedded.get("service_selections")
        if (
            not isinstance(selection, dict)
            or detail_level not in {"instances", "cards", "machines"}
            or relation != "previous_day"
            or not isinstance(timezone, str)
            or not timezone
            or not isinstance(service_selections, list)
            or any(not isinstance(value, str) for value in service_selections)
        ):
            raise ReclaimPipelineError(
                "计划中的 canonical request 无效", "ARTIFACT_INVALID"
            )
        return copy.deepcopy(embedded)

    provenance = plan.get("provenance")
    parents = provenance.get("parents") if isinstance(provenance, dict) else None
    paths = [
        parent.get("path")
        for parent in parents or []
        if isinstance(parent, dict) and parent.get("role") == "prepare_request"
    ]
    if len(paths) != 1 or not isinstance(paths[0], str):
        raise ReclaimPipelineError(
            "云上回收计划必须绑定唯一 prepare_request",
            "ARTIFACT_INVALID",
        )
    _, request = load_object(paths[0])
    try:
        validate_provenance(
            request,
            expected_artifact_type=PREPARE_REQUEST_ARTIFACT_TYPE,
            expected_producer_script=PRODUCER_SCRIPT,
            expected_producer_version=SCRIPT_VERSION,
            expected_stage="request_normalized",
        )
    except ArtifactContractError as exc:
        raise ReclaimPipelineError(str(exc), "ARTIFACT_INVALID") from exc
    if request.get("run_id") != plan.get("run_id"):
        raise ReclaimPipelineError(
            "prepare_request 与计划的 run_id 不一致", "ARTIFACT_INVALID"
        )
    summary = request.get("summary")
    if not isinstance(summary, dict):
        raise ReclaimPipelineError(
            "prepare_request 缺少 summary", "ARTIFACT_INVALID"
        )
    return summary


def headroom_dependency_indexes(
    *,
    args: argparse.Namespace,
    entries: list[dict[str, Any]],
    model_paths: list[Path],
    headroom_paths: list[Path],
) -> list[int]:
    """Return only models whose cloud headroom can consume KConf/iSvc."""

    ready: list[int] = []
    for index, (entry, model_path, headroom_path) in enumerate(
        zip(entries, model_paths, headroom_paths)
    ):
        _, artifact = load_object(headroom_path)
        if artifact.get("domain") != "capacity" or artifact.get("scenario") != "query-headroom":
            raise ReclaimPipelineError(
                f"headroom[{index}] 不是容量 query-headroom Artifact",
                "ARTIFACT_INVALID",
            )
        if artifact.get("status") not in {"success", "partial", "error"}:
            raise ReclaimPipelineError(
                f"headroom[{index}].status 无效", "ARTIFACT_INVALID"
            )
        query = artifact.get("query")
        if not isinstance(query, dict):
            raise ReclaimPipelineError(
                f"headroom[{index}] 缺少 query", "ARTIFACT_INVALID"
            )
        try:
            validate_embedded_model_resolution(
                query.get("model_resolution"),
                expected_model=str(entry["model"]),
                expected_domain="capacity",
                expected_scenario="cloud-reclaim",
                expected_artifact=model_path,
                field=f"headroom[{index}].query.model_resolution",
            )
        except ModelContractError as exc:
            raise ReclaimPipelineError(
                str(exc), "ARTIFACT_INVALID"
            ) from exc
        if artifact.get("status") != "success":
            continue
        filters = query.get("filters")
        window = query.get("window_epoch_seconds")
        if not isinstance(filters, dict) or not isinstance(window, dict):
            raise ReclaimPipelineError(
                f"headroom[{index}] 缺少过滤或窗口语义", "ARTIFACT_INVALID"
            )
        if (
            filters.get("model") != entry["model"]
            or filters.get("providers") != ["public"]
            or filters.get("provider_scope") != "cloud"
            or filters.get("priority") != "在线"
            or window.get("relation") != args.window_relation
            or window.get("timezone") != args.timezone
        ):
            raise ReclaimPipelineError(
                f"headroom[{index}] 的模型、provider 或窗口与回收请求不一致",
                "ARTIFACT_INVALID",
            )
        handoff = artifact.get("handoffs", {}).get("cloud_reclaim")
        if not isinstance(handoff, dict) or handoff.get("status") != "ready":
            continue
        ready.append(index)
    return ready


def command_common_window(args: argparse.Namespace) -> list[str]:
    return [
        "--provider",
        "public",
        "--priority",
        "在线",
        "--window-relation",
        args.window_relation,
        "--timezone",
        args.timezone,
        "--timeout",
        str(args.timeout),
    ]


def build_policy_model_scope(
    entries: list[dict[str, Any]],
    selection: dict[str, Any],
    output_dir: Path,
) -> tuple[Path, Path, dict[str, Any], list[Path]]:
    """Create trusted model-resolution Artifacts from the static GPU policy."""

    generated_at = utc_now()
    stage_dir = output_dir / "01-model-scope"
    scope_path = stage_dir / "scope.json"
    scope = {
        "schema_version": "1.1",
        "script_version": SCRIPT_VERSION,
        "domain": "capacity",
        "scenario": "cloud-reclaim-model-scope",
        "status": "success",
        "generated_at": generated_at,
        "summary": {
            "decision": "trusted_policy_model_scope_ready",
            "scope": copy.deepcopy(selection),
            "models": [entry["model_input"] for entry in entries],
            "model_count": len(entries),
            "policy_source": POLICY_SOURCE,
            "policy_version": POLICY_VERSION,
            "write_performed": False,
        },
        "warnings": [],
        "errors": [],
    }
    annotate_outcome(scope, complete=True, reason_code="OK", next_action="NONE")
    add_provenance(
        scope,
        artifact_type="wanqing.model_scope",
        producer_script=PRODUCER_SCRIPT,
        producer_version=SCRIPT_VERSION,
        run_id=str(uuid.uuid4()),
        stage="model_scope",
    )
    write_artifact(str(scope_path), scope)

    resolution_dir = output_dir / "02-model-resolution"
    resolution_paths: list[Path] = []
    items: list[dict[str, Any]] = []
    for index, entry in enumerate(entries):
        model = entry["model_input"]
        artifact = trusted_scope_resolution_artifact(
            model=model,
            target_domain="capacity",
            target_scenario="cloud-reclaim",
            scope_artifact=scope_path,
            resolved_at=generated_at,
            scope_source=POLICY_SOURCE,
            scope_version=POLICY_VERSION,
        )
        annotate_outcome(artifact, complete=True, reason_code="OK", next_action="NONE")
        add_provenance(
            artifact,
            artifact_type="wanqing.model_resolution.policy",
            producer_script=PRODUCER_SCRIPT,
            producer_version=SCRIPT_VERSION,
            run_id=str(scope["run_id"]),
            stage="model_resolution",
            parents=[artifact_reference(scope_path, role="model_scope")],
        )
        path = resolution_dir / f"resolution-{index + 1:03d}.json"
        write_artifact(str(path), artifact)
        resolved_path = path.resolve()
        resolution_paths.append(resolved_path)
        items.append(
            {
                "index": index,
                "model_input": model,
                "model": model,
                "status": "success",
                "artifact": str(resolved_path),
                "summary": artifact["summary"],
            }
        )

    manifest_path = resolution_dir / "manifest.json"
    manifest = {
        "schema_version": "1.1",
        "script_version": SCRIPT_VERSION,
        "domain": "common",
        "scenario": "model-resolution-batch",
        "status": "success",
        "generated_at": generated_at,
        "query": {
            "target_domain": "capacity",
            "target_scenario": "cloud-reclaim",
            "anchor_source": "capacity",
            "resolution_source": "trusted_model_scope",
            "scope_artifact": str(scope_path.resolve()),
        },
        "summary": {
            "decision": "batch_resolved",
            "input_count": len(entries),
            "successful_input_count": len(entries),
            "partial_input_count": 0,
            "failed_input_count": 0,
            "write_performed": False,
        },
        "artifacts": {"model_resolution": items},
        "handoffs": {
            "model_artifacts": {
                "status": "ready",
                "models": [entry["model_input"] for entry in entries],
                "artifacts": [str(path) for path in resolution_paths],
            }
        },
        "warnings": [],
        "errors": [],
    }
    annotate_outcome(manifest, complete=True, reason_code="OK", next_action="NONE")
    add_provenance(
        manifest,
        artifact_type="wanqing.model_resolution_batch.policy",
        producer_script=PRODUCER_SCRIPT,
        producer_version=SCRIPT_VERSION,
        run_id=str(scope["run_id"]),
        stage="model_resolution_batch",
        parents=[artifact_reference(scope_path, role="model_scope")]
        + [artifact_reference(path, role="model_resolution") for path in resolution_paths],
    )
    write_artifact(str(manifest_path), manifest)
    return scope_path.resolve(), manifest_path.resolve(), manifest, resolution_paths


def discover_candidates(
    args: argparse.Namespace,
    entries: list[dict[str, Any]],
    output_dir: Path,
) -> tuple[Path, dict[str, Any], list[Path]]:
    fixtures = list(args.candidate_fixture or [])
    stage_dir = output_dir / "01-candidates"
    if len(entries) == 1:
        output = stage_dir / "candidate.json"
        command = [
            sys.executable,
            "-B",
            str(CAPACITY_SCRIPT),
            "list-models",
            "--anchor-source",
            "capacity",
            "--model-input",
            entries[0]["model_input"],
            *command_common_window(args),
            "--output",
            str(output),
        ]
        if fixtures:
            command.extend(["--fixture", fixtures[0]])
        artifact = run_artifact_command(command, output, "模型候选查询")
        return output, artifact, [output]

    output = stage_dir / "manifest.json"
    command = [
        sys.executable,
        "-B",
        str(CAPACITY_SCRIPT),
        "list-models-batch",
        "--anchor-source",
        "capacity",
    ]
    for entry in entries:
        command.extend(["--model-input", entry["model_input"]])
    command.extend(command_common_window(args))
    for fixture in fixtures:
        command.extend(["--fixture", fixture])
    command.extend(
        [
            "--max-workers",
            str(args.max_workers),
            "--output-dir",
            str(stage_dir),
            "--output",
            str(output),
        ]
    )
    artifact = run_artifact_command(command, output, "批量模型候选查询")
    items = artifact.get("artifacts", {}).get("model_candidates", [])
    paths = [Path(item["artifact"]).resolve() for item in items]
    return output, artifact, paths


def resolve_models(
    args: argparse.Namespace,
    entries: list[dict[str, Any]],
    candidates_path: Path,
    candidate_paths: list[Path],
    output_dir: Path,
) -> tuple[Path, dict[str, Any], list[Path]]:
    stage_dir = output_dir / "02-model-resolution"
    if len(entries) == 1:
        output = stage_dir / "resolution.json"
        command = [
            sys.executable,
            "-B",
            str(MODEL_RESOLVER_SCRIPT),
            "resolve",
            "--input",
            entries[0]["model_input"],
            "--candidates-artifact",
            str(candidate_paths[0]),
            "--target-domain",
            "capacity",
            "--target-scenario",
            "cloud-reclaim",
            "--output",
            str(output),
        ]
        artifact = run_artifact_command(command, output, "模型解析")
        return output, artifact, [output]

    output = stage_dir / "manifest.json"
    command = [
        sys.executable,
        "-B",
        str(MODEL_RESOLVER_SCRIPT),
        "resolve-batch",
        "--candidates-manifest",
        str(candidates_path),
        "--target-domain",
        "capacity",
        "--target-scenario",
        "cloud-reclaim",
        "--max-workers",
        str(args.max_workers),
        "--output-dir",
        str(stage_dir),
        "--output",
        str(output),
    ]
    artifact = run_artifact_command(command, output, "批量模型解析")
    items = artifact.get("artifacts", {}).get("model_resolution", [])
    paths = [Path(item["artifact"]).resolve() for item in items]
    return output, artifact, paths


def query_headroom(
    args: argparse.Namespace,
    model_paths: list[Path],
    output_dir: Path,
) -> tuple[Path, dict[str, Any], list[Path]]:
    stage_dir = output_dir / "03-headroom"
    if len(model_paths) == 1:
        output = stage_dir / "headroom.json"
        command = [
            sys.executable,
            "-B",
            str(CAPACITY_SCRIPT),
            "query-headroom",
            "--model-artifact",
            str(model_paths[0]),
            "--provider",
            "public",
            "--provider-scope",
            "cloud",
            "--window-relation",
            args.window_relation,
            "--timezone",
            args.timezone,
            "--timeout",
            str(args.timeout),
            "--output",
            str(output),
        ]
        if args.capacity_fixture:
            command.extend(["--capacity-fixture", args.capacity_fixture])
        if args.usage_fixture:
            command.extend(["--usage-fixture", args.usage_fixture])
        artifact = run_artifact_command(command, output, "云上容量查询")
        return output, artifact, [output]

    output = stage_dir / "manifest.json"
    command = [
        sys.executable,
        "-B",
        str(CAPACITY_SCRIPT),
        "query-headroom-batch",
    ]
    for path in model_paths:
        command.extend(["--model-artifact", str(path)])
    command.extend(
        [
            "--provider",
            "public",
            "--provider-scope",
            "cloud",
            "--window-relation",
            args.window_relation,
            "--timezone",
            args.timezone,
            "--timeout",
            str(args.timeout),
            "--max-workers",
            str(args.max_workers),
            "--output-dir",
            str(stage_dir),
            "--output",
            str(output),
        ]
    )
    if args.capacity_fixture:
        command.extend(["--capacity-fixture", args.capacity_fixture])
    if args.usage_fixture:
        command.extend(["--usage-fixture", args.usage_fixture])
    artifact = run_artifact_command(command, output, "批量云上容量查询")
    items = artifact.get("artifacts", {}).get("headroom", [])
    paths = [Path(item["artifact"]).resolve() for item in items]
    return output, artifact, paths


def query_isvc(
    args: argparse.Namespace,
    model_paths: list[Path],
    output_dir: Path,
    service_selections: dict[str, str] | None = None,
) -> tuple[Path, dict[str, Any], list[Path]]:
    stage_dir = output_dir / "04-isvc"
    output = stage_dir / "manifest.json"
    command = build_isvc_batch_command(
        python=sys.executable,
        script=ISVC_SCRIPT,
        model_artifacts=model_paths,
        timeout=args.isvc_timeout,
        max_workers=args.max_workers,
        output_dir=stage_dir,
        output=output,
        fixture=args.isvc_fixture,
        service_selections=service_selections,
    )
    artifact = run_artifact_command(command, output, "批量 iSvc 查询")
    items = artifact.get("artifacts", {}).get("isvc", [])
    paths = [Path(item["artifact"]).resolve() for item in items]
    if not paths and artifact.get("status") == "error":
        generated_at = utc_now()
        shared_errors = [
            str(item) for item in artifact.get("errors", []) if isinstance(item, str)
        ] or ["批量 iSvc 查询失败"]
        for index, model_path in enumerate(model_paths):
            verified = load_model_resolution(
                model_path,
                expected_domain="capacity",
                allowed_scenarios={"cloud-reclaim"},
            )
            blocked = {
                "schema_version": "1.1",
                "script_version": SCRIPT_VERSION,
                "domain": "capacity",
                "scenario": "isvc-single-instance-cards",
                "status": "error",
                "generated_at": generated_at,
                "summary": {
                    "decision": "query_or_normalization_failed",
                    "model": verified.model,
                    "failure_stage": "batch_isvc_query",
                    "request_sent": not bool(args.isvc_fixture),
                    "write_performed": False,
                },
                "query": {
                    "model_resolution": verified.evidence,
                    "batch": {
                        "enabled": True,
                        "model_index": index,
                        "model_count": len(model_paths),
                        "shared_list_response": True,
                    },
                },
                "handoffs": {},
                "warnings": [],
                "errors": shared_errors,
            }
            annotate_outcome(
                blocked,
                complete=False,
                reason_code="QUERY_FAILED",
                next_action="STOP",
            )
            blocked_path = stage_dir / f"isvc-{index + 1:03d}.json"
            write_artifact(str(blocked_path), blocked)
            paths.append(blocked_path.resolve())
    return output, artifact, paths


def fixture_replay_without_holdings(args: argparse.Namespace) -> bool:
    """Keep legacy fixture replays offline unless holdings data is supplied."""

    upstream_fixture = any(
        (
            args.candidate_fixture,
            args.capacity_fixture,
            args.usage_fixture,
            args.isvc_fixture,
        )
    )
    return bool(upstream_fixture and not args.resource_fixture)


def fixture_replay_without_cost(args: argparse.Namespace) -> bool:
    """Keep existing fixture replays offline unless cost data is supplied."""

    upstream_fixture = any(
        (
            args.candidate_fixture,
            args.capacity_fixture,
            args.usage_fixture,
            args.isvc_fixture,
            args.resource_fixture,
        )
    )
    return bool(upstream_fixture and not args.cost_fixture)


def query_cloud_cost(
    args: argparse.Namespace,
    model_paths: list[Path],
    headroom_paths: list[Path],
    output_dir: Path,
) -> tuple[Path, dict[str, Any]]:
    """Query previous-day billable cost through the cost-domain CLI."""

    stage_dir = output_dir / "05-cloud-cost"
    output = stage_dir / "daily-billing.json"
    command = [
        sys.executable,
        "-B",
        str(COST_SCRIPT),
        "query-cloud-daily-cost",
    ]
    for path in model_paths:
        command.extend(["--capacity-model-artifact", str(path)])
    for path in headroom_paths:
        command.extend(["--headroom-artifact", str(path)])
    command.extend(
        [
            "--timeout",
            str(args.timeout),
            "--output",
            str(output),
        ]
    )
    if args.cost_fixture:
        command.extend(["--fixture", args.cost_fixture])
    artifact = run_artifact_command(command, output, "成本域前一天云上成本查询")
    return output.resolve(), artifact


def query_resource_holdings(
    args: argparse.Namespace,
    model_paths: list[Path],
    output_dir: Path,
) -> tuple[Path, dict[str, Any]]:
    """Query current online model holdings through the resource-domain CLI."""

    stage_dir = output_dir / "05-resource-holdings"
    output = stage_dir / "model-holdings.json"
    command = [
        sys.executable,
        "-B",
        str(RESOURCE_SCRIPT),
        "model-holdings",
    ]
    for path in model_paths:
        command.extend(["--capacity-model-artifact", str(path)])
    command.extend(
        [
            "--service-type",
            "online",
            "--window-seconds",
            "300",
            "--timeout",
            str(args.timeout),
            "--output",
            str(output),
        ]
    )
    if args.resource_fixture:
        command.extend(["--fixture", args.resource_fixture])
    artifact = run_artifact_command(
        command, output, "资源域模型当前持有量查询"
    )
    return output.resolve(), artifact


def isvc_service_confirmations(paths: list[Path]) -> list[dict[str, Any]]:
    confirmations: list[dict[str, Any]] = []
    for path in paths:
        _, artifact = load_object(path)
        summary = artifact.get("summary")
        if not isinstance(summary, dict):
            continue
        if summary.get("decision") != "ambiguous_deployment_specs":
            continue
        confirmations.append(
            {
                "model": summary.get("model"),
                "service_names": summary.get("service_names", []),
                "artifact": str(path),
            }
        )
    return confirmations


def stopped_prepare_manifest(
    *,
    run_id: str,
    selection: dict[str, Any],
    artifact: dict[str, Any],
    artifact_path: Path,
    parents: list[dict[str, str]],
) -> dict[str, Any]:
    reason = reason_code_for(artifact)
    summary = artifact.get("summary", {})
    next_action: Any = "STOP"
    if reason == "MODEL_CONFIRMATION_REQUIRED":
        next_action = {
            "type": "request_model_confirmation",
            "confirmations": (
                summary.get("confirmations", [])
                if isinstance(summary, dict)
                else []
            ),
        }
    manifest = {
        "schema_version": "1.1",
        "script_version": SCRIPT_VERSION,
        "domain": "workflow",
        "scenario": "cloud-reclaim-prepare",
        "status": "partial" if artifact.get("status") == "partial" else "error",
        "generated_at": utc_now(),
        "summary": {
            "decision": "prepare_stopped",
            "selection": selection,
            "stopped_artifact": str(artifact_path),
            "write_performed": False,
        },
        "artifacts": {"stopped_at": str(artifact_path)},
        "warnings": artifact.get("warnings", []),
        "errors": artifact.get("errors", []),
    }
    annotate_outcome(
        manifest,
        complete=False,
        reason_code=reason,
        next_action=next_action,
    )
    return add_provenance(
        manifest,
        artifact_type=PLAN_ARTIFACT_TYPE,
        producer_script=PRODUCER_SCRIPT,
        producer_version=SCRIPT_VERSION,
        run_id=run_id,
        stage="prepare_stopped",
        parents=parents,
    )


def attach_reclaim_plan_evidence_ids(artifact: dict[str, Any]) -> None:
    """Bind reclaim model entries to canonical evidence IDs."""

    summary = artifact.get("summary")
    entries = summary.get("model_entries") if isinstance(summary, dict) else None
    if not isinstance(entries, list):
        return
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        for id_field, path_field, role in (
            ("model_evidence_id", "model_artifact", "model_resolution"),
            ("headroom_evidence_id", "headroom_artifact", "headroom"),
            ("cost_evidence_id", "cost_artifact", "cost"),
            ("isvc_evidence_id", "isvc_artifact", "isvc"),
            ("holdings_evidence_id", "holdings_artifact", "resource"),
        ):
            attach_evidence_id(
                artifact,
                entry,
                id_field=id_field,
                path_value=entry.get(path_field),
                role=role,
            )


def attach_reclaim_result_evidence_ids(
    artifact: dict[str, Any],
    *,
    entries: list[dict[str, Any]] | None = None,
    kconf_paths: list[Path] | None = None,
) -> None:
    if entries is None or kconf_paths is None:
        return
    by_model = {
        str(entry.get("model")): (entry, kconf_path)
        for entry, kconf_path in zip(entries, kconf_paths)
    }
    summary = artifact.get("summary")
    candidates = summary.get("candidates") if isinstance(summary, dict) else None
    if not isinstance(candidates, list):
        return
    for candidate in candidates:
        if not isinstance(candidate, dict):
            continue
        pair = by_model.get(str(candidate.get("model")))
        if pair is None:
            continue
        entry, kconf_path = pair
        references: dict[str, Any] = {}
        for id_field, path_value, role in (
            ("model", entry.get("model_artifact"), "model_resolution"),
            ("headroom", entry.get("headroom_artifact"), "headroom"),
            ("cost", entry.get("cost_artifact"), "cost"),
            ("kconf", kconf_path, "kconf"),
            ("isvc", entry.get("isvc_artifact"), "isvc"),
            ("holdings", entry.get("holdings_artifact"), "resource"),
        ):
            attach_evidence_id(
                artifact,
                references,
                id_field=id_field,
                path_value=path_value,
                role=role,
            )
        candidate["evidence_ids"] = references


def run_prepare(args: argparse.Namespace) -> dict[str, Any]:
    run_id = str(uuid.uuid4())
    entries, selection = select_scope(args)
    output_dir = Path(args.output_dir).expanduser().resolve()
    prepare_request_path = write_prepare_request(
        args, selection, output_dir, run_id
    )
    request_record = normalized_reclaim_request(args, selection)

    policy_scope_path: Path | None = None
    trusted_exact_explicit = args.scope == "explicit" and all(
        entry["model_input"] in TRUSTED_POLICY_MODELS for entry in entries
    )
    if args.scope in {"all", "gpu"} or trusted_exact_explicit:
        (
            policy_scope_path,
            resolution_path,
            resolution,
            model_paths,
        ) = build_policy_model_scope(entries, selection, output_dir)
        candidates_path = policy_scope_path
        candidate_paths: list[Path] = []
    else:
        candidates_path, candidates, candidate_paths = discover_candidates(
            args, entries, output_dir
        )
        parents = parent_references(
            [(prepare_request_path, "prepare_request")]
            + [(candidates_path, "candidate_manifest")]
            + [(path, "model_candidates") for path in candidate_paths]
        )
        if candidates.get("status") != "success":
            return stopped_prepare_manifest(
                run_id=run_id,
                selection=selection,
                artifact=candidates,
                artifact_path=candidates_path,
                parents=parents,
            )

        resolution_path, resolution, model_paths = resolve_models(
            args, entries, candidates_path, candidate_paths, output_dir
        )
        if resolution.get("status") != "success":
            parents = parent_references(
                [(prepare_request_path, "prepare_request")]
                + [(candidates_path, "candidate_manifest")]
                + [(path, "model_candidates") for path in candidate_paths]
                + [(resolution_path, "resolution_manifest")]
                + [(path, "model_resolution") for path in model_paths]
            )
            return stopped_prepare_manifest(
                run_id=run_id,
                selection=selection,
                artifact=resolution,
                artifact_path=resolution_path,
                parents=parents,
            )

    identity_parent_paths = (
        [(prepare_request_path, "prepare_request")]
        + [(candidates_path, "candidate_manifest")]
        + (
            [(policy_scope_path, "model_scope")]
            if policy_scope_path is not None
            else []
        )
        + [(path, "model_candidates") for path in candidate_paths]
        + [(resolution_path, "resolution_manifest")]
        + [(path, "model_resolution") for path in model_paths]
    )

    verified = [
        load_model_resolution(
            path,
            expected_domain="capacity",
            allowed_scenarios={"cloud-reclaim"},
        )
        for path in model_paths
    ]
    if len(verified) != len(entries):
        raise ReclaimPipelineError(
            "模型解析 Artifact 数量与计划不一致", "ARTIFACT_INVALID"
        )
    for index, item in enumerate(verified):
        entries[index]["model"] = item.model
        entries[index]["model_artifact"] = str(model_paths[index])
        if (
            args.scope in {"all", "gpu"} or trusted_exact_explicit
        ) and item.model != entries[index]["model_input"]:
            raise ReclaimPipelineError(
                "静态策略模型必须解析为同名精确模型", "MODEL_RESOLUTION_FAILED"
            )
    try:
        service_selections = parse_named_selections(
            args.service_selection,
            option_name="service-selection",
        )
    except ValueError as exc:
        raise ReclaimPipelineError(str(exc)) from exc
    unknown_service_models = sorted(
        set(service_selections) - {entry["model"] for entry in entries}
    )
    if unknown_service_models:
        raise ReclaimPipelineError(
            "service-selection 的模型不在当前计划中："
            + ", ".join(unknown_service_models)
        )

    headroom_path, headroom, headroom_paths = query_headroom(
        args, model_paths, output_dir
    )
    parents = parent_references(
        identity_parent_paths
        + [(headroom_path, "headroom_manifest")]
        + [(path, "headroom") for path in headroom_paths]
    )
    if headroom.get("status") == "error":
        return stopped_prepare_manifest(
            run_id=run_id,
            selection=selection,
            artifact=headroom,
            artifact_path=headroom_path,
            parents=parents,
        )

    if len(headroom_paths) != len(entries):
        raise ReclaimPipelineError(
            "容量 Artifact 数量与模型计划不一致", "ARTIFACT_INVALID"
        )
    dependency_indexes = headroom_dependency_indexes(
        args=args,
        entries=entries,
        model_paths=model_paths,
        headroom_paths=headroom_paths,
    )
    if not dependency_indexes:
        return stopped_prepare_manifest(
            run_id=run_id,
            selection=selection,
            artifact=headroom,
            artifact_path=headroom_path,
            parents=parents,
        )

    cost_path: Path | None = None
    cost: dict[str, Any] | None = None
    if fixture_replay_without_cost(args):
        cost_estimation_mode = "fixture_replay_skipped"
    else:
        cost_estimation_mode = "required"
        cost_path, cost = query_cloud_cost(
            args,
            [model_paths[index] for index in dependency_indexes],
            [headroom_paths[index] for index in dependency_indexes],
            output_dir,
        )

    isvc_path: Path | None = None
    isvc: dict[str, Any] | None = None
    isvc_paths: list[Path] = []
    if args.detail_level != "instances":
        isvc_path, isvc, isvc_paths = query_isvc(
            args,
            [model_paths[index] for index in dependency_indexes],
            output_dir,
            {
                model: service
                for model, service in service_selections.items()
                if model
                in {str(entries[index]["model"]) for index in dependency_indexes}
            },
        )
    parents = parent_references(
        identity_parent_paths
        + [(headroom_path, "headroom_manifest")]
        + [(path, "headroom") for path in headroom_paths]
        + ([(cost_path, "cost")] if cost_path is not None else [])
        + (
            [(isvc_path, "isvc_manifest")]
            if isvc_path is not None
            else []
        )
        + [(path, "isvc") for path in isvc_paths]
    )

    if (
        args.detail_level != "instances"
        and len(isvc_paths) != len(dependency_indexes)
    ):
        raise ReclaimPipelineError(
            "容量或 iSvc Artifact 数量与模型计划不一致", "ARTIFACT_INVALID"
        )
    isvc_by_model_index = dict(zip(dependency_indexes, isvc_paths))
    dependency_index_set = set(dependency_indexes)
    model_entries: list[dict[str, Any]] = []
    for index, entry in enumerate(entries):
        model_entries.append(
            {
                **entry,
                "headroom_artifact": str(headroom_paths[index]),
                "requires_dependencies": index in dependency_index_set,
                "cost_artifact": (
                    str(cost_path)
                    if cost_path is not None and index in dependency_index_set
                    else None
                ),
                "isvc_artifact": (
                    None
                    if args.detail_level == "instances"
                    else str(isvc_by_model_index[index])
                    if index in isvc_by_model_index
                    else None
                ),
            }
        )

    service_confirmations = isvc_service_confirmations(isvc_paths)
    if service_confirmations:
        manifest = {
            "schema_version": "1.1",
            "script_version": SCRIPT_VERSION,
            "domain": "workflow",
            "scenario": "cloud-reclaim-prepare",
            "status": "partial",
            "generated_at": utc_now(),
            "request": copy.deepcopy(request_record),
            "summary": {
                "decision": "isvc_service_confirmation_required",
                "detail_level": args.detail_level,
                "selection": selection,
                "model_count": len(model_entries),
                "models": [item["model"] for item in model_entries],
                "model_entries": model_entries,
                "headroom_status": headroom.get("status"),
                "cost_estimation_mode": cost_estimation_mode,
                "cost_status": None if cost is None else cost.get("status"),
                "isvc_status": None if isvc is None else isvc.get("status"),
                "write_performed": False,
            },
            "artifacts": {
                "prepare_request": str(prepare_request_path),
                "candidate_manifest": str(candidates_path),
                "resolution_manifest": str(resolution_path),
                "headroom_manifest": str(headroom_path),
                **(
                    {"cloud_cost": str(cost_path)}
                    if cost_path is not None
                    else {}
                ),
                **(
                    {"isvc_manifest": str(isvc_path)}
                    if isvc_path is not None
                    else {}
                ),
                **(
                    {"model_scope": str(policy_scope_path)}
                    if policy_scope_path is not None
                    else {}
                ),
            },
            "warnings": list(headroom.get("warnings", []))
            + ([] if cost is None else list(cost.get("warnings", [])))
            + ([] if isvc is None else list(isvc.get("warnings", []))),
            "errors": list(headroom.get("errors", []))
            + ([] if cost is None else list(cost.get("errors", [])))
            + ([] if isvc is None else list(isvc.get("errors", []))),
        }
        annotate_outcome(
            manifest,
            complete=False,
            reason_code="ISVC_CONFIRMATION_REQUIRED",
            next_action={
                "type": "request_isvc_service_confirmation",
                "confirmations": service_confirmations,
                "then": (
                    "使用原参数重新运行 cloud-reclaim-prepare，并为每个歧义模型"
                    "重复传 --service-selection MODEL=SERVICE"
                ),
            },
        )
        prepared = add_provenance(
            manifest,
            artifact_type=PLAN_ARTIFACT_TYPE,
            producer_script=PRODUCER_SCRIPT,
            producer_version=SCRIPT_VERSION,
            run_id=run_id,
            stage="awaiting_isvc_service_confirmation",
            parents=parents,
        )
        attach_reclaim_plan_evidence_ids(prepared)
        return prepared

    holdings_path: Path | None = None
    holdings: dict[str, Any] | None = None
    if args.detail_level == "instances":
        holdings_alignment_mode = "not_requested"
    elif fixture_replay_without_holdings(args):
        holdings_alignment_mode = "fixture_replay_skipped"
    else:
        holdings_alignment_mode = "required"
        holdings_path, holdings = query_resource_holdings(
            args,
            [model_paths[index] for index in dependency_indexes],
            output_dir,
        )
        for index in dependency_indexes:
            model_entries[index]["holdings_artifact"] = str(holdings_path)

    parents = parent_references(
        identity_parent_paths
        + [(headroom_path, "headroom_manifest")]
        + [(path, "headroom") for path in headroom_paths]
        + ([(cost_path, "cost")] if cost_path is not None else [])
        + (
            [(isvc_path, "isvc_manifest")]
            if isvc_path is not None
            else []
        )
        + [(path, "isvc") for path in isvc_paths]
        + (
            [(holdings_path, "resource")]
            if holdings_path is not None
            else []
        )
    )

    kconf_output = output_dir / "06-kconf" / "tool-result.json"
    finalize_dir = output_dir / "07-finalize"
    finalize_output = output_dir / "cloud-reclaim-result.json"
    status = (
        "success"
        if headroom.get("status") == "success"
        and (
            cost_estimation_mode != "required"
            or cost is not None
            and cost.get("status") == "success"
        )
        and (
            holdings_alignment_mode != "required"
            or holdings is not None
            and holdings.get("status") == "success"
        )
        else "partial"
    )
    manifest = {
        "schema_version": "1.1",
        "script_version": SCRIPT_VERSION,
        "domain": "workflow",
        "scenario": "cloud-reclaim-prepare",
        "status": status,
        "generated_at": utc_now(),
        "request": copy.deepcopy(request_record),
        "summary": {
            "decision": "kconf_tool_call_required",
            "detail_level": args.detail_level,
            "selection": selection,
            "model_count": len(model_entries),
            "models": [item["model"] for item in model_entries],
            "model_entries": model_entries,
            "headroom_status": headroom.get("status"),
            "cost_estimation_mode": cost_estimation_mode,
            "cost_status": None if cost is None else cost.get("status"),
            "isvc_status": None if isvc is None else isvc.get("status"),
            "holdings_alignment_mode": holdings_alignment_mode,
            "holdings_status": (
                None if holdings is None else holdings.get("status")
            ),
            "output_dir": str(output_dir),
            "write_performed": False,
        },
        "artifacts": {
            "prepare_request": str(prepare_request_path),
            "candidate_manifest": str(candidates_path),
            "resolution_manifest": str(resolution_path),
            "headroom_manifest": str(headroom_path),
            **(
                {"cloud_cost": str(cost_path)}
                if cost_path is not None
                else {}
            ),
            **(
                {"isvc_manifest": str(isvc_path)}
                if isvc_path is not None
                else {}
            ),
            **(
                {"model_scope": str(policy_scope_path)}
                if policy_scope_path is not None
                else {}
            ),
            **(
                {"resource_holdings": str(holdings_path)}
                if holdings_path is not None
                else {}
            ),
        },
        "warnings": list(headroom.get("warnings", []))
        + ([] if cost is None else list(cost.get("warnings", [])))
        + ([] if isvc is None else list(isvc.get("warnings", [])))
        + (
            []
            if isvc is None
            else [f"iSvc：{item}" for item in isvc.get("errors", [])]
        )
        + ([] if holdings is None else list(holdings.get("warnings", []))),
        "errors": list(headroom.get("errors", []))
        + ([] if cost is None else list(cost.get("errors", [])))
        + ([] if holdings is None else list(holdings.get("errors", []))),
    }
    next_action = {
        "type": "tool_call",
        "tool": KCONF_TOOL,
        "arguments": {"key": KCONF_KEY, "stage": KCONF_STAGE},
        "save_raw_result_as": str(kconf_output),
        "then": {
            "command": "cloud-reclaim-finalize",
            "arguments": {
                "plan_artifact": str(Path(args.output).expanduser().resolve()),
                "kconf_tool_result": str(kconf_output),
                "output_dir": str(finalize_dir),
                "output": str(finalize_output),
            },
        },
    }
    annotate_outcome(
        manifest,
        complete=False,
        reason_code=(
            "KCONF_REQUIRED"
            if headroom.get("status") == "success"
            else "CAPACITY_INCOMPLETE"
        ),
        next_action=next_action,
    )
    prepared = add_provenance(
        manifest,
        artifact_type=PLAN_ARTIFACT_TYPE,
        producer_script=PRODUCER_SCRIPT,
        producer_version=SCRIPT_VERSION,
        run_id=run_id,
        stage="awaiting_kconf",
        parents=parents,
    )
    attach_reclaim_plan_evidence_ids(prepared)
    return prepared


def plan_entries(
    plan: dict[str, Any],
) -> tuple[dict[str, Any], str, list[dict[str, Any]]]:
    summary = plan.get("summary")
    if not isinstance(summary, dict):
        raise ReclaimPipelineError("计划 Artifact 缺少 summary", "ARTIFACT_INVALID")
    selection = summary.get("selection")
    detail_level = summary.get("detail_level")
    holdings_alignment_mode = summary.get(
        "holdings_alignment_mode",
        "not_requested" if detail_level == "instances" else "fixture_replay_skipped",
    )
    cost_estimation_mode = summary.get(
        "cost_estimation_mode", "fixture_replay_skipped"
    )
    entries = summary.get("model_entries")
    if (
        not isinstance(selection, dict)
        or detail_level not in {"instances", "cards", "machines"}
        or not isinstance(entries, list)
        or not entries
    ):
        raise ReclaimPipelineError(
            "计划 Artifact 缺少 selection、detail_level 或 model_entries",
            "ARTIFACT_INVALID",
        )
    if holdings_alignment_mode not in {
        "not_requested",
        "required",
        "fixture_replay_skipped",
    }:
        raise ReclaimPipelineError(
            "计划 Artifact 的 holdings_alignment_mode 无效",
            "ARTIFACT_INVALID",
        )
    if cost_estimation_mode not in {"required", "fixture_replay_skipped"}:
        raise ReclaimPipelineError(
            "计划 Artifact 的 cost_estimation_mode 无效",
            "ARTIFACT_INVALID",
        )
    if detail_level == "instances" and holdings_alignment_mode != "not_requested":
        raise ReclaimPipelineError(
            "instances 路径不得要求资源持有量校准", "ARTIFACT_INVALID"
        )
    if detail_level != "instances" and holdings_alignment_mode == "not_requested":
        raise ReclaimPipelineError(
            "cards/machines 路径必须声明资源持有量校准模式",
            "ARTIFACT_INVALID",
        )
    for index, entry in enumerate(entries):
        if not isinstance(entry, dict):
            raise ReclaimPipelineError(
                f"model_entries[{index}] 必须是对象", "ARTIFACT_INVALID"
            )
        for field in ("model", "model_artifact", "headroom_artifact"):
            if not isinstance(entry.get(field), str) or not entry[field]:
                raise ReclaimPipelineError(
                    f"model_entries[{index}] 缺少 {field}", "ARTIFACT_INVALID"
                )
        requires_dependencies = entry.get("requires_dependencies")
        if not isinstance(requires_dependencies, bool):
            raise ReclaimPipelineError(
                f"model_entries[{index}] 缺少 requires_dependencies",
                "ARTIFACT_INVALID",
            )
        isvc_artifact = entry.get("isvc_artifact")
        if detail_level == "instances":
            if isvc_artifact is not None:
                raise ReclaimPipelineError(
                    f"model_entries[{index}] 的 instances 路径不得包含 iSvc",
                    "ARTIFACT_INVALID",
                )
        elif requires_dependencies and (
            not isinstance(isvc_artifact, str) or not isvc_artifact
        ):
            raise ReclaimPipelineError(
                f"model_entries[{index}] 缺少 isvc_artifact", "ARTIFACT_INVALID"
            )
        elif not requires_dependencies and isvc_artifact is not None:
            raise ReclaimPipelineError(
                f"model_entries[{index}] 的上游容量不完整，不得包含 iSvc",
                "ARTIFACT_INVALID",
            )
        holdings_artifact = entry.get("holdings_artifact")
        if holdings_alignment_mode == "required" and requires_dependencies:
            if not isinstance(holdings_artifact, str) or not holdings_artifact:
                raise ReclaimPipelineError(
                    f"model_entries[{index}] 缺少 holdings_artifact",
                    "ARTIFACT_INVALID",
                )
        elif holdings_artifact is not None:
            raise ReclaimPipelineError(
                f"model_entries[{index}] 不得包含 holdings_artifact",
                "ARTIFACT_INVALID",
            )
        cost_artifact = entry.get("cost_artifact")
        if cost_estimation_mode == "required" and requires_dependencies:
            if not isinstance(cost_artifact, str) or not cost_artifact:
                raise ReclaimPipelineError(
                    f"model_entries[{index}] 缺少 cost_artifact",
                    "ARTIFACT_INVALID",
                )
        elif cost_artifact is not None:
            raise ReclaimPipelineError(
                f"model_entries[{index}] 不得包含 cost_artifact",
                "ARTIFACT_INVALID",
            )
    return selection, str(detail_level), entries


def validate_entry_parent_references(
    plan: dict[str, Any], detail_level: str, entries: list[dict[str, Any]]
) -> None:
    bindings: list[tuple[str, str, str]] = []
    for index, entry in enumerate(entries):
        for id_field, path_field, role in (
            ("model_evidence_id", "model_artifact", "model_resolution"),
            ("headroom_evidence_id", "headroom_artifact", "headroom"),
        ):
            if id_field in entry:
                validate_evidence_id_binding(
                    plan,
                    entry,
                    id_field=id_field,
                    path_field=path_field,
                    role=role,
                )
            else:
                bindings.append(
                    (f"model_entries[{index}].{path_field}", entry[path_field], role)
                )
        cost_artifact = entry.get("cost_artifact")
        if cost_artifact is not None:
            if "cost_evidence_id" in entry:
                validate_evidence_id_binding(
                    plan,
                    entry,
                    id_field="cost_evidence_id",
                    path_field="cost_artifact",
                    role="cost",
                )
            else:
                bindings.append(
                    (
                        f"model_entries[{index}].cost_artifact",
                        cost_artifact,
                        "cost",
                    )
                )
    if detail_level != "instances":
        for index, entry in enumerate(entries):
            if entry.get("requires_dependencies") is not True:
                continue
            if "isvc_evidence_id" in entry:
                validate_evidence_id_binding(
                    plan,
                    entry,
                    id_field="isvc_evidence_id",
                    path_field="isvc_artifact",
                    role="isvc",
                )
            else:
                bindings.append(
                    (
                        f"model_entries[{index}].isvc_artifact",
                        entry["isvc_artifact"],
                        "isvc",
                    )
                )
            holdings_artifact = entry.get("holdings_artifact")
            if holdings_artifact is None:
                continue
            if "holdings_evidence_id" in entry:
                validate_evidence_id_binding(
                    plan,
                    entry,
                    id_field="holdings_evidence_id",
                    path_field="holdings_artifact",
                    role="resource",
                )
            else:
                bindings.append(
                    (
                        f"model_entries[{index}].holdings_artifact",
                        holdings_artifact,
                        "resource",
                    )
                )
    if bindings:
        validate_parent_path_bindings(plan, bindings)


def validate_plan_dependency_partition(
    request_summary: dict[str, Any], entries: list[dict[str, Any]]
) -> None:
    if all(
        isinstance(entry.get("model_evidence_id"), str)
        and isinstance(entry.get("headroom_evidence_id"), str)
        for entry in entries
    ):
        return
    relation = request_summary.get("window_relation")
    timezone = request_summary.get("timezone")
    if relation != "previous_day" or not isinstance(timezone, str) or not timezone:
        raise ReclaimPipelineError(
            "prepare_request 的容量窗口契约无效", "ARTIFACT_INVALID"
        )
    ready_indexes = headroom_dependency_indexes(
        args=argparse.Namespace(window_relation=relation, timezone=timezone),
        entries=entries,
        model_paths=[Path(entry["model_artifact"]) for entry in entries],
        headroom_paths=[Path(entry["headroom_artifact"]) for entry in entries],
    )
    expected = {
        index
        for index, entry in enumerate(entries)
        if entry.get("requires_dependencies") is True
    }
    if set(ready_indexes) != expected:
        raise ReclaimPipelineError(
            "计划的依赖裁剪结果与云上容量证据不一致", "ARTIFACT_INVALID"
        )


def normalize_kconf(
    args: argparse.Namespace,
    entries: list[dict[str, Any]],
    output_dir: Path,
) -> tuple[Path, dict[str, Any], list[Path]]:
    stage_dir = output_dir / "01-kconf-normalized"
    output = stage_dir / "manifest.json"
    eligible_entries = [
        entry for entry in entries if entry.get("requires_dependencies") is True
    ]
    if not eligible_entries:
        raise ReclaimPipelineError(
            "计划中没有可消费 KConf 的容量完整模型",
            "WORKFLOW_NOT_READY",
        )
    eligible_output = stage_dir / "eligible-manifest.json"
    command = build_kconf_batch_command(
        python=sys.executable,
        script=KCONF_SCRIPT,
        tool_result=args.kconf_tool_result,
        model_artifacts=[entry["model_artifact"] for entry in eligible_entries],
        key=KCONF_KEY,
        stage=KCONF_STAGE,
        max_workers=args.max_workers,
        output_dir=stage_dir / "eligible",
        output=eligible_output,
        device_type=args.device_type,
        device_type_selections=args.parsed_device_type_selections,
    )
    eligible_manifest = run_artifact_command(
        command, eligible_output, "KConf 批量规范化"
    )
    eligible_items = eligible_manifest.get("artifacts", {}).get("kconf", [])
    if not isinstance(eligible_items, list):
        eligible_items = []
    eligible_by_model = {
        str(item.get("model")): item
        for item in eligible_items
        if isinstance(item, dict) and isinstance(item.get("artifact"), str)
    }

    generated_at = utc_now()
    items: list[dict[str, Any]] = []
    paths: list[Path] = []
    statuses: list[str] = []
    warnings: list[str] = list(eligible_manifest.get("warnings", []))
    errors: list[str] = list(eligible_manifest.get("errors", []))
    for index, entry in enumerate(entries):
        model = str(entry["model"])
        item = eligible_by_model.get(model)
        if entry.get("requires_dependencies") is True and item is not None:
            path = Path(str(item["artifact"])).expanduser().resolve()
            _, value = load_object(path)
        else:
            verified = load_model_resolution(
                entry["model_artifact"],
                expected_domain="capacity",
                allowed_scenarios={"cloud-reclaim"},
            )
            upstream_missing = entry.get("requires_dependencies") is not True
            value = {
                "schema_version": "1.1",
                "script_version": SCRIPT_VERSION,
                "domain": "capacity",
                "scenario": "kconf-single-instance-capacity",
                "status": "partial" if upstream_missing else "error",
                "generated_at": generated_at,
                "summary": {
                    "decision": (
                        "dependency_skipped_upstream_evidence_missing"
                        if upstream_missing
                        else "query_or_normalization_failed"
                    ),
                    "model": model,
                    "write_performed": False,
                },
                "query": {
                    "key": KCONF_KEY,
                    "stage": KCONF_STAGE,
                    "model_resolution": verified.evidence,
                    "dependency_execution": (
                        "skipped" if upstream_missing else "failed_before_item_artifact"
                    ),
                },
                "handoffs": {},
                "warnings": (
                    ["上游云上容量证据不完整，未查询该模型 KConf"]
                    if upstream_missing
                    else []
                ),
                "errors": (
                    []
                    if upstream_missing
                    else ["KConf 批量结果缺少该模型的独立 Artifact"]
                ),
            }
            annotate_outcome(
                value,
                complete=False,
                reason_code=(
                    "EVIDENCE_MISSING" if upstream_missing else "QUERY_FAILED"
                ),
                next_action="STOP",
            )
            path = stage_dir / "skipped" / f"kconf-{index + 1:03d}.json"
            write_artifact(str(path), value)
            path = path.resolve()
        status = str(value.get("status", "error"))
        statuses.append(status)
        paths.append(path)
        items.append(
            {
                "index": index,
                "model": model,
                "status": status,
                "artifact": str(path),
                "summary": copy.deepcopy(value.get("summary", {})),
            }
        )
        warnings.extend(
            f"{model}: {warning}"
            for warning in value.get("warnings", [])
            if isinstance(warning, str)
        )
        errors.extend(
            f"{model}: {error}"
            for error in value.get("errors", [])
            if isinstance(error, str)
        )

    if all(status == "success" for status in statuses):
        status = "success"
    elif all(status == "error" for status in statuses):
        status = "error"
    else:
        status = "partial"
    manifest = {
        "schema_version": "1.1",
        "script_version": SCRIPT_VERSION,
        "domain": "capacity",
        "scenario": "kconf-normalize-batch",
        "status": status,
        "generated_at": generated_at,
        "summary": {
            "decision": "batch_normalization_completed",
            "models": [str(entry["model"]) for entry in entries],
            "model_count": len(entries),
            "successful_model_count": statuses.count("success"),
            "partial_model_count": statuses.count("partial"),
            "failed_model_count": statuses.count("error"),
            "eligible_model_count": len(eligible_entries),
            "skipped_model_count": len(entries) - len(eligible_entries),
            "write_performed": False,
        },
        "artifacts": {"kconf": items},
        "query": {
            "source_manifest": str(eligible_output.resolve()),
            "key": KCONF_KEY,
            "stage": KCONF_STAGE,
            "dependency_execution": "eligible_models_only_then_original_order_merge",
        },
        "warnings": warnings,
        "errors": errors,
    }
    annotate_outcome(
        manifest,
        complete=status == "success",
        reason_code="OK" if status == "success" else "EVIDENCE_MISSING",
        next_action="NONE",
    )
    write_artifact(str(output), manifest)
    return output.resolve(), manifest, paths


def build_assembly_source(
    selection: dict[str, Any],
    detail_level: str,
    entries: list[dict[str, Any]],
    kconf_paths: list[Path],
) -> tuple[str, dict[str, Any]]:
    if len(entries) != len(kconf_paths):
        raise ReclaimPipelineError(
            "KConf Artifact 数量与计划模型数不一致", "ARTIFACT_INVALID"
        )
    candidates = []
    for entry, kconf_path in zip(entries, kconf_paths):
        candidate = {
            "model": entry["model"],
            "model_artifact": entry["model_artifact"],
            "cloud": {"headroom_artifact": entry["headroom_artifact"]},
            "kconf": {"artifact": str(kconf_path)},
        }
        if detail_level != "instances":
            candidate["isvc"] = {"artifact": entry["isvc_artifact"]}
        candidates.append(candidate)

    scope = selection.get("scope")
    source: dict[str, Any] = {
        "observed_at": utc_now(),
        "detail_level": detail_level,
    }
    if scope == "all":
        source["candidates_by_gpu"] = {"X60": [], "X40": []}
        for entry, candidate in zip(entries, candidates):
            gpu_type = entry.get("policy_gpu_type")
            if gpu_type not in source["candidates_by_gpu"]:
                raise ReclaimPipelineError(
                    "全量计划候选缺少有效 policy_gpu_type", "ARTIFACT_INVALID"
                )
            source["candidates_by_gpu"][gpu_type].append(candidate)
        return "cloud-reclaim-all", source
    if scope == "gpu":
        source["policy"] = {
            "gpu_type": selection.get("gpu_type"),
            "top_p": selection.get("top_p"),
        }
        source["candidates"] = candidates
        return "cloud-reclaim", source
    if scope == "explicit":
        source["selection"] = {
            "mode": "explicit_models",
            "source": "user_explicit",
            "models": [entry["model"] for entry in entries],
        }
        source["candidates"] = candidates
        return "cloud-reclaim-explicit", source
    raise ReclaimPipelineError("计划 scope 无效", "ARTIFACT_INVALID")


def device_type_action(kconf: dict[str, Any]) -> dict[str, Any] | None:
    items = kconf.get("artifacts", {}).get("kconf", [])
    required = []
    for item in items:
        summary = item.get("summary") if isinstance(item, dict) else None
        if isinstance(summary, dict) and summary.get("decision") == "device_type_required":
            required.append(
                {
                    "model": item.get("model"),
                    "options": summary.get("available_device_types", []),
                }
            )
    if not required:
        return None
    return {"type": "request_device_type", "models": required}


def non_negative_card_count(value: Any, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ReclaimPipelineError(
            f"资源持有量 {field} 必须是非负整数", "ARTIFACT_INVALID"
        )
    return value


def load_cloud_cost(
    path_value: str | Path,
    entries: list[dict[str, Any]],
) -> dict[str, Any]:
    """Validate one cost-domain Artifact against the capacity candidates."""

    _, artifact = load_object(path_value)
    status = artifact.get("status")
    if (
        artifact.get("domain") != "cost"
        or artifact.get("scenario") != "cloud-daily-billing"
        or status not in {"success", "partial", "error"}
    ):
        raise ReclaimPipelineError(
            "云上成本 Artifact 的领域、场景或状态无效",
            "ARTIFACT_INVALID",
        )
    expected_entries = [
        entry for entry in entries if entry.get("requires_dependencies") is True
    ]
    expected_models = [str(entry["model"]) for entry in expected_entries]
    expected_model_paths = [
        str(Path(entry["model_artifact"]).expanduser().resolve())
        for entry in expected_entries
    ]
    expected_headroom_paths = [
        str(Path(entry["headroom_artifact"]).expanduser().resolve())
        for entry in expected_entries
    ]
    query = artifact.get("query")
    if not isinstance(query, dict):
        raise ReclaimPipelineError(
            "云上成本 Artifact 缺少 query", "ARTIFACT_INVALID"
        )

    def canonical_paths(value: Any, field: str) -> list[str]:
        if not isinstance(value, list) or any(
            not isinstance(item, str) or not item for item in value
        ):
            raise ReclaimPipelineError(
                f"云上成本 Artifact 的 {field} 无效", "ARTIFACT_INVALID"
            )
        return [str(Path(item).expanduser().resolve()) for item in value]

    if (
        canonical_paths(
            query.get("capacity_model_artifacts"),
            "capacity_model_artifacts",
        )
        != expected_model_paths
        or canonical_paths(
            query.get("headroom_artifacts"), "headroom_artifacts"
        )
        != expected_headroom_paths
    ):
        raise ReclaimPipelineError(
            "云上成本 Artifact 的容量模型或 headroom 证据与计划不一致",
            "ARTIFACT_INVALID",
        )
    if status == "error":
        return artifact
    if query.get("models") != expected_models:
        raise ReclaimPipelineError(
            "云上成本 Artifact 的模型和顺序与计划不一致",
            "ARTIFACT_INVALID",
        )
    summary = artifact.get("summary")
    rows = summary.get("models") if isinstance(summary, dict) else None
    if not isinstance(rows, list) or [
        row.get("model_name") if isinstance(row, dict) else None
        for row in rows
    ] != expected_models:
        raise ReclaimPipelineError(
            "云上成本 Artifact 的 summary.models 与计划不一致",
            "ARTIFACT_INVALID",
        )
    resolution_evidence = query.get("model_resolution")
    if not isinstance(resolution_evidence, list) or len(
        resolution_evidence
    ) != len(expected_entries):
        raise ReclaimPipelineError(
            "云上成本 Artifact 的模型解析证据数量不一致",
            "ARTIFACT_INVALID",
        )
    for index, (evidence, entry) in enumerate(
        zip(resolution_evidence, expected_entries)
    ):
        if not isinstance(evidence, dict):
            raise ReclaimPipelineError(
                f"云上成本模型证据[{index}] 必须是对象",
                "ARTIFACT_INVALID",
            )
        if (
            evidence.get("mode") != "verified_artifact"
            or evidence.get("resolved_model") != entry["model"]
            or evidence.get("target_domain") != "capacity"
            or evidence.get("target_scenario") != "cloud-reclaim"
            or evidence.get("handoff_usage")
            != "cloud_reclaim_cost_estimation"
            or evidence.get("consumer_domain") != "cost"
            or evidence.get("consumer_scenario") != "cloud-daily-billing"
            or str(Path(str(evidence.get("artifact"))).expanduser().resolve())
            != str(Path(entry["model_artifact"]).expanduser().resolve())
            or str(
                Path(str(evidence.get("headroom_artifact")))
                .expanduser()
                .resolve()
            )
            != str(Path(entry["headroom_artifact"]).expanduser().resolve())
        ):
            raise ReclaimPipelineError(
                f"云上成本模型证据[{index}] 与容量回收候选不一致",
                "ARTIFACT_INVALID",
            )
    return artifact


def load_resource_holdings(
    path_value: str | Path,
    entries: list[dict[str, Any]],
) -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    """Validate one resource-domain holdings Artifact and index it by model."""

    path, artifact = load_object(path_value)
    status = artifact.get("status")
    if status == "error":
        return {}, artifact
    if (
        artifact.get("domain") != "resource"
        or artifact.get("scenario") != "model-holdings"
        or status not in {"success", "partial"}
    ):
        raise ReclaimPipelineError(
            "资源持有量 Artifact 的领域、场景或状态无效",
            "ARTIFACT_INVALID",
        )
    expected_entries = [
        entry for entry in entries if entry.get("requires_dependencies") is True
    ]
    expected_models = [str(entry["model"]) for entry in expected_entries]
    query = artifact.get("query")
    if not isinstance(query, dict):
        raise ReclaimPipelineError(
            "资源持有量 Artifact 缺少 query", "ARTIFACT_INVALID"
        )
    if (
        query.get("models") != expected_models
        or query.get("model_scope") != "regular"
        or query.get("service_type") != "online"
        or query.get("window_seconds") != 300
    ):
        raise ReclaimPipelineError(
            "资源持有量 Artifact 的模型、范围或当前窗口与计划不一致",
            "ARTIFACT_INVALID",
        )
    resolution_evidence = query.get("model_resolution")
    if not isinstance(resolution_evidence, list) or len(resolution_evidence) != len(
        expected_entries
    ):
        raise ReclaimPipelineError(
            "资源持有量 Artifact 的模型解析证据数量不一致",
            "ARTIFACT_INVALID",
        )
    for index, (evidence, entry) in enumerate(
        zip(resolution_evidence, expected_entries)
    ):
        if not isinstance(evidence, dict):
            raise ReclaimPipelineError(
                f"资源持有量模型证据[{index}] 必须是对象",
                "ARTIFACT_INVALID",
            )
        evidence_path = evidence.get("artifact")
        if (
            evidence.get("mode") != "verified_artifact"
            or evidence.get("resolved_model") != entry["model"]
            or evidence.get("target_domain") != "capacity"
            or evidence.get("target_scenario") != "cloud-reclaim"
            or evidence.get("handoff_usage")
            != "cloud_reclaim_resource_alignment"
            or not isinstance(evidence_path, str)
            or Path(evidence_path).expanduser().resolve()
            != Path(entry["model_artifact"]).expanduser().resolve()
        ):
            raise ReclaimPipelineError(
                f"资源持有量模型证据[{index}] 与容量回收候选不一致",
                "ARTIFACT_INVALID",
            )

    summary = artifact.get("summary")
    rows = summary.get("models") if isinstance(summary, dict) else None
    if not isinstance(rows, list):
        raise ReclaimPipelineError(
            "资源持有量 Artifact 缺少 summary.models",
            "ARTIFACT_INVALID",
        )
    indexed: dict[str, dict[str, Any]] = {}
    for index, row in enumerate(rows):
        if not isinstance(row, dict):
            raise ReclaimPipelineError(
                f"资源持有量 models[{index}] 必须是对象",
                "ARTIFACT_INVALID",
            )
        model = row.get("model_name")
        if model not in expected_models or model in indexed:
            raise ReclaimPipelineError(
                "资源持有量返回了计划外或重复模型", "ARTIFACT_INVALID"
            )
        total_cards = non_negative_card_count(
            row.get("gpu_cards"), f"models[{index}].gpu_cards"
        )
        breakdown = row.get("breakdown")
        if not isinstance(breakdown, list):
            raise ReclaimPipelineError(
                f"资源持有量 models[{index}].breakdown 必须是数组",
                "ARTIFACT_INVALID",
            )
        cards_by_type: dict[str, int] = {}
        for breakdown_index, item in enumerate(breakdown):
            if not isinstance(item, dict):
                raise ReclaimPipelineError(
                    "资源持有量卡型分项必须是对象", "ARTIFACT_INVALID"
                )
            gpu_type = item.get("gpu_type")
            if not isinstance(gpu_type, str) or not gpu_type:
                raise ReclaimPipelineError(
                    "资源持有量卡型分项缺少 gpu_type", "ARTIFACT_INVALID"
                )
            if item.get("service_type") != "online":
                raise ReclaimPipelineError(
                    "资源持有量校准只能消费 online 分项",
                    "ARTIFACT_INVALID",
                )
            cards = non_negative_card_count(
                item.get("gpu_cards"),
                f"models[{index}].breakdown[{breakdown_index}].gpu_cards",
            )
            cards_by_type[gpu_type] = cards_by_type.get(gpu_type, 0) + cards
        if sum(cards_by_type.values()) != total_cards:
            raise ReclaimPipelineError(
                f"资源持有量模型 {model} 的总卡数与卡型分项不一致",
                "ARTIFACT_INVALID",
            )
        indexed[str(model)] = {
            "artifact": str(path),
            "generated_at": artifact.get("generated_at"),
            "from_inclusive": query.get("from_inclusive"),
            "to_inclusive": query.get("to_inclusive"),
            "gpu_cards": total_cards,
            "gpu_cards_by_type": dict(sorted(cards_by_type.items())),
            "equivalent_machines": round(total_cards / 8, 4),
        }
    return indexed, artifact


def apply_holdings_alignment(
    summary: dict[str, Any],
    *,
    entries: list[dict[str, Any]],
    detail_level: str,
    alignment_mode: str,
) -> tuple[dict[str, Any], bool, list[str]]:
    """Cap theoretical card savings by current per-model online holdings."""

    from capacity_metrics import align_reclaim_to_holdings

    aligned_summary = copy.deepcopy(summary)
    aligned_summary["holdings_alignment_mode"] = alignment_mode
    candidates = aligned_summary.get("candidates")
    if not isinstance(candidates, list) or len(candidates) != len(entries):
        raise ReclaimPipelineError(
            "云上回收候选与资源校准计划数量不一致",
            "ARTIFACT_INVALID",
        )
    if detail_level == "instances":
        aligned_summary["holdings_alignment_complete"] = None
        return aligned_summary, True, []
    if alignment_mode == "fixture_replay_skipped":
        aligned_summary["holdings_alignment_complete"] = None
        aligned_summary["final_reclaimable_gpu_cards_total"] = aligned_summary.get(
            "reclaimable_gpu_cards_total"
        )
        aligned_summary[
            "final_reclaimable_8_card_machine_equivalents_total"
        ] = aligned_summary.get("reclaimable_8_card_machine_equivalents_total")
        return aligned_summary, True, [
            "离线 fixture 回放未提供资源持有量 fixture，跳过当前持有量校准。"
        ]
    if alignment_mode != "required":
        raise ReclaimPipelineError(
            "cards/machines 路径缺少资源持有量校准",
            "ARTIFACT_INVALID",
        )

    holdings_paths = {
        str(Path(entry["holdings_artifact"]).expanduser().resolve())
        for entry in entries
        if entry.get("requires_dependencies") is True
    }
    if len(holdings_paths) != 1:
        raise ReclaimPipelineError(
            "云上回收必须绑定唯一的批量资源持有量 Artifact",
            "ARTIFACT_INVALID",
        )
    holdings_by_model, holdings_artifact = load_resource_holdings(
        next(iter(holdings_paths)), entries
    )
    warnings: list[str] = []
    alignment_complete = holdings_artifact.get("status") == "success"
    aligned_cards_partial_sum = 0
    aligned_cards_by_type: dict[str, int] = {}
    held_cards_partial_sum = 0
    held_cards_by_type: dict[str, int] = {}
    aligned_candidate_count = 0

    for candidate, entry in zip(candidates, entries):
        if not isinstance(candidate, dict) or candidate.get("model") != entry["model"]:
            raise ReclaimPipelineError(
                "云上回收候选顺序与资源校准计划不一致",
                "ARTIFACT_INVALID",
            )
        raw_cards = candidate.get("reclaimable_gpu_cards")
        raw_by_type = candidate.get("reclaimable_gpu_cards_by_type")
        raw_machines = candidate.get(
            "reclaimable_8_card_machine_equivalents"
        )
        candidate["capacity_theoretical_reclaimable_gpu_cards"] = raw_cards
        candidate[
            "capacity_theoretical_reclaimable_gpu_cards_by_type"
        ] = copy.deepcopy(raw_by_type)
        candidate[
            "capacity_theoretical_reclaimable_8_card_machine_equivalents"
        ] = raw_machines

        if raw_cards is None or raw_by_type is None:
            candidate["holdings_alignment_status"] = "upstream_incomplete"
            candidate["aligned_reclaimable_gpu_cards"] = None
            candidate["aligned_reclaimable_gpu_cards_by_type"] = None
            candidate[
                "aligned_reclaimable_8_card_machine_equivalents"
            ] = None
            alignment_complete = False
            continue
        if (
            isinstance(raw_cards, bool)
            or not isinstance(raw_cards, int)
            or raw_cards < 0
            or not isinstance(raw_by_type, dict)
        ):
            raise ReclaimPipelineError(
                "云上回收理论卡数不是合法的非负整数",
                "ARTIFACT_INVALID",
            )
        normalized_raw_by_type: dict[str, int] = {}
        for gpu_type, value in raw_by_type.items():
            if not isinstance(gpu_type, str) or not gpu_type:
                raise ReclaimPipelineError(
                    "云上回收理论卡型无效", "ARTIFACT_INVALID"
                )
            normalized_raw_by_type[gpu_type] = non_negative_card_count(
                value, f"{entry['model']}.{gpu_type}.reclaimable_gpu_cards"
            )
        if sum(normalized_raw_by_type.values()) != raw_cards:
            raise ReclaimPipelineError(
                f"模型 {entry['model']} 的理论总卡数与卡型分项不一致",
                "ARTIFACT_INVALID",
            )

        holdings = holdings_by_model.get(str(entry["model"]))
        if holdings is None:
            candidate["holdings_alignment_status"] = "holdings_missing"
            candidate["current_held_gpu_cards"] = None
            candidate["current_held_gpu_cards_by_type"] = None
            candidate["current_held_8_card_machine_equivalents"] = None
            candidate[
                "current_held_8_card_machine_equivalents_by_type"
            ] = None
            candidate["aligned_reclaimable_gpu_cards"] = None
            candidate["aligned_reclaimable_gpu_cards_by_type"] = None
            candidate[
                "aligned_reclaimable_8_card_machine_equivalents"
            ] = None
            candidate["holdings_alignment_limited"] = None
            alignment_complete = False
            warnings.append(
                f"{entry['model']} 当前 online 持有量没有匹配记录，未形成校准结果。"
            )
            continue

        held_by_type = holdings["gpu_cards_by_type"]
        aligned = align_reclaim_to_holdings(
            normalized_raw_by_type,
            {
                gpu_type: int(cards)
                for gpu_type, cards in held_by_type.items()
            },
        )
        aligned_by_type = aligned["gpu_cards_by_type"]
        aligned_cards = int(aligned["gpu_cards"])
        aligned_machines_by_type = aligned[
            "equivalent_machines_by_type"
        ]
        candidate["holdings_alignment_status"] = "aligned"
        candidate["current_held_gpu_cards"] = holdings["gpu_cards"]
        candidate["current_held_gpu_cards_by_type"] = copy.deepcopy(held_by_type)
        candidate[
            "current_held_8_card_machine_equivalents"
        ] = holdings["equivalent_machines"]
        candidate[
            "current_held_8_card_machine_equivalents_by_type"
        ] = {
            gpu_type: round(cards / 8, 4)
            for gpu_type, cards in sorted(held_by_type.items())
        }
        candidate["current_holdings_window"] = {
            "from_inclusive": holdings["from_inclusive"],
            "to_inclusive": holdings["to_inclusive"],
            "generated_at": holdings["generated_at"],
            "service_type": "online",
        }
        candidate["aligned_reclaimable_gpu_cards"] = aligned_cards
        candidate["aligned_reclaimable_gpu_cards_by_type"] = dict(
            sorted(aligned_by_type.items())
        )
        candidate[
            "aligned_reclaimable_8_card_machine_equivalents_by_type"
        ] = aligned_machines_by_type
        candidate[
            "aligned_reclaimable_8_card_machine_equivalents"
        ] = aligned["equivalent_machines"]
        candidate["holdings_alignment_limited"] = aligned_cards < raw_cards
        candidate["final_reclaimable_gpu_cards"] = aligned_cards
        candidate[
            "final_reclaimable_8_card_machine_equivalents"
        ] = aligned["equivalent_machines"]
        aligned_candidate_count += 1
        aligned_cards_partial_sum += aligned_cards
        held_cards_partial_sum += int(holdings["gpu_cards"])
        for gpu_type, cards in held_by_type.items():
            held_cards_by_type[gpu_type] = held_cards_by_type.get(gpu_type, 0) + int(
                cards
            )
        for gpu_type, cards in aligned_by_type.items():
            aligned_cards_by_type[gpu_type] = (
                aligned_cards_by_type.get(gpu_type, 0) + cards
            )

    raw_cards_complete = aligned_summary.get("gpu_card_savings_complete") is True
    alignment_complete = (
        alignment_complete
        and raw_cards_complete
        and aligned_candidate_count == len(candidates)
    )
    aligned_summary["holdings_alignment_complete"] = alignment_complete
    aligned_summary["aligned_candidate_count"] = aligned_candidate_count
    aligned_summary["current_held_gpu_cards_partial_sum"] = held_cards_partial_sum
    aligned_summary["current_held_gpu_cards_total"] = (
        held_cards_partial_sum if alignment_complete else None
    )
    aligned_summary["current_held_gpu_cards_total_by_type"] = (
        dict(sorted(held_cards_by_type.items())) if alignment_complete else None
    )
    aligned_summary[
        "current_held_8_card_machine_equivalents_total"
    ] = round(held_cards_partial_sum / 8, 4) if alignment_complete else None
    aligned_summary[
        "aligned_reclaimable_gpu_cards_partial_sum"
    ] = aligned_cards_partial_sum
    aligned_summary["aligned_reclaimable_gpu_cards_total"] = (
        aligned_cards_partial_sum if alignment_complete else None
    )
    aligned_summary["aligned_reclaimable_gpu_cards_total_by_type"] = (
        dict(sorted(aligned_cards_by_type.items()))
        if alignment_complete
        else None
    )
    aligned_summary[
        "aligned_reclaimable_8_card_machine_equivalents_total"
    ] = (
        round(aligned_cards_partial_sum / 8, 4)
        if alignment_complete
        else None
    )
    aligned_summary["final_reclaimable_gpu_cards_total"] = (
        aligned_cards_partial_sum if alignment_complete else None
    )
    aligned_summary[
        "final_reclaimable_8_card_machine_equivalents_total"
    ] = (
        round(aligned_cards_partial_sum / 8, 4)
        if alignment_complete
        else None
    )
    return aligned_summary, alignment_complete, warnings


def build_reclaim_report_projection(
    summary: dict[str, Any],
    *,
    status: str,
    complete: bool,
    warnings: list[Any],
    errors: list[Any],
) -> dict[str, Any]:
    """Build the report view once, at the trusted Result boundary."""

    candidates = summary.get("candidates")
    if not isinstance(candidates, list):
        raise ReclaimPipelineError(
            "云上回收结果缺少 candidates", "ARTIFACT_INVALID"
        )
    report_summary = {
        "decision": summary.get("decision"),
        "window": summary.get("window"),
        "requested_detail": summary.get("requested_detail"),
        "source_scope": summary.get("source_scope"),
        "evaluated_candidate_count": summary.get(
            "evaluated_candidate_count", len(candidates)
        ),
        "reclaimable_instances_total": summary.get(
            "reclaimable_instances_total"
        ),
        "reclaimable_instances_partial_sum": summary.get(
            "reclaimable_instances_partial_sum"
        ),
        "reclaimable_gpu_cards_total": summary.get(
            "reclaimable_gpu_cards_total"
        ),
        "reclaimable_gpu_cards_total_by_type": summary.get(
            "reclaimable_gpu_cards_total_by_type"
        ),
        "reclaimable_8_card_machine_equivalents_total": summary.get(
            "reclaimable_8_card_machine_equivalents_total"
        ),
        "holdings_alignment_mode": summary.get("holdings_alignment_mode"),
        "holdings_alignment_complete": summary.get(
            "holdings_alignment_complete"
        ),
        "current_held_gpu_cards_total": summary.get(
            "current_held_gpu_cards_total"
        ),
        "current_held_gpu_cards_total_by_type": summary.get(
            "current_held_gpu_cards_total_by_type"
        ),
        "current_held_8_card_machine_equivalents_total": summary.get(
            "current_held_8_card_machine_equivalents_total"
        ),
        "aligned_reclaimable_gpu_cards_total": summary.get(
            "aligned_reclaimable_gpu_cards_total"
        ),
        "aligned_reclaimable_gpu_cards_total_by_type": summary.get(
            "aligned_reclaimable_gpu_cards_total_by_type"
        ),
        "aligned_reclaimable_8_card_machine_equivalents_total": summary.get(
            "aligned_reclaimable_8_card_machine_equivalents_total"
        ),
        "final_reclaimable_gpu_cards_total": summary.get(
            "final_reclaimable_gpu_cards_total"
        ),
        "final_reclaimable_8_card_machine_equivalents_total": summary.get(
            "final_reclaimable_8_card_machine_equivalents_total"
        ),
        "cloud_cost_estimation_mode": summary.get(
            "cloud_cost_estimation_mode"
        ),
        "cloud_cost_estimation_complete": summary.get(
            "cloud_cost_estimation_complete"
        ),
        "cloud_cost_unit": summary.get("cloud_cost_unit"),
        "previous_day_billable_usage_cost_total": summary.get(
            "previous_day_billable_usage_cost_total"
        ),
        "estimated_incremental_cloud_daily_cost_total": summary.get(
            "estimated_incremental_cloud_daily_cost_total"
        ),
        "estimated_incremental_cloud_daily_cost_partial_sum": summary.get(
            "estimated_incremental_cloud_daily_cost_partial_sum"
        ),
        "estimated_projected_cloud_daily_cost_total": summary.get(
            "estimated_projected_cloud_daily_cost_total"
        ),
        "complete": complete,
        "write_performed": False,
    }
    alignment_mode = summary.get("holdings_alignment_mode")
    if alignment_mode == "required":
        limitations = [
            "持有量校准后的机器数仍是 8 卡等效值，不是去重物理宿主机数；"
            "实际迁流和释放需要变更审批。"
        ]
    elif alignment_mode == "fixture_replay_skipped":
        limitations = [
            "离线 fixture 回放未执行当前持有量校准，不得作为生产释放上限；"
            "机器数仍是 8 卡等效值。"
        ]
    else:
        limitations = [
            "理论实例数不表示实际已经下线实例；实际迁流和释放需要变更审批。"
        ]
    cost_mode = summary.get("cloud_cost_estimation_mode")
    if cost_mode == "required":
        limitations.append(
            "云上成本按云上余量/前一天流量P90线性估算，单位沿用源表；"
            "不等于实际账单或已节省成本。"
        )
    elif cost_mode == "fixture_replay_skipped":
        limitations.append(
            "离线 fixture 回放未提供成本证据，不得表述为生产成本估算。"
        )
    return {
        "schema_version": "2.0",
        "status": status,
        "complete": complete,
        "reason_code": "OK" if complete else "EVIDENCE_MISSING",
        "summary": report_summary,
        "candidates": copy.deepcopy(candidates),
        "limitations": limitations
        + (
            [
                "部分证据不完整；只能使用非 null 的完整维度，"
                "partial_sum 不能作为全量结论。"
            ]
            if not complete
            else []
        ),
        "warnings": copy.deepcopy(warnings),
        "errors": copy.deepcopy(errors),
    }


def run_finalize(args: argparse.Namespace) -> dict[str, Any]:
    if not 1 <= args.max_workers <= 8:
        raise ReclaimPipelineError("--max-workers 必须在 1～8 之间")
    plan_path, plan = load_object(args.plan_artifact)
    validate_provenance(
        plan,
        expected_artifact_type=PLAN_ARTIFACT_TYPE,
        expected_producer_script=PRODUCER_SCRIPT,
        expected_producer_version=SCRIPT_VERSION,
        expected_stage="awaiting_kconf",
        required_parent_roles=(
            "model_resolution",
            "headroom",
        ),
    )
    if plan.get("status") not in {"success", "partial"}:
        raise ReclaimPipelineError(
            "prepare 计划未进入 awaiting_kconf", "WORKFLOW_NOT_READY"
        )
    next_action = plan.get("next_action")
    try:
        validate_kconf_next_action(
            next_action,
            tool=KCONF_TOOL,
            key=KCONF_KEY,
            stage=KCONF_STAGE,
            then_command="cloud-reclaim-finalize",
            plan_path=plan_path,
            artifact=plan,
        )
    except ArtifactContractError as exc:
        raise ReclaimPipelineError(str(exc), "ARTIFACT_INVALID") from exc
    selection, detail_level, entries = plan_entries(plan)
    request_summary = validate_prepare_request(plan)
    if (
        request_summary.get("selection") != selection
        or request_summary.get("detail_level") != detail_level
    ):
        raise ReclaimPipelineError(
            "prepare_request 与计划的选择范围或明细层级不一致",
            "ARTIFACT_INVALID",
        )
    try:
        device_type_selections = parse_named_selections(
            args.device_type_selection,
            option_name="device-type-selection",
        )
    except ValueError as exc:
        raise ReclaimPipelineError(str(exc)) from exc
    if args.device_type and device_type_selections:
        raise ReclaimPipelineError(
            "--device-type 与 --device-type-selection 不得同时使用"
        )
    plan_models = {
        entry["model"]
        for entry in entries
        if entry.get("requires_dependencies") is True
    }
    unknown_selections = sorted(set(device_type_selections) - plan_models)
    if unknown_selections:
        raise ReclaimPipelineError(
            "device-type-selection 的模型不在计划中："
            + ", ".join(unknown_selections)
        )
    args.parsed_device_type_selections = device_type_selections
    validate_entry_parent_references(plan, detail_level, entries)
    validate_plan_dependency_partition(request_summary, entries)
    output_dir = Path(args.output_dir).expanduser().resolve()
    kconf_path, kconf, kconf_paths = normalize_kconf(args, entries, output_dir)
    if kconf.get("status") == "error":
        raise ReclaimPipelineError(
            "KConf 工具返回无法规范化：" + "; ".join(kconf.get("errors", [])),
            "KCONF_INVALID",
        )

    workflow_name, source = build_assembly_source(
        selection, detail_level, entries, kconf_paths
    )
    assembly_input = output_dir / "02-assembly" / "input.json"
    write_artifact(str(assembly_input), source)
    calculation_manifest = output_dir / "02-assembly" / "manifest.json"
    from reclaim_assembly import assemble_reclaim_workflow

    calculation = assemble_reclaim_workflow(
        workflow_name,
        input_path=assembly_input,
        output_dir=output_dir / "02-assembly" / "artifacts",
        max_workers=args.max_workers,
    )
    annotate_outcome(calculation)
    write_artifact(str(calculation_manifest), calculation)
    status = str(calculation.get("status", "error"))
    summary = copy.deepcopy(calculation.get("summary", {}))
    if not isinstance(summary, dict):
        raise ReclaimPipelineError(
            "计算 Manifest 缺少 summary", "ARTIFACT_INVALID"
        )
    plan_summary = plan.get("summary")
    if not isinstance(plan_summary, dict):
        raise ReclaimPipelineError(
            "prepare 计划缺少 summary", "ARTIFACT_INVALID"
        )
    alignment_mode = plan_summary.get(
        "holdings_alignment_mode",
        "not_requested" if detail_level == "instances" else "fixture_replay_skipped",
    )
    summary, holdings_complete, alignment_warnings = apply_holdings_alignment(
        summary,
        entries=entries,
        detail_level=detail_level,
        alignment_mode=str(alignment_mode),
    )
    if alignment_mode == "required" and not holdings_complete and status == "success":
        status = "partial"
    cost_mode = str(
        plan_summary.get("cost_estimation_mode", "fixture_replay_skipped")
    )
    cost_path: Path | None = None
    cost_artifact: dict[str, Any] | None = None
    if cost_mode == "required":
        cost_paths = {
            Path(str(entry["cost_artifact"])).expanduser().resolve()
            for entry in entries
            if entry.get("requires_dependencies") is True
        }
        if len(cost_paths) != 1:
            raise ReclaimPipelineError(
                "计划必须绑定唯一云上成本 Artifact", "ARTIFACT_INVALID"
            )
        cost_path = next(iter(cost_paths))
        cost_artifact = load_cloud_cost(cost_path, entries)
    from cost_metrics import CostMetricError, apply_cloud_cost_estimates

    try:
        summary, cost_complete, cost_warnings = apply_cloud_cost_estimates(
            summary,
            cost_artifact=cost_artifact,
            cost_mode=cost_mode,
        )
    except CostMetricError as exc:
        raise ReclaimPipelineError(str(exc), "ARTIFACT_INVALID") from exc
    if cost_mode == "required" and not cost_complete and status == "success":
        status = "partial"
    complete = status == "success"
    reason = "OK" if complete else "EVIDENCE_MISSING"
    requested_device_type = device_type_action(kconf)
    final_next_action: Any = requested_device_type or {
        "type": "command",
        "command": "render-report",
        "arguments": {
            "manifest": str(Path(args.output).expanduser().resolve()),
            "output": str(output_dir / "cloud-reclaim-report.json"),
        },
    }
    result = {
        "schema_version": "1.2",
        "script_version": SCRIPT_VERSION,
        "domain": "workflow",
        "scenario": "cloud-reclaim-finalize",
        "status": status,
        "generated_at": utc_now(),
        "summary": {
            **summary,
            "source_scope": selection.get("scope"),
            "requested_detail": detail_level,
            "source_plan": str(plan_path),
            "write_performed": False,
        },
        "artifacts": {
            "plan": str(plan_path),
            "kconf_manifest": str(kconf_path),
            "assembly_input": str(assembly_input),
            "calculation_manifest": str(calculation_manifest),
            **(
                {
                    "resource_holdings": next(
                        entry["holdings_artifact"]
                        for entry in entries
                        if isinstance(entry.get("holdings_artifact"), str)
                    )
                }
                if alignment_mode == "required"
                else {}
            ),
            **(
                {"cloud_cost": str(cost_path)}
                if cost_path is not None
                else {}
            ),
        },
        "warnings": list(plan.get("warnings", []))
        + list(kconf.get("warnings", []))
        + list(calculation.get("warnings", []))
        + alignment_warnings
        + cost_warnings,
        "errors": list(plan.get("errors", []))
        + list(kconf.get("errors", []))
        + list(calculation.get("errors", [])),
    }
    if requested_device_type is None:
        result["report_projection"] = build_reclaim_report_projection(
            result["summary"],
            status=status,
            complete=complete,
            warnings=result["warnings"],
            errors=result["errors"],
        )
    annotate_outcome(
        result,
        complete=complete,
        reason_code=reason if requested_device_type is None else "DEVICE_TYPE_REQUIRED",
        next_action=final_next_action,
    )
    parents = parent_references(
        [(plan_path, "prepare_plan")]
        + [
            (
                Path(args.kconf_tool_result).expanduser().resolve(),
                "kconf_tool_result",
            ),
            (kconf_path, "kconf_manifest"),
        ]
        + [(path, "kconf") for path in kconf_paths]
        + [
            (Path(entry["model_artifact"]), "model_resolution")
            for entry in entries
        ]
        + [
            (Path(entry["headroom_artifact"]), "headroom")
            for entry in entries
        ]
        + (
            [(cost_path, "cost")]
            if cost_path is not None
            else []
        )
        + [
            (Path(entry["isvc_artifact"]), "isvc")
            for entry in entries
            if isinstance(entry.get("isvc_artifact"), str)
        ]
        + [
            (Path(entry["holdings_artifact"]), "resource")
            for entry in entries
            if isinstance(entry.get("holdings_artifact"), str)
        ]
        + [
            (assembly_input, "assembly_input"),
            (calculation_manifest, "calculation_manifest"),
        ]
    )
    finalized = add_provenance(
        result,
        artifact_type=RESULT_ARTIFACT_TYPE,
        producer_script=PRODUCER_SCRIPT,
        producer_version=SCRIPT_VERSION,
        run_id=str(plan["run_id"]),
        stage="finalized",
        parents=parents,
    )
    attach_reclaim_result_evidence_ids(
        finalized,
        entries=entries,
        kconf_paths=kconf_paths,
    )
    if requested_device_type is None:
        finalized["report_projection"] = build_reclaim_report_projection(
            finalized["summary"],
            status=finalized["status"],
            complete=finalized["complete"],
            warnings=finalized["warnings"],
            errors=finalized["errors"],
        )
    return finalized


def _render_projected_report(
    *,
    result_path: Path,
    result: dict[str, Any],
) -> dict[str, Any]:
    try:
        validate_provenance(
            result,
            expected_artifact_type=RESULT_ARTIFACT_TYPE,
            expected_producer_script=PRODUCER_SCRIPT,
            expected_producer_version=SCRIPT_VERSION,
            expected_stage="finalized",
            verify_parent_hashes=False,
        )
    except ArtifactContractError as exc:
        raise ReclaimPipelineError(str(exc), "ARTIFACT_INVALID") from exc
    next_action = result.get("next_action")
    if (
        not isinstance(next_action, dict)
        or next_action.get("type") != "command"
        or next_action.get("command") != "render-report"
        or not isinstance(next_action.get("arguments"), dict)
        or Path(str(next_action["arguments"].get("manifest", "")))
        .expanduser()
        .resolve()
        != result_path
    ):
        raise ReclaimPipelineError(
            "最终结果的报告动作不符合固定契约", "ARTIFACT_INVALID"
        )
    summary = result.get("summary")
    if not isinstance(summary, dict):
        raise ReclaimPipelineError("最终结果缺少 summary", "ARTIFACT_INVALID")
    status = result.get("status")
    complete = result.get("complete")
    if status not in {"success", "partial"} or not isinstance(complete, bool):
        raise ReclaimPipelineError("最终结果状态无效", "ARTIFACT_INVALID")
    expected = build_reclaim_report_projection(
        summary,
        status=status,
        complete=complete,
        warnings=list(result.get("warnings", [])),
        errors=list(result.get("errors", [])),
    )
    if result.get("report_projection") != expected:
        raise ReclaimPipelineError(
            "最终结果与固定报告投影不一致", "ARTIFACT_INVALID"
        )
    if result.get("reason_code") != expected["reason_code"]:
        raise ReclaimPipelineError(
            "最终结果 reason_code 与固定报告投影不一致",
            "ARTIFACT_INVALID",
        )
    report = {
        "schema_version": "1.1",
        "script_version": SCRIPT_VERSION,
        "domain": "workflow",
        "scenario": "cloud-reclaim-report",
        "status": expected["status"],
        "generated_at": utc_now(),
        "summary": copy.deepcopy(expected["summary"]),
        "candidates": copy.deepcopy(expected["candidates"]),
        "limitations": copy.deepcopy(expected["limitations"]),
        "artifacts": {"source_manifest": str(result_path)},
        "warnings": copy.deepcopy(expected["warnings"]),
        "errors": copy.deepcopy(expected["errors"]),
    }
    annotate_outcome(
        report,
        complete=expected["complete"],
        reason_code=expected["reason_code"],
        next_action="NONE",
    )
    return add_provenance(
        report,
        artifact_type=REPORT_ARTIFACT_TYPE,
        producer_script=PRODUCER_SCRIPT,
        producer_version=SCRIPT_VERSION,
        run_id=str(result["run_id"]),
        stage="report_rendered",
        parents=[
            artifact_reference(
                result_path,
                role="final_result",
                include_in_evidence=False,
            )
        ],
    )


def run_report(args: argparse.Namespace) -> dict[str, Any]:
    result_path, result = load_object(args.manifest)
    if result.get("report_projection") is not None:
        return _render_projected_report(
            result_path=result_path,
            result=result,
        )
    return _run_report_legacy(args, loaded=(result_path, result))


def _run_report_legacy(
    args: argparse.Namespace,
    *,
    loaded: tuple[Path, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    result_path, result = loaded or load_object(args.manifest)
    validate_provenance(
        result,
        expected_artifact_type=RESULT_ARTIFACT_TYPE,
        expected_producer_script=PRODUCER_SCRIPT,
        expected_producer_version=SCRIPT_VERSION,
        expected_stage="finalized",
        required_parent_roles=(
            "prepare_plan",
            "kconf_tool_result",
            "kconf_manifest",
            "assembly_input",
            "calculation_manifest",
        ),
    )
    artifacts = result.get("artifacts")
    if not isinstance(artifacts, dict):
        raise ReclaimPipelineError("最终结果缺少 artifacts", "ARTIFACT_INVALID")
    required_artifacts = {
        "plan": "prepare_plan",
        "kconf_manifest": "kconf_manifest",
        "assembly_input": "assembly_input",
        "calculation_manifest": "calculation_manifest",
    }
    bindings: list[tuple[str, str, str]] = []
    for field, role in required_artifacts.items():
        path_value = artifacts.get(field)
        if not isinstance(path_value, str) or not path_value:
            raise ReclaimPipelineError(
                f"最终结果缺少 artifacts.{field}", "ARTIFACT_INVALID"
            )
        bindings.append((f"artifacts.{field}", path_value, role))
    try:
        validate_parent_path_bindings(result, bindings)
    except ArtifactContractError as exc:
        raise ReclaimPipelineError(str(exc), "ARTIFACT_INVALID") from exc

    plan_path, plan = load_object(artifacts["plan"])
    validate_provenance(
        plan,
        expected_artifact_type=PLAN_ARTIFACT_TYPE,
        expected_producer_script=PRODUCER_SCRIPT,
        expected_producer_version=SCRIPT_VERSION,
        expected_stage="awaiting_kconf",
        required_parent_roles=(
            "prepare_request",
            "candidate_manifest",
            "resolution_manifest",
            "headroom_manifest",
            "model_resolution",
            "headroom",
        ),
    )
    if plan.get("run_id") != result.get("run_id"):
        raise ReclaimPipelineError(
            "最终结果与 prepare 计划的 run_id 不一致", "ARTIFACT_INVALID"
        )
    selection, detail_level, entries = plan_entries(plan)
    request_summary = validate_prepare_request(plan)
    if (
        request_summary.get("selection") != selection
        or request_summary.get("detail_level") != detail_level
    ):
        raise ReclaimPipelineError(
            "prepare_request 与计划的选择范围或明细层级不一致",
            "ARTIFACT_INVALID",
        )
    validate_entry_parent_references(plan, detail_level, entries)
    validate_plan_dependency_partition(request_summary, entries)

    _, kconf = load_object(artifacts["kconf_manifest"])
    _, calculation = load_object(artifacts["calculation_manifest"])
    expected_scenario = {
        "all": "cloud-reclaim-all",
        "gpu": "cloud-reclaim",
        "explicit": "cloud-reclaim-explicit",
    }.get(selection.get("scope"))
    if (
        calculation.get("domain") != "workflow"
        or calculation.get("scenario") != expected_scenario
        or calculation.get("status") not in {"success", "partial", "error"}
    ):
        raise ReclaimPipelineError(
            "计算 Manifest 的领域、场景或状态与计划不一致",
            "ARTIFACT_INVALID",
        )
    calculation_summary = calculation.get("summary")
    if not isinstance(calculation_summary, dict):
        raise ReclaimPipelineError(
            "计算 Manifest 缺少 summary", "ARTIFACT_INVALID"
        )
    calculation_candidates = calculation_summary.get("candidates")
    if (
        calculation_summary.get("requested_detail") != detail_level
        or calculation_summary.get("evaluated_candidate_count") != len(entries)
        or not isinstance(calculation_candidates, list)
        or len(calculation_candidates) != len(entries)
        or [
            candidate.get("model") if isinstance(candidate, dict) else None
            for candidate in calculation_candidates
        ]
        != [entry["model"] for entry in entries]
    ):
        raise ReclaimPipelineError(
            "计算 Manifest 的明细层级或候选模型与计划不一致",
            "ARTIFACT_INVALID",
        )
    summary = {
        **copy.deepcopy(calculation_summary),
        "source_scope": selection.get("scope"),
        "requested_detail": detail_level,
        "source_plan": str(plan_path),
        "write_performed": False,
    }
    expected_status = str(calculation["status"])
    complete = expected_status == "success"
    requested_device_type = device_type_action(kconf)
    expected_reason = (
        "DEVICE_TYPE_REQUIRED"
        if requested_device_type is not None
        else "OK"
        if complete
        else "EVIDENCE_MISSING"
    )
    expected_warnings = (
        list(plan.get("warnings", []))
        + list(kconf.get("warnings", []))
        + list(calculation.get("warnings", []))
    )
    expected_errors = (
        list(plan.get("errors", []))
        + list(kconf.get("errors", []))
        + list(calculation.get("errors", []))
    )
    if (
        result.get("summary") != summary
        or result.get("status") != expected_status
        or result.get("complete") is not complete
        or result.get("reason_code") != expected_reason
        or result.get("warnings") != expected_warnings
        or result.get("errors") != expected_errors
    ):
        raise ReclaimPipelineError(
            "最终结果与受绑定的计划或计算 Manifest 不一致",
            "ARTIFACT_INVALID",
        )
    result_next_action = result.get("next_action")
    if requested_device_type is not None:
        if result_next_action != requested_device_type:
            raise ReclaimPipelineError(
                "最终结果的卡型确认动作与 KConf 不一致", "ARTIFACT_INVALID"
            )
    elif (
        not isinstance(result_next_action, dict)
        or result_next_action.get("type") != "command"
        or result_next_action.get("command") != "render-report"
        or not isinstance(result_next_action.get("arguments"), dict)
        or Path(
            str(result_next_action["arguments"].get("manifest", ""))
        ).expanduser().resolve()
        != result_path
    ):
        raise ReclaimPipelineError(
            "最终结果的报告动作不符合固定契约", "ARTIFACT_INVALID"
        )

    report_summary = {
        "decision": summary.get("decision"),
        "window": summary.get("window"),
        "requested_detail": summary.get("requested_detail"),
        "source_scope": summary.get("source_scope"),
        "evaluated_candidate_count": summary.get(
            "evaluated_candidate_count",
            len(summary.get("candidates", []))
            if isinstance(summary.get("candidates"), list)
            else None,
        ),
        "reclaimable_instances_total": summary.get(
            "reclaimable_instances_total"
        ),
        "reclaimable_instances_partial_sum": summary.get(
            "reclaimable_instances_partial_sum"
        ),
        "reclaimable_gpu_cards_total": summary.get(
            "reclaimable_gpu_cards_total"
        ),
        "reclaimable_gpu_cards_total_by_type": summary.get(
            "reclaimable_gpu_cards_total_by_type"
        ),
        "reclaimable_8_card_machine_equivalents_total": summary.get(
            "reclaimable_8_card_machine_equivalents_total"
        ),
        "complete": complete,
        "write_performed": False,
    }
    report = {
        "schema_version": "1.1",
        "script_version": SCRIPT_VERSION,
        "domain": "workflow",
        "scenario": "cloud-reclaim-report",
        "status": expected_status,
        "generated_at": utc_now(),
        "summary": report_summary,
        "candidates": copy.deepcopy(summary.get("candidates", [])),
        "limitations": [
            "理论节省不表示已经形成空闲物理机器；实际迁流和释放需要变更审批。"
        ]
        + (
            [
                "部分证据不完整；只能使用非 null 的完整维度，"
                "partial_sum 不能作为全量结论。"
            ]
            if not complete
            else []
        ),
        "artifacts": {"source_manifest": str(result_path)},
        "warnings": copy.deepcopy(expected_warnings),
        "errors": copy.deepcopy(expected_errors),
    }
    annotate_outcome(
        report,
        complete=complete,
        reason_code=expected_reason,
        next_action=(
            copy.deepcopy(requested_device_type)
            if requested_device_type is not None
            else "NONE"
        ),
    )
    return add_provenance(
        report,
        artifact_type=REPORT_ARTIFACT_TYPE,
        producer_script=PRODUCER_SCRIPT,
        producer_version=SCRIPT_VERSION,
        run_id=str(result["run_id"]),
        stage="report_rendered",
        parents=[
            artifact_reference(
                result_path,
                role="final_result",
                include_in_evidence=False,
            )
        ],
    )


def error_artifact(
    *,
    scenario: str,
    error: Exception,
) -> dict[str, Any]:
    artifact_type = {
        "cloud-reclaim-prepare": PLAN_ARTIFACT_TYPE,
        "cloud-reclaim-finalize": RESULT_ARTIFACT_TYPE,
        "render-report": REPORT_ARTIFACT_TYPE,
    }.get(scenario, RESULT_ARTIFACT_TYPE)
    reason = (
        error.reason_code
        if isinstance(error, ReclaimPipelineError)
        else "ARTIFACT_INVALID"
        if isinstance(error, ArtifactContractError)
        else "WORKFLOW_FAILED"
    )
    artifact = {
        "schema_version": "1.1",
        "script_version": SCRIPT_VERSION,
        "domain": "workflow",
        "scenario": scenario,
        "status": "error",
        "generated_at": utc_now(),
        "summary": {"decision": "workflow_failed", "write_performed": False},
        "artifacts": {},
        "warnings": [],
        "errors": [str(error)],
    }
    annotate_outcome(
        artifact,
        complete=False,
        reason_code=reason,
        next_action="STOP",
    )
    return add_provenance(
        artifact,
        artifact_type=artifact_type,
        producer_script=PRODUCER_SCRIPT,
        producer_version=SCRIPT_VERSION,
        run_id=str(uuid.uuid4()),
        stage="failed",
        parents=[],
    )
