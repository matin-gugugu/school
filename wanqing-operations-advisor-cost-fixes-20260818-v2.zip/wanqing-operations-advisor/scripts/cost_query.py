#!/usr/bin/env python3
"""Cloud billing query and cross-domain evidence validation."""

from __future__ import annotations

import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from cost_metrics import COST_UNIT, non_negative_decimal, json_number
from model_contract import (
    ModelContractError,
    load_model_resolution,
    validate_embedded_model_resolution,
)
from runtime import query_or_fixture, utc_now


TABLE = "wanqing_data.ai_infra_billing_project_usage_bill_day"
SCHEMA_VERSION = "1.0"
SCRIPT_VERSION = "1.0.1"
BILLABLE_RULE_VERSION = "1.0"
BILLABLE_DEMOTION_TYPES = ("Capacity", "Load", "Proactive", "Token")
EXCLUDED_EXACT_MODELS = ("kimi-k2-instruct-0905", "gemma-3-27b-it")
EXCLUDED_MODEL_FRAGMENTS = (
    "langbridge",
    "flicker",
    "private",
    "kat",
    "dataagent",
)


class CostQueryError(ValueError):
    """Raised when cost query input or output violates the contract."""


def sql_string(value: str) -> str:
    return "'" + value.replace("\\", "\\\\").replace("'", "\\'") + "'"


def sql_array(values: list[str] | tuple[str, ...]) -> str:
    return "[" + ", ".join(sql_string(value) for value in values) + "]"


def build_cloud_daily_cost_sql(
    *,
    models: list[str],
    from_epoch_seconds: int,
    to_epoch_seconds: int,
    timezone_name: str,
) -> str:
    if not models:
        raise CostQueryError("至少提供一个精确模型")
    from_ms = from_epoch_seconds * 1000
    to_ms = to_epoch_seconds * 1000
    timezone_sql = sql_string(timezone_name)
    billable = (
        "x_ks_model_demotion_type IN "
        f"{sql_array(BILLABLE_DEMOTION_TYPES)} OR provider IN ('公共云')"
    )
    exclusions = "\n    ".join(
        [
            "AND llm_model NOT LIKE '%langbridge%'",
            "AND llm_model NOT IN " + sql_array(EXCLUDED_EXACT_MODELS),
            "AND llm_model NOT LIKE '%flicker%'",
            "AND llm_model NOT LIKE '%private%'",
            "AND llm_model NOT LIKE '%kat%'",
            "AND llm_model NOT LIKE '%dataagent%'",
        ]
    )
    return f"""SELECT
    data_day,
    llm_model AS model_name,
    SUM(
        CASE WHEN {billable}
        THEN detail_true_usage_cost ELSE NULL END
    ) AS billable_usage_cost,
    SUM(
        CASE WHEN {billable}
        THEN detail_source_record_count ELSE 0 END
    ) AS billable_record_count,
    SUM(detail_source_record_count) AS source_record_count,
    max(detail_latest_data_time_ms) AS latest_data_time_ms
FROM (
    SELECT
        toDate(toDateTime(data_time / 1000, {timezone_sql}), {timezone_sql}) AS data_day,
        CASE
            WHEN wq_request_schedule_priority IN ('Sheddable') THEN '离线场景'
            ELSE '在线场景'
        END AS priority_scene,
        llm_model,
        provider,
        x_ks_model_demotion_type,
        SUM(true_usage_cost) AS detail_true_usage_cost,
        count() AS detail_source_record_count,
        max(data_time) AS detail_latest_data_time_ms
    FROM {TABLE}
    WHERE
        data_time >= {from_ms}
        AND data_time < {to_ms}
        AND llm_model IN {sql_array(models)}
    GROUP BY
        data_day,
        llm_model,
        priority_scene,
        service_tree_node_path,
        x_ks_model_demotion_type,
        provider
) AS billing_detail
WHERE
    priority_scene IN ('在线场景')
    {exclusions}
GROUP BY data_day, model_name
ORDER BY billable_usage_cost DESC, model_name"""


def _load_object(path_value: str | Path) -> tuple[Path, dict[str, Any]]:
    path = Path(path_value).expanduser().resolve()
    with path.open(encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise CostQueryError(f"Artifact 必须是 JSON 对象：{path}")
    return path, value


def validate_cross_domain_inputs(
    model_artifacts: list[str],
    headroom_artifacts: list[str],
) -> dict[str, Any]:
    if not model_artifacts or len(model_artifacts) > 20:
        raise CostQueryError("capacity-model-artifact 必须提供 1～20 个")
    if len(model_artifacts) != len(headroom_artifacts):
        raise CostQueryError("模型 Artifact 与 headroom Artifact 数量必须一致")

    models: list[str] = []
    model_evidence: list[dict[str, Any]] = []
    resolved_model_paths: list[str] = []
    resolved_headroom_paths: list[str] = []
    shared_window: dict[str, Any] | None = None
    for index, (model_value, headroom_value) in enumerate(
        zip(model_artifacts, headroom_artifacts)
    ):
        model_path = Path(model_value).expanduser().resolve()
        try:
            verified = load_model_resolution(
                model_path,
                expected_domain="capacity",
                allowed_scenarios={"cloud-reclaim"},
            )
        except ModelContractError as exc:
            raise CostQueryError(str(exc)) from exc
        headroom_path, headroom = _load_object(headroom_value)
        if (
            headroom.get("domain") != "capacity"
            or headroom.get("scenario") != "query-headroom"
            or headroom.get("status") != "success"
        ):
            raise CostQueryError(
                f"headroom[{index}] 必须是成功的 capacity/query-headroom Artifact"
            )
        query = headroom.get("query")
        if not isinstance(query, dict):
            raise CostQueryError(f"headroom[{index}] 缺少 query")
        try:
            validate_embedded_model_resolution(
                query.get("model_resolution"),
                expected_model=verified.model,
                expected_domain="capacity",
                expected_scenario="cloud-reclaim",
                expected_artifact=model_path,
                field=f"headroom[{index}].query.model_resolution",
            )
        except ModelContractError as exc:
            raise CostQueryError(str(exc)) from exc
        filters = query.get("filters")
        window = query.get("window_epoch_seconds")
        if not isinstance(filters, dict) or not isinstance(window, dict):
            raise CostQueryError(f"headroom[{index}] 缺少过滤或窗口语义")
        if (
            filters.get("model") != verified.model
            or filters.get("providers") != ["public"]
            or filters.get("provider_scope") != "cloud"
            or filters.get("priority") != "在线"
        ):
            raise CostQueryError(f"headroom[{index}] 不是云上在线容量证据")
        current_window = {
            "from_epoch_seconds": window.get("from_exclusive"),
            "to_epoch_seconds": window.get("to_exclusive"),
            "timezone": window.get("timezone"),
            "relation": window.get("relation"),
        }
        if shared_window is None:
            shared_window = current_window
        elif current_window != shared_window:
            raise CostQueryError("所有 headroom Artifact 必须使用同一个前一天窗口")
        models.append(verified.model)
        resolved_model_paths.append(str(model_path))
        resolved_headroom_paths.append(str(headroom_path))
        model_evidence.append(
            {
                **verified.evidence,
                "handoff_usage": "cloud_reclaim_cost_estimation",
                "consumer_domain": "cost",
                "consumer_scenario": "cloud-daily-billing",
                "headroom_artifact": str(headroom_path),
            }
        )

    if len(set(models)) != len(models):
        raise CostQueryError("成本查询模型不得重复")
    assert shared_window is not None
    from_ts = shared_window["from_epoch_seconds"]
    to_ts = shared_window["to_epoch_seconds"]
    timezone_name = shared_window["timezone"]
    if (
        isinstance(from_ts, bool)
        or not isinstance(from_ts, int)
        or isinstance(to_ts, bool)
        or not isinstance(to_ts, int)
        or from_ts >= to_ts
        or shared_window["relation"] != "previous_day"
        or not isinstance(timezone_name, str)
        or not timezone_name
    ):
        raise CostQueryError("headroom 的 previous_day 窗口无效")
    try:
        timezone_value = ZoneInfo(timezone_name)
    except ZoneInfoNotFoundError as exc:
        raise CostQueryError(f"timezone 无效：{timezone_name}") from exc
    start = datetime.fromtimestamp(from_ts, timezone_value)
    end = datetime.fromtimestamp(to_ts, timezone_value)
    if (
        any((start.hour, start.minute, start.second, start.microsecond))
        or any((end.hour, end.minute, end.second, end.microsecond))
        or end.date() - start.date() != timedelta(days=1)
    ):
        raise CostQueryError("成本窗口必须是业务时区前一完整自然日")
    return {
        "models": models,
        "model_artifacts": resolved_model_paths,
        "headroom_artifacts": resolved_headroom_paths,
        "model_resolution": model_evidence,
        "window": shared_window,
        "data_day": start.date().isoformat(),
    }


def _non_negative_int(value: Any, field: str) -> int:
    if isinstance(value, bool):
        raise CostQueryError(f"{field} 必须是非负整数")
    try:
        number = int(value)
    except (TypeError, ValueError) as exc:
        raise CostQueryError(f"{field} 必须是非负整数") from exc
    if number < 0 or str(number) != str(value).strip():
        if not isinstance(value, int):
            raise CostQueryError(f"{field} 必须是非负整数")
    return number


def normalize_cost_result(
    result: dict[str, Any],
    *,
    models: list[str],
    data_day: str,
) -> tuple[list[dict[str, Any]], list[str]]:
    rows = result.get("data")
    if not isinstance(rows, list):
        raise CostQueryError("ClickHouse 结果缺少 data 数组")
    indexed: dict[str, dict[str, Any]] = {}
    for index, row in enumerate(rows):
        if not isinstance(row, dict):
            raise CostQueryError(f"data[{index}] 必须是对象")
        model = str(row.get("model_name", "")).strip()
        if model not in models or model in indexed:
            raise CostQueryError("成本查询返回了计划外或重复模型")
        if str(row.get("data_day")) != data_day:
            raise CostQueryError(f"data[{index}].data_day 与查询窗口不一致")
        raw_cost = row.get("billable_usage_cost")
        if raw_cost is None:
            continue
        cost = non_negative_decimal(raw_cost, f"data[{index}].billable_usage_cost")
        indexed[model] = {
            "model_name": model,
            "status": "success",
            "billable_usage_cost": json_number(cost),
            "billable_record_count": _non_negative_int(
                row.get("billable_record_count", 0),
                f"data[{index}].billable_record_count",
            ),
            "source_record_count": _non_negative_int(
                row.get("source_record_count", 0),
                f"data[{index}].source_record_count",
            ),
            "latest_data_time_ms": row.get("latest_data_time_ms"),
            "cost_unit": COST_UNIT,
        }
    normalized: list[dict[str, Any]] = []
    missing: list[str] = []
    for model in models:
        if model in indexed:
            normalized.append(indexed[model])
        else:
            missing.append(model)
            normalized.append(
                {
                    "model_name": model,
                    "status": "partial",
                    "billable_usage_cost": None,
                    "billable_record_count": 0,
                    "source_record_count": 0,
                    "latest_data_time_ms": None,
                    "cost_unit": COST_UNIT,
                    "reason_code": "NO_ROWS",
                }
            )
    return normalized, missing


def query_cloud_daily_cost(args: Any) -> dict[str, Any]:
    if not 1 <= args.timeout <= 600:
        raise CostQueryError("timeout 必须在 1～600 秒之间")
    contract = validate_cross_domain_inputs(
        list(args.capacity_model_artifact or []),
        list(args.headroom_artifact or []),
    )
    window = contract["window"]
    sql = build_cloud_daily_cost_sql(
        models=contract["models"],
        from_epoch_seconds=window["from_epoch_seconds"],
        to_epoch_seconds=window["to_epoch_seconds"],
        timezone_name=window["timezone"],
    )
    result = query_or_fixture(sql, args.timeout, args.fixture)
    rows, missing = normalize_cost_result(
        result,
        models=contract["models"],
        data_day=contract["data_day"],
    )
    status = "success" if not missing else "partial"
    warnings = (
        []
        if not missing
        else ["前一天云上成本无返回记录：" + ", ".join(missing)]
    )
    return {
        "schema_version": SCHEMA_VERSION,
        "script_version": SCRIPT_VERSION,
        "domain": "cost",
        "scenario": "cloud-daily-billing",
        "status": status,
        "generated_at": utc_now(),
        "query": {
            "table": TABLE,
            "models": contract["models"],
            "capacity_model_artifacts": contract["model_artifacts"],
            "data_day": contract["data_day"],
            "window": window,
            "priority_scene": "在线场景",
            "online_definition": "Sheddable=离线场景；其他值=在线场景",
            "billable_rule": (
                "x_ks_model_demotion_type in "
                "(Capacity, Load, Proactive, Token) OR provider=公共云"
            ),
            "billable_rule_version": BILLABLE_RULE_VERSION,
            "excluded_exact_models": list(EXCLUDED_EXACT_MODELS),
            "excluded_model_fragments": list(EXCLUDED_MODEL_FRAGMENTS),
            "model_resolution": contract["model_resolution"],
            "headroom_artifacts": contract["headroom_artifacts"],
            "source": "fixture" if args.fixture else "clickhouse",
            "sql": sql,
        },
        "summary": {
            "decision": (
                "cloud_daily_billing_ready"
                if status == "success"
                else "cloud_daily_billing_incomplete"
            ),
            "data_day": contract["data_day"],
            "models": rows,
            "model_count": len(rows),
            "successful_model_count": len(rows) - len(missing),
            "missing_models": missing,
            "cost_unit": COST_UNIT,
            "write_performed": False,
        },
        "handoffs": {
            "cloud_reclaim_cost": {
                "status": "ready" if status == "success" else "partial",
                "data_day": contract["data_day"],
                "cost_unit": COST_UNIT,
                "models": rows,
            }
        },
        "evidence": {
            "clickhouse_meta": result.get("meta", []),
            "row_count": result.get("rows", len(result.get("data", []))),
            "statistics": result.get("statistics"),
        },
        "warnings": warnings,
        "errors": [],
    }
