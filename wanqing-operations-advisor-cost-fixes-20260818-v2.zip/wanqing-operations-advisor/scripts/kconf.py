#!/usr/bin/env python3
"""Normalize Agent-side KConf results into capacity Artifacts."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Any

from artifact_contract import annotate_outcome, terminal_brief
from capacity_workflow_contract import parse_named_selections
from model_contract import resolve_single_model
from runtime import utc_now, write_artifact


SCHEMA_VERSION = "1.0"
SCRIPT_VERSION = "1.4.0"
EXPECTED_SOURCE_TOOL = "kconf_single_config_data"
SCENARIO = "kconf-single-instance-capacity"
ONLINE_SCENE = "online"
NORMALIZED_SOURCE = "normalizedCapacities"
ORDINARY_SOURCE = "capacities"
CAPACITY_CONFIG_KEY = "cloud.llmdevops.stability-capacity-by-instance"
CAPACITY_CONFIG_STAGE = "production"
DEFAULT_MAX_WORKERS = 4
MAX_MAX_WORKERS = 8


class KconfError(ValueError):
    """Raised when KConf evidence cannot be safely consumed."""


def mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def bounded_text(value: Any, field: str, *, maximum: int = 512) -> str:
    normalized = value.strip() if isinstance(value, str) else ""
    if not normalized:
        raise KconfError(f"{field} 不能为空")
    if len(normalized) > maximum:
        raise KconfError(f"{field} 长度不能超过 {maximum}")
    if any(ord(character) < 32 for character in normalized):
        raise KconfError(f"{field} 不能包含控制字符")
    return normalized


def positive_number(value: Any, field: str) -> int | float:
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(float(value))
        or float(value) <= 0
    ):
        raise KconfError(f"{field} 必须是大于 0 的有限数字")
    return value


def config_version(value: Any, field: str = "KConf handoff.version") -> int | str:
    if isinstance(value, bool):
        raise KconfError(
            f"{field} 必须是非负整数或非空字符串"
        )
    if isinstance(value, int) and value >= 0:
        return value
    if isinstance(value, str) and value.strip():
        return value.strip()
    raise KconfError(
        f"{field} 必须是非负整数或非空字符串"
    )


def timestamp(value: Any, field: str) -> str:
    normalized = bounded_text(value, field)
    try:
        parsed = datetime.fromisoformat(normalized.replace("Z", "+00:00"))
    except ValueError as exc:
        raise KconfError(f"{field} 必须是 ISO 8601 时间") from exc
    if parsed.tzinfo is None:
        raise KconfError(f"{field} 必须包含时区")
    return normalized


def optional_device_type(value: Any, field: str) -> str | None:
    if value is None:
        return None
    return bounded_text(value, field, maximum=128).upper()


def response_digest(value: dict[str, Any]) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def load_tool_result(path_value: str | Path) -> dict[str, Any]:
    path = Path(path_value).expanduser().resolve()
    with path.open(encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise KconfError("KConf 工具返回必须是 JSON 对象")
    return value


def validate_tool_result(
    value: dict[str, Any], expected_key: str, expected_stage: str
) -> tuple[int | str, list[Any], list[Any]]:
    if value.get("result") != 1:
        raise KconfError(
            f"KConf 工具返回失败：result={value.get('result')}"
        )
    if value.get("message") != "success":
        raise KconfError(
            f"KConf 工具返回失败：message={value.get('message')}"
        )
    envelope = value.get("data")
    if not isinstance(envelope, dict):
        raise KconfError("KConf 工具返回缺少 data 对象")
    returned_key = bounded_text(envelope.get("key"), "KConf data.key")
    if returned_key != expected_key:
        raise KconfError(
            f"KConf key 不匹配：期望 {expected_key}，实际 {returned_key}"
        )
    returned_stage = bounded_text(
        envelope.get("stage"), "KConf data.stage", maximum=128
    )
    if returned_stage != expected_stage:
        raise KconfError(
            f"KConf stage 不匹配：期望 {expected_stage}，"
            f"实际 {returned_stage}"
        )
    version = config_version(envelope.get("version"), "KConf data.version")
    body = envelope.get("data")
    if not isinstance(body, dict):
        raise KconfError("KConf 工具返回缺少 data.data 对象")
    if NORMALIZED_SOURCE not in body and ORDINARY_SOURCE not in body:
        raise KconfError(
            "KConf data.data 缺少 normalizedCapacities 和 capacities"
        )
    normalized = body.get(NORMALIZED_SOURCE, [])
    ordinary = body.get(ORDINARY_SOURCE, [])
    if normalized is None:
        normalized = []
    if ordinary is None:
        ordinary = []
    if not isinstance(normalized, list):
        raise KconfError("KConf data.data.normalizedCapacities 必须是数组")
    if not isinstance(ordinary, list):
        raise KconfError("KConf data.data.capacities 必须是数组")
    return version, normalized, ordinary


def exact_rows(rows: list[Any], model: str) -> list[dict[str, Any]]:
    return [
        row
        for row in rows
        if isinstance(row, dict)
        and row.get("modelServiceName") == model
        and row.get("scene") == ONLINE_SCENE
    ]


def row_tpm(row: dict[str, Any], field: str) -> int | float:
    return positive_number(row.get("tpm"), field)


def query_evidence(
    response: dict[str, Any],
    *,
    key: str,
    stage: str,
    version: int | str,
    model: str,
    device_type: str | None,
    normalized_count: int,
    ordinary_count: int,
) -> dict[str, Any]:
    return {
        "source_tool": EXPECTED_SOURCE_TOOL,
        "key": key,
        "stage": stage,
        "version": version,
        "model": model,
        "scene": ONLINE_SCENE,
        "requested_device_type": device_type,
        "normalized_row_count": normalized_count,
        "ordinary_row_count": ordinary_count,
        "response_sha256": response_digest(response),
    }


def base_artifact(
    status: str,
    generated_at: str,
    summary: dict[str, Any],
    query: dict[str, Any],
) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "script_version": SCRIPT_VERSION,
        "domain": "capacity",
        "scenario": SCENARIO,
        "status": status,
        "generated_at": generated_at,
        "summary": {**summary, "write_performed": False},
        "query": query,
        "handoffs": {},
        "warnings": [],
        "errors": [],
    }


def selected_artifact(
    *,
    generated_at: str,
    model: str,
    key: str,
    stage: str,
    version: int | str,
    capacity_source: str,
    device_type: str | None,
    capacity_tpm: int | float,
    query: dict[str, Any],
) -> dict[str, Any]:
    selection_rule = (
        "exact_model_online_normalized_first"
        if capacity_source == NORMALIZED_SOURCE
        else (
            "normalized_first_then_exact_device_type"
            if device_type is not None
            else "normalized_first_then_unique_ordinary"
        )
    )
    selectors = [
        f"modelServiceName={model}",
        f"scene={ONLINE_SCENE}",
    ]
    if device_type is not None:
        selectors.append(f"deviceType={device_type}")
    field_path = (
        f"data.data.{capacity_source}[{','.join(selectors)}].tpm"
    )
    handoff = {
        "status": "ready",
        "model": model,
        "provider": "internal",
        "priority": "在线",
        "scene": ONLINE_SCENE,
        "capacity_source": capacity_source,
        "device_type": device_type,
        "selection_rule": selection_rule,
        "key": key,
        "stage": stage,
        "field_path": field_path,
        "single_instance_capacity_tpm": capacity_tpm,
        "version": version,
        "retrieved_at": generated_at,
    }
    artifact = base_artifact(
        "success",
        generated_at,
        {
            "decision": "single_instance_capacity_ready",
            **handoff,
        },
        query,
    )
    artifact["handoffs"]["capacity"] = handoff
    return artifact


def device_choices(
    rows: list[dict[str, Any]], model: str
) -> list[dict[str, Any]]:
    choices: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, row in enumerate(rows):
        prefix = f"capacities match[{index}]"
        device_type = optional_device_type(
            row.get("deviceType"), f"{prefix}.deviceType"
        )
        if device_type is None:
            raise KconfError(
                f"{model} 普通在线配置有多条，"
                "但存在缺少 deviceType 的行"
            )
        if device_type in seen:
            raise KconfError(
                f"{model} 普通在线配置的 deviceType={device_type} 不唯一"
            )
        seen.add(device_type)
        choices.append(
            {
                "device_type": device_type,
                "single_instance_capacity_tpm": row_tpm(
                    row, f"{prefix}.tpm"
                ),
            }
        )
    return sorted(choices, key=lambda item: str(item["device_type"]))


def build_artifact(
    response: dict[str, Any],
    *,
    model: str,
    key: str,
    stage: str,
    requested_device_type: str | None,
    retrieved_at: str,
) -> dict[str, Any]:
    model = bounded_text(model, "model", maximum=256)
    key = bounded_text(key, "key")
    stage = bounded_text(stage, "stage", maximum=128)
    if key != CAPACITY_CONFIG_KEY:
        raise KconfError(
            f"单实例容量 KConf key 必须是 {CAPACITY_CONFIG_KEY}"
        )
    if stage != CAPACITY_CONFIG_STAGE:
        raise KconfError(
            f"单实例容量 KConf stage 必须是 {CAPACITY_CONFIG_STAGE}"
        )
    device_type = optional_device_type(
        requested_device_type, "device-type"
    )
    retrieved_at = timestamp(retrieved_at, "retrieved-at")
    version, normalized_rows, ordinary_rows = validate_tool_result(
        response, key, stage
    )
    normalized_matches = exact_rows(normalized_rows, model)
    ordinary_matches = exact_rows(ordinary_rows, model)
    query = query_evidence(
        response,
        key=key,
        stage=stage,
        version=version,
        model=model,
        device_type=device_type,
        normalized_count=len(normalized_matches),
        ordinary_count=len(ordinary_matches),
    )

    if len(normalized_matches) > 1:
        raise KconfError(
            f"{model} 存在多条 normalizedCapacities 在线配置"
        )
    if len(normalized_matches) == 1:
        return selected_artifact(
            generated_at=retrieved_at,
            model=model,
            key=key,
            stage=stage,
            version=version,
            capacity_source=NORMALIZED_SOURCE,
            device_type=None,
            capacity_tpm=row_tpm(
                normalized_matches[0], "normalizedCapacities match.tpm"
            ),
            query=query,
        )

    if not ordinary_matches:
        artifact = base_artifact(
            "partial",
            retrieved_at,
            {
                "decision": "single_instance_capacity_not_found",
                "model": model,
                "scene": ONLINE_SCENE,
            },
            query,
        )
        artifact["warnings"] = [
            f"未找到 {model} 的归一化或普通在线单实例容量"
        ]
        return artifact

    if len(ordinary_matches) == 1:
        row = ordinary_matches[0]
        row_device_type = optional_device_type(
            row.get("deviceType"), "capacities match.deviceType"
        )
        if (
            device_type is not None
            and row_device_type is not None
            and row_device_type != device_type
        ):
            choices = device_choices(ordinary_matches, model)
            artifact = base_artifact(
                "partial",
                retrieved_at,
                {
                    "decision": "device_type_not_found",
                    "model": model,
                    "scene": ONLINE_SCENE,
                    "requested_device_type": device_type,
                    "available_device_types": choices,
                },
                query,
            )
            artifact["warnings"] = [
                f"{model} 普通在线配置不包含 deviceType={device_type}"
            ]
            return artifact
        return selected_artifact(
            generated_at=retrieved_at,
            model=model,
            key=key,
            stage=stage,
            version=version,
            capacity_source=ORDINARY_SOURCE,
            device_type=row_device_type,
            capacity_tpm=row_tpm(row, "capacities match.tpm"),
            query=query,
        )

    choices = device_choices(ordinary_matches, model)
    if device_type is None:
        artifact = base_artifact(
            "partial",
            retrieved_at,
            {
                "decision": "device_type_required",
                "model": model,
                "scene": ONLINE_SCENE,
                "capacity_source": ORDINARY_SOURCE,
                "available_device_types": choices,
            },
            query,
        )
        artifact["warnings"] = [
            f"{model} 普通在线配置存在多个 deviceType，"
            "需要用户明确承载卡型"
        ]
        return artifact

    selected = [
        row
        for row in ordinary_matches
        if optional_device_type(
            row.get("deviceType"), "capacities match.deviceType"
        )
        == device_type
    ]
    if len(selected) != 1:
        artifact = base_artifact(
            "partial",
            retrieved_at,
            {
                "decision": "device_type_not_found",
                "model": model,
                "scene": ONLINE_SCENE,
                "requested_device_type": device_type,
                "available_device_types": choices,
            },
            query,
        )
        artifact["warnings"] = [
            f"{model} 普通在线配置不包含 deviceType={device_type}"
        ]
        return artifact
    return selected_artifact(
        generated_at=retrieved_at,
        model=model,
        key=key,
        stage=stage,
        version=version,
        capacity_source=ORDINARY_SOURCE,
        device_type=device_type,
        capacity_tpm=row_tpm(
            selected[0], f"capacities[{device_type}].tpm"
        ),
        query=query,
    )


def load_capacity_handoff(
    path_value: str | Path, expected_model: str
) -> dict[str, Any]:
    """Load a normalized Agent-tool Artifact for capacity calculations."""

    path = Path(path_value).expanduser().resolve()
    with path.open(encoding="utf-8") as handle:
        artifact = json.load(handle)
    if not isinstance(artifact, dict):
        raise KconfError("KConf Artifact 必须是 JSON 对象")
    if artifact.get("domain") != "capacity":
        raise KconfError("KConf Artifact 的 domain 必须是 capacity")
    if artifact.get("scenario") != SCENARIO:
        raise KconfError(
            "KConf Artifact 的 scenario 必须是 "
            "kconf-single-instance-capacity"
        )
    if artifact.get("status") != "success":
        raise KconfError("KConf Artifact 的 status 必须是 success")

    query = mapping(artifact.get("query"))
    source_tool = bounded_text(
        query.get("source_tool"), "KConf query.source_tool"
    )
    if source_tool != EXPECTED_SOURCE_TOOL:
        raise KconfError(
            "KConf Artifact 的 source_tool 必须是 "
            f"{EXPECTED_SOURCE_TOOL}"
        )

    handoff = mapping(mapping(artifact.get("handoffs")).get("capacity"))
    if handoff.get("status") != "ready":
        raise KconfError("KConf Artifact 的 capacity 交接尚未 ready")
    model = bounded_text(
        handoff.get("model"), "KConf handoff.model", maximum=256
    )
    if model != expected_model:
        raise KconfError(
            f"KConf Artifact 模型不匹配：期望 {expected_model}，实际 {model}"
        )
    provider = bounded_text(
        handoff.get("provider"), "KConf handoff.provider", maximum=64
    )
    if provider != "internal":
        raise KconfError("KConf Artifact 的 provider 必须是 internal")
    priority = bounded_text(
        handoff.get("priority"), "KConf handoff.priority", maximum=64
    )
    if priority != "在线":
        raise KconfError("KConf Artifact 的 priority 必须是在线")

    scene = bounded_text(
        handoff.get("scene"), "KConf handoff.scene", maximum=64
    )
    if scene != ONLINE_SCENE:
        raise KconfError("KConf Artifact 的 scene 必须是 online")
    capacity_source = bounded_text(
        handoff.get("capacity_source"),
        "KConf handoff.capacity_source",
        maximum=64,
    )
    if capacity_source not in {NORMALIZED_SOURCE, ORDINARY_SOURCE}:
        raise KconfError(
            "KConf Artifact 的 capacity_source 必须是 "
            "normalizedCapacities 或 capacities"
        )
    device_type = optional_device_type(
        handoff.get("device_type"), "KConf handoff.device_type"
    )
    if capacity_source == NORMALIZED_SOURCE and device_type is not None:
        raise KconfError(
            "normalizedCapacities Artifact 的 device_type 必须为 null"
        )
    selection_rule = bounded_text(
        handoff.get("selection_rule"),
        "KConf handoff.selection_rule",
    )
    expected_selection_rule = (
        "exact_model_online_normalized_first"
        if capacity_source == NORMALIZED_SOURCE
        else (
            "normalized_first_then_exact_device_type"
            if device_type is not None
            else "normalized_first_then_unique_ordinary"
        )
    )
    if selection_rule != expected_selection_rule:
        raise KconfError(
            "KConf Artifact 的 selection_rule 与配置来源或卡型不一致"
        )
    key = bounded_text(handoff.get("key"), "KConf handoff.key")
    if key != CAPACITY_CONFIG_KEY:
        raise KconfError(
            f"KConf Artifact 的 key 必须是 {CAPACITY_CONFIG_KEY}"
        )
    stage = bounded_text(
        handoff.get("stage"), "KConf handoff.stage", maximum=128
    )
    if stage != CAPACITY_CONFIG_STAGE:
        raise KconfError(
            f"KConf Artifact 的 stage 必须是 {CAPACITY_CONFIG_STAGE}"
        )
    field_path = bounded_text(
        handoff.get("field_path"), "KConf handoff.field_path"
    )
    if (
        not field_path.startswith(f"data.data.{capacity_source}[")
        or not field_path.endswith("].tpm")
    ):
        raise KconfError(
            "KConf Artifact 的 field_path 与 capacity_source 不一致"
        )

    return {
        "model": model,
        "provider": provider,
        "priority": priority,
        "scene": scene,
        "capacity_source": capacity_source,
        "device_type": device_type,
        "selection_rule": selection_rule,
        "key": key,
        "stage": stage,
        "field_path": field_path,
        "single_instance_capacity_tpm": positive_number(
            handoff.get("single_instance_capacity_tpm"),
            "KConf handoff.single_instance_capacity_tpm",
        ),
        "version": config_version(handoff.get("version")),
        "retrieved_at": timestamp(
            handoff.get("retrieved_at"), "KConf handoff.retrieved_at"
        ),
        "source_tool": source_tool,
        "artifact": str(path),
    }


def validate_max_workers(value: int) -> int:
    if not 1 <= value <= MAX_MAX_WORKERS:
        raise KconfError(
            f"max-workers 必须在 1～{MAX_MAX_WORKERS} 之间"
        )
    return value


def normalize_batch(args: argparse.Namespace) -> dict[str, Any]:
    max_workers = validate_max_workers(args.max_workers)
    if not args.model_artifact:
        raise KconfError("至少提供一个 --model-artifact")
    verified_models = [
        resolve_single_model(
            artifact_path=artifact_path,
            raw_model=None,
            expected_domain="capacity",
            allowed_scenarios={"headroom", "cloud-reclaim"},
        )
        for artifact_path in args.model_artifact
    ]
    models = [verified.model for verified in verified_models]
    if len(set(models)) != len(models):
        raise KconfError("批量模型不得重复")
    try:
        device_type_selections = parse_named_selections(
            args.device_type_selection,
            option_name="device-type-selection",
        )
    except ValueError as exc:
        raise KconfError(str(exc)) from exc
    unknown_models = sorted(set(device_type_selections) - set(models))
    if unknown_models:
        raise KconfError(
            "device-type-selection 的模型不在当前批次："
            + ", ".join(unknown_models)
        )
    if args.device_type and device_type_selections:
        raise KconfError(
            "--device-type 与 --device-type-selection 不得同时使用"
        )

    response = load_tool_result(args.input)
    generated_at = utc_now()
    output_dir = Path(args.output_dir).expanduser().resolve()

    def normalize_one(index: int) -> tuple[int, dict[str, Any], Path]:
        verified = verified_models[index]
        try:
            artifact = build_artifact(
                response,
                model=verified.model,
                key=args.key,
                stage=args.stage,
                requested_device_type=(
                    device_type_selections.get(verified.model)
                    or args.device_type
                ),
                retrieved_at=generated_at,
            )
            artifact["query"]["model_resolution"] = verified.evidence
            artifact["query"]["batch"] = {
                "enabled": True,
                "model_index": index,
                "model_count": len(models),
                "shared_tool_result": True,
            }
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            artifact = base_artifact(
                "error",
                generated_at,
                {
                    "decision": "query_result_normalization_failed",
                    "model": verified.model,
                },
                {
                    "source_tool": EXPECTED_SOURCE_TOOL,
                    "key": str(args.key),
                    "stage": str(args.stage),
                    "model_resolution": verified.evidence,
                    "batch": {
                        "enabled": True,
                        "model_index": index,
                        "model_count": len(models),
                        "shared_tool_result": True,
                    },
                },
            )
            artifact["errors"] = [str(exc)]
        output_path = output_dir / f"kconf-{index + 1:03d}.json"
        write_artifact(str(output_path), artifact)
        return index, artifact, output_path

    completed_by_index: dict[int, tuple[dict[str, Any], Path]] = {}
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(normalize_one, index): index
            for index in range(len(models))
        }
        for future in as_completed(futures):
            index, artifact, output_path = future.result()
            completed_by_index[index] = (artifact, output_path)

    statuses: list[str] = []
    items: list[dict[str, Any]] = []
    warnings: list[str] = []
    errors: list[str] = []
    for index, model in enumerate(models):
        artifact, output_path = completed_by_index[index]
        status = str(artifact.get("status", "error"))
        statuses.append(status)
        items.append(
            {
                "index": index,
                "model": model,
                "status": status,
                "artifact": str(output_path),
                "summary": artifact.get("summary", {}),
            }
        )
        warnings.extend(
            f"{model}: {item}"
            for item in artifact.get("warnings", [])
            if isinstance(item, str)
        )
        errors.extend(
            f"{model}: {item}"
            for item in artifact.get("errors", [])
            if isinstance(item, str)
        )
    if all(status == "success" for status in statuses):
        status = "success"
    elif all(status == "error" for status in statuses):
        status = "error"
    else:
        status = "partial"
    return {
        "schema_version": SCHEMA_VERSION,
        "script_version": SCRIPT_VERSION,
        "domain": "capacity",
        "scenario": "kconf-normalize-batch",
        "status": status,
        "generated_at": generated_at,
        "summary": {
            "decision": "batch_normalization_completed",
            "models": models,
            "model_count": len(models),
            "successful_model_count": statuses.count("success"),
            "partial_model_count": statuses.count("partial"),
            "failed_model_count": statuses.count("error"),
            "max_workers": max_workers,
            "shared_tool_result": True,
            "write_performed": False,
        },
        "artifacts": {"kconf": items},
        "query": {
            "source_tool": EXPECTED_SOURCE_TOOL,
            "input": str(Path(args.input).expanduser().resolve()),
            "key": args.key,
            "stage": args.stage,
            "response_sha256": response_digest(response),
            "device_type_selections": device_type_selections,
        },
        "warnings": warnings,
        "errors": errors,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="将 kconf_single_config_data 返回规范化为容量 Artifact"
    )
    commands = parser.add_subparsers(dest="command", required=True)
    normalize = commands.add_parser("normalize")
    normalize.add_argument("--input", required=True, help="Agent 工具返回 JSON")
    normalize.add_argument(
        "--model-artifact",
        help="成功的容量域 model-resolution Artifact；生产规范化必填",
    )
    normalize.add_argument(
        "--model",
        help="可选精确模型名；提供时必须与 --model-artifact 一致",
    )
    normalize.add_argument("--key", required=True, help="请求使用的 KConf key")
    normalize.add_argument("--stage", required=True, help="请求使用的 stage")
    normalize.add_argument(
        "--device-type",
        help="普通配置多卡型时，用户明确的承载卡型",
    )
    normalize.add_argument("--output", required=True, help="结果 Artifact 路径")
    normalize_batch_parser = commands.add_parser(
        "normalize-batch",
        help="复用同一份 key+stage 工具结果规范化多个模型",
    )
    normalize_batch_parser.add_argument(
        "--input", required=True, help="单次 Agent 工具返回 JSON"
    )
    normalize_batch_parser.add_argument(
        "--model-artifact",
        action="append",
        required=True,
        help="成功的容量域 model-resolution Artifact；按顺序重复传入",
    )
    normalize_batch_parser.add_argument(
        "--key", required=True, help="请求使用的 KConf key"
    )
    normalize_batch_parser.add_argument(
        "--stage", required=True, help="请求使用的 stage"
    )
    normalize_batch_parser.add_argument(
        "--device-type",
        help="可选的整批普通配置承载卡型；多卡型未指定时逐模型返回 partial",
    )
    normalize_batch_parser.add_argument(
        "--device-type-selection",
        action="append",
        default=[],
        help="可选的逐模型承载卡型，格式 MODEL=DEVICE，可重复传入",
    )
    normalize_batch_parser.add_argument(
        "--max-workers",
        type=int,
        default=DEFAULT_MAX_WORKERS,
        help=(
            f"最大并发规范化任务数，默认 {DEFAULT_MAX_WORKERS}，"
            f"上限 {MAX_MAX_WORKERS}"
        ),
    )
    normalize_batch_parser.add_argument(
        "--output-dir", required=True, help="逐模型 Artifact 输出目录"
    )
    normalize_batch_parser.add_argument(
        "--output", required=True, help="批量 Manifest 路径"
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    generated_at = utc_now()
    model = str(getattr(args, "model", None) or "")
    try:
        if args.command == "normalize-batch":
            artifact = normalize_batch(args)
        else:
            verified_model = resolve_single_model(
                artifact_path=args.model_artifact,
                raw_model=args.model,
                expected_domain="capacity",
                allowed_scenarios={"headroom", "cloud-reclaim"},
            )
            model = verified_model.model
            response = load_tool_result(args.input)
            artifact = build_artifact(
                response,
                model=model,
                key=args.key,
                stage=args.stage,
                requested_device_type=args.device_type,
                retrieved_at=generated_at,
            )
            artifact["query"]["model_resolution"] = verified_model.evidence
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        artifact = base_artifact(
            "error",
            generated_at,
            {
                "decision": "query_result_normalization_failed",
                "model": model or None,
            },
            {
                "source_tool": EXPECTED_SOURCE_TOOL,
                "key": str(args.key),
                "stage": str(args.stage),
            },
        )
        artifact["errors"] = [str(exc)]
    annotate_outcome(artifact)
    try:
        output = write_artifact(args.output, artifact)
    except OSError as exc:
        print(
            json.dumps(
                {"status": "error", "error": str(exc)},
                ensure_ascii=False,
            )
        )
        return 1
    print(json.dumps(terminal_brief(artifact, output), ensure_ascii=False))
    return 0 if artifact["status"] in {"success", "partial"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
