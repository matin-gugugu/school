#!/usr/bin/env python3
"""Low-freedom orchestration for capacity analysis scenarios."""

from __future__ import annotations

import argparse
import copy
import json
import math
import sys
import uuid
from pathlib import Path
from typing import Any

from artifact_contract import (
    ArtifactContractError,
    add_provenance,
    annotate_outcome,
    artifact_reference,
    reason_code_for,
    validate_provenance,
)
from capacity_workflow_contract import (
    DEFAULT_LOOKBACK,
    DEFAULT_REQUEST_SCHEMA_VERSION,
    DETAIL_LEVELS,
    MAX_MODELS_PER_TASK,
    MAX_TOTAL_MODEL_INPUTS,
    PROVIDER_SCOPES,
    REQUEST_SCHEMA_VERSION,
    SCENARIOS,
    parse_indexed_selections,
    parse_named_selections,
    validate_request_schema,
)
from capacity_report import build_report_tasks
from capacity_evidence_contract import validate_capacity_evidence_semantics
from capacity_workflow_support import (
    WorkflowArtifactSupport,
    attach_evidence_id,
    build_isvc_batch_command,
    build_kconf_batch_command,
    parent_references,
    provenance_paths_by_role,
    validate_kconf_next_action,
    validate_evidence_id_binding,
    validate_parent_path_bindings,
)
from model_contract import (
    CAPACITY_QUERY_SOURCES,
    expected_anchor_source,
    load_model_resolution,
    trusted_scope_resolution_artifact,
)
from runtime import utc_now, write_artifact
from top_p_policy import (
    CANDIDATE_MODELS_BY_GPU,
    CANDIDATE_POLICY_SOURCE,
    CANDIDATE_POLICY_VERSION,
    TopPPolicyError,
    default_candidate_models,
    selected_models as policy_selected_models,
)


SCRIPT_VERSION = "1.5.0"
SCRIPT_ROOT = Path(__file__).resolve().parent
CAPACITY_SCRIPT = SCRIPT_ROOT / "capacity.py"
MODEL_RESOLVER_SCRIPT = SCRIPT_ROOT / "model_resolver.py"
KCONF_SCRIPT = SCRIPT_ROOT / "kconf.py"
ISVC_SCRIPT = SCRIPT_ROOT / "isvc.py"
RESOURCE_SCRIPT = SCRIPT_ROOT / "resource.py"

PRODUCER_SCRIPT = "workflow.py"
PLAN_ARTIFACT_TYPE = "wanqing.capacity_analysis.plan"
RESULT_ARTIFACT_TYPE = "wanqing.capacity_analysis.result"
REPORT_ARTIFACT_TYPE = "wanqing.capacity_analysis.report"

KCONF_TOOL = "kconf_single_config_data"
KCONF_KEY = "cloud.llmdevops.stability-capacity-by-instance"
KCONF_STAGE = "production"

class CapacityPipelineError(ValueError):
    """Raised when a capacity workflow cannot continue safely."""

    def __init__(self, message: str, reason_code: str = "INVALID_INPUT") -> None:
        super().__init__(message)
        self.reason_code = reason_code


_artifact_support = WorkflowArtifactSupport(CapacityPipelineError)
load_object = _artifact_support.load_object
run_artifact_command = _artifact_support.run_artifact_command


def add_analyze_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--input", required=True, help="容量分析请求 JSON")
    parser.add_argument("--output-dir", required=True, help="阶段 Artifact 目录")
    parser.add_argument(
        "--candidate-fixture",
        action="append",
        help="仅用于离线测试；按全部任务和模型输入顺序重复传入",
    )
    parser.add_argument("--capacity-fixture", help="仅用于离线测试")
    parser.add_argument("--usage-fixture", help="仅用于离线测试")
    parser.add_argument("--isvc-fixture", help="仅用于离线测试")
    parser.add_argument("--resource-fixture", help="仅用于离线测试")
    parser.add_argument("--isvc-endpoint")
    parser.add_argument("--timeout", type=float, default=30.0)
    parser.add_argument("--isvc-timeout", type=float, default=30.0)
    parser.add_argument("--max-workers", type=int, default=4)
    parser.add_argument("--output", required=True, help="Workflow Artifact")


def add_finalize_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--plan-artifact", required=True)
    parser.add_argument("--kconf-tool-result", required=True)
    parser.add_argument(
        "--device-type",
        help="KConf 普通配置存在多卡型时，由用户确认后提供",
    )
    parser.add_argument(
        "--device-type-selection",
        action="append",
        default=[],
        help="逐模型 KConf 卡型选择，格式 MODEL=DEVICE，可重复传入",
    )
    parser.add_argument("--max-workers", type=int, default=4)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--output", required=True)


def add_report_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--output", required=True)


def validate_runtime_args(args: argparse.Namespace) -> None:
    if not 1 <= args.max_workers <= 8:
        raise CapacityPipelineError("--max-workers 必须在 1～8 之间")
    for field in ("timeout", "isvc_timeout"):
        value = getattr(args, field, None)
        if value is not None and not 1 <= value <= 600:
            raise CapacityPipelineError(f"--{field.replace('_', '-')} 必须在 1～600 秒之间")


def bounded_text(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise CapacityPipelineError(f"{field} 必须是非空字符串")
    result = value.strip()
    if len(result) > 256 or any(ord(character) < 32 for character in result):
        raise CapacityPipelineError(f"{field} 非法")
    return result


def nonnegative_number(value: Any, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise CapacityPipelineError(f"{field} 必须是非负数字")
    result = float(value)
    if not math.isfinite(result) or result < 0:
        raise CapacityPipelineError(f"{field} 必须是非负数字")
    return result


def normalize_model_scope(
    raw: dict[str, Any],
    index: int,
    *,
    scenario: str,
    schema_version: str,
) -> tuple[list[str], dict[str, Any]]:
    raw_model_inputs = raw.get("model_inputs")
    model_inputs: list[str] = []
    if raw_model_inputs is not None:
        if not isinstance(raw_model_inputs, list) or not raw_model_inputs:
            raise CapacityPipelineError(
                f"tasks[{index}].model_inputs 必须是非空数组"
            )
        model_inputs = [
            bounded_text(value, f"tasks[{index}].model_inputs[{position}]")
            for position, value in enumerate(raw_model_inputs)
        ]
        if len(set(model_inputs)) != len(model_inputs):
            raise CapacityPipelineError(
                f"tasks[{index}].model_inputs 不得重复"
            )

    raw_scope = raw.get("model_scope")
    if raw_scope is None:
        if model_inputs:
            return model_inputs, {
                "mode": "explicit_models",
                "selection_source": "user_explicit",
                "models": list(model_inputs),
            }
        if schema_version == REQUEST_SCHEMA_VERSION and scenario == "headroom":
            models = default_candidate_models()
            return models, {
                "mode": "default_candidates",
                "selection_source": "skill_default",
                "policy_source": CANDIDATE_POLICY_SOURCE,
                "policy_version": CANDIDATE_POLICY_VERSION,
                "models": list(models),
            }
        raise CapacityPipelineError(
            f"tasks[{index}].model_inputs 必须是非空数组"
        )

    if schema_version != REQUEST_SCHEMA_VERSION:
        raise CapacityPipelineError(
            f"tasks[{index}].model_scope 仅适用于 schema_version={REQUEST_SCHEMA_VERSION}"
        )
    if scenario != "headroom":
        raise CapacityPipelineError(
            f"tasks[{index}].model_scope 当前只适用于 headroom"
        )
    if not isinstance(raw_scope, dict):
        raise CapacityPipelineError(f"tasks[{index}].model_scope 必须是对象")
    allowed_fields = {"mode", "gpu_type", "top_p"}
    unknown_fields = sorted(set(raw_scope) - allowed_fields)
    if unknown_fields:
        raise CapacityPipelineError(
            f"tasks[{index}].model_scope 包含未知字段 {unknown_fields[0]}"
        )
    mode = raw_scope.get("mode")
    if mode not in {"default_candidates", "gpu_candidates", "explicit_models"}:
        raise CapacityPipelineError(
            f"tasks[{index}].model_scope.mode 必须是 "
            "default_candidates、gpu_candidates 或 explicit_models"
        )
    if mode == "explicit_models":
        extra = sorted(set(raw_scope) - {"mode"})
        if extra:
            raise CapacityPipelineError(
                f"tasks[{index}].model_scope.mode=explicit_models 不接受 {extra[0]}"
            )
        if not model_inputs:
            raise CapacityPipelineError(
                f"tasks[{index}] explicit_models 需要非空 model_inputs"
            )
        return model_inputs, {
            "mode": mode,
            "selection_source": "user_explicit",
            "models": list(model_inputs),
        }
    if model_inputs:
        raise CapacityPipelineError(
            f"tasks[{index}] model_inputs 与候选范围 model_scope 不得同时提供"
        )

    if mode == "default_candidates":
        extra = sorted(set(raw_scope) - {"mode"})
        if extra:
            raise CapacityPipelineError(
                f"tasks[{index}].model_scope.mode=default_candidates 不接受 {extra[0]}"
            )
        models = default_candidate_models()
        return models, {
            "mode": mode,
            "selection_source": "user_explicit_range",
            "policy_source": CANDIDATE_POLICY_SOURCE,
            "policy_version": CANDIDATE_POLICY_VERSION,
            "models": list(models),
        }

    gpu_type = raw_scope.get("gpu_type")
    if not isinstance(gpu_type, str) or gpu_type not in CANDIDATE_MODELS_BY_GPU:
        raise CapacityPipelineError(
            f"tasks[{index}].model_scope.gpu_type 仅支持 X60 或 X40"
        )
    top_p = raw_scope.get("top_p", len(CANDIDATE_MODELS_BY_GPU[gpu_type]))
    try:
        models = policy_selected_models(gpu_type, top_p)
    except TopPPolicyError as exc:
        raise CapacityPipelineError(
            f"tasks[{index}].model_scope：{exc}"
        ) from exc
    return models, {
        "mode": mode,
        "selection_source": "user_explicit_range",
        "policy_source": CANDIDATE_POLICY_SOURCE,
        "policy_version": CANDIDATE_POLICY_VERSION,
        "gpu_type": gpu_type,
        "top_p": top_p,
        "models": list(models),
    }


def normalize_task(
    raw: Any,
    index: int,
    *,
    schema_version: str = DEFAULT_REQUEST_SCHEMA_VERSION,
) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise CapacityPipelineError(f"tasks[{index}] 必须是对象")
    task_id = bounded_text(raw.get("task_id"), f"tasks[{index}].task_id")
    if (
        len(task_id) > 64
        or not task_id[0].isalnum()
        or any(not (character.isalnum() or character in "._-") for character in task_id)
        or ".." in task_id
    ):
        raise CapacityPipelineError(
            f"tasks[{index}].task_id 只允许安全的字母、数字、点、下划线和连字符"
        )
    scenario = bounded_text(raw.get("scenario"), f"tasks[{index}].scenario")
    if scenario not in SCENARIOS:
        raise CapacityPipelineError(
            f"tasks[{index}].scenario 必须是 " + "、".join(sorted(SCENARIOS))
        )
    model_inputs, model_scope = normalize_model_scope(
        raw,
        index,
        scenario=scenario,
        schema_version=schema_version,
    )

    providers_value = raw.get("providers")
    provider_selection_source = "user_explicit"
    if providers_value is None:
        if schema_version == REQUEST_SCHEMA_VERSION and scenario == "headroom":
            providers_value = ["internal"]
            provider_selection_source = "skill_default"
        else:
            raise CapacityPipelineError(f"tasks[{index}].providers 必须是非空数组")
    if not isinstance(providers_value, list) or not providers_value:
        raise CapacityPipelineError(f"tasks[{index}].providers 必须是非空数组")
    providers = [
        bounded_text(value, f"tasks[{index}].providers[{position}]")
        for position, value in enumerate(providers_value)
    ]
    if len(set(providers)) != len(providers):
        raise CapacityPipelineError(f"tasks[{index}].providers 不得重复")
    provider_set = frozenset(providers)
    expected_scope = PROVIDER_SCOPES.get(provider_set)
    if expected_scope is None:
        raise CapacityPipelineError(
            f"tasks[{index}].providers 当前只支持 public、internal 或二者组合"
        )
    provider_scope = raw.get("provider_scope", expected_scope)
    if provider_scope != expected_scope:
        raise CapacityPipelineError(
            f"tasks[{index}].provider_scope 应为 {expected_scope}"
        )
    if raw.get("priority", "在线") != "在线":
        raise CapacityPipelineError(f"tasks[{index}] 当前只支持 priority=在线")

    timezone = bounded_text(
        raw.get("timezone", "Asia/Shanghai"), f"tasks[{index}].timezone"
    )
    relation = raw.get(
        "window_relation",
        "previous_day" if scenario == "headroom" else "current",
    )
    if relation not in {
        "current",
        "custom",
        "previous_day",
        "previous_same_period",
    }:
        raise CapacityPipelineError(f"tasks[{index}].window_relation 非法")
    from_ts = raw.get("from")
    to_ts = raw.get("to")
    lookback = raw.get("lookback_seconds")
    if relation == "current":
        if from_ts is not None or to_ts is not None:
            raise CapacityPipelineError(
                f"tasks[{index}] current 禁止传 from/to"
            )
        if lookback is None:
            lookback = DEFAULT_LOOKBACK.get(scenario)
        if not isinstance(lookback, int) or isinstance(lookback, bool) or lookback < 60:
            raise CapacityPipelineError(
                f"tasks[{index}].lookback_seconds 必须是至少 60 的整数"
            )
    else:
        if lookback is not None:
            raise CapacityPipelineError(
                f"tasks[{index}] 非 current 窗口禁止 lookback_seconds"
            )
        if relation in {"custom", "previous_same_period"}:
            if (
                not isinstance(from_ts, int)
                or isinstance(from_ts, bool)
                or not isinstance(to_ts, int)
                or isinstance(to_ts, bool)
                or from_ts >= to_ts
            ):
                raise CapacityPipelineError(
                    f"tasks[{index}] {relation} 必须提供有效整数 from/to"
                )
        elif from_ts is not None or to_ts is not None:
            raise CapacityPipelineError(
                f"tasks[{index}] previous_day 禁止显式传 from/to"
            )

    incremental = raw.get("incremental_tpm")
    reserve_ratio = raw.get("reserve_ratio", 0)
    detail_level = raw.get(
        "detail_level",
        "decision" if incremental is not None else "headroom",
    )
    resource_artifact = raw.get("resource_artifact")
    try:
        selected_models = parse_indexed_selections(
            raw.get("selected_models", {}),
            field=f"tasks[{index}].selected_models",
            item_count=len(model_inputs),
            text_validator=bounded_text,
        )
        service_selections = parse_indexed_selections(
            raw.get("service_selections", {}),
            field=f"tasks[{index}].service_selections",
            item_count=len(model_inputs),
            text_validator=bounded_text,
        )
    except ValueError as exc:
        raise CapacityPipelineError(str(exc)) from exc
    if model_scope["mode"] != "explicit_models" and selected_models:
        raise CapacityPipelineError(
            f"tasks[{index}].selected_models 不适用于受信候选 model_scope"
        )

    if scenario != "headroom":
        forbidden = [
            name
            for name in (
                "incremental_tpm",
                "reserve_ratio",
                "detail_level",
                "resource_artifact",
                "service_selections",
            )
            if name in raw
        ]
        if forbidden:
            raise CapacityPipelineError(
                f"tasks[{index}] {scenario} 不接受：" + ", ".join(forbidden)
            )
        detail_level = scenario
        incremental = None
        reserve_ratio = 0.0
    else:
        if provider_scope == "mixed":
            raise CapacityPipelineError(
                f"tasks[{index}] headroom 不接受未确认聚合口径的 mixed provider"
            )
        if relation != "previous_day":
            raise CapacityPipelineError(
                f"tasks[{index}] headroom 固定使用 previous_day"
            )
        if detail_level not in DETAIL_LEVELS:
            raise CapacityPipelineError(
                f"tasks[{index}].detail_level 非法"
            )
        reserve_ratio = nonnegative_number(
            reserve_ratio, f"tasks[{index}].reserve_ratio"
        )
        if reserve_ratio > 1:
            raise CapacityPipelineError(
                f"tasks[{index}].reserve_ratio 不能大于 1"
            )
        if incremental is not None:
            incremental = nonnegative_number(
                incremental, f"tasks[{index}].incremental_tpm"
            )
        if detail_level != "headroom" and incremental is None:
            raise CapacityPipelineError(
                f"tasks[{index}] detail_level={detail_level} 需要 incremental_tpm"
            )
        if detail_level == "headroom" and incremental is not None:
            raise CapacityPipelineError(
                f"tasks[{index}] 提供 incremental_tpm 时不能使用 detail_level=headroom"
            )
        if (
            provider_scope != "self_deployed"
            and detail_level in {"instances", "cards", "resources"}
        ):
            raise CapacityPipelineError(
                f"tasks[{index}] 云上余量只支持 headroom/decision；"
                "内部实例和资源换算请使用 cloud-reclaim"
            )
        if resource_artifact is not None:
            resource_artifact = str(
                Path(bounded_text(resource_artifact, "resource_artifact"))
                .expanduser()
                .resolve()
            )
            if detail_level != "resources":
                raise CapacityPipelineError(
                    f"tasks[{index}].resource_artifact 只适用于 detail_level=resources"
                )
        if service_selections and detail_level not in {"cards", "resources"}:
            raise CapacityPipelineError(
                f"tasks[{index}].service_selections 只适用于 cards/resources"
            )

    return {
        "task_id": task_id,
        "scenario": scenario,
        "model_inputs": model_inputs,
        "model_scope": model_scope,
        "providers": providers,
        "provider_scope": provider_scope,
        "provider_selection_source": provider_selection_source,
        "priority": "在线",
        "timezone": timezone,
        "window_relation": relation,
        "lookback_seconds": lookback,
        "from": from_ts,
        "to": to_ts,
        "incremental_tpm": incremental,
        "reserve_ratio": reserve_ratio,
        "detail_level": detail_level,
        "resource_artifact": resource_artifact,
        "selected_models": selected_models,
        "service_selections": service_selections,
    }


def normalize_request_object(
    request: Any,
    *,
    reason_code: str = "INVALID_INPUT",
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    try:
        validate_request_schema(request)
    except ValueError as exc:
        raise CapacityPipelineError(str(exc), reason_code) from exc
    assert isinstance(request, dict)
    schema_version = request.get(
        "schema_version", DEFAULT_REQUEST_SCHEMA_VERSION
    )
    tasks = [
        normalize_task(raw, index, schema_version=schema_version)
        for index, raw in enumerate(request["tasks"])
    ]
    task_ids = [task["task_id"] for task in tasks]
    if len(set(task_ids)) != len(task_ids):
        raise CapacityPipelineError("tasks.task_id 不得重复", reason_code)
    for index, task in enumerate(tasks):
        if len(task["model_inputs"]) > MAX_MODELS_PER_TASK:
            raise CapacityPipelineError(
                f"tasks[{index}] 归一化后的模型数不能超过 "
                f"{MAX_MODELS_PER_TASK}",
                reason_code,
            )
    total_models = sum(len(task["model_inputs"]) for task in tasks)
    if total_models > MAX_TOTAL_MODEL_INPUTS:
        raise CapacityPipelineError(
            f"请求中归一化模型总数不能超过 {MAX_TOTAL_MODEL_INPUTS}",
            reason_code,
        )
    normalized_request = copy.deepcopy(request)
    normalized_request["schema_version"] = schema_version
    return normalized_request, tasks


def load_request(args: argparse.Namespace) -> tuple[Path, dict[str, Any], list[dict[str, Any]]]:
    input_path, request = load_object(args.input)
    normalized_request, tasks = normalize_request_object(request)
    fixtures = list(args.candidate_fixture or [])
    expected = sum(
        len(task["model_inputs"])
        for task in tasks
        if task["model_scope"]["mode"] == "explicit_models"
    )
    if fixtures and len(fixtures) != expected:
        raise CapacityPipelineError(
            "--candidate-fixture 数量必须等于需要候选发现的 model_inputs 数量"
        )
    return input_path, normalized_request, tasks


def load_bound_capacity_request(
    artifact: dict[str, Any],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Reload and normalize the single hashed capacity request parent."""

    provenance = artifact.get("provenance")
    parents = provenance.get("parents") if isinstance(provenance, dict) else None
    request_paths = [
        parent.get("path")
        for parent in parents or []
        if isinstance(parent, dict) and parent.get("role") == "capacity_request"
    ]
    if len(request_paths) != 1 or not isinstance(request_paths[0], str):
        raise CapacityPipelineError(
            "容量计划必须绑定唯一 capacity_request", "ARTIFACT_INVALID"
        )
    _, request = load_object(request_paths[0])
    return normalize_request_object(request, reason_code="ARTIFACT_INVALID")


def load_bound_capacity_request_for_result(
    artifact: dict[str, Any],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Resolve the immutable request from a direct result or its prepare plan."""

    try:
        paths_by_role = provenance_paths_by_role(artifact)
    except ArtifactContractError as exc:
        raise CapacityPipelineError(str(exc), "ARTIFACT_INVALID") from exc
    request_paths = paths_by_role.get("capacity_request", set())
    if request_paths:
        if len(request_paths) != 1:
            raise CapacityPipelineError(
                "容量结果必须绑定唯一 capacity_request",
                "ARTIFACT_INVALID",
            )
        return load_bound_capacity_request(artifact)

    plan_paths = paths_by_role.get("capacity_plan", set())
    if len(plan_paths) != 1:
        raise CapacityPipelineError(
            "容量结果必须绑定 capacity_request 或唯一 capacity_plan",
            "ARTIFACT_INVALID",
        )
    _, plan = load_object(next(iter(plan_paths)))
    try:
        validate_provenance(
            plan,
            expected_artifact_type=PLAN_ARTIFACT_TYPE,
            expected_producer_script=PRODUCER_SCRIPT,
            expected_producer_version=SCRIPT_VERSION,
            expected_stage="awaiting_kconf",
            required_parent_roles=("capacity_request",),
        )
    except ArtifactContractError as exc:
        raise CapacityPipelineError(str(exc), "ARTIFACT_INVALID") from exc
    if plan.get("run_id") != artifact.get("run_id"):
        raise CapacityPipelineError(
            "容量结果与 prepare plan 的 run_id 不一致",
            "ARTIFACT_INVALID",
        )
    return load_bound_capacity_request(plan)


def window_arguments(task: dict[str, Any]) -> list[str]:
    values = [
        "--window-relation",
        task["window_relation"],
        "--timezone",
        task["timezone"],
    ]
    if task["window_relation"] == "current":
        values.extend(["--lookback-seconds", str(task["lookback_seconds"])])
    elif task["window_relation"] in {"custom", "previous_same_period"}:
        values.extend(["--from", str(task["from"]), "--to", str(task["to"])])
    return values


def provider_arguments(task: dict[str, Any]) -> list[str]:
    values: list[str] = []
    for provider in task["providers"]:
        values.extend(["--provider", provider])
    return values


def build_trusted_headroom_model_scope(
    task: dict[str, Any],
    task_dir: Path,
) -> tuple[dict[str, Any], list[Path], list[tuple[Path, str]]]:
    """Materialize the versioned candidate policy as verified model identity."""

    selection = task["model_scope"]
    models = task["model_inputs"]
    generated_at = utc_now()
    scope_dir = task_dir / "01-model-scope"
    scope_path = scope_dir / "scope.json"
    scope = {
        "schema_version": "1.1",
        "script_version": SCRIPT_VERSION,
        "domain": "capacity",
        "scenario": "headroom-model-scope",
        "status": "success",
        "generated_at": generated_at,
        "summary": {
            "decision": "trusted_policy_model_scope_ready",
            "scope": copy.deepcopy(selection),
            "models": list(models),
            "model_count": len(models),
            "policy_source": selection["policy_source"],
            "policy_version": selection["policy_version"],
            "write_performed": False,
        },
        "warnings": [],
        "errors": [],
    }
    annotate_outcome(scope, complete=True, reason_code="OK", next_action="NONE")
    add_provenance(
        scope,
        artifact_type="wanqing.model_scope",
        producer_script=PRODUCER_SCRIPT,
        producer_version=SCRIPT_VERSION,
        run_id=str(uuid.uuid4()),
        stage="model_scope",
    )
    write_artifact(str(scope_path), scope)

    resolution_dir = task_dir / "02-model-resolution"
    resolution_paths: list[Path] = []
    items: list[dict[str, Any]] = []
    for index, model in enumerate(models):
        artifact = trusted_scope_resolution_artifact(
            model=model,
            target_domain="capacity",
            target_scenario="headroom",
            scope_artifact=scope_path,
            resolved_at=generated_at,
            scope_source=selection["policy_source"],
            scope_version=selection["policy_version"],
        )
        annotate_outcome(
            artifact, complete=True, reason_code="OK", next_action="NONE"
        )
        add_provenance(
            artifact,
            artifact_type="wanqing.model_resolution.policy",
            producer_script=PRODUCER_SCRIPT,
            producer_version=SCRIPT_VERSION,
            run_id=str(scope["run_id"]),
            stage="model_resolution",
            parents=[artifact_reference(scope_path, role="model_scope")],
        )
        path = resolution_dir / f"resolution-{index + 1:03d}.json"
        write_artifact(str(path), artifact)
        resolved_path = path.resolve()
        resolution_paths.append(resolved_path)
        items.append(
            {
                "index": index,
                "model_input": model,
                "model": model,
                "status": "success",
                "artifact": str(resolved_path),
                "summary": artifact["summary"],
            }
        )

    manifest_path = resolution_dir / "manifest.json"
    manifest = {
        "schema_version": "1.1",
        "script_version": SCRIPT_VERSION,
        "domain": "common",
        "scenario": "model-resolution-batch",
        "status": "success",
        "generated_at": generated_at,
        "query": {
            "target_domain": "capacity",
            "target_scenario": "headroom",
            "anchor_source": "capacity",
            "resolution_source": "trusted_model_scope",
            "scope_artifact": str(scope_path.resolve()),
        },
        "summary": {
            "decision": "batch_resolved",
            "input_count": len(models),
            "successful_input_count": len(models),
            "partial_input_count": 0,
            "failed_input_count": 0,
            "write_performed": False,
        },
        "artifacts": {"model_resolution": items},
        "handoffs": {
            "model_artifacts": {
                "status": "ready",
                "models": list(models),
                "artifacts": [str(path) for path in resolution_paths],
            }
        },
        "warnings": [],
        "errors": [],
    }
    annotate_outcome(
        manifest, complete=True, reason_code="OK", next_action="NONE"
    )
    add_provenance(
        manifest,
        artifact_type="wanqing.model_resolution_batch.policy",
        producer_script=PRODUCER_SCRIPT,
        producer_version=SCRIPT_VERSION,
        run_id=str(scope["run_id"]),
        stage="model_resolution_batch",
        parents=[artifact_reference(scope_path, role="model_scope")]
        + [
            artifact_reference(path, role="model_resolution")
            for path in resolution_paths
        ],
    )
    write_artifact(str(manifest_path), manifest)
    parents = [
        (scope_path.resolve(), "model_scope"),
        (manifest_path.resolve(), "resolution_manifest"),
        *[(path, "model_resolution") for path in resolution_paths],
    ]
    return manifest, resolution_paths, parents


def discover_and_resolve(
    args: argparse.Namespace,
    task: dict[str, Any],
    task_dir: Path,
    candidate_fixtures: list[str],
) -> tuple[dict[str, Any], list[Path], list[tuple[Path, str]]]:
    if task["model_scope"]["mode"] != "explicit_models":
        return build_trusted_headroom_model_scope(task, task_dir)

    candidate_dir = task_dir / "01-candidates"
    model_inputs = task["model_inputs"]
    anchor = expected_anchor_source("capacity", task["scenario"])
    parents: list[tuple[Path, str]] = []
    if len(model_inputs) == 1:
        candidate_output = candidate_dir / "candidate.json"
        command = [
            sys.executable,
            "-B",
            str(CAPACITY_SCRIPT),
            "list-models",
            "--anchor-source",
            anchor,
            "--model-input",
            model_inputs[0],
            *provider_arguments(task),
            "--priority",
            "在线",
            *window_arguments(task),
            "--timeout",
            str(args.timeout),
            "--output",
            str(candidate_output),
        ]
        if candidate_fixtures:
            command.extend(["--fixture", candidate_fixtures[0]])
        candidates = run_artifact_command(command, candidate_output, "模型候选查询")
        parents.append((candidate_output, "model_candidates"))
        if candidates.get("status") != "success":
            return candidates, [], parents

        resolution_output = task_dir / "02-model-resolution" / "resolution.json"
        command = [
            sys.executable,
            "-B",
            str(MODEL_RESOLVER_SCRIPT),
            "resolve",
            "--input",
            model_inputs[0],
            "--candidates-artifact",
            str(candidate_output),
            "--target-domain",
            "capacity",
            "--target-scenario",
            task["scenario"],
            "--output",
            str(resolution_output),
        ]
        if 0 in task["selected_models"]:
            command.extend(["--selected-model", task["selected_models"][0]])
        resolution = run_artifact_command(command, resolution_output, "模型解析")
        parents.append((resolution_output, "model_resolution"))
        return resolution, [resolution_output], parents

    candidate_output = candidate_dir / "manifest.json"
    command = [
        sys.executable,
        "-B",
        str(CAPACITY_SCRIPT),
        "list-models-batch",
        "--anchor-source",
        anchor,
    ]
    for value in model_inputs:
        command.extend(["--model-input", value])
    command.extend(provider_arguments(task))
    command.extend(["--priority", "在线", *window_arguments(task)])
    for fixture in candidate_fixtures:
        command.extend(["--fixture", fixture])
    command.extend(
        [
            "--timeout",
            str(args.timeout),
            "--max-workers",
            str(args.max_workers),
            "--output-dir",
            str(candidate_dir),
            "--output",
            str(candidate_output),
        ]
    )
    candidates = run_artifact_command(command, candidate_output, "批量模型候选查询")
    parents.append((candidate_output, "candidate_manifest"))
    candidate_items = candidates.get("artifacts", {}).get("model_candidates", [])
    for item in candidate_items:
        if isinstance(item, dict) and isinstance(item.get("artifact"), str):
            parents.append((Path(item["artifact"]), "model_candidates"))
    if candidates.get("status") != "success":
        return candidates, [], parents

    resolution_dir = task_dir / "02-model-resolution"
    resolution_output = resolution_dir / "manifest.json"
    command = [
        sys.executable,
        "-B",
        str(MODEL_RESOLVER_SCRIPT),
        "resolve-batch",
        "--candidates-manifest",
        str(candidate_output),
        "--target-domain",
        "capacity",
        "--target-scenario",
        task["scenario"],
    ]
    for position, model in sorted(task["selected_models"].items()):
        command.extend(["--selection", f"{position}={model}"])
    command.extend(
        [
            "--max-workers",
            str(args.max_workers),
            "--output-dir",
            str(resolution_dir),
            "--output",
            str(resolution_output),
        ]
    )
    resolution = run_artifact_command(command, resolution_output, "批量模型解析")
    parents.append((resolution_output, "resolution_manifest"))
    resolution_items = resolution.get("artifacts", {}).get("model_resolution", [])
    paths = [
        Path(item["artifact"]).expanduser().resolve()
        for item in resolution_items
        if isinstance(item, dict) and isinstance(item.get("artifact"), str)
    ]
    parents.extend((path, "model_resolution") for path in paths)
    return resolution, paths, parents


def query_base_evidence(
    args: argparse.Namespace,
    task: dict[str, Any],
    model_paths: list[Path],
    task_dir: Path,
) -> tuple[dict[str, Any], list[Path], list[tuple[Path, str]]]:
    stage_dir = task_dir / "03-capacity-query"
    common = [
        *provider_arguments(task),
        "--provider-scope",
        task["provider_scope"],
        *window_arguments(task),
        "--timeout",
        str(args.timeout),
    ]
    if task["scenario"] == "headroom":
        common.extend(["--detail-level", task["detail_level"]])
        if task["incremental_tpm"] is not None:
            common.extend(["--incremental-tpm", str(task["incremental_tpm"])])
        if task["reserve_ratio"]:
            common.extend(["--reserve-ratio", str(task["reserve_ratio"])])
    if args.capacity_fixture:
        common.extend(["--capacity-fixture", args.capacity_fixture])
    if args.usage_fixture:
        common.extend(["--usage-fixture", args.usage_fixture])

    if len(model_paths) == 1:
        output = stage_dir / "result.json"
        command = [
            sys.executable,
            "-B",
            str(CAPACITY_SCRIPT),
            "query-headroom",
            "--model-artifact",
            str(model_paths[0]),
            *common,
            "--output",
            str(output),
        ]
        artifact = run_artifact_command(command, output, "容量分析查询")
        return artifact, [output], [(output, "capacity_result")]

    output = stage_dir / "manifest.json"
    command = [sys.executable, "-B", str(CAPACITY_SCRIPT), "query-headroom-batch"]
    for path in model_paths:
        command.extend(["--model-artifact", str(path)])
    command.extend(
        [
            *common,
            "--max-workers",
            str(args.max_workers),
            "--output-dir",
            str(stage_dir),
            "--output",
            str(output),
        ]
    )
    artifact = run_artifact_command(command, output, "批量容量分析查询")
    items = artifact.get("artifacts", {}).get("headroom", [])
    paths = [
        Path(item["artifact"]).expanduser().resolve()
        for item in items
        if isinstance(item, dict) and isinstance(item.get("artifact"), str)
    ]
    parents = [(output, "capacity_manifest")]
    parents.extend((path, "capacity_result") for path in paths)
    return artifact, paths, parents


def numeric(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def evaluate_model_artifact(
    task: dict[str, Any],
    artifact_path: Path,
    *,
    model: str,
    model_artifact_path: Path,
) -> tuple[bool, bool, dict[str, Any]]:
    """Rebuild one model row and dependency state from its bound evidence."""

    path, artifact = load_object(artifact_path)
    try:
        validate_capacity_evidence_semantics(
            artifact,
            request=task,
            expected_model=model,
            expected_model_artifact=model_artifact_path,
            field=f"容量证据 {path}",
        )
    except ArtifactContractError as exc:
        raise CapacityPipelineError(str(exc), "ARTIFACT_INVALID") from exc
    summary = artifact.get("summary")
    if not isinstance(summary, dict):
        summary = {}
    row = {
        "artifact": str(path),
        "status": artifact.get("status"),
        "reason_code": reason_code_for(artifact),
        "summary": summary,
        "_evidence_status": artifact.get("status"),
        "_evidence_reason_code": reason_code_for(artifact),
        "needs_kconf": False,
        "warnings": [
            item for item in artifact.get("warnings", []) if isinstance(item, str)
        ],
        "errors": [
            item for item in artifact.get("errors", []) if isinstance(item, str)
        ],
    }
    if task["scenario"] in {"supply-profile", "traffic-profile"}:
        return artifact.get("status") == "success", False, row

    usable = summary.get("usable_headroom_tpm")
    if not numeric(usable):
        return False, False, row
    detail = task["detail_level"]
    if detail == "headroom":
        return artifact.get("status") == "success", False, row
    deficit = summary.get("deficit_tpm")
    if not numeric(deficit):
        return False, False, row
    if detail == "decision" or float(deficit) <= 0:
        return artifact.get("status") == "success", False, row
    row["needs_kconf"] = True
    return False, True, row


def evaluate_task(
    task: dict[str, Any],
    artifact_paths: list[Path],
    models: list[str],
    model_artifact_paths: list[Path],
) -> tuple[bool, list[int], list[dict[str, Any]]]:
    """Return task completeness, KConf-dependent model indexes and model rows."""

    rows: list[dict[str, Any]] = []
    model_complete: list[bool] = []
    kconf_model_indexes: list[int] = []
    if not (
        len(artifact_paths) == len(models) == len(model_artifact_paths)
    ):
        raise CapacityPipelineError(
            "容量证据、模型与模型解析 Artifact 数量不一致",
            "ARTIFACT_INVALID",
        )
    for index, path in enumerate(artifact_paths):
        complete, needs_kconf, row = evaluate_model_artifact(
            task,
            path,
            model=models[index],
            model_artifact_path=model_artifact_paths[index],
        )
        rows.append(row)
        model_complete.append(complete)
        if needs_kconf:
            kconf_model_indexes.append(index)
    return all(model_complete), kconf_model_indexes, rows


def query_isvc_evidence(
    args: argparse.Namespace,
    task: dict[str, Any],
    model_paths: list[Path],
    model_indexes: list[int],
    task_dir: Path,
) -> tuple[dict[str, Any] | None, list[Path], list[tuple[Path, str]]]:
    if task["detail_level"] not in {"cards", "resources"}:
        return None, [], []
    stage_dir = task_dir / "04-isvc"
    if len(model_paths) == 1:
        output = stage_dir / "result.json"
        command = [
            sys.executable,
            "-B",
            str(ISVC_SCRIPT),
            "query-model",
            "--model-artifact",
            str(model_paths[0]),
            "--pool",
            "online",
            "--timeout",
            str(args.isvc_timeout),
            "--output",
            str(output),
        ]
        if args.isvc_endpoint:
            command.extend(["--endpoint", args.isvc_endpoint])
        if args.isvc_fixture:
            command.extend(["--fixture", args.isvc_fixture])
        original_index = model_indexes[0]
        if original_index in task["service_selections"]:
            command.extend(
                ["--service-name", task["service_selections"][original_index]]
            )
        artifact = run_artifact_command(command, output, "iSvc 查询")
        return artifact, [output], [(output, "isvc")]

    output = stage_dir / "manifest.json"
    selections: dict[str, str] = {}
    for local_index, original_index in enumerate(model_indexes):
        service_name = task["service_selections"].get(original_index)
        if not service_name:
            continue
        verified = load_model_resolution(
            model_paths[local_index],
            expected_domain="capacity",
            allowed_scenarios={task["scenario"]},
        )
        selections[verified.model] = service_name
    command = build_isvc_batch_command(
        python=sys.executable,
        script=ISVC_SCRIPT,
        model_artifacts=model_paths,
        timeout=args.isvc_timeout,
        max_workers=args.max_workers,
        output_dir=stage_dir,
        output=output,
        endpoint=args.isvc_endpoint,
        fixture=args.isvc_fixture,
        service_selections=selections,
    )
    artifact = run_artifact_command(command, output, "批量 iSvc 查询")
    items = artifact.get("artifacts", {}).get("isvc", [])
    paths = [
        Path(item["artifact"]).expanduser().resolve()
        for item in items
        if isinstance(item, dict) and isinstance(item.get("artifact"), str)
    ]
    parents = [(output, "isvc_manifest")]
    parents.extend((path, "isvc") for path in paths)
    return artifact, paths, parents


def isvc_service_confirmations(
    task: dict[str, Any],
    models: list[str],
    model_indexes: list[int],
    artifact_paths: list[Path],
) -> list[dict[str, Any]]:
    confirmations: list[dict[str, Any]] = []
    for model, original_index, path in zip(models, model_indexes, artifact_paths):
        _, artifact = load_object(path)
        summary = artifact.get("summary")
        if not isinstance(summary, dict):
            continue
        if summary.get("decision") != "ambiguous_deployment_specs":
            continue
        confirmations.append(
            {
                "task_id": task["task_id"],
                "model_index": original_index,
                "model": model,
                "service_names": summary.get("service_names", []),
                "artifact": str(path),
            }
        )
    return confirmations


def query_resource_evidence(
    args: argparse.Namespace,
    task: dict[str, Any],
    models: list[str],
    isvc_paths: list[Path],
    task_dir: Path,
) -> tuple[Path | None, dict[str, Any] | None, list[tuple[Path, str]]]:
    from isvc import IsvcError, load_capacity_handoff as load_isvc_handoff

    if task["detail_level"] != "resources":
        return None, None, []
    if task.get("resource_artifact"):
        path, artifact = load_object(task["resource_artifact"])
        return path, artifact, [(path, "resource")]
    gpu_types: set[str] = set()
    for model, path in zip(models, isvc_paths):
        try:
            handoff = load_isvc_handoff(path, model)
        except (OSError, IsvcError):
            continue
        profile = handoff.get("single_instance_gpu_cards_by_type")
        if isinstance(profile, dict):
            gpu_types.update(str(key).upper() for key in profile)
    if not gpu_types:
        return None, None, []
    output = task_dir / "05-resource" / "available.json"
    command = [sys.executable, "-B", str(RESOURCE_SCRIPT), "available"]
    for gpu_type in sorted(gpu_types):
        command.extend(["--gpu", gpu_type])
    command.extend(["--timeout", str(args.timeout), "--output", str(output)])
    if args.resource_fixture:
        command.extend(["--fixture", args.resource_fixture])
    artifact = run_artifact_command(command, output, "可用资源查询")
    return output, artifact, [(output, "resource")]


def task_public_request(task: dict[str, Any]) -> dict[str, Any]:
    return {
        key: copy.deepcopy(value)
        for key, value in task.items()
        if key != "selected_models" or value
    }


def stopped_task_record(
    task: dict[str, Any], artifact: dict[str, Any], artifact_path: Path | None
) -> dict[str, Any]:
    summary = artifact.get("summary") if isinstance(artifact.get("summary"), dict) else {}
    return {
        "task_id": task["task_id"],
        "scenario": task["scenario"],
        "request": task_public_request(task),
        "status": artifact.get("status", "error"),
        "complete": False,
        "reason_code": reason_code_for(artifact),
        "stopped_artifact": None if artifact_path is None else str(artifact_path),
        "confirmations": summary.get("confirmations", []),
        "warnings": artifact.get("warnings", []),
        "errors": artifact.get("errors", []),
        "models": [],
        "model_entries": [],
        "results": [],
    }


def attach_capacity_evidence_ids(artifact: dict[str, Any]) -> None:
    """Bind task records to canonical evidence IDs; paths remain compatibility data."""

    summary = artifact.get("summary")
    tasks = summary.get("tasks") if isinstance(summary, dict) else None
    if not isinstance(tasks, list):
        return
    for task in tasks:
        if not isinstance(task, dict):
            continue
        entries = task.get("model_entries")
        rows = task.get("results")
        if not isinstance(entries, list) or not isinstance(rows, list):
            continue
        for entry, row in zip(entries, rows):
            if not isinstance(entry, dict) or not isinstance(row, dict):
                continue
            attach_evidence_id(
                artifact,
                entry,
                id_field="model_evidence_id",
                path_value=entry.get("model_artifact"),
                role="model_resolution",
            )
            attach_evidence_id(
                artifact,
                entry,
                id_field="base_evidence_id",
                path_value=entry.get("base_artifact"),
                role="capacity_result",
            )
            attach_evidence_id(
                artifact,
                entry,
                id_field="isvc_evidence_id",
                path_value=entry.get("isvc_artifact"),
                role="isvc",
            )
            result_path = entry.get("result_artifact") or row.get("artifact")
            result_role = (
                "headroom_result"
                if entry.get("result_artifact") is not None
                else "capacity_result"
            )
            attach_evidence_id(
                artifact,
                entry,
                id_field="result_evidence_id",
                path_value=result_path,
                role=result_role,
            )
            attach_evidence_id(
                artifact,
                row,
                id_field="evidence_id",
                path_value=result_path,
                role=result_role,
            )
            attach_evidence_id(
                artifact,
                row,
                id_field="kconf_evidence_id",
                path_value=row.get("kconf_artifact"),
                role="kconf",
            )
            attach_evidence_id(
                artifact,
                row,
                id_field="isvc_evidence_id",
                path_value=row.get("isvc_artifact"),
                role="isvc",
            )
        attach_evidence_id(
            artifact,
            task,
            id_field="resource_evidence_id",
            path_value=task.get("resource_artifact"),
            role="resource",
        )


def run_analyze(args: argparse.Namespace) -> dict[str, Any]:
    validate_runtime_args(args)
    input_path, request, tasks = load_request(args)
    run_id = str(uuid.uuid4())
    output_dir = Path(args.output_dir).expanduser().resolve()
    fixtures = list(args.candidate_fixture or [])
    fixture_cursor = 0
    task_records: list[dict[str, Any]] = []
    parent_paths: list[tuple[Path, str]] = [(input_path, "capacity_request")]
    confirmations: list[dict[str, Any]] = []
    service_confirmations: list[dict[str, Any]] = []
    pending_kconf = False

    for task_index, task in enumerate(tasks):
        task_dir = output_dir / f"task-{task_index + 1:03d}-{task['task_id']}"
        count = len(task["model_inputs"])
        candidate_count = (
            count if task["model_scope"]["mode"] == "explicit_models" else 0
        )
        task_fixtures = (
            fixtures[fixture_cursor : fixture_cursor + candidate_count]
            if fixtures
            else []
        )
        fixture_cursor += candidate_count
        stage_artifact, model_paths, stage_parents = discover_and_resolve(
            args, task, task_dir, task_fixtures
        )
        parent_paths.extend(stage_parents)
        if stage_artifact.get("status") != "success":
            artifact_path = stage_parents[-1][0] if stage_parents else None
            record = stopped_task_record(task, stage_artifact, artifact_path)
            task_records.append(record)
            if record["reason_code"] == "MODEL_CONFIRMATION_REQUIRED":
                confirmations.extend(record["confirmations"])
            continue
        if len(model_paths) != count:
            raise CapacityPipelineError(
                f"任务 {task['task_id']} 的模型解析数量与输入不一致",
                "ARTIFACT_INVALID",
            )
        verified = [
            load_model_resolution(
                path,
                expected_domain="capacity",
                allowed_scenarios={task["scenario"]},
            )
            for path in model_paths
        ]
        models = [item.model for item in verified]
        base_manifest, base_paths, base_parents = query_base_evidence(
            args, task, model_paths, task_dir
        )
        parent_paths.extend(base_parents)
        if len(base_paths) != count:
            raise CapacityPipelineError(
                f"任务 {task['task_id']} 的容量结果数量与模型数量不一致",
                "ARTIFACT_INVALID",
            )
        complete, kconf_model_indexes, model_results = evaluate_task(
            task, base_paths, models, model_paths
        )
        needs_kconf = bool(kconf_model_indexes)
        isvc_manifest: dict[str, Any] | None = None
        isvc_paths: list[Path] = []
        isvc_paths_by_model_index: dict[int, Path] = {}
        resource_path: Path | None = None
        resource_artifact: dict[str, Any] | None = None
        task_service_confirmations: list[dict[str, Any]] = []
        if needs_kconf:
            dependent_model_paths = [
                model_paths[index] for index in kconf_model_indexes
            ]
            dependent_models = [models[index] for index in kconf_model_indexes]
            isvc_manifest, isvc_paths, isvc_parents = query_isvc_evidence(
                args,
                task,
                dependent_model_paths,
                kconf_model_indexes,
                task_dir,
            )
            parent_paths.extend(isvc_parents)
            isvc_paths_by_model_index = dict(
                zip(kconf_model_indexes, isvc_paths)
            )
            task_service_confirmations = isvc_service_confirmations(
                task,
                dependent_models,
                kconf_model_indexes,
                isvc_paths,
            )
            service_confirmations.extend(task_service_confirmations)
            if not task_service_confirmations:
                pending_kconf = True
                resource_path, resource_artifact, resource_parents = query_resource_evidence(
                    args, task, dependent_models, isvc_paths, task_dir
                )
                parent_paths.extend(resource_parents)

        if complete:
            task_status = "success"
            reason_code = "OK"
        elif task_service_confirmations:
            task_status = "partial"
            reason_code = "ISVC_CONFIRMATION_REQUIRED"
        elif needs_kconf:
            task_status = "partial"
            reason_code = "KCONF_REQUIRED"
        else:
            task_status = "partial" if base_manifest.get("status") != "error" else "error"
            reason_code = reason_code_for(base_manifest)
            if reason_code == "OK":
                reason_code = "CAPACITY_INCOMPLETE"
        model_entries = [
            {
                "index": index,
                "model_input": task["model_inputs"][index],
                "model": models[index],
                "model_artifact": str(model_paths[index]),
                "base_artifact": str(base_paths[index]),
                "isvc_artifact": (
                    None
                    if index not in isvc_paths_by_model_index
                    else str(isvc_paths_by_model_index[index])
                ),
                "needs_kconf": index in kconf_model_indexes,
            }
            for index in range(count)
        ]
        task_warnings = list(base_manifest.get("warnings", []))
        if complete and task["scenario"] == "headroom" and task["detail_level"] == "decision":
            task_warnings = [
                warning
                for warning in task_warnings
                if not any(
                    marker in str(warning)
                    for marker in ("kconf.", "KConf", "iSvc", "资源域 Artifact")
                )
            ]
        request_record = task_public_request(task)
        task_records.append(
            {
                "task_id": task["task_id"],
                "scenario": task["scenario"],
                "request": request_record,
                "status": task_status,
                "complete": complete,
                "reason_code": reason_code,
                "needs_kconf": needs_kconf,
                "models": models,
                "model_entries": model_entries,
                "results": model_results,
                "base_manifest_status": base_manifest.get("status"),
                "isvc_status": (
                    None if isvc_manifest is None else isvc_manifest.get("status")
                ),
                "resource_artifact": None if resource_path is None else str(resource_path),
                "resource_status": (
                    None if resource_artifact is None else resource_artifact.get("status")
                ),
                "warnings": task_warnings
                + ([] if isvc_manifest is None else list(isvc_manifest.get("warnings", [])))
                + ([] if resource_artifact is None else list(resource_artifact.get("warnings", []))),
                "errors": list(base_manifest.get("errors", []))
                + ([] if isvc_manifest is None else list(isvc_manifest.get("errors", [])))
                + ([] if resource_artifact is None else list(resource_artifact.get("errors", []))),
            }
        )

    complete_count = sum(bool(item.get("complete")) for item in task_records)
    error_count = sum(item.get("status") == "error" for item in task_records)
    summary = {
        "decision": "capacity_analysis_completed",
        "request": copy.deepcopy(request),
        "task_count": len(task_records),
        "complete_task_count": complete_count,
        "partial_task_count": sum(item.get("status") == "partial" for item in task_records),
        "failed_task_count": error_count,
        "tasks": task_records,
        "query_sources_by_scenario": {
            scenario: sorted(CAPACITY_QUERY_SOURCES[scenario])
            for scenario in sorted(SCENARIOS)
        },
        "write_performed": False,
    }
    warnings = [
        f"{item['task_id']}: {warning}"
        for item in task_records
        for warning in item.get("warnings", [])
        if isinstance(warning, str)
    ]
    errors = [
        f"{item['task_id']}: {error}"
        for item in task_records
        for error in item.get("errors", [])
        if isinstance(error, str)
    ]

    if confirmations:
        manifest = {
            "schema_version": "1.1",
            "script_version": SCRIPT_VERSION,
            "domain": "workflow",
            "scenario": "capacity-analyze",
            "status": "partial",
            "generated_at": utc_now(),
            "summary": summary,
            "warnings": warnings,
            "errors": errors,
        }
        annotate_outcome(
            manifest,
            complete=False,
            reason_code="MODEL_CONFIRMATION_REQUIRED",
            next_action={
                "type": "request_model_confirmation",
                "confirmations": confirmations,
                "then": "在请求 tasks[].selected_models 中按下标补充选择后重新运行 capacity-analyze",
            },
        )
        artifact_type = PLAN_ARTIFACT_TYPE
        stage = "awaiting_model_confirmation"
    elif service_confirmations:
        manifest = {
            "schema_version": "1.1",
            "script_version": SCRIPT_VERSION,
            "domain": "workflow",
            "scenario": "capacity-analyze",
            "status": "partial",
            "generated_at": utc_now(),
            "summary": summary,
            "warnings": warnings,
            "errors": errors,
        }
        annotate_outcome(
            manifest,
            complete=False,
            reason_code="ISVC_CONFIRMATION_REQUIRED",
            next_action={
                "type": "request_isvc_service_confirmation",
                "confirmations": service_confirmations,
                "then": (
                    "在对应 tasks[].service_selections 中用模型输入下标补充 "
                    "serviceName，再使用原请求重新运行 capacity-analyze"
                ),
            },
        )
        artifact_type = PLAN_ARTIFACT_TYPE
        stage = "awaiting_isvc_service_confirmation"
    elif pending_kconf:
        kconf_output = output_dir / "shared-kconf" / "tool-result.json"
        final_output = output_dir / "capacity-analysis-result.json"
        final_dir = output_dir / "finalize"
        manifest = {
            "schema_version": "1.1",
            "script_version": SCRIPT_VERSION,
            "domain": "workflow",
            "scenario": "capacity-analyze",
            "status": "success" if error_count == 0 else "partial",
            "generated_at": utc_now(),
            "summary": summary,
            "warnings": warnings,
            "errors": errors,
        }
        annotate_outcome(
            manifest,
            complete=False,
            reason_code="KCONF_REQUIRED",
            next_action={
                "type": "tool_call",
                "tool": KCONF_TOOL,
                "arguments": {"key": KCONF_KEY, "stage": KCONF_STAGE},
                "save_raw_result_as": str(kconf_output),
                "then": {
                    "command": "capacity-analyze-finalize",
                    "arguments": {
                        "plan_artifact": str(Path(args.output).expanduser().resolve()),
                        "kconf_tool_result": str(kconf_output),
                        "output_dir": str(final_dir),
                        "output": str(final_output),
                    },
                },
            },
        )
        artifact_type = PLAN_ARTIFACT_TYPE
        stage = "awaiting_kconf"
    else:
        all_complete = complete_count == len(task_records)
        status = (
            "success"
            if all_complete
            else "error"
            if task_records and error_count == len(task_records)
            else "partial"
        )
        manifest = {
            "schema_version": "1.1",
            "script_version": SCRIPT_VERSION,
            "domain": "workflow",
            "scenario": "capacity-analyze",
            "status": status,
            "generated_at": utc_now(),
            "summary": summary,
            "warnings": warnings,
            "errors": errors,
        }
        if status != "error":
            attach_report_projection(manifest)
        report_output = output_dir / "capacity-analysis-report.json"
        annotate_outcome(
            manifest,
            complete=all_complete,
            reason_code="OK" if all_complete else "CAPACITY_INCOMPLETE",
            next_action=(
                {
                    "type": "command",
                    "command": "render-capacity-report",
                    "arguments": {
                        "manifest": str(Path(args.output).expanduser().resolve()),
                        "output": str(report_output),
                    },
                }
                if status != "error"
                else "STOP"
            ),
        )
        artifact_type = RESULT_ARTIFACT_TYPE
        stage = "analysis_complete" if all_complete else "analysis_partial"

    result = add_provenance(
        manifest,
        artifact_type=artifact_type,
        producer_script=PRODUCER_SCRIPT,
        producer_version=SCRIPT_VERSION,
        run_id=run_id,
        stage=stage,
        parents=parent_references(parent_paths),
    )
    attach_capacity_evidence_ids(result)
    if result.get("report_projection") is not None:
        attach_report_projection(result)
    return result


def kconf_paths_from_manifest(manifest: dict[str, Any]) -> list[tuple[Path, str]]:
    items = manifest.get("artifacts", {}).get("kconf", [])
    results: list[tuple[Path, str]] = []
    for item in items:
        if isinstance(item, dict) and isinstance(item.get("artifact"), str):
            results.append((Path(item["artifact"]).expanduser().resolve(), str(item.get("status"))))
    return results


def final_detail_complete(detail: str, summary: dict[str, Any]) -> bool:
    deficit = summary.get("deficit_tpm")
    if not numeric(deficit):
        return False
    if float(deficit) <= 0:
        return True
    if detail == "instances":
        return numeric(summary.get("required_additional_instances"))
    if detail == "cards":
        return numeric(summary.get("required_additional_gpu_cards"))
    if detail == "resources":
        return (
            numeric(summary.get("required_additional_gpu_cards"))
            and isinstance(summary.get("available_resource_machines_by_type"), dict)
            and summary.get("decision")
            in {"expand_from_available_resources", "resource_shortage"}
        )
    return detail in {"headroom", "decision"}


def without_evidence_links(value: dict[str, Any]) -> dict[str, Any]:
    """Remove canonical references before comparing legacy business projections."""

    return {
        key: copy.deepcopy(item)
        for key, item in value.items()
        if key != "evidence_id" and not key.endswith("_evidence_id")
    }


def validate_capacity_plan_entries(
    plan: dict[str, Any], task_records: list[Any]
) -> list[tuple[Path, str]]:
    """Validate canonical evidence links; legacy plans still rebuild base rows."""

    bindings: list[tuple[str, str | Path, str | tuple[str, ...]]] = []
    referenced_parents: list[tuple[Path, str]] = []
    canonical_links = True
    for task_index, record in enumerate(task_records):
        if not isinstance(record, dict):
            raise CapacityPipelineError(
                f"summary.tasks[{task_index}] 必须是对象", "ARTIFACT_INVALID"
            )
        entries = record.get("model_entries")
        results = record.get("results")
        models = record.get("models")
        if not isinstance(entries, list) or not isinstance(results, list):
            raise CapacityPipelineError(
                f"summary.tasks[{task_index}] 缺少 model_entries/results",
                "ARTIFACT_INVALID",
            )
        if not isinstance(models, list) or len(entries) != len(results) or len(entries) != len(models):
            raise CapacityPipelineError(
                f"summary.tasks[{task_index}] 的模型、条目和结果数量不一致",
                "ARTIFACT_INVALID",
            )
        task_has_pending = False
        for entry_index, entry in enumerate(entries):
            if not isinstance(entry, dict):
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].model_entries[{entry_index}] 必须是对象",
                    "ARTIFACT_INVALID",
                )
            if entry.get("index") != entry_index:
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].model_entries[{entry_index}].index 非法",
                    "ARTIFACT_INVALID",
                )
            model = entry.get("model")
            if not isinstance(model, str) or not model or models[entry_index] != model:
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].model_entries[{entry_index}].model 不一致",
                    "ARTIFACT_INVALID",
                )
            row = results[entry_index]
            if not isinstance(row, dict):
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].results[{entry_index}] 必须是对象",
                    "ARTIFACT_INVALID",
                )
            for field, role in (
                ("model_artifact", "model_resolution"),
                ("base_artifact", "capacity_result"),
            ):
                path_value = entry.get(field)
                if not isinstance(path_value, str) or not path_value:
                    raise CapacityPipelineError(
                        f"summary.tasks[{task_index}].model_entries[{entry_index}] 缺少 {field}",
                        "ARTIFACT_INVALID",
                    )
                id_field = (
                    "model_evidence_id"
                    if field == "model_artifact"
                    else "base_evidence_id"
                )
                if id_field in entry:
                    try:
                        validate_evidence_id_binding(
                            plan,
                            entry,
                            id_field=id_field,
                            path_field=field,
                            role=role,
                        )
                    except ArtifactContractError as exc:
                        raise CapacityPipelineError(
                            str(exc), "ARTIFACT_INVALID"
                        ) from exc
                else:
                    canonical_links = False
                    bindings.append(
                        (
                            f"summary.tasks[{task_index}].model_entries[{entry_index}].{field}",
                            path_value,
                            role,
                        )
                    )
                referenced_parents.append((Path(path_value), role))
            row_artifact = row.get("artifact")
            if (
                not isinstance(row_artifact, str)
                or Path(row_artifact).expanduser().resolve()
                != Path(entry["base_artifact"]).expanduser().resolve()
            ):
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].results[{entry_index}].artifact 与基础证据不一致",
                    "ARTIFACT_INVALID",
                )
            if "evidence_id" in row:
                if row.get("evidence_id") != entry.get("result_evidence_id"):
                    raise CapacityPipelineError(
                        f"summary.tasks[{task_index}].results[{entry_index}]"
                        ".evidence_id 与模型条目不一致",
                        "ARTIFACT_INVALID",
                    )
            else:
                canonical_links = False
            isvc_path = entry.get("isvc_artifact")
            if isvc_path is not None:
                if not isinstance(isvc_path, str) or not isvc_path:
                    raise CapacityPipelineError(
                        f"summary.tasks[{task_index}].model_entries[{entry_index}].isvc_artifact 非法",
                        "ARTIFACT_INVALID",
                    )
                if "isvc_evidence_id" in entry:
                    try:
                        validate_evidence_id_binding(
                            plan,
                            entry,
                            id_field="isvc_evidence_id",
                            path_field="isvc_artifact",
                            role="isvc",
                        )
                    except ArtifactContractError as exc:
                        raise CapacityPipelineError(
                            str(exc), "ARTIFACT_INVALID"
                        ) from exc
                else:
                    canonical_links = False
                    bindings.append(
                        (
                            f"summary.tasks[{task_index}].model_entries[{entry_index}].isvc_artifact",
                            isvc_path,
                            "isvc",
                        )
                    )
                referenced_parents.append((Path(isvc_path), "isvc"))
            entry_pending = entry.get("needs_kconf")
            if not isinstance(entry_pending, bool):
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].model_entries[{entry_index}].needs_kconf 必须是布尔值",
                    "ARTIFACT_INVALID",
                )
            if entry_pending:
                task_has_pending = True
        if bool(record.get("needs_kconf")) != task_has_pending:
            raise CapacityPipelineError(
                f"summary.tasks[{task_index}].needs_kconf 与逐模型状态不一致",
                "ARTIFACT_INVALID",
            )
        resource_path = record.get("resource_artifact")
        if resource_path is not None:
            if not isinstance(resource_path, str) or not resource_path:
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].resource_artifact 非法",
                    "ARTIFACT_INVALID",
                )
            if "resource_evidence_id" in record:
                try:
                    validate_evidence_id_binding(
                        plan,
                        record,
                        id_field="resource_evidence_id",
                        path_field="resource_artifact",
                        role="resource",
                    )
                except ArtifactContractError as exc:
                    raise CapacityPipelineError(
                        str(exc), "ARTIFACT_INVALID"
                    ) from exc
            else:
                canonical_links = False
                bindings.append(
                    (
                        f"summary.tasks[{task_index}].resource_artifact",
                        resource_path,
                        "resource",
                    )
                )
            referenced_parents.append((Path(resource_path), "resource"))
    if bindings:
        try:
            validate_parent_path_bindings(plan, bindings)
        except ArtifactContractError as exc:
            raise CapacityPipelineError(str(exc), "ARTIFACT_INVALID") from exc

    if canonical_links:
        pending_count = sum(
            entry.get("needs_kconf") is True
            for record in task_records
            if isinstance(record, dict)
            for entry in record.get("model_entries", [])
            if isinstance(entry, dict)
        )
        if pending_count == 0:
            raise CapacityPipelineError(
                "容量计划没有待补充 KConf 的模型", "WORKFLOW_NOT_READY"
            )
        return referenced_parents

    pending_count = 0
    for task_index, record in enumerate(task_records):
        request = record.get("request")
        entries = record["model_entries"]
        if not isinstance(request, dict) or request.get("scenario") != record.get(
            "scenario"
        ):
            raise CapacityPipelineError(
                f"summary.tasks[{task_index}].request 与任务场景不一致",
                "ARTIFACT_INVALID",
            )
        base_paths = [
            Path(entry["base_artifact"]).expanduser().resolve() for entry in entries
        ]
        model_artifact_paths = [
            Path(entry["model_artifact"]).expanduser().resolve()
            for entry in entries
        ]
        complete, pending_indexes, canonical_rows = evaluate_task(
            request, base_paths, list(models), model_artifact_paths
        )
        pending_index_set = set(pending_indexes)
        for entry_index, entry in enumerate(entries):
            verified = load_model_resolution(
                Path(entry["model_artifact"]).expanduser().resolve(),
                expected_domain="capacity",
                allowed_scenarios={request["scenario"]},
            )
            if verified.model != entry["model"]:
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].model_entries[{entry_index}]"
                    ".model 与模型证据不一致",
                    "ARTIFACT_INVALID",
                )
            if without_evidence_links(
                record["results"][entry_index]
            ) != without_evidence_links(canonical_rows[entry_index]):
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].results[{entry_index}]"
                    " 与基础证据内容不一致",
                    "ARTIFACT_INVALID",
                )
            expected_pending = entry_index in pending_index_set
            if entry["needs_kconf"] is not expected_pending:
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].model_entries[{entry_index}]"
                    ".needs_kconf 与基础证据不一致",
                    "ARTIFACT_INVALID",
                )

        has_pending = bool(pending_indexes)
        if complete:
            expected_status = "success"
            expected_reason = "OK"
        elif has_pending:
            expected_status = "partial"
            expected_reason = "KCONF_REQUIRED"
        else:
            expected_status = (
                "error"
                if canonical_rows
                and all(row.get("status") == "error" for row in canonical_rows)
                else "partial"
            )
            expected_reason = next(
                (
                    str(row.get("reason_code"))
                    for row in canonical_rows
                    if row.get("reason_code") not in {None, "OK"}
                ),
                "CAPACITY_INCOMPLETE",
            )
        for field, expected in (
            ("complete", complete),
            ("needs_kconf", has_pending),
            ("status", expected_status),
            ("reason_code", expected_reason),
        ):
            if record.get(field) != expected:
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].{field} 与基础证据不一致",
                    "ARTIFACT_INVALID",
                )
        record["results"] = canonical_rows
        pending_count += len(pending_indexes)

    if pending_count == 0:
        raise CapacityPipelineError(
            "容量计划没有待补充 KConf 的模型", "WORKFLOW_NOT_READY"
        )
    return referenced_parents


def normalize_kconf_for_task(
    args: argparse.Namespace,
    task: dict[str, Any],
    entries: list[dict[str, Any]],
    task_dir: Path,
) -> tuple[dict[str, Any], list[tuple[Path, str]], list[tuple[Path, str]]]:
    output = task_dir / "kconf" / "manifest.json"
    selected_device_types = getattr(args, "parsed_device_type_selections", {})
    command = build_kconf_batch_command(
        python=sys.executable,
        script=KCONF_SCRIPT,
        tool_result=args.kconf_tool_result,
        model_artifacts=[entry["model_artifact"] for entry in entries],
        key=KCONF_KEY,
        stage=KCONF_STAGE,
        max_workers=args.max_workers,
        output_dir=task_dir / "kconf",
        output=output,
        device_type=args.device_type,
        device_type_selections={
            entry["model"]: selected_device_types[entry["model"]]
            for entry in entries
            if entry["model"] in selected_device_types
        },
    )
    manifest = run_artifact_command(command, output, "KConf 批量规范化")
    paths = kconf_paths_from_manifest(manifest)
    parents = [(output, "kconf_manifest")]
    parents.extend((path, "kconf") for path, _ in paths)
    return manifest, paths, parents


def run_final_headroom(
    args: argparse.Namespace,
    task: dict[str, Any],
    entries: list[dict[str, Any]],
    kconf_paths: list[tuple[Path, str]],
    task_dir: Path,
    resource_artifact: str | None = None,
) -> tuple[list[dict[str, Any]], list[tuple[Path, str]]]:
    results: list[dict[str, Any]] = []
    parents: list[tuple[Path, str]] = []
    if len(kconf_paths) != len(entries):
        raise CapacityPipelineError(
            f"任务 {task['task_id']} 的 KConf Artifact 数量不一致",
            "ARTIFACT_INVALID",
        )
    for index, entry in enumerate(entries):
        base_path, base_artifact = load_object(entry["base_artifact"])
        source = base_artifact.get("input")
        if not isinstance(source, dict):
            raise CapacityPipelineError(
                f"基础容量 Artifact 缺少 input：{base_path}", "ARTIFACT_INVALID"
            )
        normalized_input = task_dir / "inputs" / f"headroom-{index + 1:03d}.json"
        write_artifact(str(normalized_input), source)
        parents.append((normalized_input, "headroom_input"))
        kconf_path, kconf_status = kconf_paths[index]
        if kconf_status != "success":
            _, kconf_artifact = load_object(kconf_path)
            results.append(
                {
                    "artifact": str(base_path),
                    "status": "partial",
                    "reason_code": reason_code_for(kconf_artifact),
                    "summary": base_artifact.get("summary", {}),
                    "_evidence_status": base_artifact.get("status"),
                    "_evidence_reason_code": reason_code_for(base_artifact),
                    "kconf_artifact": str(kconf_path),
                    "warnings": kconf_artifact.get("warnings", []),
                    "errors": kconf_artifact.get("errors", []),
                }
            )
            continue
        output = task_dir / "results" / f"headroom-{index + 1:03d}.json"
        command = [
            sys.executable,
            "-B",
            str(CAPACITY_SCRIPT),
            "headroom",
            "--input",
            str(normalized_input),
            "--evidence-mode",
            "production",
            "--model-artifact",
            entry["model_artifact"],
            "--kconf-artifact",
            str(kconf_path),
            "--output",
            str(output),
        ]
        isvc_artifact_path = entry.get("isvc_artifact")
        if task["detail_level"] in {"cards", "resources"} and isvc_artifact_path:
            _, isvc_artifact = load_object(isvc_artifact_path)
            if isvc_artifact.get("status") == "success":
                command.extend(["--isvc-artifact", isvc_artifact_path])
        if task["detail_level"] == "resources" and resource_artifact:
            command.extend(["--resource-artifact", resource_artifact])
        artifact = run_artifact_command(command, output, "扩容证据计算")
        results.append(
            {
                "artifact": str(output),
                "status": artifact.get("status"),
                "reason_code": reason_code_for(artifact),
                "summary": artifact.get("summary", {}),
                "_evidence_status": artifact.get("status"),
                "_evidence_reason_code": reason_code_for(artifact),
                "kconf_artifact": str(kconf_path),
                "isvc_artifact": entry.get("isvc_artifact"),
                "warnings": artifact.get("warnings", []),
                "errors": artifact.get("errors", []),
            }
        )
        parents.append((output, "headroom_result"))
    return results, parents


def run_finalize(args: argparse.Namespace) -> dict[str, Any]:
    validate_runtime_args(args)
    plan_path, plan = load_object(args.plan_artifact)
    try:
        validate_provenance(
            plan,
            expected_artifact_type=PLAN_ARTIFACT_TYPE,
            expected_producer_script=PRODUCER_SCRIPT,
            expected_producer_version=SCRIPT_VERSION,
            expected_stage="awaiting_kconf",
            required_parent_roles=(
                "model_resolution",
                "capacity_result",
            ),
        )
    except ArtifactContractError as exc:
        raise CapacityPipelineError(str(exc), "ARTIFACT_INVALID") from exc
    if plan.get("status") not in {"success", "partial"}:
        raise CapacityPipelineError(
            "容量计划未进入 awaiting_kconf", "WORKFLOW_NOT_READY"
        )
    try:
        validate_kconf_next_action(
            plan.get("next_action"),
            tool=KCONF_TOOL,
            key=KCONF_KEY,
            stage=KCONF_STAGE,
            then_command="capacity-analyze-finalize",
            plan_path=plan_path,
            artifact=plan,
        )
    except ArtifactContractError as exc:
        raise CapacityPipelineError(str(exc), "ARTIFACT_INVALID") from exc
    summary = plan.get("summary")
    if not isinstance(summary, dict) or not isinstance(summary.get("tasks"), list):
        raise CapacityPipelineError("容量计划缺少 summary.tasks", "ARTIFACT_INVALID")
    task_records = copy.deepcopy(summary["tasks"])
    embedded_request = summary.get("request")
    if isinstance(embedded_request, dict) and all(
        isinstance(record, dict)
        and all(
            isinstance(entry, dict)
            and isinstance(entry.get("model_evidence_id"), str)
            and isinstance(entry.get("base_evidence_id"), str)
            for entry in record.get("model_entries", [])
        )
        for record in task_records
    ):
        bound_request, bound_tasks = normalize_request_object(
            embedded_request,
            reason_code="ARTIFACT_INVALID",
        )
    else:
        bound_request, bound_tasks = load_bound_capacity_request(plan)
    if summary.get("request") != bound_request or len(bound_tasks) != len(task_records):
        raise CapacityPipelineError(
            "容量计划请求与绑定的 capacity_request 不一致",
            "ARTIFACT_INVALID",
        )
    for task_index, (record, bound_task) in enumerate(zip(task_records, bound_tasks)):
        expected_request = json.loads(json.dumps(task_public_request(bound_task)))
        if not isinstance(record, dict) or record.get("request") != expected_request:
            raise CapacityPipelineError(
                f"summary.tasks[{task_index}].request 与绑定请求不一致",
                "ARTIFACT_INVALID",
            )
    referenced_plan_parents = validate_capacity_plan_entries(plan, task_records)
    try:
        device_type_selections = parse_named_selections(
            args.device_type_selection,
            option_name="device-type-selection",
        )
    except ValueError as exc:
        raise CapacityPipelineError(str(exc)) from exc
    if args.device_type and device_type_selections:
        raise CapacityPipelineError(
            "--device-type 与 --device-type-selection 不得同时使用"
        )
    plan_models = {
        str(entry.get("model"))
        for record in task_records
        if isinstance(record, dict)
        for entry in record.get("model_entries", [])
        if (
            isinstance(entry, dict)
            and entry.get("model")
            and entry.get("needs_kconf") is True
        )
    }
    unknown_selections = sorted(set(device_type_selections) - plan_models)
    if unknown_selections:
        raise CapacityPipelineError(
            "device-type-selection 的模型不在计划中："
            + ", ".join(unknown_selections)
        )
    args.parsed_device_type_selections = device_type_selections
    output_dir = Path(args.output_dir).expanduser().resolve()
    parent_paths: list[tuple[Path, str]] = [
        (plan_path, "capacity_plan"),
        (Path(args.kconf_tool_result), "kconf_tool_result"),
        *referenced_plan_parents,
    ]
    device_type_required: list[dict[str, Any]] = []
    for task_index, record in enumerate(task_records):
        if not record.get("needs_kconf"):
            continue
        request = record.get("request")
        entries = record.get("model_entries")
        if not isinstance(request, dict) or not isinstance(entries, list) or not entries:
            raise CapacityPipelineError(
                f"计划任务 {record.get('task_id')} 缺少请求或模型条目",
                "ARTIFACT_INVALID",
            )
        pending_entries = [
            entry for entry in entries if entry.get("needs_kconf") is True
        ]
        if not pending_entries:
            raise CapacityPipelineError(
                f"计划任务 {record.get('task_id')} 没有待补充 KConf 的模型",
                "ARTIFACT_INVALID",
            )
        task_dir = output_dir / f"task-{task_index + 1:03d}-{record['task_id']}"
        kconf_manifest, kconf_paths, kconf_parents = normalize_kconf_for_task(
            args, request, pending_entries, task_dir
        )
        parent_paths.extend(kconf_parents)
        final_rows, final_parents = run_final_headroom(
            args,
            request,
            pending_entries,
            kconf_paths,
            task_dir,
            resource_artifact=record.get("resource_artifact"),
        )
        parent_paths.extend(final_parents)
        merged_rows = list(record["results"])
        for entry, row in zip(pending_entries, final_rows):
            model_index = entry["index"]
            merged_rows[model_index] = row
            entry["result_artifact"] = row["artifact"]
            entry["kconf_artifact"] = row.get("kconf_artifact")
            entry["needs_kconf"] = False
        record["results"] = merged_rows
        record["kconf_status"] = kconf_manifest.get("status")
        complete = all(
            row.get("status") == "success"
            and final_detail_complete(
                request["detail_level"], row.get("summary", {})
            )
            for row in merged_rows
        )
        record["complete"] = complete
        record["needs_kconf"] = False
        record["status"] = "success" if complete else "partial"
        record["reason_code"] = "OK" if complete else "EVIDENCE_MISSING"
        record["warnings"] = [
            warning
            for row in merged_rows
            for warning in row.get("warnings", [])
            if isinstance(warning, str)
        ]
        record["errors"] = [
            error
            for row in merged_rows
            for error in row.get("errors", [])
            if isinstance(error, str)
        ]
        for path, status in kconf_paths:
            if status != "success":
                _, artifact = load_object(path)
                if artifact.get("summary", {}).get("decision") == "device_type_required":
                    device_type_required.append(
                        {
                            "model": artifact.get("summary", {}).get("model"),
                            "options": artifact.get("summary", {}).get(
                                "available_device_types", []
                            ),
                        }
                    )

    complete_count = sum(bool(item.get("complete")) for item in task_records)
    all_complete = complete_count == len(task_records)
    result_summary = {
        **{key: value for key, value in summary.items() if key != "tasks"},
        "decision": "capacity_analysis_finalized",
        "complete_task_count": complete_count,
        "partial_task_count": sum(not bool(item.get("complete")) for item in task_records),
        "tasks": task_records,
    }
    warnings = [
        f"{item['task_id']}: {warning}"
        for item in task_records
        for warning in item.get("warnings", [])
    ]
    errors = [
        f"{item['task_id']}: {error}"
        for item in task_records
        for error in item.get("errors", [])
    ]
    result = {
        "schema_version": "1.1",
        "script_version": SCRIPT_VERSION,
        "domain": "workflow",
        "scenario": "capacity-analyze-finalize",
        "status": "success" if all_complete else "partial",
        "generated_at": utc_now(),
        "summary": result_summary,
        "warnings": warnings,
        "errors": errors,
    }
    if device_type_required:
        next_action: Any = {
            "type": "request_device_type",
            "models": device_type_required,
            "then": (
                "使用同一 plan 和原始 KConf 返回重新运行 finalize，"
                "并为每个模型重复传 --device-type-selection MODEL=DEVICE"
            ),
        }
        reason_code = "DEVICE_TYPE_REQUIRED"
    else:
        next_action = {
            "type": "command",
            "command": "render-capacity-report",
            "arguments": {
                "manifest": str(Path(args.output).expanduser().resolve()),
                "output": str(output_dir / "capacity-analysis-report.json"),
            },
        }
        reason_code = "OK" if all_complete else "EVIDENCE_MISSING"
        attach_report_projection(result)
    annotate_outcome(
        result,
        complete=all_complete,
        reason_code=reason_code,
        next_action=next_action,
    )
    finalized = add_provenance(
        result,
        artifact_type=RESULT_ARTIFACT_TYPE,
        producer_script=PRODUCER_SCRIPT,
        producer_version=SCRIPT_VERSION,
        run_id=str(plan["run_id"]),
        stage="analysis_complete" if all_complete else "analysis_partial",
        parents=parent_references(parent_paths),
    )
    attach_capacity_evidence_ids(finalized)
    if finalized.get("report_projection") is not None:
        attach_report_projection(finalized)
    return finalized


def build_report_projection(
    summary: dict[str, Any],
    *,
    warnings: list[Any],
    errors: list[Any],
) -> dict[str, Any]:
    """Build the immutable report view at the Result boundary."""

    source_tasks = copy.deepcopy(summary.get("tasks"))
    if not isinstance(source_tasks, list):
        raise CapacityPipelineError("容量结果缺少 summary.tasks", "ARTIFACT_INVALID")
    try:
        report_tasks = build_report_tasks(source_tasks)
    except ValueError as exc:
        raise CapacityPipelineError(str(exc), "ARTIFACT_INVALID") from exc
    for task_index, (source_task, projected_task) in enumerate(
        zip(source_tasks, report_tasks)
    ):
        if not isinstance(source_task, dict):
            raise CapacityPipelineError(
                f"summary.tasks[{task_index}] 必须是对象", "ARTIFACT_INVALID"
            )
        for field in ("status", "complete"):
            if source_task.get(field) != projected_task[field]:
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].{field} 与报告投影不一致",
                    "ARTIFACT_INVALID",
                )
        source_rows = source_task.get("results")
        if not isinstance(source_rows, list):
            raise CapacityPipelineError(
                f"summary.tasks[{task_index}].results 必须是数组",
                "ARTIFACT_INVALID",
            )
        for row_index, (source_row, projected_model) in enumerate(
            zip(source_rows, projected_task["models"])
        ):
            if not isinstance(source_row, dict) or (
                source_row.get("status") != projected_model["status"]
            ):
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].results[{row_index}].status"
                    " 与报告投影不一致",
                    "ARTIFACT_INVALID",
                )
    complete_count = sum(bool(task["complete"]) for task in report_tasks)
    complete = bool(report_tasks) and complete_count == len(report_tasks)
    status = (
        "success"
        if complete
        else "error"
        if report_tasks and all(task["status"] == "error" for task in report_tasks)
        else "partial"
    )
    if summary.get("task_count") != len(report_tasks):
        raise CapacityPipelineError(
            "容量结果的 task_count 与报告投影不一致", "ARTIFACT_INVALID"
        )
    if summary.get("complete_task_count") != complete_count:
        raise CapacityPipelineError(
            "容量结果的 complete_task_count 与报告投影不一致",
            "ARTIFACT_INVALID",
        )
    return {
        "schema_version": "2.1",
        "status": status,
        "complete": complete,
        "reason_code": "OK" if complete else "EVIDENCE_MISSING",
        "task_count": len(report_tasks),
        "complete_task_count": complete_count,
        "tasks": report_tasks,
        "warnings": copy.deepcopy(warnings),
        "errors": copy.deepcopy(errors),
    }


def attach_report_projection(result: dict[str, Any]) -> None:
    summary = result.get("summary")
    if not isinstance(summary, dict):
        raise CapacityPipelineError("容量结果缺少 summary", "ARTIFACT_INVALID")
    result["report_projection"] = build_report_projection(
        summary,
        warnings=list(result.get("warnings", [])),
        errors=list(result.get("errors", [])),
    )


def _render_projected_report(
    *,
    manifest_path: Path,
    manifest: dict[str, Any],
) -> dict[str, Any]:
    try:
        validate_provenance(
            manifest,
            expected_artifact_type=RESULT_ARTIFACT_TYPE,
            expected_producer_script=PRODUCER_SCRIPT,
            expected_producer_version=SCRIPT_VERSION,
            verify_parent_hashes=False,
        )
    except ArtifactContractError as exc:
        raise CapacityPipelineError(str(exc), "ARTIFACT_INVALID") from exc
    if manifest.get("stage") not in {"analysis_complete", "analysis_partial"}:
        raise CapacityPipelineError(
            "容量结果尚未进入可报告阶段", "WORKFLOW_NOT_READY"
        )
    next_action = manifest.get("next_action")
    if (
        not isinstance(next_action, dict)
        or next_action.get("type") != "command"
        or next_action.get("command") != "render-capacity-report"
    ):
        raise CapacityPipelineError(
            "容量结果没有合法的报告 next_action", "WORKFLOW_NOT_READY"
        )
    summary = manifest.get("summary")
    if not isinstance(summary, dict):
        raise CapacityPipelineError("容量结果缺少 summary", "ARTIFACT_INVALID")
    expected = build_report_projection(
        summary,
        warnings=list(manifest.get("warnings", [])),
        errors=list(manifest.get("errors", [])),
    )
    if manifest.get("report_projection") != expected:
        raise CapacityPipelineError(
            "容量结果与固定报告投影不一致", "ARTIFACT_INVALID"
        )
    if (
        manifest.get("status") != expected["status"]
        or manifest.get("complete") is not expected["complete"]
    ):
        raise CapacityPipelineError(
            "容量结果状态与固定报告投影不一致", "ARTIFACT_INVALID"
        )
    report = {
        "schema_version": "1.1",
        "script_version": SCRIPT_VERSION,
        "domain": "capacity",
        "scenario": "capacity-analysis-report",
        "status": expected["status"],
        "generated_at": utc_now(),
        "summary": {
            "complete": expected["complete"],
            "task_count": expected["task_count"],
            "complete_task_count": expected["complete_task_count"],
            "tasks": copy.deepcopy(expected["tasks"]),
            "source_manifest": str(manifest_path),
            "write_performed": False,
        },
        "warnings": copy.deepcopy(expected["warnings"]),
        "errors": copy.deepcopy(expected["errors"]),
    }
    annotate_outcome(
        report,
        complete=expected["complete"],
        reason_code=expected["reason_code"],
        next_action="NONE",
    )
    return add_provenance(
        report,
        artifact_type=REPORT_ARTIFACT_TYPE,
        producer_script=PRODUCER_SCRIPT,
        producer_version=SCRIPT_VERSION,
        run_id=str(manifest["run_id"]),
        stage="report",
        parents=[
            artifact_reference(
                manifest_path,
                role="capacity_result",
                include_in_evidence=False,
            )
        ],
    )


def run_report(args: argparse.Namespace) -> dict[str, Any]:
    manifest_path, manifest = load_object(args.manifest)
    if manifest.get("report_projection") is not None:
        return _render_projected_report(
            manifest_path=manifest_path,
            manifest=manifest,
        )
    return _run_report_legacy(args, loaded=(manifest_path, manifest))


def _run_report_legacy(
    args: argparse.Namespace,
    *,
    loaded: tuple[Path, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    manifest_path, manifest = loaded or load_object(args.manifest)
    try:
        validate_provenance(
            manifest,
            expected_artifact_type=RESULT_ARTIFACT_TYPE,
            expected_producer_script=PRODUCER_SCRIPT,
            expected_producer_version=SCRIPT_VERSION,
        )
    except ArtifactContractError as exc:
        raise CapacityPipelineError(str(exc), "ARTIFACT_INVALID") from exc
    if manifest.get("stage") not in {"analysis_complete", "analysis_partial"}:
        raise CapacityPipelineError(
            "容量结果尚未进入可报告阶段", "WORKFLOW_NOT_READY"
        )
    next_action = manifest.get("next_action")
    if (
        not isinstance(next_action, dict)
        or next_action.get("type") != "command"
        or next_action.get("command") != "render-capacity-report"
    ):
        raise CapacityPipelineError(
            "容量结果没有合法的报告 next_action", "WORKFLOW_NOT_READY"
        )
    bound_request, bound_tasks = load_bound_capacity_request_for_result(manifest)
    summary = manifest.get("summary")
    if not isinstance(summary, dict) or not isinstance(summary.get("tasks"), list):
        raise CapacityPipelineError("容量结果缺少 summary.tasks", "ARTIFACT_INVALID")
    report_source_tasks = copy.deepcopy(summary["tasks"])
    if summary.get("request") != bound_request or len(bound_tasks) != len(
        report_source_tasks
    ):
        raise CapacityPipelineError(
            "容量结果请求与绑定的 capacity_request 不一致",
            "ARTIFACT_INVALID",
        )
    if summary.get("task_count") != len(report_source_tasks):
        raise CapacityPipelineError(
            "容量结果的 task_count 与 tasks 不一致", "ARTIFACT_INVALID"
        )
    if not isinstance(manifest.get("complete"), bool):
        raise CapacityPipelineError(
            "容量结果缺少布尔 complete", "ARTIFACT_INVALID"
        )
    bindings: list[tuple[str, str | Path, str | tuple[str, ...]]] = []
    for task_index, (task, bound_task) in enumerate(
        zip(report_source_tasks, bound_tasks)
    ):
        if not isinstance(task, dict):
            raise CapacityPipelineError(
                f"summary.tasks[{task_index}] 必须是对象", "ARTIFACT_INVALID"
            )
        if task.get("scenario") not in SCENARIOS:
            raise CapacityPipelineError(
                f"summary.tasks[{task_index}].scenario 非法",
                "ARTIFACT_INVALID",
            )
        expected_request = json.loads(json.dumps(task_public_request(bound_task)))
        if task.get("request") != expected_request:
            raise CapacityPipelineError(
                f"summary.tasks[{task_index}].request 与绑定请求不一致",
                "ARTIFACT_INVALID",
            )
        if not isinstance(task.get("complete"), bool):
            raise CapacityPipelineError(
                f"summary.tasks[{task_index}].complete 必须是布尔值",
                "ARTIFACT_INVALID",
            )
        models = task.get("models")
        rows = task.get("results")
        if not isinstance(models, list) or not isinstance(rows, list):
            raise CapacityPipelineError(
                f"summary.tasks[{task_index}] 缺少 models/results",
                "ARTIFACT_INVALID",
            )
        if len(models) != len(rows):
            raise CapacityPipelineError(
                f"summary.tasks[{task_index}] 的模型与结果数量不一致",
                "ARTIFACT_INVALID",
            )
        entries = task.get("model_entries")
        if not isinstance(entries, list) or len(entries) != len(rows):
            raise CapacityPipelineError(
                f"summary.tasks[{task_index}] 缺少与结果同序的 model_entries",
                "ARTIFACT_INVALID",
            )
        for row_index, row in enumerate(rows):
            if not isinstance(row, dict):
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].results[{row_index}] 必须是对象",
                    "ARTIFACT_INVALID",
                )
            artifact_path = row.get("artifact")
            if not isinstance(artifact_path, str) or not artifact_path:
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].results[{row_index}] 缺少 artifact",
                    "ARTIFACT_INVALID",
                )
            bindings.append(
                (
                    f"summary.tasks[{task_index}].results[{row_index}].artifact",
                    artifact_path,
                    ("capacity_result", "headroom_result"),
                )
            )
            entry = entries[row_index]
            if not isinstance(entry, dict):
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].model_entries[{row_index}] 必须是对象",
                    "ARTIFACT_INVALID",
                )
            model_artifact = entry.get("model_artifact")
            if not isinstance(model_artifact, str) or not model_artifact:
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].model_entries[{row_index}] 缺少 model_artifact",
                    "ARTIFACT_INVALID",
                )
            bindings.append(
                (
                    f"summary.tasks[{task_index}].model_entries[{row_index}].model_artifact",
                    model_artifact,
                    "model_resolution",
                )
            )
            for field, role in (
                ("kconf_artifact", "kconf"),
                ("isvc_artifact", "isvc"),
            ):
                evidence_path = row.get(field)
                if evidence_path is None:
                    continue
                if not isinstance(evidence_path, str) or not evidence_path:
                    raise CapacityPipelineError(
                        f"summary.tasks[{task_index}].results[{row_index}].{field} 非法",
                        "ARTIFACT_INVALID",
                    )
                bindings.append(
                    (
                        f"summary.tasks[{task_index}].results[{row_index}].{field}",
                        evidence_path,
                        role,
                    )
                )
    try:
        validate_parent_path_bindings(manifest, bindings)
    except ArtifactContractError as exc:
        raise CapacityPipelineError(str(exc), "ARTIFACT_INVALID") from exc
    for task_index, (task, bound_task) in enumerate(
        zip(report_source_tasks, bound_tasks)
    ):
        models = task["models"]
        for row_index, row in enumerate(task["results"]):
            _, source_artifact = load_object(row["artifact"])
            source_summary = source_artifact.get("summary")
            if (
                not isinstance(source_summary, dict)
                or row.get("summary") != source_summary
            ):
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].results[{row_index}].summary 与证据 Artifact 不一致",
                    "ARTIFACT_INVALID",
                )
            source_model = source_summary.get("model")
            if source_model is not None and source_model != models[row_index]:
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].results[{row_index}] 的模型与证据不一致",
                    "ARTIFACT_INVALID",
                )
            entry = task["model_entries"][row_index]
            try:
                validate_capacity_evidence_semantics(
                    source_artifact,
                    request=bound_task,
                    expected_model=models[row_index],
                    expected_model_artifact=entry["model_artifact"],
                    field=(
                        f"summary.tasks[{task_index}].results[{row_index}]"
                        ".artifact"
                    ),
                )
            except ArtifactContractError as exc:
                raise CapacityPipelineError(
                    str(exc), "ARTIFACT_INVALID"
                ) from exc
            row["_evidence_status"] = source_artifact.get("status")
            row["_evidence_reason_code"] = reason_code_for(source_artifact)
    try:
        report_tasks = build_report_tasks(report_source_tasks)
    except ValueError as exc:
        raise CapacityPipelineError(str(exc), "ARTIFACT_INVALID") from exc
    for task_index, (source_task, projected_task) in enumerate(
        zip(report_source_tasks, report_tasks)
    ):
        for field in ("status", "complete"):
            if source_task.get(field) != projected_task[field]:
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].{field} 与实际证据不一致",
                    "ARTIFACT_INVALID",
                )
        for row_index, (source_row, projected_model) in enumerate(
            zip(source_task["results"], projected_task["models"])
        ):
            if source_row.get("status") != projected_model["status"]:
                raise CapacityPipelineError(
                    f"summary.tasks[{task_index}].results[{row_index}].status"
                    " 与实际证据及请求深度不一致",
                    "ARTIFACT_INVALID",
                )

    complete_task_count = sum(task["complete"] for task in report_tasks)
    complete = bool(report_tasks) and complete_task_count == len(report_tasks)
    if complete:
        status = "success"
    elif report_tasks and all(task["status"] == "error" for task in report_tasks):
        status = "error"
    else:
        status = "partial"
    if summary.get("complete_task_count") != complete_task_count:
        raise CapacityPipelineError(
            "容量结果的 complete_task_count 与实际证据不一致",
            "ARTIFACT_INVALID",
        )
    if manifest.get("complete") is not complete or manifest.get("status") != status:
        raise CapacityPipelineError(
            "容量结果的 complete/status 与实际证据不一致",
            "ARTIFACT_INVALID",
        )
    expected_stage = "analysis_complete" if complete else "analysis_partial"
    if manifest.get("stage") != expected_stage:
        raise CapacityPipelineError(
            "容量结果 stage 与实际证据不一致", "ARTIFACT_INVALID"
        )
    report = {
        "schema_version": "1.1",
        "script_version": SCRIPT_VERSION,
        "domain": "capacity",
        "scenario": "capacity-analysis-report",
        "status": status,
        "generated_at": utc_now(),
        "summary": {
            "complete": complete,
            "task_count": len(report_tasks),
            "complete_task_count": sum(bool(task["complete"]) for task in report_tasks),
            "tasks": report_tasks,
            "source_manifest": str(manifest_path),
            "write_performed": False,
        },
        "warnings": list(manifest.get("warnings", [])),
        "errors": list(manifest.get("errors", [])),
    }
    annotate_outcome(
        report,
        complete=complete,
        reason_code="OK" if complete else "EVIDENCE_MISSING",
        next_action="NONE",
    )
    return add_provenance(
        report,
        artifact_type=REPORT_ARTIFACT_TYPE,
        producer_script=PRODUCER_SCRIPT,
        producer_version=SCRIPT_VERSION,
        run_id=str(manifest["run_id"]),
        stage="report",
        parents=[
            artifact_reference(
                manifest_path,
                role="capacity_result",
                include_in_evidence=False,
            )
        ],
    )


def error_artifact(*, scenario: str, error: Exception) -> dict[str, Any]:
    reason_code = (
        error.reason_code
        if isinstance(error, CapacityPipelineError)
        else "WORKFLOW_FAILED"
    )
    artifact = {
        "schema_version": "1.1",
        "script_version": SCRIPT_VERSION,
        "domain": "workflow",
        "scenario": scenario,
        "status": "error",
        "generated_at": utc_now(),
        "summary": {"decision": "workflow_failed", "write_performed": False},
        "warnings": [],
        "errors": [str(error)],
    }
    annotate_outcome(
        artifact,
        complete=False,
        reason_code=reason_code,
        next_action="STOP",
    )
    return artifact
