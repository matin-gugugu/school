#!/usr/bin/env python3
"""Deterministic capacity calculations and evidence shaping.

This module owns capacity formulas and normalized evidence calculations.  It
performs no ClickHouse or iSvc network queries; callers provide verified input
objects or Artifact paths.
"""

from __future__ import annotations

import json
import math
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from isvc import IsvcError, load_capacity_handoff, normalize_card_profile
from kconf import KconfError, load_capacity_handoff as load_kconf_handoff
from top_p_policy import (
    POLICY_SOURCE as TOP_P_POLICY_SOURCE,
    POLICY_VERSION as TOP_P_POLICY_VERSION,
    validate_candidate_prefix,
    validate_explicit_candidate_selection,
)


SCHEMA_VERSION = "1.0"
SCRIPT_VERSION = "0.34.0"
MIN_PERCENTILE_SAMPLE_COUNT = 10
CLOUD_RECLAIM_PERCENTILE = 0.90
PROFILE_BASES = {
    "observed",
    "observed_10m_average",
    "configured_capacity",
}
ROUTE_TYPES = {"cloud", "self_deployed"}
PROVIDER_SCOPE_BY_VALUE = {
    "public": "cloud",
    "internal": "self_deployed",
}
PRIORITY_VALUES = {"在线", "离线"}
GPU_CARDS_PER_EQUIVALENT_MACHINE = 8
CURRENT_USAGE_WINDOW_MINUTES = 10
TIANWEN_PERFORMANCE_DASHBOARD_URL = (
    "https://tianwen.corp.kuaishou.com/dashboard/50030/detail"
    "?instructionId=5530&activeTab=12"
)


class InputError(ValueError):
    """Raised when a capacity evidence file is structurally invalid."""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_object(path_value: str) -> dict[str, Any]:
    path = Path(path_value).expanduser().resolve()
    with path.open(encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise InputError("输入 JSON 必须是对象")
    return value


def write_artifact(path_value: str, value: dict[str, Any]) -> Path:
    path = Path(path_value).expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
        os.replace(temporary, path)
    except Exception:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise
    return path



def finite_number(value: Any, field: str, *, minimum: float = 0) -> float:
    if isinstance(value, bool):
        raise InputError(f"{field} 必须是数字")
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise InputError(f"{field} 必须是数字") from exc
    if not math.isfinite(number) or number < minimum:
        raise InputError(f"{field} 必须是大于等于 {minimum:g} 的有限数字")
    return number


def integer_timestamp(value: Any, field: str) -> int:
    number = finite_number(value, field)
    if number != int(number):
        raise InputError(f"{field} 必须是整数时间戳")
    return int(number)


def deep_get(value: dict[str, Any], dotted: str) -> Any:
    current: Any = value
    for part in dotted.split("."):
        if not isinstance(current, dict) or part not in current:
            return None
        current = current[part]
    return current


def read_number(
    value: dict[str, Any],
    dotted: str,
    missing: list[str],
    *,
    minimum: float | None = None,
    maximum: float | None = None,
    required: bool = True,
) -> float | None:
    raw = deep_get(value, dotted)
    if raw is None:
        if required:
            missing.append(dotted)
        return None
    if isinstance(raw, bool) or not isinstance(raw, (int, float)):
        raise InputError(f"{dotted} 必须是数字")
    number = float(raw)
    if not math.isfinite(number):
        raise InputError(f"{dotted} 必须是有限数字")
    if minimum is not None and number < minimum:
        raise InputError(f"{dotted} 不能小于 {minimum:g}")
    if maximum is not None and number > maximum:
        raise InputError(f"{dotted} 不能大于 {maximum:g}")
    return number


def read_text(
    value: dict[str, Any], dotted: str, missing: list[str]
) -> str | None:
    raw = deep_get(value, dotted)
    if raw is None or not str(raw).strip():
        missing.append(dotted)
        return None
    if not isinstance(raw, str):
        raise InputError(f"{dotted} 必须是字符串")
    return raw.strip()


def read_number_list(
    value: dict[str, Any],
    dotted: str,
    missing: list[str],
    *,
    minimum: float = 0,
    min_items: int = MIN_PERCENTILE_SAMPLE_COUNT,
) -> list[float] | None:
    raw = deep_get(value, dotted)
    if raw is None:
        missing.append(dotted)
        return None
    if not isinstance(raw, list):
        raise InputError(f"{dotted} 必须是数字数组")
    if len(raw) < min_items:
        missing.append(f"{dotted}[至少{min_items}个样本]")
        return None
    numbers: list[float] = []
    for index, item in enumerate(raw):
        if isinstance(item, bool) or not isinstance(item, (int, float)):
            raise InputError(f"{dotted}[{index}] 必须是数字")
        number = float(item)
        if not math.isfinite(number) or number < minimum:
            raise InputError(
                f"{dotted}[{index}] 必须是大于等于 {minimum:g} 的有限数字"
            )
        numbers.append(number)
    return numbers


def read_list(
    value: dict[str, Any], dotted: str, missing: list[str]
) -> list[Any] | None:
    raw = deep_get(value, dotted)
    if raw is None:
        missing.append(dotted)
        return None
    if not isinstance(raw, list):
        raise InputError(f"{dotted} 必须是数组")
    return raw


def read_cloud_minute_samples(
    value: dict[str, Any],
    dotted: str,
    missing: list[str],
) -> list[dict[str, float | int]] | None:
    raw = deep_get(value, dotted)
    if raw is None:
        missing.append(dotted)
        return None
    if not isinstance(raw, list):
        raise InputError(f"{dotted} 必须是数组")
    if len(raw) < MIN_PERCENTILE_SAMPLE_COUNT:
        missing.append(
            f"{dotted}[至少{MIN_PERCENTILE_SAMPLE_COUNT}个样本]"
        )
        return None

    samples: list[dict[str, float | int]] = []
    minute_starts: set[int] = set()
    for index, item in enumerate(raw):
        if not isinstance(item, dict):
            raise InputError(f"{dotted}[{index}] 必须是对象")
        minute_raw = item.get("minute_start_epoch_seconds")
        if isinstance(minute_raw, bool) or not isinstance(
            minute_raw, (int, float)
        ):
            raise InputError(
                f"{dotted}[{index}].minute_start_epoch_seconds 必须是数字"
            )
        minute_number = float(minute_raw)
        if (
            not math.isfinite(minute_number)
            or minute_number != int(minute_number)
            or int(minute_number) % 60 != 0
        ):
            raise InputError(
                f"{dotted}[{index}].minute_start_epoch_seconds "
                "必须是自然分钟 Unix 秒"
            )
        minute_start = int(minute_number)
        if minute_start in minute_starts:
            raise InputError(f"{dotted} 的分钟不能重复")
        minute_starts.add(minute_start)

        normalized: dict[str, float | int] = {
            "minute_start_epoch_seconds": minute_start
        }
        for field in ("capacity_tpm", "usage_tpm"):
            field_value = item.get(field)
            if isinstance(field_value, bool) or not isinstance(
                field_value, (int, float)
            ):
                raise InputError(f"{dotted}[{index}].{field} 必须是数字")
            number = float(field_value)
            if not math.isfinite(number) or number < 0:
                raise InputError(
                    f"{dotted}[{index}].{field} 必须是非负有限数字"
                )
            normalized[field] = number
        samples.append(normalized)
    return samples


def read_cloud_metric_samples(
    value: dict[str, Any],
    dotted: str,
    metric_field: str,
    missing: list[str],
) -> list[dict[str, float | int]] | None:
    raw = deep_get(value, dotted)
    if raw is None:
        missing.append(dotted)
        return None
    if not isinstance(raw, list):
        raise InputError(f"{dotted} 必须是数组")
    if len(raw) < MIN_PERCENTILE_SAMPLE_COUNT:
        missing.append(
            f"{dotted}[至少{MIN_PERCENTILE_SAMPLE_COUNT}个样本]"
        )
        return None

    samples: list[dict[str, float | int]] = []
    minute_starts: set[int] = set()
    for index, item in enumerate(raw):
        if not isinstance(item, dict):
            raise InputError(f"{dotted}[{index}] 必须是对象")
        minute_raw = item.get("minute_start_epoch_seconds")
        if isinstance(minute_raw, bool) or not isinstance(
            minute_raw, (int, float)
        ):
            raise InputError(
                f"{dotted}[{index}].minute_start_epoch_seconds 必须是数字"
            )
        minute_number = float(minute_raw)
        if (
            not math.isfinite(minute_number)
            or minute_number != int(minute_number)
            or int(minute_number) % 60 != 0
        ):
            raise InputError(
                f"{dotted}[{index}].minute_start_epoch_seconds "
                "必须是自然分钟 Unix 秒"
            )
        minute_start = int(minute_number)
        if minute_start in minute_starts:
            raise InputError(f"{dotted} 的分钟不能重复")
        minute_starts.add(minute_start)

        field_value = item.get(metric_field)
        if isinstance(field_value, bool) or not isinstance(
            field_value, (int, float)
        ):
            raise InputError(
                f"{dotted}[{index}].{metric_field} 必须是数字"
            )
        number = float(field_value)
        if not math.isfinite(number) or number < 0:
            raise InputError(
                f"{dotted}[{index}].{metric_field} 必须是非负有限数字"
            )
        samples.append(
            {
                "minute_start_epoch_seconds": minute_start,
                metric_field: number,
            }
        )
    return samples


def read_independent_cloud_samples(
    value: dict[str, Any],
    missing: list[str],
) -> tuple[
    list[dict[str, float | int]] | None,
    list[dict[str, float | int]] | None,
    str,
]:
    capacity_raw = deep_get(value, "cloud.capacity_minute_samples")
    usage_raw = deep_get(value, "cloud.usage_minute_samples")
    if capacity_raw is not None or usage_raw is not None:
        capacity_samples = read_cloud_metric_samples(
            value,
            "cloud.capacity_minute_samples",
            "capacity_tpm",
            missing,
        )
        usage_samples = read_cloud_metric_samples(
            value,
            "cloud.usage_minute_samples",
            "usage_tpm",
            missing,
        )
        return (
            capacity_samples,
            usage_samples,
            "independent_capacity_and_usage_complete_minute_sets",
        )

    legacy_samples = read_cloud_minute_samples(
        value, "cloud.minute_samples", missing
    )
    if legacy_samples is None:
        return None, None, "legacy_aligned_complete_minute_set"
    return (
        [
            {
                "minute_start_epoch_seconds": sample[
                    "minute_start_epoch_seconds"
                ],
                "capacity_tpm": sample["capacity_tpm"],
            }
            for sample in legacy_samples
        ],
        [
            {
                "minute_start_epoch_seconds": sample[
                    "minute_start_epoch_seconds"
                ],
                "usage_tpm": sample["usage_tpm"],
            }
            for sample in legacy_samples
        ],
        "legacy_aligned_complete_minute_set",
    )


def nearest_rank_p90_capacity_and_usage(
    capacity_samples: list[dict[str, float | int]],
    usage_samples: list[dict[str, float | int]],
) -> tuple[float, int, float, int]:
    capacity_p90_tpm, capacity_rank = nearest_rank_percentile(
        [float(sample["capacity_tpm"]) for sample in capacity_samples],
        CLOUD_RECLAIM_PERCENTILE,
    )
    traffic_p90_tpm, traffic_rank = nearest_rank_percentile(
        [float(sample["usage_tpm"]) for sample in usage_samples],
        CLOUD_RECLAIM_PERCENTILE,
    )
    return (
        capacity_p90_tpm,
        capacity_rank,
        traffic_p90_tpm,
        traffic_rank,
    )


def nearest_rank_percentile(
    samples: list[float], percentile: float
) -> tuple[float, int]:
    if not samples:
        raise InputError("分位值计算至少需要一个样本")
    if not 0 < percentile <= 1:
        raise InputError("percentile 必须在 (0, 1] 内")
    ordered = sorted(samples)
    rank = int(math.ceil(len(ordered) * percentile))
    return ordered[rank - 1], rank


def calculate_headroom_values(
    capacity_samples: list[float],
    traffic_samples: list[float],
    *,
    reserve_ratio: float,
    incremental_tpm: float | None,
) -> dict[str, float | int]:
    """Return the pure P90 headroom arithmetic used by capacity decisions."""

    capacity_p90, capacity_rank = nearest_rank_percentile(
        capacity_samples, CLOUD_RECLAIM_PERCENTILE
    )
    traffic_p90, traffic_rank = nearest_rank_percentile(
        traffic_samples, CLOUD_RECLAIM_PERCENTILE
    )
    reserved_tpm = capacity_p90 * reserve_ratio
    raw_headroom = capacity_p90 - traffic_p90
    usable_headroom = max(0.0, raw_headroom - reserved_tpm)
    deficit = (
        0.0
        if incremental_tpm is None
        else max(0.0, incremental_tpm - usable_headroom)
    )
    return {
        "capacity_p90_tpm": capacity_p90,
        "capacity_p90_rank": capacity_rank,
        "traffic_p90_tpm": traffic_p90,
        "traffic_p90_rank": traffic_rank,
        "reserved_tpm": reserved_tpm,
        "raw_headroom_tpm": raw_headroom,
        "usable_headroom_tpm": usable_headroom,
        "deficit_tpm": deficit,
    }


def required_instance_count(deficit_tpm: float, per_instance_tpm: float) -> int:
    """Return expansion instances using the established ceiling rule."""

    if deficit_tpm < 0 or per_instance_tpm <= 0:
        raise InputError("扩容实例换算要求非负缺口和正数单实例容量")
    return int(math.ceil(deficit_tpm / per_instance_tpm))


def expansion_resources(
    instances: int,
    *,
    gpu_cards_per_instance: int,
    gpu_cards_per_instance_by_type: dict[str, int] | None,
) -> dict[str, Any]:
    """Convert an expansion instance count to cards and 8-card machines."""

    cards = instances * gpu_cards_per_instance
    cards_by_type = (
        None
        if gpu_cards_per_instance_by_type is None
        else {
            card_type: instances * per_instance_cards
            for card_type, per_instance_cards
            in gpu_cards_per_instance_by_type.items()
        }
    )
    machines_by_type = (
        None
        if cards_by_type is None
        else {
            card_type: int(
                math.ceil(card_count / GPU_CARDS_PER_EQUIVALENT_MACHINE)
            )
            for card_type, card_count in cards_by_type.items()
        }
    )
    machines = (
        int(math.ceil(cards / GPU_CARDS_PER_EQUIVALENT_MACHINE))
        if machines_by_type is None
        else sum(machines_by_type.values())
    )
    return {
        "gpu_cards": cards,
        "gpu_cards_by_type": cards_by_type,
        "equivalent_machines": machines,
        "equivalent_machines_by_type": machines_by_type,
    }


def calculate_reclaim_candidate_metrics(
    capacity_samples: list[dict[str, float | int]],
    usage_samples: list[dict[str, float | int]],
    *,
    single_instance_capacity_tpm: float,
    gpu_cards_per_instance: int | None,
    gpu_cards_per_instance_by_type: dict[str, int] | None,
) -> dict[str, Any]:
    """Calculate one model's theoretical reclaim result without I/O."""

    (
        capacity_p90,
        capacity_rank,
        traffic_p90,
        traffic_rank,
    ) = nearest_rank_p90_capacity_and_usage(capacity_samples, usage_samples)
    reclaimable_tpm = max(capacity_p90 - traffic_p90, 0.0)
    instances = int(
        math.floor(reclaimable_tpm / single_instance_capacity_tpm)
    )
    cards = (
        None
        if gpu_cards_per_instance is None
        else instances * gpu_cards_per_instance
    )
    cards_by_type = (
        None
        if gpu_cards_per_instance_by_type is None
        else {
            card_type: instances * per_instance_cards
            for card_type, per_instance_cards
            in gpu_cards_per_instance_by_type.items()
        }
    )
    return {
        "capacity_p90_tpm": capacity_p90,
        "capacity_p90_rank": capacity_rank,
        "traffic_p90_tpm": traffic_p90,
        "traffic_p90_rank": traffic_rank,
        "reclaimable_tpm": reclaimable_tpm,
        "reclaimable_instances": instances,
        "reclaimable_gpu_cards": cards,
        "reclaimable_gpu_cards_by_type": cards_by_type,
        "reclaimable_8_card_machine_equivalents": (
            None
            if cards is None
            else round(cards / GPU_CARDS_PER_EQUIVALENT_MACHINE, 4)
        ),
        "reclaimable_8_card_machine_equivalents_by_type": (
            None
            if cards_by_type is None
            else {
                card_type: round(
                    card_count / GPU_CARDS_PER_EQUIVALENT_MACHINE, 4
                )
                for card_type, card_count in cards_by_type.items()
            }
        ),
    }


def align_reclaim_to_holdings(
    theoretical_cards_by_type: dict[str, int],
    held_cards_by_type: dict[str, int],
) -> dict[str, Any]:
    """Cap theoretical reclaim cards by current holdings for each card type."""

    aligned_by_type = {
        gpu_type: min(theoretical, held_cards_by_type.get(gpu_type, 0))
        for gpu_type, theoretical in theoretical_cards_by_type.items()
    }
    aligned_cards = sum(aligned_by_type.values())
    return {
        "gpu_cards": aligned_cards,
        "gpu_cards_by_type": dict(sorted(aligned_by_type.items())),
        "equivalent_machines": round(
            aligned_cards / GPU_CARDS_PER_EQUIVALENT_MACHINE, 4
        ),
        "equivalent_machines_by_type": {
            gpu_type: round(
                cards / GPU_CARDS_PER_EQUIVALENT_MACHINE, 4
            )
            for gpu_type, cards in sorted(aligned_by_type.items())
        },
    }


def parse_iso8601(value: str, field: str) -> datetime:
    normalized = value[:-1] + "+00:00" if value.endswith("Z") else value
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError as exc:
        raise InputError(f"{field} 必须是 ISO 8601 时间") from exc
    if parsed.tzinfo is None:
        raise InputError(f"{field} 必须包含时区")
    return parsed


def validate_window(
    source: dict[str, Any], missing: list[str]
) -> dict[str, str] | None:
    start = read_text(source, "window.start", missing)
    end = read_text(source, "window.end", missing)
    timezone_name = read_text(source, "window.timezone", missing)
    relation = read_text(source, "window.relation", missing)
    if None in (start, end, timezone_name, relation):
        return None
    start_time = parse_iso8601(str(start), "window.start")
    end_time = parse_iso8601(str(end), "window.end")
    if start_time >= end_time:
        raise InputError("window.start 必须早于 window.end")
    return {
        "start": str(start),
        "end": str(end),
        "timezone": str(timezone_name),
        "relation": str(relation),
    }


def validate_http_url(value: str, field: str) -> str:
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise InputError(f"{field} 必须是有效的 HTTP(S) URL")
    return value


def base_artifact(
    scenario: str, source: dict[str, Any]
) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "script_version": SCRIPT_VERSION,
        "domain": "capacity",
        "scenario": scenario,
        "status": "success",
        "generated_at": utc_now(),
        "input": source,
        "summary": {},
        "evidence": [],
        "handoffs": {},
        "warnings": [],
        "errors": [],
    }


def insufficient(
    scenario: str, source: dict[str, Any], missing: list[str]
) -> dict[str, Any]:
    artifact = base_artifact(scenario, source)
    artifact["status"] = "partial"
    artifact["summary"] = {
        "decision": "insufficient_data",
        "missing_fields": sorted(set(missing)),
        "write_performed": False,
    }
    artifact["warnings"] = ["证据字段不完整，未形成容量变更建议"]
    return artifact


def resource_machines_from_artifact(
    artifact_path: str, gpu_type: str
) -> tuple[int, dict[str, Any]]:
    value = load_object(artifact_path)
    if value.get("domain") != "resource":
        raise InputError("resource artifact 的 domain 必须是 resource")
    if value.get("status") != "success":
        raise InputError("resource artifact 的 status 必须是 success")
    summary = value.get("summary")
    if not isinstance(summary, dict):
        raise InputError("resource artifact 缺少 summary")
    rows = summary.get("resources")
    if not isinstance(rows, list):
        raise InputError("resource artifact 的 summary.resources 必须是数组")
    selected = [
        row for row in rows
        if isinstance(row, dict) and str(row.get("gpu_type", "")).upper() == gpu_type
    ]
    if len(selected) != 1:
        raise InputError(
            f"resource artifact 中必须恰好包含一个 {gpu_type} 资源行"
        )
    row = selected[0]
    for field in ("actual_available_machines", "equivalent_idle_machines"):
        raw = row.get(field)
        if raw is not None:
            if isinstance(raw, bool) or not isinstance(raw, (int, float)):
                raise InputError(f"resource artifact 的 {field} 必须是数字")
            if not math.isfinite(float(raw)):
                raise InputError(f"resource artifact 的 {field} 必须是有限数字")
            machines = int(math.floor(float(raw)))
            if machines < 0:
                raise InputError(f"resource artifact 的 {field} 不能为负数")
            return machines, {
                "artifact": str(Path(artifact_path).expanduser().resolve()),
                "generated_at": value.get("generated_at"),
                "scenario": value.get("scenario"),
                "gpu_type": gpu_type,
                "field": field,
            }
    raise InputError(
        "resource artifact 不包含 actual_available_machines 或 "
        "equivalent_idle_machines"
    )


def read_gpu_card_evidence(
    source: dict[str, Any], field_prefix: str = "isvc"
) -> tuple[int | None, dict[str, int] | None]:
    raw_total = deep_get(source, f"{field_prefix}.single_instance_gpu_cards")
    raw_profile = deep_get(
        source, f"{field_prefix}.single_instance_gpu_cards_by_type"
    )
    profile: dict[str, int] | None = None
    if raw_profile is not None:
        try:
            profile = normalize_card_profile(
                raw_profile,
                f"{field_prefix}.single_instance_gpu_cards_by_type",
            )
        except IsvcError as exc:
            raise InputError(str(exc)) from exc

    total: int | None = None
    if raw_total is not None:
        if (
            isinstance(raw_total, bool)
            or not isinstance(raw_total, (int, float))
            or not math.isfinite(float(raw_total))
            or int(raw_total) != raw_total
            or int(raw_total) < 1
        ):
            raise InputError(
                f"{field_prefix}.single_instance_gpu_cards 必须是正整数"
            )
        total = int(raw_total)
    if profile is not None:
        profile_total = sum(profile.values())
        if total is not None and total != profile_total:
            raise InputError(
                f"{field_prefix} 单实例总卡数与按卡型分项之和不一致"
            )
        total = profile_total
    return total, profile


def attach_isvc_artifact(
    source: dict[str, Any], artifact_path: str, expected_model: str
) -> dict[str, Any]:
    try:
        evidence = load_capacity_handoff(artifact_path, expected_model)
    except IsvcError as exc:
        raise InputError(str(exc)) from exc
    normalized = dict(source)
    normalized["isvc"] = evidence
    return normalized


def attach_kconf_artifact(
    source: dict[str, Any], artifact_path: str, expected_model: str
) -> dict[str, Any]:
    try:
        evidence = load_kconf_handoff(artifact_path, expected_model)
    except KconfError as exc:
        raise InputError(str(exc)) from exc
    normalized = dict(source)
    normalized["kconf"] = evidence
    return normalized


def headroom(
    source: dict[str, Any],
    resource_artifact: str | None,
    gpu_type: str | None,
) -> dict[str, Any]:
    missing: list[str] = []
    model = read_text(source, "model", missing)
    observed_at = read_text(source, "observed_at", missing)
    window = validate_window(source, missing)
    traffic_sample_field = (
        "traffic.tpm_samples"
        if deep_get(source, "traffic.tpm_samples") is not None
        else "traffic.self_deployed_tpm_samples"
    )
    samples = read_number_list(source, traffic_sample_field, missing)
    capacity_sample_field = "deployment.capacity_tpm_samples"
    capacity_samples = read_number_list(
        source, capacity_sample_field, missing
    )
    total_capacity = read_number(
        source,
        "deployment.total_capacity_tpm",
        missing,
        minimum=0,
        required=False,
    )
    ready_instances = read_number(
        source,
        "deployment.ready_instances",
        missing,
        minimum=0,
        required=False,
    )
    per_instance = read_number(
        source,
        "kconf.single_instance_capacity_tpm",
        missing,
        minimum=0,
        required=False,
    )
    gpu_cards_per_instance, gpu_cards_per_instance_by_type = (
        read_gpu_card_evidence(source)
    )
    target_tpm = read_number(
        source,
        "demand.incremental_tpm",
        missing,
        minimum=0,
        required=False,
    )
    reserve_ratio = read_number(
        source,
        "policy.reserve_ratio",
        missing,
        minimum=0,
        maximum=1,
        required=False,
    )
    detail_level = deep_get(source, "policy.detail_level") or "legacy"
    if detail_level not in {
        "legacy",
        "headroom",
        "decision",
        "instances",
        "cards",
        "resources",
    }:
        raise InputError("policy.detail_level 非法")
    direct_resource_machines = read_number(
        source,
        "resource.available_machines",
        missing,
        minimum=0,
        required=False,
    )

    if missing:
        return insufficient("headroom", source, missing)
    assert None not in (
        model,
        observed_at,
        window,
        samples,
        capacity_samples,
    )
    parse_iso8601(str(observed_at), "observed_at")
    headroom_values = calculate_headroom_values(
        capacity_samples,
        samples,
        reserve_ratio=reserve_ratio or 0,
        incremental_tpm=target_tpm,
    )
    capacity_p90 = float(headroom_values["capacity_p90_tpm"])
    capacity_p90_rank = int(headroom_values["capacity_p90_rank"])
    traffic_p90 = float(headroom_values["traffic_p90_tpm"])
    traffic_p90_rank = int(headroom_values["traffic_p90_rank"])
    provider_scope = (
        deep_get(source, "deployment.provider_scope")
        or deep_get(source, "filters.provider_scope")
    )
    if provider_scope is None and traffic_sample_field == "traffic.self_deployed_tpm_samples":
        provider_scope = "self_deployed"
    provider_label = {
        "self_deployed": "internal",
        "cloud": "public",
    }.get(provider_scope, "selected-provider")
    capacity_basis = (
        f"previous-day {provider_label} capacity nearest-rank P90 for headroom"
    )
    if ready_instances is not None:
        if ready_instances != int(ready_instances):
            raise InputError("deployment.ready_instances 必须是整数")
        if total_capacity is None and per_instance is not None:
            total_capacity = ready_instances * per_instance
    if total_capacity is None:
        total_capacity = capacity_p90
    reserved_tpm = float(headroom_values["reserved_tpm"])
    raw_headroom = float(headroom_values["raw_headroom_tpm"])
    usable_headroom = float(headroom_values["usable_headroom_tpm"])
    headroom_basis = (
        f"previous_day_{provider_label}_capacity_p90_minus_"
        f"{provider_label}_traffic_p90"
    )
    decision = "headroom_only"
    deficit = float(headroom_values["deficit_tpm"])
    required_instances: int | None = None
    required_gpu_cards: int | None = None
    required_gpu_cards_by_type: dict[str, int] | None = None
    required_equivalent_machines: int | None = None
    required_equivalent_machines_by_type: dict[str, int] | None = None
    available_machines: int | None = None
    available_machines_by_type: dict[str, int] | None = None
    resource_shortage_by_type: dict[str, int] | None = None
    resource_source: list[dict[str, Any]] | None = None
    warnings: list[str] = []
    status = "success"
    normalized_gpu = str(
        gpu_type or deep_get(source, "deployment.gpu_type") or ""
    ).upper()
    if gpu_cards_per_instance_by_type is None and (
        gpu_cards_per_instance is not None and normalized_gpu
    ):
        gpu_cards_per_instance_by_type = {
            normalized_gpu: gpu_cards_per_instance
        }
    elif gpu_cards_per_instance_by_type is not None and gpu_type:
        if len(gpu_cards_per_instance_by_type) != 1:
            raise InputError(
                "按卡型 iSvc 证据包含多个 GPU 型号时不得再传 --gpu"
            )
        profile_gpu = next(iter(gpu_cards_per_instance_by_type))
        if normalized_gpu != profile_gpu:
            raise InputError(
                f"--gpu={normalized_gpu} 与 iSvc 卡型 {profile_gpu} 不一致"
            )

    if target_tpm is not None:
        if deficit <= 0:
            decision = "can_serve"
        elif detail_level == "headroom":
            decision = "headroom_only"
        elif detail_level == "decision":
            decision = "expansion_required"
        elif per_instance is None or per_instance <= 0:
            decision = "insufficient_data"
            status = "partial"
            warnings.append(
                "容量不足，但缺少正数的 kconf.single_instance_capacity_tpm，"
                "无法计算扩容实例数"
            )
        else:
            required_instances = required_instance_count(
                deficit, per_instance
            )
            if detail_level == "instances":
                decision = "expansion_required_instances"
            elif gpu_cards_per_instance is None:
                decision = "insufficient_data"
                status = "partial"
                warnings.append(
                    "已算出扩容实例数，但缺少 iSvc 单实例部署卡数，"
                    "无法换算所需 GPU 卡数和 8 卡等效机器数"
                )
            else:
                expansion = expansion_resources(
                    required_instances,
                    gpu_cards_per_instance=gpu_cards_per_instance,
                    gpu_cards_per_instance_by_type=(
                        gpu_cards_per_instance_by_type
                    ),
                )
                required_gpu_cards = int(expansion["gpu_cards"])
                required_gpu_cards_by_type = expansion["gpu_cards_by_type"]
                required_equivalent_machines = int(
                    expansion["equivalent_machines"]
                )
                required_equivalent_machines_by_type = expansion[
                    "equivalent_machines_by_type"
                ]

                if detail_level == "cards":
                    decision = "expansion_required_cards"
                elif resource_artifact:
                    if gpu_cards_per_instance_by_type is None:
                        raise InputError(
                            "资源校验需要 iSvc 按卡型分项，或为旧标量输入提供 --gpu"
                        )
                    available_machines_by_type = {}
                    resource_source = []
                    for card_type in gpu_cards_per_instance_by_type:
                        machines, evidence = resource_machines_from_artifact(
                            resource_artifact, card_type
                        )
                        available_machines_by_type[card_type] = machines
                        resource_source.append(evidence)
                    available_machines = sum(
                        available_machines_by_type.values()
                    )
                    if direct_resource_machines is not None:
                        warnings.append(
                            "同时提供了 resource artifact 与 "
                            "resource.available_machines；以 artifact 为准"
                        )
                elif direct_resource_machines is not None:
                    if (
                        gpu_cards_per_instance_by_type is not None
                        and len(gpu_cards_per_instance_by_type) != 1
                    ):
                        raise InputError(
                            "混合卡型不能使用单个 resource.available_machines"
                        )
                    available_machines = int(
                        math.floor(direct_resource_machines)
                    )
                    card_type = (
                        next(iter(gpu_cards_per_instance_by_type))
                        if gpu_cards_per_instance_by_type
                        else normalized_gpu or "UNSPECIFIED"
                    )
                    available_machines_by_type = {
                        card_type: available_machines
                    }
                    resource_source = [
                        {
                            "field": "input.resource.available_machines",
                            "gpu_type": card_type,
                        }
                    ]

                if detail_level != "cards":
                    if available_machines_by_type is None:
                        decision = "expansion_required_resource_unverified"
                        if detail_level == "resources":
                            status = "partial"
                        warnings.append(
                            "缺少资源域 Artifact，无法确认所需机器是否可落地"
                        )
                    else:
                        if required_equivalent_machines_by_type is None:
                            card_type = next(iter(available_machines_by_type))
                            required_equivalent_machines_by_type = {
                                card_type: required_equivalent_machines
                            }
                        resource_shortage_by_type = {
                            card_type: max(
                                0,
                                required_machines
                                - available_machines_by_type.get(card_type, 0),
                            )
                            for card_type, required_machines
                            in required_equivalent_machines_by_type.items()
                        }
                        decision = (
                            "resource_shortage"
                            if any(resource_shortage_by_type.values())
                            else "expand_from_available_resources"
                        )

    artifact = base_artifact("headroom", source)
    artifact["status"] = status
    summary = {
        "model": model,
        "observed_at": observed_at,
        "window": window,
        "provider_scope": provider_scope,
        "decision": decision,
        "detail_level": detail_level,
        "capacity_basis": capacity_basis,
        "headroom_basis": headroom_basis,
        "installed_capacity_tpm": round(total_capacity, 4),
        "previous_day_capacity_p90_tpm": round(capacity_p90, 4),
        "previous_day_capacity_p90_rank": capacity_p90_rank,
        "previous_day_traffic_p90_tpm": round(traffic_p90, 4),
        "previous_day_traffic_p90_rank": traffic_p90_rank,
        "reserve_ratio": reserve_ratio or 0,
        "reserved_tpm": round(reserved_tpm, 4),
        "raw_headroom_tpm": round(raw_headroom, 4),
        "usable_headroom_tpm": round(usable_headroom, 4),
        "incremental_demand_tpm": (
            None if target_tpm is None else round(target_tpm, 4)
        ),
        "deficit_tpm": round(deficit, 4),
        "required_additional_instances": required_instances,
        "single_instance_gpu_cards": (
            None
            if gpu_cards_per_instance is None
            else gpu_cards_per_instance
        ),
        "single_instance_gpu_cards_by_type": (
            gpu_cards_per_instance_by_type
        ),
        "required_additional_gpu_cards": required_gpu_cards,
        "required_additional_gpu_cards_by_type": required_gpu_cards_by_type,
        "required_additional_8_card_machine_equivalents": (
            required_equivalent_machines
        ),
        "required_additional_8_card_machine_equivalents_by_type": (
            required_equivalent_machines_by_type
        ),
        "available_resource_machines": available_machines,
        "available_resource_machines_by_type": available_machines_by_type,
        "resource_shortage_8_card_machine_equivalents": (
            None
            if resource_shortage_by_type is None
            else sum(resource_shortage_by_type.values())
        ),
        "resource_shortage_8_card_machine_equivalents_by_type": (
            resource_shortage_by_type
        ),
        "next_step": None,
        "write_performed": False,
    }
    if provider_scope == "self_deployed":
        summary.update(
            {
                "previous_day_internal_capacity_p90_tpm": round(
                    capacity_p90, 4
                ),
                "previous_day_internal_capacity_p90_rank": capacity_p90_rank,
                "previous_day_internal_traffic_p90_tpm": round(
                    traffic_p90, 4
                ),
                "previous_day_internal_traffic_p90_rank": traffic_p90_rank,
            }
        )
    elif provider_scope == "cloud":
        summary.update(
            {
                "previous_day_public_capacity_p90_tpm": round(capacity_p90, 4),
                "previous_day_public_capacity_p90_rank": capacity_p90_rank,
                "previous_day_public_traffic_p90_tpm": round(traffic_p90, 4),
                "previous_day_public_traffic_p90_rank": traffic_p90_rank,
            }
        )
    artifact["summary"] = summary
    artifact["evidence"] = [
        {
            "name": "previous_day_capacity_traffic_p90",
            "provider_scope": provider_scope,
            "source_fields": [
                capacity_sample_field,
                traffic_sample_field,
            ],
            "sample_relation": (
                "independent_capacity_and_usage_complete_minute_sets"
            ),
            "sample_count": (
                len(samples)
                if len(capacity_samples) == len(samples)
                else None
            ),
            "capacity_sample_count": len(capacity_samples),
            "traffic_sample_count": len(samples),
            "percentile_method": "nearest-rank",
            "capacity_p90_tpm": round(capacity_p90, 4),
            "capacity_p90_rank": capacity_p90_rank,
            "traffic_p90_tpm": round(traffic_p90, 4),
            "traffic_p90_rank": traffic_p90_rank,
        },
        {
            "name": "resource_constraint",
            "source": resource_source,
        },
    ]
    if per_instance is not None:
        artifact["evidence"].append(
            {
                "name": "kconf_single_instance_capacity",
                "model": deep_get(source, "kconf.model") or model,
                "provider": deep_get(source, "kconf.provider"),
                "priority": deep_get(source, "kconf.priority"),
                "scene": deep_get(source, "kconf.scene"),
                "capacity_source": deep_get(
                    source, "kconf.capacity_source"
                ),
                "device_type": deep_get(source, "kconf.device_type"),
                "selection_rule": deep_get(
                    source, "kconf.selection_rule"
                ),
                "key": deep_get(source, "kconf.key"),
                "stage": deep_get(source, "kconf.stage"),
                "field_path": deep_get(source, "kconf.field_path"),
                "single_instance_capacity_tpm": round(per_instance, 4),
                "version": deep_get(source, "kconf.version"),
                "retrieved_at": deep_get(source, "kconf.retrieved_at"),
                "source_tool": deep_get(source, "kconf.source_tool"),
                "artifact": deep_get(source, "kconf.artifact"),
            }
        )
    artifact["warnings"] = warnings
    return artifact



def cloud_reclaim(source: dict[str, Any]) -> dict[str, Any]:
    missing: list[str] = []
    observed_at = read_text(source, "observed_at", missing)
    detail_level = source.get("detail_level", "machines")
    if detail_level not in {"instances", "cards", "machines"}:
        raise InputError(
            "detail_level 必须是 instances、cards 或 machines"
        )
    window = validate_window(source, missing)
    policy = deep_get(source, "policy")
    selection = deep_get(source, "selection")
    candidates = read_list(source, "candidates", missing)
    if missing:
        return insufficient("cloud-reclaim", source, missing)
    assert None not in (observed_at, window, candidates)
    if selection is not None:
        if policy is not None:
            raise InputError(
                "显式模型云上回收不接受 policy；不得同时使用显式模型和 Top P"
            )
        selected_models = validate_explicit_candidate_selection(
            selection, candidates
        )
        selection_mode = "explicit_models"
        gpu_type: str | None = None
        top_p: int | None = None
        selected_raw = candidates
    else:
        gpu_type, top_p, selected_models = validate_candidate_prefix(
            policy, candidates
        )
        selection_mode = "top_p"
        selected_raw = candidates[:top_p]
    parse_iso8601(str(observed_at), "observed_at")
    if window["relation"] != "previous_day":
        raise InputError("云上容量回收只接受 window.relation=previous_day")
    if not selected_raw:
        return insufficient(
            "cloud-reclaim", source, ["candidates[至少1个候选模型]"]
        )

    results: list[dict[str, Any]] = []
    missing_candidates: list[str] = []
    warnings: list[str] = []
    total_instances = 0
    total_gpu_cards = 0
    total_gpu_cards_by_type: dict[str, int] = {}
    instance_savings_complete = True
    gpu_card_savings_complete = True
    gpu_card_type_savings_complete = True

    for index, raw in enumerate(selected_raw):
        if not isinstance(raw, dict):
            raise InputError(f"candidates[{index}] 必须是对象")
        local_missing: list[str] = []
        model = read_text(raw, "model", local_missing)
        provider = read_text(raw, "cloud.provider", local_missing)
        priority = read_text(raw, "cloud.priority", local_missing)
        (
            capacity_minute_samples,
            usage_minute_samples,
            sample_relation,
        ) = read_independent_cloud_samples(
            raw, local_missing
        )
        per_instance = read_number(
            raw,
            "kconf.single_instance_capacity_tpm",
            local_missing,
            minimum=0,
        )
        kconf_key = read_text(raw, "kconf.key", local_missing)
        kconf_stage = read_text(raw, "kconf.stage", local_missing)
        kconf_field_path = read_text(
            raw, "kconf.field_path", local_missing
        )
        (
            gpu_cards_per_instance,
            gpu_cards_per_instance_by_type,
        ) = read_gpu_card_evidence(
            raw,
            "isvc",
        )
        if local_missing:
            qualified_missing = [
                f"candidates[{index}].{field}" for field in local_missing
            ]
            missing_candidates.extend(qualified_missing)
            instance_savings_complete = False
            gpu_card_savings_complete = False
            gpu_card_type_savings_complete = False
            results.append(
                {
                    "model": model or selected_models[index],
                    "status": "partial",
                    "decision": "insufficient_data",
                    "missing_fields": qualified_missing,
                }
            )
            continue
        assert None not in (
            model,
            provider,
            priority,
            capacity_minute_samples,
            usage_minute_samples,
            per_instance,
            kconf_key,
            kconf_stage,
            kconf_field_path,
        )
        if provider != "public":
            raise InputError(
                f"candidates[{index}].cloud.provider 必须是 public"
            )
        if priority != "在线":
            raise InputError(
                f"candidates[{index}].cloud.priority 必须是在线"
            )
        if per_instance <= 0:
            raise InputError(
                f"candidates[{index}].kconf.single_instance_capacity_tpm "
                "必须大于 0"
            )
        metrics = calculate_reclaim_candidate_metrics(
            capacity_minute_samples,
            usage_minute_samples,
            single_instance_capacity_tpm=per_instance,
            gpu_cards_per_instance=gpu_cards_per_instance,
            gpu_cards_per_instance_by_type=(
                gpu_cards_per_instance_by_type
            ),
        )
        capacity_p90 = float(metrics["capacity_p90_tpm"])
        capacity_p90_rank = int(metrics["capacity_p90_rank"])
        traffic_p90 = float(metrics["traffic_p90_tpm"])
        traffic_p90_rank = int(metrics["traffic_p90_rank"])
        reclaimable_tpm = float(metrics["reclaimable_tpm"])
        reclaimable_instances = int(metrics["reclaimable_instances"])
        reclaimable_gpu_cards = metrics["reclaimable_gpu_cards"]
        reclaimable_gpu_cards_by_type = metrics[
            "reclaimable_gpu_cards_by_type"
        ]
        reclaimable_8_card_machine_equivalents = metrics[
            "reclaimable_8_card_machine_equivalents"
        ]
        reclaimable_8_card_machine_equivalents_by_type = metrics[
            "reclaimable_8_card_machine_equivalents_by_type"
        ]
        total_instances += reclaimable_instances
        if reclaimable_gpu_cards is None:
            gpu_card_savings_complete = False
            gpu_card_type_savings_complete = False
            if detail_level != "instances":
                warnings.append(
                    f"{model} 尚缺 iSvc 单实例部署卡数；"
                    "本次只输出理论可回收内部实例数，不输出"
                    "理论节省卡数或 8 卡等效机器数"
                )
        else:
            total_gpu_cards += reclaimable_gpu_cards
            if reclaimable_gpu_cards_by_type is None:
                gpu_card_type_savings_complete = False
            else:
                for card_type, cards in reclaimable_gpu_cards_by_type.items():
                    total_gpu_cards_by_type[card_type] = (
                        total_gpu_cards_by_type.get(card_type, 0) + cards
                    )

        candidate_status = (
            "success"
            if detail_level == "instances" or reclaimable_gpu_cards is not None
            else "partial"
        )
        results.append(
            {
                "model": model,
                "status": candidate_status,
                "decision": (
                    "reclaimable_instances_calculated"
                    if detail_level == "instances"
                    else "reclaimable_resources_calculated"
                    if candidate_status == "success"
                    else "reclaimable_instances_calculated_cards_missing"
                ),
                "provider": provider,
                "priority": priority,
                "capacity_rule": (
                    "nearest-rank P90 of complete minute capacity"
                ),
                "traffic_rule": (
                    "nearest-rank P90 of complete minute usage"
                ),
                "sample_relation": sample_relation,
                "previous_day_complete_minute_count": (
                    len(capacity_minute_samples)
                    if len(capacity_minute_samples)
                    == len(usage_minute_samples)
                    else None
                ),
                "previous_day_capacity_complete_minute_count": len(
                    capacity_minute_samples
                ),
                "previous_day_traffic_complete_minute_count": len(
                    usage_minute_samples
                ),
                "previous_day_cloud_capacity_p90_rank": (
                    capacity_p90_rank
                ),
                "previous_day_cloud_traffic_p90_rank": traffic_p90_rank,
                "previous_day_cloud_capacity_p90_tpm": round(
                    capacity_p90, 4
                ),
                "previous_day_cloud_traffic_p90_tpm": round(
                    traffic_p90, 4
                ),
                "previous_day_cloud_traffic_peak_mean_tpm": round(
                    traffic_p90, 4
                ),
                "cloud_reclaimable_tpm": round(reclaimable_tpm, 4),
                "single_instance_capacity_tpm": round(per_instance, 4),
                "kconf_evidence": {
                    "key": kconf_key,
                    "stage": kconf_stage,
                    "field_path": kconf_field_path,
                    "scene": deep_get(raw, "kconf.scene"),
                    "capacity_source": deep_get(
                        raw, "kconf.capacity_source"
                    ),
                    "device_type": deep_get(raw, "kconf.device_type"),
                    "selection_rule": deep_get(
                        raw, "kconf.selection_rule"
                    ),
                    "version": deep_get(raw, "kconf.version"),
                    "retrieved_at": deep_get(raw, "kconf.retrieved_at"),
                    "source_tool": deep_get(raw, "kconf.source_tool"),
                    "artifact": deep_get(raw, "kconf.artifact"),
                },
                "reclaimable_instances": reclaimable_instances,
                "single_instance_gpu_cards": (
                    None
                    if gpu_cards_per_instance is None
                    else gpu_cards_per_instance
                ),
                "single_instance_gpu_cards_by_type": (
                    gpu_cards_per_instance_by_type
                ),
                "reclaimable_gpu_cards": reclaimable_gpu_cards,
                "reclaimable_gpu_cards_by_type": (
                    reclaimable_gpu_cards_by_type
                ),
                "reclaimable_8_card_machine_equivalents": (
                    reclaimable_8_card_machine_equivalents
                ),
                "reclaimable_8_card_machine_equivalents_by_type": (
                    reclaimable_8_card_machine_equivalents_by_type
                ),
                "isvc_evidence": (
                    None
                    if gpu_cards_per_instance is None
                    else {
                        "artifact": deep_get(raw, "isvc.artifact"),
                        "retrieved_at": deep_get(raw, "isvc.retrieved_at"),
                        "service_names": deep_get(raw, "isvc.service_names"),
                    }
                ),
            }
        )

    artifact = base_artifact("cloud-reclaim", source)
    if any(result.get("status") != "success" for result in results):
        artifact["status"] = "partial"
    evaluated_candidate_count = sum(
        "reclaimable_instances" in result for result in results
    )
    artifact["summary"] = {
        "decision": (
            "insufficient_data"
            if evaluated_candidate_count == 0
            else "partial_candidates_evaluated"
            if not instance_savings_complete
            else "cloud_reclaim_candidates_available"
            if total_instances > 0
            else "no_reclaimable_instance"
        ),
        "window": window,
        "selection_mode": selection_mode,
        "requested_detail": detail_level,
        "selected_models": selected_models,
        "gpu_type": gpu_type,
        "top_p": top_p,
        "top_p_models": (
            selected_models if selection_mode == "top_p" else None
        ),
        "top_p_policy_source": (
            TOP_P_POLICY_SOURCE if selection_mode == "top_p" else None
        ),
        "top_p_policy_version": (
            TOP_P_POLICY_VERSION if selection_mode == "top_p" else None
        ),
        "input_candidate_count": len(candidates),
        "candidate_count": len(results),
        "evaluated_candidate_count": evaluated_candidate_count,
        "partial_candidate_count": sum(
            result.get("status") == "partial" for result in results
        ),
        "candidates": results,
        "instance_savings_complete": instance_savings_complete,
        "reclaimable_instances_total": (
            total_instances if instance_savings_complete else None
        ),
        "reclaimable_instances_partial_sum": total_instances,
        "reclaimable_instances_capped_by_current_deployment": False,
        "gpu_card_savings_complete": gpu_card_savings_complete,
        "gpu_card_type_savings_complete": gpu_card_type_savings_complete,
        "reclaimable_gpu_cards_total": (
            total_gpu_cards if gpu_card_savings_complete else None
        ),
        "reclaimable_gpu_cards_total_by_type": (
            dict(sorted(total_gpu_cards_by_type.items()))
            if gpu_card_savings_complete and gpu_card_type_savings_complete
            else None
        ),
        "reclaimable_8_card_machine_equivalents_total": (
            round(
                total_gpu_cards / GPU_CARDS_PER_EQUIVALENT_MACHINE,
                4,
            )
            if gpu_card_savings_complete
            else None
        ),
        "reclaimable_8_card_machine_equivalents_total_by_type": (
            {
                card_type: round(
                    cards / GPU_CARDS_PER_EQUIVALENT_MACHINE,
                    4,
                )
                for card_type, cards
                in sorted(total_gpu_cards_by_type.items())
            }
            if gpu_card_savings_complete and gpu_card_type_savings_complete
            else None
        ),
        "write_performed": False,
    }
    if missing_candidates:
        artifact["summary"]["missing_fields"] = sorted(
            set(missing_candidates)
        )
        warnings.append(
            "部分模型证据不完整；已保留其他模型结果，"
            "汇总总量返回 null，partial_sum 仅表示已完成模型的小计"
        )
    artifact["evidence"] = [
        {
            "name": "formula",
            "previous_day_cloud_capacity": (
                "nearest-rank P90(previous-day complete minute capacity)"
            ),
            "previous_day_cloud_traffic_peak_mean": (
                "nearest-rank P90(previous-day complete minute usage)"
            ),
            "cloud_reclaimable_tpm": (
                "max(capacity_p90 - traffic_p90, 0)"
            ),
            "reclaimable_instances": (
                "floor(cloud_reclaimable_tpm / "
                "kconf.single_instance_capacity_tpm); "
                "not capped by current deployment count"
            ),
            "reclaimable_gpu_cards": (
                "按卡型计算 reclaimable_instances × "
                "isvc.single_instance_gpu_cards_by_type[gpu_type]"
            ),
            "reclaimable_8_card_machine_equivalents": (
                "按卡型计算 reclaimable_gpu_cards_by_type[gpu_type] / 8 "
                "后求和；允许小数，不代表空闲物理机器"
            ),
        }
    ]
    artifact["warnings"] = warnings
    return artifact


def reclaim_capacity(source: dict[str, Any]) -> dict[str, Any]:
    """Compatibility alias for the renamed cloud reclaim calculation."""
    return cloud_reclaim(source)


def traffic_profile(source: dict[str, Any]) -> dict[str, Any]:
    missing: list[str] = []
    model = read_text(source, "model", missing)
    observed_at = read_text(source, "observed_at", missing)
    as_of_minute = read_text(source, "as_of_minute", missing)
    priority = read_text(source, "priority", missing)
    basis = read_text(source, "tpm_basis", missing)
    window = validate_window(source, missing)
    routes = read_list(source, "routes", missing)
    if missing:
        return insufficient("traffic-profile", source, missing)
    assert None not in (
        model,
        observed_at,
        as_of_minute,
        priority,
        basis,
        window,
        routes,
    )
    parse_iso8601(str(observed_at), "observed_at")
    as_of_time = parse_iso8601(str(as_of_minute), "as_of_minute")
    if (
        as_of_time.second != 0
        or as_of_time.microsecond != 0
    ):
        raise InputError("as_of_minute 必须对齐到自然分钟起点")
    if basis not in PROFILE_BASES:
        raise InputError(
            "tpm_basis 仅支持 observed、observed_10m_average "
            "或 configured_capacity"
        )
    if priority not in PRIORITY_VALUES:
        raise InputError("priority 仅支持 在线 或 离线")
    if basis == "observed_10m_average":
        profile_window_start = parse_iso8601(
            window["start"], "window.start"
        )
        profile_window_end = parse_iso8601(window["end"], "window.end")
        if any(
            value.second != 0 or value.microsecond != 0
            for value in (profile_window_start, profile_window_end)
        ):
            raise InputError(
                "observed_10m_average 的 window 必须对齐自然分钟"
            )
        if (
            profile_window_end - profile_window_start
        ).total_seconds() != CURRENT_USAGE_WINDOW_MINUTES * 60:
            raise InputError(
                "observed_10m_average 的 window 必须恰好覆盖 10 分钟"
            )
        if as_of_time.timestamp() != profile_window_end.timestamp() - 60:
            raise InputError(
                "as_of_minute 必须是 observed_10m_average 窗口的最后一分钟"
            )
    if not routes:
        return insufficient("traffic-profile", source, ["routes[至少1项]"])

    normalized: list[dict[str, Any]] = []
    metric_missing: list[str] = []
    links: list[str] = [TIANWEN_PERFORMANCE_DASHBOARD_URL]
    total_tpm = 0.0
    totals = {"cloud": 0.0, "self_deployed": 0.0}
    inferred_zero_only_routes: list[str] = []
    seen_providers: set[str] = set()

    for index, raw in enumerate(routes):
        if not isinstance(raw, dict):
            raise InputError(f"routes[{index}] 必须是对象")
        local_missing: list[str] = []
        route_type = read_text(raw, "route_type", local_missing)
        provider = read_text(raw, "provider", local_missing)
        tpm = read_number(raw, "tpm", local_missing, minimum=0)
        if local_missing:
            missing.extend(
                f"routes[{index}].{field}" for field in local_missing
            )
            continue
        assert route_type is not None and provider is not None and tpm is not None
        if route_type not in ROUTE_TYPES:
            raise InputError(
                f"routes[{index}].route_type 仅支持 cloud 或 self_deployed"
            )
        if provider not in PROVIDER_SCOPE_BY_VALUE:
            raise InputError(
                f"routes[{index}].provider 仅支持 internal 或 public"
            )
        if provider in seen_providers:
            raise InputError(
                f"routes[{index}].provider={provider} 重复；"
                "每个 provider 只能有一条聚合 route"
            )
        seen_providers.add(provider)
        expected_route_type = PROVIDER_SCOPE_BY_VALUE[provider]
        if route_type != expected_route_type:
            raise InputError(
                f"routes[{index}] 的 provider={provider} 必须对应 "
                f"route_type={expected_route_type}"
            )
        if deep_get(raw, "supplier") is not None:
            raise InputError(
                f"routes[{index}].supplier 不受支持；"
                "云上统一使用 provider=public，不做供应商拆分"
            )
        usage_evidence = raw.get("usage_evidence")
        normalized_usage_evidence: dict[str, Any] | None = None
        if basis == "observed_10m_average":
            if not isinstance(usage_evidence, dict):
                local_missing.append("usage_evidence")
            else:
                evidence_missing: list[str] = []
                evidence_window_minutes = read_number(
                    usage_evidence,
                    "window_minutes",
                    evidence_missing,
                    minimum=1,
                )
                observed_minute_count = read_number(
                    usage_evidence,
                    "observed_minute_count",
                    evidence_missing,
                    minimum=0,
                )
                inferred_zero_count = read_number(
                    usage_evidence,
                    "inferred_zero_count",
                    evidence_missing,
                    minimum=0,
                )
                evidence_confidence = read_text(
                    usage_evidence,
                    "confidence",
                    evidence_missing,
                )
                if evidence_missing:
                    local_missing.extend(
                        "usage_evidence." + field
                        for field in evidence_missing
                    )
                else:
                    assert None not in (
                        evidence_window_minutes,
                        observed_minute_count,
                        inferred_zero_count,
                        evidence_confidence,
                    )
                    if evidence_window_minutes != CURRENT_USAGE_WINDOW_MINUTES:
                        raise InputError(
                            f"routes[{index}].usage_evidence.window_minutes "
                            f"必须是 {CURRENT_USAGE_WINDOW_MINUTES}"
                        )
                    if not all(
                        float(value).is_integer()
                        for value in (
                            evidence_window_minutes,
                            observed_minute_count,
                            inferred_zero_count,
                        )
                    ):
                        raise InputError(
                            f"routes[{index}].usage_evidence 分钟计数必须是整数"
                        )
                    if (
                        observed_minute_count + inferred_zero_count
                        != CURRENT_USAGE_WINDOW_MINUTES
                    ):
                        raise InputError(
                            f"routes[{index}].usage_evidence 的 observed 与 "
                            "inferred 计数之和必须等于 10"
                        )
                    allowed_confidence = {
                        "clickhouse_observed",
                        "observed_and_inferred_zero_sparse_contract",
                        "inferred_zero_only_sparse_contract",
                        "fixture_observed",
                    }
                    if evidence_confidence not in allowed_confidence:
                        raise InputError(
                            f"routes[{index}].usage_evidence.confidence "
                            "不受支持"
                        )
                    expected_counts_by_confidence = {
                        "clickhouse_observed": (10, 0),
                        "inferred_zero_only_sparse_contract": (0, 10),
                        "fixture_observed": (10, 0),
                    }
                    expected_counts = expected_counts_by_confidence.get(
                        evidence_confidence
                    )
                    if expected_counts is not None and (
                        observed_minute_count,
                        inferred_zero_count,
                    ) != expected_counts:
                        raise InputError(
                            f"routes[{index}].usage_evidence 的分钟计数与 "
                            "confidence 不一致"
                        )
                    if (
                        evidence_confidence
                        == "observed_and_inferred_zero_sparse_contract"
                        and not (
                            0 < observed_minute_count < 10
                            and 0 < inferred_zero_count < 10
                        )
                    ):
                        raise InputError(
                            f"routes[{index}].usage_evidence 的混合置信度 "
                            "必须同时包含原始观测和补零分钟"
                        )
                    normalized_usage_evidence = {
                        "window_minutes": int(evidence_window_minutes),
                        "observed_minute_count": int(
                            observed_minute_count
                        ),
                        "inferred_zero_count": int(inferred_zero_count),
                        "confidence": evidence_confidence,
                    }
                    if (
                        evidence_confidence
                        == "inferred_zero_only_sparse_contract"
                    ):
                        inferred_zero_only_routes.append(provider)
        if local_missing:
            missing.extend(
                f"routes[{index}].{field}" for field in local_missing
            )
            continue
        cache_hit_rate = read_number(
            raw,
            "performance.cache_hit_rate",
            local_missing,
            minimum=0,
            maximum=1,
            required=False,
        )
        ttft = read_number(
            raw,
            "performance.ttft_ms",
            local_missing,
            minimum=0,
            required=False,
        )
        tpot = read_number(
            raw,
            "performance.tpot_ms",
            local_missing,
            minimum=0,
            required=False,
        )
        link = deep_get(raw, "performance.tianwen_url")
        if link is not None:
            if not isinstance(link, str) or not link.strip():
                raise InputError(
                    f"routes[{index}].performance.tianwen_url 必须是字符串"
                )
            link = validate_http_url(
                link.strip(),
                f"routes[{index}].performance.tianwen_url",
            )
            if link not in links:
                links.append(link)
        for field, value in (
            ("cache_hit_rate", cache_hit_rate),
            ("ttft_ms", ttft),
            ("tpot_ms", tpot),
        ):
            if value is None:
                metric_missing.append(
                    f"routes[{index}].performance.{field}"
                )
        total_tpm += tpm
        totals[route_type] += tpm
        normalized_route = {
            "route_type": route_type,
            "provider": provider,
            "tpm": round(tpm, 4),
            "share": None,
            "cache_hit_rate": cache_hit_rate,
            "ttft_ms": ttft,
            "tpot_ms": tpot,
            "tianwen_url": link,
        }
        if normalized_usage_evidence is not None:
            normalized_route["usage_evidence"] = normalized_usage_evidence
        normalized.append(normalized_route)

    if missing:
        return insufficient("traffic-profile", source, missing)
    zero_traffic = total_tpm == 0
    provider_shares_reportable = (
        not zero_traffic and not inferred_zero_only_routes
    )
    for route in normalized:
        route["share"] = (
            None
            if not provider_shares_reportable
            else round(route["tpm"] / total_tpm, 6)
        )

    warnings: list[str] = []
    status = "success"
    if basis == "configured_capacity":
        warnings.append(
            "TPM 来自配置容量，只能解释配置分配，不能表述为实际流量"
        )
    if zero_traffic:
        warnings.append(
            (
                "当前10分钟平均总 TPM 为 0；provider 占比无定义，返回 null"
                if basis == "observed_10m_average"
                else "当前分钟总 TPM 为 0；provider 占比无定义，返回 null"
            )
        )
    if inferred_zero_only_routes:
        status = "partial"
        warnings.append(
            "以下 provider 的10分钟样本全部来自稀疏写入补零："
            + ",".join(inferred_zero_only_routes)
            + "；所有 provider 占比返回 null，不得断言其无流量，"
            "也不得据此表述其他 provider 占比为 100%"
        )
    if metric_missing:
        status = "partial"
        warnings.append(
            "部分 cache 命中率、TTFT 或 TPOT 缺失；仅返回已有指标和天问链接"
        )

    artifact = base_artifact("traffic-profile", source)
    artifact["status"] = status
    artifact["summary"] = {
        "model": model,
        "observed_at": observed_at,
        "as_of_minute": as_of_minute,
        "priority": priority,
        "window": window,
        "tpm_basis": basis,
        "tpm_aggregation": (
            "arithmetic_mean"
            if basis == "observed_10m_average"
            else "point_in_time"
        ),
        "tpm_window_minutes": (
            CURRENT_USAGE_WINDOW_MINUTES
            if basis == "observed_10m_average"
            else None
        ),
        "total_tpm": round(total_tpm, 4),
        "zero_traffic": zero_traffic,
        "provider_shares_reportable": provider_shares_reportable,
        "cloud_tpm": round(totals["cloud"], 4),
        "cloud_share": (
            None
            if not provider_shares_reportable
            else round(totals["cloud"] / total_tpm, 6)
        ),
        "self_deployed_tpm": round(totals["self_deployed"], 4),
        "self_deployed_share": (
            None
            if not provider_shares_reportable
            else round(totals["self_deployed"] / total_tpm, 6)
        ),
        "routes": normalized,
        "tianwen_links": links,
        "missing_performance_fields": metric_missing,
        "inferred_zero_only_providers": inferred_zero_only_routes,
        "write_performed": False,
    }
    artifact["warnings"] = warnings
    return artifact

