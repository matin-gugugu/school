#!/usr/bin/env python3
"""Shared outcome and provenance contract for Wanqing Artifacts."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Iterable

from workflow_core import (
    EVIDENCE_SCHEMA_VERSION,
    WorkflowCoreError,
    WorkflowOutcome,
    apply_outcome,
    build_evidence_index,
    checkpoint_for,
    evidence_paths_by_role,
    source_evidence_from_artifact,
    validate_checkpoint_projection,
    validate_outcome_projection,
)


OUTCOME_SCHEMA_VERSION = "1.0"
VALID_STATUSES = {"success", "partial", "error"}

DECISION_REASON_CODES = {
    "model_candidates_ready": "OK",
    "model_candidates_batch_ready": "OK",
    "model_candidate_query_failed": "QUERY_FAILED",
    "model_candidates_batch_failed": "QUERY_FAILED",
    "model_candidates_batch_partial": "QUERY_FAILED",
    "query_failed": "QUERY_FAILED",
    "resolved": "OK",
    "batch_resolved": "OK",
    "model_not_found": "MODEL_NOT_FOUND",
    "user_confirmation_required": "MODEL_CONFIRMATION_REQUIRED",
    "resolution_failed": "MODEL_RESOLUTION_FAILED",
    "batch_resolution_failed": "MODEL_RESOLUTION_FAILED",
    "batch_resolution_incomplete": "MODEL_RESOLUTION_FAILED",
    "query_or_normalization_failed": "QUERY_FAILED",
    "batch_query_failed": "QUERY_FAILED",
    "response_normalization_failed": "QUERY_FAILED",
    "single_instance_capacity_not_found": "KCONF_MISSING",
    "device_type_required": "DEVICE_TYPE_REQUIRED",
    "device_type_not_found": "DEVICE_TYPE_REQUIRED",
    "query_result_normalization_failed": "KCONF_INVALID",
    "single_instance_capacity_ready": "OK",
    "invalid_input": "INVALID_INPUT",
    "workflow_failed": "WORKFLOW_FAILED",
    "insufficient_data": "EVIDENCE_MISSING",
    "no_reclaimable_instance": "OK",
    "cloud_reclaim_candidates_available": "OK",
    "capacity_analysis_completed": "OK",
    "capacity_analysis_finalized": "OK",
}


class ArtifactContractError(ValueError):
    """Raised when an Artifact fails the trusted workflow contract."""


def sha256_file(path_value: str | Path) -> str:
    path = Path(path_value).expanduser().resolve()
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def artifact_reference(
    path_value: str | Path,
    *,
    role: str,
    artifact_type: str | None = None,
    include_in_evidence: bool = True,
) -> dict[str, Any]:
    path = Path(path_value).expanduser().resolve()
    digest = sha256_file(path)
    value = {
        "role": role,
        "path": str(path),
        "sha256": digest,
    }
    if artifact_type:
        value["artifact_type"] = artifact_type
    if not include_in_evidence:
        value["lineage_only"] = True
        return value
    try:
        with path.open(encoding="utf-8") as handle:
            artifact = json.load(handle)
    except (OSError, UnicodeError, json.JSONDecodeError):
        artifact = None
    if isinstance(artifact, dict):
        value["source_evidence"] = source_evidence_from_artifact(
            artifact=artifact,
            path=path,
            content_digest=digest,
            role=role,
            source=artifact_type,
        ).as_dict()
    return value


def reason_code_for(artifact: dict[str, Any]) -> str:
    explicit = artifact.get("reason_code")
    if isinstance(explicit, str) and explicit.strip():
        return explicit.strip()

    summary = artifact.get("summary")
    decision = summary.get("decision") if isinstance(summary, dict) else None
    if isinstance(decision, str) and decision in DECISION_REASON_CODES:
        return DECISION_REASON_CODES[decision]
    if (
        isinstance(summary, dict)
        and summary.get("candidate_count") == 0
        and artifact.get("status") == "success"
    ):
        return "NO_ROWS"

    status = artifact.get("status")
    if status == "success":
        return "OK"
    if status == "partial":
        return "EVIDENCE_MISSING"
    return "UNCLASSIFIED_ERROR"


def next_action_for(artifact: dict[str, Any], reason_code: str) -> Any:
    if "next_action" in artifact:
        return artifact["next_action"]
    if reason_code == "MODEL_CONFIRMATION_REQUIRED":
        return "REQUEST_MODEL_CONFIRMATION"
    if reason_code == "DEVICE_TYPE_REQUIRED":
        return "REQUEST_DEVICE_TYPE"
    if artifact.get("status") == "error":
        return "STOP"
    return "NONE"


def annotate_outcome(
    artifact: dict[str, Any],
    *,
    complete: bool | None = None,
    reason_code: str | None = None,
    next_action: Any | None = None,
) -> dict[str, Any]:
    status = artifact.get("status")
    if status not in VALID_STATUSES:
        raise ArtifactContractError(
            "Artifact status 必须是 success、partial 或 error"
        )
    resolved_reason = reason_code or reason_code_for(artifact)
    artifact["outcome_schema_version"] = OUTCOME_SCHEMA_VERSION
    if complete is None and isinstance(artifact.get("complete"), bool):
        resolved_complete = bool(artifact["complete"])
    else:
        resolved_complete = status == "success" if complete is None else complete
    resolved_action: Any
    if next_action is not None:
        resolved_action = next_action
    elif "next_action" not in artifact:
        resolved_action = next_action_for(artifact, resolved_reason)
    else:
        resolved_action = artifact["next_action"]
    try:
        outcome = WorkflowOutcome.from_legacy(
            status=str(status),
            complete=bool(resolved_complete),
            reason_code=resolved_reason,
            next_action=resolved_action,
        )
        apply_outcome(artifact, outcome)
    except WorkflowCoreError as exc:
        raise ArtifactContractError(str(exc)) from exc
    return artifact


def terminal_brief(
    artifact: dict[str, Any],
    output_path: str | Path,
    *,
    flatten_summary: bool = False,
) -> dict[str, Any]:
    annotate_outcome(artifact)
    summary = artifact.get("summary", {})
    brief: dict[str, Any] = {
        "status": artifact["status"],
        "reason_code": artifact["reason_code"],
        "complete": artifact["complete"],
        "artifact": str(Path(output_path).expanduser().resolve()),
        "summary": summary,
        "warnings": artifact.get("warnings", []),
        "errors": artifact.get("errors", []),
        "next_action": artifact.get("next_action", "NONE"),
    }
    if flatten_summary and isinstance(summary, dict):
        brief.update(summary)
    return brief


def add_provenance(
    artifact: dict[str, Any],
    *,
    artifact_type: str,
    producer_script: str,
    producer_version: str,
    run_id: str,
    stage: str,
    parents: Iterable[dict[str, Any]] = (),
) -> dict[str, Any]:
    artifact["artifact_type"] = artifact_type
    artifact["run_id"] = run_id
    artifact["stage"] = stage
    parent_list = list(parents)
    artifact["provenance"] = {
        "producer": {
            "script": producer_script,
            "version": producer_version,
        },
        "parents": parent_list,
    }
    try:
        artifact["evidence_index"] = build_evidence_index(parent_list)
        outcome = validate_outcome_projection(artifact)
        checkpoint = checkpoint_for(
            run_id=run_id,
            stage=stage,
            outcome=outcome,
        )
    except WorkflowCoreError as exc:
        raise ArtifactContractError(str(exc)) from exc
    if checkpoint is None:
        artifact.pop("checkpoint", None)
    else:
        artifact["checkpoint"] = checkpoint
    return artifact


def validate_provenance(
    artifact: dict[str, Any],
    *,
    expected_artifact_type: str,
    expected_producer_script: str,
    expected_producer_version: str | None = None,
    expected_stage: str | None = None,
    verify_parent_hashes: bool = True,
    required_parent_roles: Iterable[str] = (),
) -> None:
    if artifact.get("artifact_type") != expected_artifact_type:
        raise ArtifactContractError(
            f"Artifact 类型必须是 {expected_artifact_type}"
        )
    run_id = artifact.get("run_id")
    if not isinstance(run_id, str) or not run_id.strip():
        raise ArtifactContractError("Artifact 缺少 run_id")
    if expected_stage is not None and artifact.get("stage") != expected_stage:
        raise ArtifactContractError(f"Artifact stage 必须是 {expected_stage}")
    provenance = artifact.get("provenance")
    if not isinstance(provenance, dict):
        raise ArtifactContractError("Artifact 缺少 provenance")
    producer = provenance.get("producer")
    if not isinstance(producer, dict):
        raise ArtifactContractError("Artifact 缺少 provenance.producer")
    if producer.get("script") != expected_producer_script:
        raise ArtifactContractError(
            f"Artifact producer 必须是 {expected_producer_script}"
        )
    version = producer.get("version")
    if not isinstance(version, str) or not version.strip():
        raise ArtifactContractError("Artifact producer 缺少 version")
    if expected_producer_version is not None and version != expected_producer_version:
        raise ArtifactContractError(
            f"Artifact producer.version 必须是 {expected_producer_version}"
        )
    try:
        validate_outcome_projection(artifact)
        validate_checkpoint_projection(artifact)
    except WorkflowCoreError as exc:
        raise ArtifactContractError(str(exc)) from exc
    parents = provenance.get("parents")
    evidence_index = artifact.get("evidence_index")
    canonical_evidence = (
        isinstance(evidence_index, dict)
        and evidence_index.get("schema_version") == EVIDENCE_SCHEMA_VERSION
    )
    if canonical_evidence:
        try:
            indexed_paths = evidence_paths_by_role(artifact)
        except WorkflowCoreError as exc:
            raise ArtifactContractError(str(exc)) from exc
        roles = set(indexed_paths)
    else:
        if not isinstance(parents, list):
            raise ArtifactContractError("Artifact provenance.parents 必须是数组")
        roles = {
            parent.get("role")
            for parent in parents
            if isinstance(parent, dict) and isinstance(parent.get("role"), str)
        }
    missing_roles = sorted(set(required_parent_roles) - roles)
    if missing_roles:
        raise ArtifactContractError(
            "Artifact 缺少必需父证据角色：" + ", ".join(missing_roles)
        )
    if evidence_index is not None and not canonical_evidence:
        try:
            indexed_paths = evidence_paths_by_role(artifact)
        except WorkflowCoreError as exc:
            raise ArtifactContractError(str(exc)) from exc
        parent_paths: dict[str, set[Path]] = {}
        for parent in parents:
            if not isinstance(parent, dict):
                continue
            role = parent.get("role")
            path_value = parent.get("path")
            if isinstance(role, str) and isinstance(path_value, str):
                parent_paths.setdefault(role, set()).add(
                    Path(path_value).expanduser().resolve()
                )
        if indexed_paths != parent_paths:
            raise ArtifactContractError(
                "canonical evidence_index 与兼容 provenance.parents 不一致"
            )
    if not verify_parent_hashes:
        return
    if canonical_evidence:
        expected_by_path: dict[Path, str] = {}
        for item_index, item in enumerate(evidence_index["items"]):
            digest = item.get("content_digest")
            locations = item.get("locations")
            if not isinstance(digest, str) or len(digest) != 64:
                raise ArtifactContractError(
                    f"evidence_index.items[{item_index}] 缺少 content_digest"
                )
            if not isinstance(locations, list) or not locations:
                raise ArtifactContractError(
                    f"evidence_index.items[{item_index}] 缺少 locations"
                )
            for path_value in locations:
                if not isinstance(path_value, str) or not path_value:
                    raise ArtifactContractError(
                        f"evidence_index.items[{item_index}] 包含无效路径"
                    )
                path = Path(path_value).expanduser().resolve()
                previous = expected_by_path.setdefault(path, digest)
                if previous != digest:
                    raise ArtifactContractError(
                        f"同一证据路径对应多个内容摘要：{path}"
                    )
        for path, expected_digest in expected_by_path.items():
            try:
                actual_digest = sha256_file(path)
            except OSError as exc:
                raise ArtifactContractError(f"证据不可读取：{path}") from exc
            if actual_digest != expected_digest:
                raise ArtifactContractError(f"证据已变化，拒绝继续：{path}")
        return
    assert isinstance(parents, list)
    for index, parent in enumerate(parents):
        if not isinstance(parent, dict):
            raise ArtifactContractError(
                f"provenance.parents[{index}] 必须是对象"
            )
        path_value = parent.get("path")
        expected_digest = parent.get("sha256")
        if not isinstance(path_value, str) or not path_value:
            raise ArtifactContractError(
                f"provenance.parents[{index}] 缺少 path"
            )
        if not isinstance(expected_digest, str) or len(expected_digest) != 64:
            raise ArtifactContractError(
                f"provenance.parents[{index}] 缺少有效 sha256"
            )
        try:
            actual_digest = sha256_file(path_value)
        except OSError as exc:
            raise ArtifactContractError(
                f"父 Artifact 不可读取：{path_value}"
            ) from exc
        if actual_digest != expected_digest:
            raise ArtifactContractError(
                f"父 Artifact 已变化，拒绝继续：{path_value}"
            )
