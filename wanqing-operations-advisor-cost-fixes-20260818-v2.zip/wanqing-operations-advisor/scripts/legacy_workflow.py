#!/usr/bin/env python3
"""Compatibility adapters for former Wanqing reclaim workflow commands."""

from __future__ import annotations

import argparse
import json
import sys

from artifact_contract import annotate_outcome, terminal_brief
from reclaim_assembly import (
    absolutize_candidate_references,
    load_cloud_reclaim_handoff,
    load_object,
    merge_card_type_totals,
    merge_number_totals,
    prepare_isvc_artifacts,
    resolve_reference,
    run_artifact_command,
    run_cli,
    run_cloud_reclaim,
    run_cloud_reclaim_all,
    validate_max_workers,
)
from runtime import utc_now, write_artifact
from workflow_errors import WorkflowError


SCHEMA_VERSION = "1.0"
SCRIPT_VERSION = "2.5.0"
DEFAULT_MAX_WORKERS = 4
MAX_MAX_WORKERS = 8


def add_cloud_reclaim_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--input", required=True, help="Workflow 输入 JSON")
    parser.add_argument(
        "--output-dir", required=True, help="各阶段 Artifact 输出目录"
    )
    parser.add_argument(
        "--isvc-endpoint",
        help="覆盖 scripts/isvc.py 的默认 iSvc 列表 API",
    )
    parser.add_argument(
        "--isvc-timeout", type=float, default=30.0, help="iSvc 查询超时秒数"
    )
    parser.add_argument(
        "--isvc-fixture", help="iSvc 列表 JSON fixture，不访问 API"
    )
    parser.add_argument(
        "--max-workers",
        type=int,
        default=DEFAULT_MAX_WORKERS,
        help=(
            f"最大并发任务数，默认 {DEFAULT_MAX_WORKERS}，"
            f"上限 {MAX_MAX_WORKERS}"
        ),
    )
    parser.add_argument("--output", required=True, help="Workflow Manifest")


def build_parser() -> argparse.ArgumentParser:
    import capacity_pipeline
    import reclaim_pipeline

    parser = argparse.ArgumentParser(
        description="万擎单 Agent 多领域确定性 Workflow"
    )
    commands = parser.add_subparsers(dest="workflow", required=True)
    reclaim = commands.add_parser(
        "cloud-reclaim",
        help=(
            "云上前一日余量 → KConf 单实例容量 → "
            "理论可回收内部实例与资源"
        ),
    )
    add_cloud_reclaim_arguments(reclaim)
    reclaim_explicit = commands.add_parser(
        "cloud-reclaim-explicit",
        help=(
            "只评估用户明确指定的模型，不应用 Top P 前缀选择；"
            "容量、KConf、iSvc 和模型解析证据规则保持不变"
        ),
    )
    add_cloud_reclaim_arguments(reclaim_explicit)
    reclaim_all = commands.add_parser(
        "cloud-reclaim-all",
        help=(
            "按 X60 → X40 顺序评估两类卡型 Top 白名单内全部模型，"
            "并汇总理论可回收资源"
        ),
    )
    add_cloud_reclaim_arguments(reclaim_all)
    reclaim_prepare = commands.add_parser(
        "cloud-reclaim-prepare",
        help=(
            "从用户范围自动完成候选发现、模型解析、前一日云上容量与"
            " iSvc 查询，并只输出一次 KConf 工具调用"
        ),
    )
    reclaim_pipeline.add_common_prepare_arguments(reclaim_prepare)
    reclaim_finalize = commands.add_parser(
        "cloud-reclaim-finalize",
        help="消费 prepare 计划与一次原始 KConf 返回，完成规范化和回收汇总",
    )
    reclaim_pipeline.add_finalize_arguments(reclaim_finalize)
    render_report = commands.add_parser(
        "render-report",
        help="只从可信 cloud-reclaim-finalize Manifest 生成官方报告 Artifact",
    )
    reclaim_pipeline.add_report_arguments(render_report)
    capacity_analyze = commands.add_parser(
        "capacity-analyze",
        help=(
            "统一编排供给画像、流量画像和余量与扩容；"
            "简单查询直接完成，只有扩容换算需要 KConf 时暂停"
        ),
    )
    capacity_pipeline.add_analyze_arguments(capacity_analyze)
    capacity_finalize = commands.add_parser(
        "capacity-analyze-finalize",
        help="消费容量分析检查点与一次原始 KConf 返回，完成扩容证据计算",
    )
    capacity_pipeline.add_finalize_arguments(capacity_finalize)
    capacity_report = commands.add_parser(
        "render-capacity-report",
        help="只从可信 capacity-analyze 结果生成容量分析报告 Artifact",
    )
    capacity_pipeline.add_report_arguments(capacity_report)
    return parser


def build_legacy_parser(command: str) -> argparse.ArgumentParser:
    """Build only one compatibility command without importing modern pipelines."""

    parser = argparse.ArgumentParser(
        description="万擎单 Agent 多领域确定性 Workflow"
    )
    commands = parser.add_subparsers(dest="workflow", required=True)
    help_text = {
        "cloud-reclaim": (
            "云上前一日余量 → KConf 单实例容量 → "
            "理论可回收内部实例与资源"
        ),
        "cloud-reclaim-explicit": (
            "只评估用户明确指定的模型，不应用 Top P 前缀选择；"
            "容量、KConf、iSvc 和模型解析证据规则保持不变"
        ),
        "cloud-reclaim-all": (
            "按 X60 → X40 顺序评估两类卡型 Top 白名单内全部模型，"
            "并汇总理论可回收资源"
        ),
    }
    if command not in help_text:
        raise WorkflowError(f"未知兼容 Workflow：{command}")
    subparser = commands.add_parser(command, help=help_text[command])
    add_cloud_reclaim_arguments(subparser)
    return parser



def main() -> int:
    import capacity_pipeline
    import reclaim_pipeline

    args = build_parser().parse_args()
    try:
        if args.workflow == "capacity-analyze":
            manifest = capacity_pipeline.run_analyze(args)
        elif args.workflow == "capacity-analyze-finalize":
            manifest = capacity_pipeline.run_finalize(args)
        elif args.workflow == "render-capacity-report":
            manifest = capacity_pipeline.run_report(args)
        elif args.workflow == "cloud-reclaim-prepare":
            manifest = reclaim_pipeline.run_prepare(args)
        elif args.workflow == "cloud-reclaim-finalize":
            manifest = reclaim_pipeline.run_finalize(args)
        elif args.workflow == "render-report":
            manifest = reclaim_pipeline.run_report(args)
        elif args.workflow == "cloud-reclaim-all":
            manifest = run_cloud_reclaim_all(args)
        elif args.workflow == "cloud-reclaim-explicit":
            manifest = run_cloud_reclaim(args, explicit_models=True)
        else:
            manifest = run_cloud_reclaim(args)
    except (
        OSError,
        RuntimeError,
        ValueError,
        json.JSONDecodeError,
    ) as exc:
        if args.workflow in {
            "capacity-analyze",
            "capacity-analyze-finalize",
            "render-capacity-report",
        }:
            manifest = capacity_pipeline.error_artifact(
                scenario=args.workflow,
                error=exc,
            )
        elif args.workflow in {
            "cloud-reclaim-prepare",
            "cloud-reclaim-finalize",
            "render-report",
        }:
            manifest = reclaim_pipeline.error_artifact(
                scenario=args.workflow,
                error=exc,
            )
        else:
            manifest = {
                "schema_version": SCHEMA_VERSION,
                "script_version": SCRIPT_VERSION,
                "domain": "workflow",
                "scenario": args.workflow,
                "status": "error",
                "generated_at": utc_now(),
                "summary": {"decision": "workflow_failed"},
                "artifacts": {},
                "warnings": [],
                "errors": [str(exc)],
            }
    annotate_outcome(manifest)
    try:
        output = write_artifact(args.output, manifest)
    except OSError as exc:
        print(
            json.dumps(
                {"status": "error", "error": str(exc)},
                ensure_ascii=False,
            )
        )
        return 1
    print(json.dumps(terminal_brief(manifest, output), ensure_ascii=False))
    return 0 if manifest["status"] in {"success", "partial"} else 1


def main_legacy_command(command: str) -> int:
    """Run one former workflow.py reclaim command through its original logic."""

    args = build_legacy_parser(command).parse_args()
    try:
        if command == "cloud-reclaim-all":
            manifest = run_cloud_reclaim_all(args)
        elif command == "cloud-reclaim-explicit":
            manifest = run_cloud_reclaim(args, explicit_models=True)
        else:
            manifest = run_cloud_reclaim(args)
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as exc:
        manifest = {
            "schema_version": SCHEMA_VERSION,
            "script_version": SCRIPT_VERSION,
            "domain": "workflow",
            "scenario": command,
            "status": "error",
            "generated_at": utc_now(),
            "summary": {"decision": "workflow_failed"},
            "artifacts": {},
            "warnings": [],
            "errors": [str(exc)],
        }
    annotate_outcome(manifest)
    try:
        output = write_artifact(args.output, manifest)
    except OSError as exc:
        print(json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False))
        return 1
    print(json.dumps(terminal_brief(manifest, output), ensure_ascii=False))
    return 0 if manifest["status"] in {"success", "partial"} else 1


if __name__ == "__main__":
    raise SystemExit(main())

