#!/usr/bin/env python3
"""Thin CLI and Artifact adapter for Wanqing capacity workflows.

Query execution lives in capacity_query; deterministic formulas live in
capacity_metrics. Public imports remain available here for compatibility.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import capacity_query as _capacity_query
from artifact_contract import annotate_outcome, terminal_brief
from capacity_metrics import *  # noqa: F401,F403 - compatibility facade
from capacity_query import *  # noqa: F401,F403 - compatibility facade
from model_contract import resolve_single_model
from runtime import query_or_fixture


SCHEMA_VERSION = "1.0"
SCRIPT_VERSION = "0.34.0"
INSPECT_SECTIONS = {
    "summary",
    "evidence",
    "handoffs",
    "query",
    "warnings",
    "errors",
    "input",
}
EVIDENCE_MODES = {"production", "replay"}


def _sync_query_dependencies() -> None:
    """Keep the historical capacity module monkeypatch surface working."""

    _capacity_query.datetime = datetime
    _capacity_query.query_or_fixture = query_or_fixture
    _capacity_query.resolve_single_model = resolve_single_model


def resolve_query_window(
    args: argparse.Namespace,
    *,
    fixture_mode: bool,
) -> dict[str, Any]:
    _sync_query_dependencies()
    return _capacity_query.resolve_query_window(
        args,
        fixture_mode=fixture_mode,
    )


def query_model_candidates(args: argparse.Namespace) -> dict[str, Any]:
    _sync_query_dependencies()
    return _capacity_query.query_model_candidates(args)


def query_model_candidates_batch(args: argparse.Namespace) -> dict[str, Any]:
    _sync_query_dependencies()
    return _capacity_query.query_model_candidates_batch(args)


def query_headroom(args: argparse.Namespace, **kwargs: Any) -> dict[str, Any]:
    _sync_query_dependencies()
    return _capacity_query.query_headroom(args, **kwargs)


def query_headroom_batch(args: argparse.Namespace) -> dict[str, Any]:
    _sync_query_dependencies()
    return _capacity_query.query_headroom_batch(args)


def inspect_artifact(path_value: str, section: str) -> int:
    artifact = load_object(path_value)
    if section not in INSPECT_SECTIONS:
        raise InputError(
            f"section 仅支持：{', '.join(sorted(INSPECT_SECTIONS))}"
        )
    print(json.dumps(artifact.get(section), ensure_ascii=False, indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="万擎模型容量查询与计算（只读）"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    candidate_parser = subparsers.add_parser(
        "list-models",
        help="按容量场景锚点来源发现真实模型候选，不计算业务指标",
    )
    candidate_parser.add_argument(
        "--anchor-source",
        required=True,
        choices=("capacity", "usage"),
        help="供给/余量用 capacity，流量画像用 usage",
    )
    candidate_parser.add_argument(
        "--model-input", required=True, help="用户提供的原始模型表达"
    )
    candidate_parser.add_argument(
        "--provider",
        action="append",
        required=True,
        help="当前场景目标 provider，可重复传入",
    )
    candidate_parser.add_argument(
        "--priority",
        choices=tuple(sorted(PRIORITY_VALUES)),
        default="在线",
        help="请求等级，默认在线",
    )
    candidate_parser.add_argument(
        "--from",
        dest="from_ts",
        type=int,
        help="显式查询起点 Unix 秒；previous_day 可省略",
    )
    candidate_parser.add_argument(
        "--to",
        dest="to_ts",
        type=int,
        help="显式查询终点 Unix 秒；previous_day 可省略",
    )
    candidate_parser.add_argument(
        "--timezone", default="Asia/Shanghai", help="业务时区"
    )
    candidate_parser.add_argument(
        "--window-relation",
        required=True,
        choices=tuple(sorted(WINDOW_RELATIONS)),
        help="必须声明时间语义；前一完整自然日使用 previous_day",
    )
    candidate_parser.add_argument(
        "--lookback-seconds",
        type=int,
        help="current 窗口的回溯秒数；其他窗口禁止使用",
    )
    candidate_parser.add_argument(
        "--fixture", help="模型候选 ClickHouse JSON fixture，不访问网络"
    )
    candidate_parser.add_argument(
        "--timeout", type=float, default=30.0, help="查询超时秒数"
    )
    candidate_parser.add_argument(
        "--output", required=True, help="模型候选 Artifact 路径"
    )

    candidate_batch_parser = subparsers.add_parser(
        "list-models-batch",
        help="共享一个时间窗口，有界并发发现多个模型表达的真实候选",
    )
    candidate_batch_parser.add_argument(
        "--anchor-source",
        required=True,
        choices=("capacity", "usage"),
        help="供给/余量用 capacity，流量画像用 usage",
    )
    candidate_batch_parser.add_argument(
        "--model-input",
        action="append",
        required=True,
        help="用户提供的模型表达；按用户输入顺序重复传入",
    )
    candidate_batch_parser.add_argument(
        "--provider",
        action="append",
        required=True,
        help="当前场景目标 provider，可重复传入",
    )
    candidate_batch_parser.add_argument(
        "--priority",
        choices=tuple(sorted(PRIORITY_VALUES)),
        default="在线",
        help="请求等级，默认在线",
    )
    candidate_batch_parser.add_argument(
        "--from",
        dest="from_ts",
        type=int,
        help="显式查询起点 Unix 秒；previous_day 可省略",
    )
    candidate_batch_parser.add_argument(
        "--to",
        dest="to_ts",
        type=int,
        help="显式查询终点 Unix 秒；previous_day 可省略",
    )
    candidate_batch_parser.add_argument(
        "--timezone", default="Asia/Shanghai", help="业务时区"
    )
    candidate_batch_parser.add_argument(
        "--window-relation",
        required=True,
        choices=tuple(sorted(WINDOW_RELATIONS)),
        help="必须声明时间语义；前一完整自然日使用 previous_day",
    )
    candidate_batch_parser.add_argument(
        "--lookback-seconds",
        type=int,
        help="current 窗口的回溯秒数；其他窗口禁止使用",
    )
    candidate_batch_parser.add_argument(
        "--fixture",
        action="append",
        help="按 model-input 顺序逐一提供候选 fixture；不访问网络",
    )
    candidate_batch_parser.add_argument(
        "--timeout", type=float, default=30.0, help="每条查询的超时秒数"
    )
    candidate_batch_parser.add_argument(
        "--max-workers",
        type=int,
        default=DEFAULT_MAX_WORKERS,
        help=f"最大并发数，默认 {DEFAULT_MAX_WORKERS}",
    )
    candidate_batch_parser.add_argument(
        "--output-dir", required=True, help="逐模型候选 Artifact 输出目录"
    )
    candidate_batch_parser.add_argument(
        "--output", required=True, help="批量候选 Manifest 路径"
    )

    query_parser = subparsers.add_parser(
        "query-headroom",
        help="查询在线容量与在线用量并计算可承载余量",
    )
    query_parser.add_argument(
        "--model-artifact",
        help="成功的 model-resolution Artifact；生产查询必填",
    )
    query_parser.add_argument(
        "--model",
        help=(
            "兼容的精确模型名；只允许两个 ClickHouse fixture 均已提供，"
            "或用于校验其值与 --model-artifact 一致"
        ),
    )
    query_parser.add_argument(
        "--provider",
        action="append",
        required=True,
        help="目标路由 provider 精确值，可重复传入",
    )
    query_parser.add_argument(
        "--provider-scope",
        choices=("cloud", "self_deployed", "mixed"),
        required=True,
        help="public 用 cloud，internal 用 self_deployed，两者一起用 mixed",
    )
    query_parser.add_argument(
        "--from",
        dest="from_ts",
        type=int,
        help="显式查询起点 Unix 秒；previous_day 可省略",
    )
    query_parser.add_argument(
        "--to",
        dest="to_ts",
        type=int,
        help="显式查询终点 Unix 秒；previous_day 可省略",
    )
    query_parser.add_argument(
        "--timezone", default="Asia/Shanghai", help="业务时区"
    )
    query_parser.add_argument(
        "--window-relation",
        required=True,
        choices=tuple(sorted(WINDOW_RELATIONS)),
        help="必须声明时间窗口语义",
    )
    query_parser.add_argument(
        "--lookback-seconds",
        type=int,
        help="current 窗口的回溯秒数；其他窗口禁止使用",
    )
    query_parser.add_argument(
        "--incremental-tpm",
        type=float,
        help="要承接的新增在线 TPM；不传则只返回余量",
    )
    query_parser.add_argument(
        "--single-instance-capacity-tpm",
        type=float,
        help="兼容的 KConf 单实例在线容量标量输入",
    )
    query_parser.add_argument(
        "--kconf-artifact",
        help="kconf_single_config_data 结果生成的单实例容量 Artifact",
    )
    query_parser.add_argument(
        "--isvc-artifact",
        help="scripts/isvc.py 生成的单实例卡数 Artifact",
    )
    query_parser.add_argument(
        "--reserve-ratio",
        type=float,
        default=0,
        help="容量预留比例，默认 0",
    )
    query_parser.add_argument(
        "--detail-level",
        choices=("legacy", "headroom", "decision", "instances", "cards", "resources"),
        default="legacy",
        help="本次查询需要完整返回到哪一层；默认保留旧版深度语义",
    )
    query_parser.add_argument(
        "--resource-artifact",
        help="资源域 available/idle Artifact，用于校验机器是否足够",
    )
    query_parser.add_argument(
        "--gpu",
        choices=("X60", "X50", "X40"),
        help="资源 Artifact 对应 GPU 型号",
    )
    query_parser.add_argument(
        "--capacity-fixture",
        help="容量 ClickHouse JSON fixture，不访问容量查询",
    )
    query_parser.add_argument(
        "--usage-fixture",
        help="用量 ClickHouse JSON fixture，不访问用量查询",
    )
    query_parser.add_argument(
        "--timeout", type=float, default=30.0, help="每条查询的超时秒数"
    )
    query_parser.add_argument(
        "--output", required=True, help="结果 Artifact 路径"
    )

    batch_query_parser = subparsers.add_parser(
        "query-headroom-batch",
        help=(
            "用共享时间窗口和两条批量 SQL 查询多个模型的在线容量与用量"
        ),
    )
    batch_query_parser.add_argument(
        "--model-artifact",
        action="append",
        required=True,
        help=(
            "成功的同场景 model-resolution Artifact；"
            "按输入顺序重复传入"
        ),
    )
    batch_query_parser.add_argument(
        "--provider",
        action="append",
        required=True,
        help="目标路由 provider 精确值，可重复传入",
    )
    batch_query_parser.add_argument(
        "--provider-scope",
        choices=("cloud", "self_deployed", "mixed"),
        required=True,
        help="public 用 cloud，internal 用 self_deployed，两者一起用 mixed",
    )
    batch_query_parser.add_argument(
        "--from", dest="from_ts", type=int, help="显式查询起点 Unix 秒"
    )
    batch_query_parser.add_argument(
        "--to", dest="to_ts", type=int, help="显式查询终点 Unix 秒"
    )
    batch_query_parser.add_argument(
        "--timezone", default="Asia/Shanghai", help="业务时区"
    )
    batch_query_parser.add_argument(
        "--window-relation",
        required=True,
        choices=tuple(sorted(WINDOW_RELATIONS)),
        help="必须声明时间窗口语义；整个批次只解析一次",
    )
    batch_query_parser.add_argument(
        "--lookback-seconds",
        type=int,
        help="current 窗口的回溯秒数；其他窗口禁止使用",
    )
    batch_query_parser.add_argument(
        "--incremental-tpm",
        type=float,
        help="headroom 批次中每个模型要承接的同一新增在线 TPM",
    )
    batch_query_parser.add_argument(
        "--reserve-ratio",
        type=float,
        default=0,
        help="headroom 批次统一容量预留比例，默认 0",
    )
    batch_query_parser.add_argument(
        "--detail-level",
        choices=("legacy", "headroom", "decision", "instances", "cards", "resources"),
        default="legacy",
        help="批次中每个模型需要完整返回到哪一层",
    )
    batch_query_parser.add_argument(
        "--kconf-manifest",
        help="kconf.py normalize-batch 生成的同模型同顺序 Manifest",
    )
    batch_query_parser.add_argument(
        "--isvc-manifest",
        help="isvc.py query-models 生成的同模型同顺序 Manifest",
    )
    batch_query_parser.add_argument(
        "--resource-artifact",
        help="资源域 available/idle Artifact，用于按卡型校验扩容机器",
    )
    batch_query_parser.add_argument(
        "--capacity-fixture",
        help="批量容量 ClickHouse JSON fixture，不访问容量查询",
    )
    batch_query_parser.add_argument(
        "--usage-fixture",
        help="批量用量 ClickHouse JSON fixture，不访问用量查询",
    )
    batch_query_parser.add_argument(
        "--timeout", type=float, default=30.0, help="每条查询的超时秒数"
    )
    batch_query_parser.add_argument(
        "--max-workers",
        type=int,
        default=DEFAULT_MAX_WORKERS,
        help=(
            f"最大并发任务数，默认 {DEFAULT_MAX_WORKERS}，"
            f"上限 {MAX_MAX_WORKERS}"
        ),
    )
    batch_query_parser.add_argument(
        "--output-dir", required=True, help="逐模型 Artifact 输出目录"
    )
    batch_query_parser.add_argument(
        "--output", required=True, help="批量 Manifest 路径"
    )

    for command in (
        "headroom",
        "cloud-reclaim",
        "reclaim-capacity",
        "traffic-profile",
    ):
        subparser = subparsers.add_parser(command)
        subparser.add_argument("--input", required=True, help="规范化证据 JSON")
        subparser.add_argument("--output", required=True, help="结果 Artifact 路径")
        subparser.add_argument(
            "--evidence-mode",
            choices=tuple(sorted(EVIDENCE_MODES)),
            default="production",
            help=(
                "production 强制模型解析证据；replay 允许历史/fixture 裸模型，"
                "默认 production"
            ),
        )
        if command in {"headroom", "traffic-profile"}:
            subparser.add_argument(
                "--model-artifact",
                help="与当前容量场景一致的成功 model-resolution Artifact",
            )
        if command == "headroom":
            subparser.add_argument(
                "--kconf-artifact",
                help=(
                    "kconf_single_config_data 结果生成的"
                    "单实例容量 Artifact"
                ),
            )
            subparser.add_argument(
                "--isvc-artifact",
                help="scripts/isvc.py 生成的单实例卡数 Artifact",
            )
            subparser.add_argument(
                "--resource-artifact",
                help="wanqing-operations-advisor 生成的资源域 Artifact",
            )
            subparser.add_argument(
                "--gpu",
                choices=("X60", "X50", "X40"),
                help="从资源域 Artifact 选取的 GPU 型号",
            )
    inspect_parser = subparsers.add_parser("inspect")
    inspect_parser.add_argument("artifact", help="已有容量 Artifact")
    inspect_parser.add_argument(
        "--section", default="summary", choices=sorted(INSPECT_SECTIONS)
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.command == "inspect":
        try:
            return inspect_artifact(args.artifact, args.section)
        except (OSError, json.JSONDecodeError, InputError) as exc:
            print(
                json.dumps(
                    {"status": "error", "error": str(exc)},
                    ensure_ascii=False,
                )
            )
            return 1

    try:
        calculation_model_resolution: (
            dict[str, Any] | list[dict[str, Any]] | None
        ) = None
        if args.command == "list-models":
            artifact = query_model_candidates(args)
        elif args.command == "list-models-batch":
            artifact = query_model_candidates_batch(args)
        elif args.command == "query-headroom":
            artifact = query_headroom(args)
        elif args.command == "query-headroom-batch":
            artifact = query_headroom_batch(args)
        else:
            input_path = Path(args.input).expanduser().resolve()
            source = load_object(str(input_path))
            if args.command == "headroom":
                calculation_model_resolution = (
                    validate_single_calculation_model(
                        source,
                        model_artifact=args.model_artifact,
                        evidence_mode=args.evidence_mode,
                        target_scenario="headroom",
                    )
                )
            elif args.command == "traffic-profile":
                calculation_model_resolution = (
                    validate_single_calculation_model(
                        source,
                        model_artifact=args.model_artifact,
                        evidence_mode=args.evidence_mode,
                        target_scenario="traffic-profile",
                    )
                )
            else:
                calculation_model_resolution = validate_cloud_reclaim_models(
                    source,
                    input_path=input_path,
                    evidence_mode=args.evidence_mode,
                )
        if args.command == "headroom":
            if args.kconf_artifact:
                expected_model = read_text(source, "model", [])
                if expected_model is None:
                    raise InputError("输入缺少 model，无法校验 KConf Artifact")
                source = attach_kconf_artifact(
                    source, args.kconf_artifact, expected_model
                )
            if args.isvc_artifact:
                expected_model = read_text(source, "model", [])
                if expected_model is None:
                    raise InputError("输入缺少 model，无法校验 iSvc Artifact")
                source = attach_isvc_artifact(
                    source, args.isvc_artifact, expected_model
                )
            artifact = headroom(
                source,
                args.resource_artifact,
                args.gpu,
            )
        elif args.command in {"cloud-reclaim", "reclaim-capacity"}:
            artifact = cloud_reclaim(source)
        elif args.command == "traffic-profile":
            artifact = traffic_profile(source)
        if calculation_model_resolution is not None:
            attach_calculation_provenance(
                artifact,
                evidence_mode=args.evidence_mode,
                model_resolution=calculation_model_resolution,
            )
    except (
        OSError,
        RuntimeError,
        ValueError,
        json.JSONDecodeError,
    ) as exc:
        query_commands = {
            "list-models",
            "list-models-batch",
            "query-headroom",
            "query-headroom-batch",
        }
        query_failure = args.command in query_commands and isinstance(
            exc, (OSError, RuntimeError, json.JSONDecodeError)
        )
        artifact = {
            "schema_version": SCHEMA_VERSION,
            "script_version": SCRIPT_VERSION,
            "domain": "capacity",
            "scenario": args.command,
            "status": "error",
            "generated_at": utc_now(),
            "summary": {
                "decision": "query_failed" if query_failure else "invalid_input",
                "write_performed": False,
            },
            "query": {
                "evidence_mode": getattr(args, "evidence_mode", None),
            },
            "evidence": [],
            "warnings": [],
            "errors": [str(exc)],
        }
        artifact["reason_code"] = (
            "QUERY_FAILED" if query_failure else "INVALID_INPUT"
        )
    annotate_outcome(artifact)
    try:
        output = write_artifact(args.output, artifact)
    except OSError as exc:
        print(
            json.dumps(
                {"status": "error", "error": str(exc)}, ensure_ascii=False
            )
        )
        return 1

    brief = terminal_brief(artifact, output)
    print(json.dumps(brief, ensure_ascii=False))
    return 0 if artifact["status"] != "error" else 1


if __name__ == "__main__":
    sys.exit(main())

