#!/usr/bin/env python3
"""Semantic request-to-evidence validation for capacity workflows."""

from __future__ import annotations

import math
from datetime import datetime
from pathlib import Path
from typing import Any

from artifact_contract import ArtifactContractError
from model_contract import ModelContractError, validate_embedded_model_resolution


def _mapping(value: Any, field: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ArtifactContractError(f"{field} 必须是对象")
    return value


def _equal_number(actual: Any, expected: Any) -> bool:
    if isinstance(actual, bool) or not isinstance(actual, (int, float)):
        return False
    if isinstance(expected, bool) or not isinstance(expected, (int, float)):
        return False
    return math.isfinite(float(actual)) and math.isclose(
        float(actual), float(expected), rel_tol=0.0, abs_tol=1e-9
    )


def _epoch_seconds(value: Any, field: str) -> int:
    if not isinstance(value, str) or not value:
        raise ArtifactContractError(f"{field} 必须是 ISO 8601 时间")
    normalized = value[:-1] + "+00:00" if value.endswith("Z") else value
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError as exc:
        raise ArtifactContractError(f"{field} 必须是 ISO 8601 时间") from exc
    if parsed.tzinfo is None:
        raise ArtifactContractError(f"{field} 必须包含时区")
    return int(parsed.timestamp())


def validate_capacity_evidence_semantics(
    artifact: dict[str, Any],
    *,
    request: dict[str, Any],
    expected_model: str,
    expected_model_artifact: str | Path,
    field: str,
) -> None:
    """Bind one capacity result to its exact normalized task semantics."""

    if artifact.get("domain") != "capacity":
        raise ArtifactContractError(f"{field}.domain 必须是 capacity")
    scenario = artifact.get("scenario")
    if scenario not in {"query-headroom", "headroom"}:
        raise ArtifactContractError(
            f"{field}.scenario 必须是 query-headroom 或 headroom"
        )
    status = artifact.get("status")
    if status not in {"success", "partial", "error"}:
        raise ArtifactContractError(f"{field}.status 无效")

    query = _mapping(artifact.get("query"), f"{field}.query")
    try:
        validate_embedded_model_resolution(
            query.get("model_resolution"),
            expected_model=expected_model,
            expected_domain="capacity",
            expected_scenario=str(request.get("scenario")),
            expected_artifact=expected_model_artifact,
            field=f"{field}.query.model_resolution",
        )
    except ModelContractError as exc:
        raise ArtifactContractError(str(exc)) from exc

    source = artifact.get("input")
    if status == "error" and not isinstance(source, dict):
        window = _mapping(query.get("window"), f"{field}.query.window")
        if window.get("relation") != request.get("window_relation"):
            raise ArtifactContractError(f"{field} 的时间窗口关系与请求不一致")
        if window.get("timezone") != request.get("timezone"):
            raise ArtifactContractError(f"{field} 的时区与请求不一致")
        return
    source = _mapping(source, f"{field}.input")
    if source.get("model") != expected_model:
        raise ArtifactContractError(f"{field}.input.model 与任务模型不一致")

    filters = _mapping(source.get("filters"), f"{field}.input.filters")
    if filters.get("model") != expected_model:
        raise ArtifactContractError(f"{field} 的过滤模型与任务不一致")
    if filters.get("providers") != request.get("providers"):
        raise ArtifactContractError(f"{field} 的 providers 与任务不一致")
    if filters.get("provider_scope") != request.get("provider_scope"):
        raise ArtifactContractError(f"{field} 的 provider_scope 与任务不一致")
    if filters.get("priority") != request.get("priority"):
        raise ArtifactContractError(f"{field} 的 priority 与任务不一致")

    window = _mapping(source.get("window"), f"{field}.input.window")
    if window.get("relation") != request.get("window_relation"):
        raise ArtifactContractError(f"{field} 的时间窗口关系与任务不一致")
    if window.get("timezone") != request.get("timezone"):
        raise ArtifactContractError(f"{field} 的时区与任务不一致")
    if request.get("window_relation") in {"custom", "previous_same_period"}:
        if _epoch_seconds(window.get("start"), f"{field}.input.window.start") != request.get(
            "from"
        ):
            raise ArtifactContractError(f"{field} 的窗口起点与任务不一致")
        if _epoch_seconds(window.get("end"), f"{field}.input.window.end") != request.get(
            "to"
        ):
            raise ArtifactContractError(f"{field} 的窗口终点与任务不一致")

    if request.get("scenario") != "headroom":
        if scenario != "query-headroom":
            raise ArtifactContractError(f"{field} 不是画像任务的原始查询证据")
        return

    policy = _mapping(source.get("policy"), f"{field}.input.policy")
    if policy.get("detail_level") != request.get("detail_level"):
        raise ArtifactContractError(f"{field} 的 detail_level 与任务不一致")
    if not _equal_number(policy.get("reserve_ratio"), request.get("reserve_ratio")):
        raise ArtifactContractError(f"{field} 的 reserve_ratio 与任务不一致")
    incremental = request.get("incremental_tpm")
    demand = source.get("demand")
    if incremental is None:
        if isinstance(demand, dict) and demand.get("incremental_tpm") is not None:
            raise ArtifactContractError(f"{field} 包含请求未声明的新增 TPM")
    else:
        demand = _mapping(demand, f"{field}.input.demand")
        if not _equal_number(demand.get("incremental_tpm"), incremental):
            raise ArtifactContractError(f"{field} 的 incremental_tpm 与任务不一致")
