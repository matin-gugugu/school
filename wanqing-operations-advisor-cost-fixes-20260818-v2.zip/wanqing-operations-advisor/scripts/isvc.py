#!/usr/bin/env python3
"""Read-only iSvc topology query and single-instance GPU card calculation."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from artifact_contract import annotate_outcome, terminal_brief
from model_contract import resolve_single_model
from runtime import utc_now, write_artifact


SCHEMA_VERSION = "1.0"
SCRIPT_VERSION = "1.5.0"
DEFAULT_ISVC_ENDPOINT = (
    "http://inference-service-deployer.internal/api/v1/isvcs"
)
MAX_RESPONSE_BYTES = 64 * 1024 * 1024
MODEL_ANNOTATION = "serving.kwai.io/modelServiceName"
KSN_ANNOTATION = "serving.kwai.io/ksn"
MODEL_LABEL = "pod-inherits/modelServiceName"
POOL_LABEL = "pod-inherits/llm-inference-pool"
SERVICE_LABEL = "pod-inherits/serviceName"
DEFAULT_MAX_WORKERS = 4
MAX_MAX_WORKERS = 8


class IsvcError(ValueError):
    """Raised when iSvc evidence cannot be safely normalized."""


def mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def text_value(value: Any) -> str:
    return value.strip() if isinstance(value, str) else ""


def bounded_text(value: Any, field: str) -> str:
    normalized = text_value(value)
    if not normalized:
        raise IsvcError(f"{field} 不能为空")
    if len(normalized) > 256:
        raise IsvcError(f"{field} 长度不能超过 256")
    if any(ord(character) < 32 for character in normalized):
        raise IsvcError(f"{field} 不能包含控制字符")
    return normalized


def integer_value(
    value: Any,
    field: str,
    *,
    minimum: int,
) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise IsvcError(f"{field} 必须是整数")
    if not math.isfinite(float(value)) or int(value) != value:
        raise IsvcError(f"{field} 必须是整数")
    normalized = int(value)
    if normalized < minimum:
        raise IsvcError(f"{field} 必须大于等于 {minimum}")
    return normalized


def optional_integer(
    value: Any,
    field: str,
    *,
    minimum: int,
) -> int | None:
    if value is None:
        return None
    return integer_value(value, field, minimum=minimum)


def validate_endpoint(value: str) -> str:
    endpoint = bounded_text(value, "endpoint")
    parsed = urlparse(endpoint)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise IsvcError("endpoint 必须是有效的 HTTP(S) URL")
    return endpoint


def model_service_name(item: dict[str, Any]) -> str:
    metadata = mapping(item.get("metadata"))
    annotations = mapping(metadata.get("annotations"))
    labels = mapping(metadata.get("labels"))
    spec = mapping(item.get("spec"))
    pd_spec = mapping(item.get("pdSpec"))
    return next(
        (
            value
            for value in (
                text_value(spec.get("modelServiceName")),
                text_value(pd_spec.get("modelServiceName")),
                text_value(annotations.get(MODEL_ANNOTATION)),
                text_value(labels.get(MODEL_LABEL)),
            )
            if value
        ),
        "",
    )


def service_name(item: dict[str, Any]) -> str:
    metadata = mapping(item.get("metadata"))
    annotations = mapping(metadata.get("annotations"))
    labels = mapping(metadata.get("labels"))
    return next(
        (
            value
            for value in (
                text_value(labels.get(SERVICE_LABEL)),
                text_value(annotations.get(KSN_ANNOTATION)),
                text_value(metadata.get("name")),
            )
            if value
        ),
        "",
    )


def pool_name(item: dict[str, Any]) -> str:
    labels = mapping(mapping(item.get("metadata")).get("labels"))
    return text_value(labels.get(POOL_LABEL)).lower()


def isvc_name(item: dict[str, Any]) -> str:
    return text_value(mapping(item.get("metadata")).get("name"))


def ready_instances(item: dict[str, Any], field_prefix: str) -> int | None:
    status = mapping(item.get("status"))
    return optional_integer(
        status.get("readyReplicas"),
        f"{field_prefix}.status.readyReplicas",
        minimum=0,
    )


def desired_instances_hint(item: dict[str, Any], field_prefix: str) -> int:
    pd_spec = mapping(item.get("pdSpec"))
    if pd_spec:
        return integer_value(
            pd_spec.get("replicas"),
            f"{field_prefix}.pdSpec.replicas",
            minimum=0,
        )
    worker = mapping(mapping(item.get("spec")).get("worker"))
    if worker:
        return integer_value(
            worker.get("replicas"),
            f"{field_prefix}.spec.worker.replicas",
            minimum=0,
        )
    raise IsvcError(f"{field_prefix} 缺少 spec.worker 或 pdSpec")


def engine_dimensions(
    worker: dict[str, Any], field_prefix: str
) -> tuple[int, int]:
    engine = mapping(worker.get("engineConfig"))
    tensor_parallel = integer_value(
        engine.get("tensorParallelSize"),
        f"{field_prefix}.engineConfig.tensorParallelSize",
        minimum=1,
    )
    pipeline_parallel = integer_value(
        engine.get("pipelineParallelSize"),
        f"{field_prefix}.engineConfig.pipelineParallelSize",
        minimum=1,
    )
    return tensor_parallel, pipeline_parallel


def device_type(worker: dict[str, Any], field_prefix: str) -> str:
    return bounded_text(
        worker.get("deviceType"), f"{field_prefix}.deviceType"
    ).upper()


def parse_ordinary(
    item: dict[str, Any], field_prefix: str
) -> dict[str, Any]:
    worker = mapping(mapping(item.get("spec")).get("worker"))
    if not worker:
        raise IsvcError(f"{field_prefix}.spec.worker 必须是对象")
    desired = integer_value(
        worker.get("replicas"),
        f"{field_prefix}.spec.worker.replicas",
        minimum=1,
    )
    gpu_type = device_type(worker, f"{field_prefix}.spec.worker")
    tensor_parallel, pipeline_parallel = engine_dimensions(
        worker, f"{field_prefix}.spec.worker"
    )
    cards = tensor_parallel * pipeline_parallel
    return {
        "deployment_type": "ordinary",
        "desired_instances": desired,
        "ready_instances": ready_instances(item, field_prefix),
        "single_instance_gpu_cards": cards,
        "single_instance_gpu_cards_by_type": {gpu_type: cards},
        "ordinary": {
            "device_type": gpu_type,
            "tensor_parallel_size": tensor_parallel,
            "pipeline_parallel_size": pipeline_parallel,
            "single_instance_gpu_cards": cards,
            "formula": "tensor_parallel_size * pipeline_parallel_size",
        },
        "roles": [],
    }


def parse_pd(item: dict[str, Any], field_prefix: str) -> dict[str, Any]:
    pd_spec = mapping(item.get("pdSpec"))
    desired = integer_value(
        pd_spec.get("replicas"),
        f"{field_prefix}.pdSpec.replicas",
        minimum=1,
    )
    raw_roles = pd_spec.get("roles")
    if not isinstance(raw_roles, list) or not raw_roles:
        raise IsvcError(f"{field_prefix}.pdSpec.roles 必须是非空数组")

    profile: dict[str, int] = {}
    roles: list[dict[str, Any]] = []
    for index, raw_role in enumerate(raw_roles):
        role_prefix = f"{field_prefix}.pdSpec.roles[{index}]"
        if not isinstance(raw_role, dict):
            raise IsvcError(f"{role_prefix} 必须是对象")
        role_replicas = integer_value(
            raw_role.get("replicas"),
            f"{role_prefix}.replicas",
            minimum=1,
        )
        worker = mapping(mapping(raw_role.get("spec")).get("worker"))
        if not worker:
            raise IsvcError(f"{role_prefix}.spec.worker 必须是对象")
        worker_replicas = optional_integer(
            worker.get("replicas"),
            f"{role_prefix}.spec.worker.replicas",
            minimum=1,
        )
        if worker_replicas not in {None, 1}:
            raise IsvcError(
                f"{role_prefix}.spec.worker.replicas={worker_replicas}；"
                "当前已确认的 PD 单实例公式不包含该字段，请先重新确认契约"
            )
        gpu_type = device_type(worker, f"{role_prefix}.spec.worker")
        tensor_parallel, pipeline_parallel = engine_dimensions(
            worker, f"{role_prefix}.spec.worker"
        )
        cards = role_replicas * tensor_parallel * pipeline_parallel
        profile[gpu_type] = profile.get(gpu_type, 0) + cards
        roles.append(
            {
                "name": text_value(raw_role.get("name")) or f"role-{index}",
                "role_replicas": role_replicas,
                "worker_replicas": worker_replicas,
                "device_type": gpu_type,
                "tensor_parallel_size": tensor_parallel,
                "pipeline_parallel_size": pipeline_parallel,
                "single_instance_gpu_cards": cards,
                "formula": (
                    "role_replicas * tensor_parallel_size * "
                    "pipeline_parallel_size"
                ),
            }
        )
    return {
        "deployment_type": "pd",
        "desired_instances": desired,
        "ready_instances": ready_instances(item, field_prefix),
        "single_instance_gpu_cards": sum(profile.values()),
        "single_instance_gpu_cards_by_type": dict(sorted(profile.items())),
        "ordinary": None,
        "roles": roles,
    }


def parse_deployment(
    item: dict[str, Any], field_prefix: str
) -> dict[str, Any]:
    pd_spec = mapping(item.get("pdSpec"))
    spec_worker = mapping(mapping(item.get("spec")).get("worker"))
    pd_present = bool(pd_spec)
    ordinary_present = bool(spec_worker)
    if pd_present == ordinary_present:
        raise IsvcError(
            f"{field_prefix} 必须且只能包含 ordinary spec.worker 或 pdSpec"
        )
    calculated = (
        parse_pd(item, field_prefix)
        if pd_present
        else parse_ordinary(item, field_prefix)
    )
    calculated.update(
        {
            "isvc_name": isvc_name(item),
            "service_name": service_name(item),
            "model": model_service_name(item),
            "pool": pool_name(item),
        }
    )
    return calculated


def validate_list_response(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise IsvcError("iSvc 返回必须是 JSON 对象")
    if value.get("code") != 0:
        raise IsvcError(
            f"iSvc API 返回错误：code={value.get('code')}, "
            f"msg={text_value(value.get('msg')) or '无'}"
        )
    data = value.get("data")
    if not isinstance(data, dict) or not isinstance(data.get("info"), list):
        raise IsvcError("iSvc 返回缺少 data.info 数组")
    return value


def load_fixture(path_value: str) -> dict[str, Any]:
    path = Path(path_value).expanduser().resolve()
    with path.open(encoding="utf-8") as handle:
        return validate_list_response(json.load(handle))


def query_api(endpoint: str, timeout: float) -> tuple[dict[str, Any], int]:
    try:
        import requests
    except ImportError as exc:
        raise RuntimeError(
            "Skill 内置 HTTP 依赖不完整；请重新安装包含 vendor/ 的发布包"
        ) from exc

    response = None
    try:
        response = requests.get(endpoint, timeout=timeout)
        response.raise_for_status()
        body = response.content
    except requests.exceptions.Timeout as exc:
        raise RuntimeError(f"iSvc 请求超过 {timeout:g} 秒") from exc
    except requests.exceptions.RequestException as exc:
        detail = ""
        if response is not None and response.content:
            detail = response.content.decode("utf-8", errors="replace")[:500]
        suffix = f"：{detail}" if detail else ""
        raise RuntimeError(
            f"iSvc 请求失败（{type(exc).__name__}）{suffix}"
        ) from exc
    if len(body) > MAX_RESPONSE_BYTES:
        raise RuntimeError("iSvc 返回超过 64 MiB，拒绝继续解析")
    try:
        value = json.loads(body)
    except json.JSONDecodeError as exc:
        raise RuntimeError(
            "iSvc 返回了非法 JSON："
            + body.decode("utf-8", errors="replace")[:500]
        ) from exc
    return validate_list_response(value), int(response.status_code)


def response_digest(value: dict[str, Any]) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def card_profile_signature(deployment: dict[str, Any]) -> tuple[tuple[str, int], ...]:
    profile = deployment["single_instance_gpu_cards_by_type"]
    return tuple(sorted((str(key), int(value)) for key, value in profile.items()))


def build_artifact(
    response: dict[str, Any],
    *,
    model: str,
    pool: str,
    selected_service: str | None,
    endpoint: str,
    source_kind: str,
    http_status: int | None,
) -> dict[str, Any]:
    generated_at = utc_now()
    info = mapping(response.get("data")).get("info")
    assert isinstance(info, list)
    model_matches = 0
    pool_matches = 0
    service_matches = 0
    scaled_zero_matches = 0
    deployments: list[dict[str, Any]] = []
    invalid_deployments: list[dict[str, Any]] = []
    errors: list[str] = []
    warnings: list[str] = []

    for index, raw_item in enumerate(info):
        if not isinstance(raw_item, dict):
            continue
        if model_service_name(raw_item) != model:
            continue
        model_matches += 1
        if pool_name(raw_item) != pool:
            continue
        pool_matches += 1
        if selected_service and service_name(raw_item) != selected_service:
            continue
        service_matches += 1
        prefix = f"data.info[{index}]({isvc_name(raw_item) or 'unknown'})"
        try:
            desired = desired_instances_hint(raw_item, prefix)
            if desired == 0:
                scaled_zero_matches += 1
                continue
            deployment = parse_deployment(raw_item, prefix)
        except IsvcError as exc:
            invalid_deployments.append(
                {
                    "isvc_name": isvc_name(raw_item),
                    "service_name": service_name(raw_item),
                    "model": model_service_name(raw_item),
                    "pool": pool_name(raw_item),
                    "error": str(exc),
                }
            )
            continue
        deployments.append(deployment)
        ready = deployment.get("ready_instances")
        if ready is None:
            warnings.append(
                f"{deployment['isvc_name']} 缺少 status.readyReplicas；"
                "单实例拓扑仍来自期望 spec"
            )
        elif ready != deployment["desired_instances"]:
            warnings.append(
                f"{deployment['isvc_name']} 正在扩缩容或未完全就绪："
                f"desired={deployment['desired_instances']}, ready={ready}"
            )

    summary: dict[str, Any] = {
        "decision": "insufficient_data",
        "model": model,
        "pool": pool,
        "selected_service_name": selected_service,
        "card_profile_status": "not_found",
        "matched_deployment_count": len(deployments),
        "invalid_deployment_count": len(invalid_deployments),
        "service_names": sorted(
            {
                deployment["service_name"]
                for deployment in deployments
                if deployment["service_name"]
            }
        ),
        "deployment_types": sorted(
            {deployment["deployment_type"] for deployment in deployments}
        ),
        "single_instance_gpu_cards": None,
        "single_instance_gpu_cards_by_type": None,
        "write_performed": False,
    }
    status = "partial"
    handoffs: dict[str, Any] = {}
    if invalid_deployments and deployments:
        warnings.append(
            f"已忽略 {len(invalid_deployments)} 条未通过拓扑校验的匹配部署；"
            "仅使用有效部署计算单实例卡数"
        )
        warnings.extend(
            f"忽略 {item['isvc_name'] or item['service_name'] or 'unknown'}："
            f"{item['error']}"
            for item in invalid_deployments
        )

    if invalid_deployments and not deployments:
        errors.extend(item["error"] for item in invalid_deployments)
        summary["decision"] = "invalid_deployment_data"
        summary["card_profile_status"] = "invalid"
    elif not deployments:
        summary["decision"] = "no_active_online_deployment"
        warnings.append(
            f"未找到 model={model}、pool={pool}、期望实例数大于 0 的部署"
        )
    else:
        signatures = {card_profile_signature(item) for item in deployments}
        if len(signatures) > 1:
            summary["decision"] = "ambiguous_deployment_specs"
            summary["card_profile_status"] = "heterogeneous"
            warnings.append(
                "同一模型存在多种在线单实例卡型规格；"
                "请使用 --service-name 精确选择，未自动取第一条"
            )
        else:
            profile = dict(next(iter(signatures)))
            total = sum(profile.values())
            status = "success"
            summary.update(
                {
                    "decision": "single_instance_card_profile_ready",
                    "card_profile_status": "unique",
                    "single_instance_gpu_cards": total,
                    "single_instance_gpu_cards_by_type": profile,
                }
            )
            handoffs["capacity"] = {
                "status": "ready",
                "model": model,
                "pool": pool,
                "service_names": summary["service_names"],
                "single_instance_gpu_cards": total,
                "single_instance_gpu_cards_by_type": profile,
                "retrieved_at": generated_at,
            }

    return {
        "schema_version": SCHEMA_VERSION,
        "script_version": SCRIPT_VERSION,
        "domain": "capacity",
        "scenario": "isvc-single-instance-cards",
        "status": status,
        "generated_at": generated_at,
        "summary": summary,
        "deployments": deployments,
        "query": {
            "source": source_kind,
            "endpoint": endpoint,
            "http_status": http_status,
            "response_sha256": response_digest(response),
            "returned_info_count": len(info),
            "exact_model_match_count": model_matches,
            "exact_pool_match_count": pool_matches,
            "exact_service_match_count": service_matches,
            "scaled_zero_match_count": scaled_zero_matches,
            "invalid_deployment_match_count": len(invalid_deployments),
            "model_filter_applied_locally": True,
        },
        "handoffs": handoffs,
        "invalid_deployments": invalid_deployments,
        "warnings": warnings,
        "errors": errors,
    }


def normalize_card_profile(value: Any, field: str) -> dict[str, int]:
    if not isinstance(value, dict) or not value:
        raise IsvcError(f"{field} 必须是非空对象")
    result: dict[str, int] = {}
    for raw_type, raw_cards in value.items():
        gpu_type = bounded_text(raw_type, f"{field}.gpu_type").upper()
        if gpu_type in result:
            raise IsvcError(f"{field} 包含重复卡型 {gpu_type}")
        result[gpu_type] = integer_value(
            raw_cards, f"{field}.{gpu_type}", minimum=1
        )
    return dict(sorted(result.items()))


def load_capacity_handoff(
    path_value: str | Path, expected_model: str
) -> dict[str, Any]:
    path = Path(path_value).expanduser().resolve()
    with path.open(encoding="utf-8") as handle:
        artifact = json.load(handle)
    if not isinstance(artifact, dict):
        raise IsvcError("iSvc Artifact 必须是 JSON 对象")
    if artifact.get("domain") != "capacity":
        raise IsvcError("iSvc Artifact 的 domain 必须是 capacity")
    if artifact.get("scenario") != "isvc-single-instance-cards":
        raise IsvcError(
            "iSvc Artifact 的 scenario 必须是 isvc-single-instance-cards"
        )
    if artifact.get("status") != "success":
        raise IsvcError("iSvc Artifact 的 status 必须是 success")
    handoff = mapping(mapping(artifact.get("handoffs")).get("capacity"))
    if handoff.get("status") != "ready":
        raise IsvcError("iSvc Artifact 的 capacity 交接尚未 ready")
    model = bounded_text(handoff.get("model"), "iSvc handoff.model")
    if model != expected_model:
        raise IsvcError(
            f"iSvc Artifact 模型不匹配：期望 {expected_model}，实际 {model}"
        )
    if handoff.get("pool") != "online":
        raise IsvcError("iSvc Artifact 的 pool 必须是 online")
    profile = normalize_card_profile(
        handoff.get("single_instance_gpu_cards_by_type"),
        "iSvc handoff.single_instance_gpu_cards_by_type",
    )
    total = integer_value(
        handoff.get("single_instance_gpu_cards"),
        "iSvc handoff.single_instance_gpu_cards",
        minimum=1,
    )
    if total != sum(profile.values()):
        raise IsvcError("iSvc Artifact 的总卡数与按卡型分项之和不一致")
    return {
        "model": model,
        "pool": "online",
        "service_names": handoff.get("service_names", []),
        "single_instance_gpu_cards": total,
        "single_instance_gpu_cards_by_type": profile,
        "retrieved_at": handoff.get("retrieved_at"),
        "artifact": str(path),
    }


def validate_max_workers(value: int) -> int:
    if not 1 <= value <= MAX_MAX_WORKERS:
        raise IsvcError(
            f"max-workers 必须在 1～{MAX_MAX_WORKERS} 之间"
        )
    return value


def parse_service_selections(
    values: list[str], models: list[str]
) -> dict[str, str]:
    selections: dict[str, str] = {}
    allowed = set(models)
    for index, value in enumerate(values):
        if not isinstance(value, str) or "=" not in value:
            raise IsvcError(
                f"service-selection[{index}] 必须使用 MODEL=SERVICE 格式"
            )
        raw_model, raw_service = value.split("=", 1)
        model = bounded_text(raw_model, f"service-selection[{index}].model")
        service = bounded_text(
            raw_service, f"service-selection[{index}].service"
        )
        if model not in allowed:
            raise IsvcError(
                f"service-selection[{index}] 的模型不在当前批次：{model}"
            )
        if model in selections:
            raise IsvcError(f"service-selection 模型重复：{model}")
        selections[model] = service
    return selections


def query_models(args: argparse.Namespace) -> dict[str, Any]:
    max_workers = validate_max_workers(args.max_workers)
    if not args.model_artifact:
        raise IsvcError("至少提供一个 --model-artifact")
    verified_models = [
        resolve_single_model(
            artifact_path=artifact_path,
            raw_model=None,
            expected_domain="capacity",
            allowed_scenarios={"headroom", "cloud-reclaim"},
        )
        for artifact_path in args.model_artifact
    ]
    models = [verified.model for verified in verified_models]
    if len(set(models)) != len(models):
        raise IsvcError("批量模型不得重复")
    service_selections = parse_service_selections(
        args.service_selection, models
    )
    pool = bounded_text(args.pool, "pool").lower()
    endpoint = validate_endpoint(args.endpoint)
    if not 1 <= args.timeout <= 600:
        raise IsvcError("timeout 必须在 1～600 秒之间")
    if args.fixture:
        response = load_fixture(args.fixture)
        http_status = None
        source_kind = "fixture"
    else:
        response, http_status = query_api(endpoint, args.timeout)
        source_kind = "isvc_api"
    generated_at = utc_now()
    output_dir = Path(args.output_dir).expanduser().resolve()

    def normalize_one(index: int) -> tuple[int, dict[str, Any], Path]:
        verified = verified_models[index]
        try:
            artifact = build_artifact(
                response,
                model=verified.model,
                pool=pool,
                selected_service=service_selections.get(verified.model),
                endpoint=endpoint,
                source_kind=source_kind,
                http_status=http_status,
            )
            artifact["query"]["model_resolution"] = verified.evidence
            artifact["query"]["batch"] = {
                "enabled": True,
                "model_index": index,
                "model_count": len(models),
                "shared_list_response": True,
            }
        except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as exc:
            artifact = {
                "schema_version": SCHEMA_VERSION,
                "script_version": SCRIPT_VERSION,
                "domain": "capacity",
                "scenario": "isvc-single-instance-cards",
                "status": "error",
                "generated_at": generated_at,
                "summary": {
                    "decision": "response_normalization_failed",
                    "model": verified.model,
                    "write_performed": False,
                },
                "deployments": [],
                "query": {
                    "model_resolution": verified.evidence,
                    "batch": {
                        "enabled": True,
                        "model_index": index,
                        "model_count": len(models),
                        "shared_list_response": True,
                    },
                },
                "handoffs": {},
                "warnings": [],
                "errors": [str(exc)],
            }
        output_path = output_dir / f"isvc-{index + 1:03d}.json"
        write_artifact(str(output_path), artifact)
        return index, artifact, output_path

    completed_by_index: dict[int, tuple[dict[str, Any], Path]] = {}
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(normalize_one, index): index
            for index in range(len(models))
        }
        for future in as_completed(futures):
            index, artifact, output_path = future.result()
            completed_by_index[index] = (artifact, output_path)

    statuses: list[str] = []
    items: list[dict[str, Any]] = []
    warnings: list[str] = []
    errors: list[str] = []
    for index, model in enumerate(models):
        artifact, output_path = completed_by_index[index]
        status = str(artifact.get("status", "error"))
        statuses.append(status)
        items.append(
            {
                "index": index,
                "model": model,
                "status": status,
                "artifact": str(output_path),
                "summary": artifact.get("summary", {}),
            }
        )
        warnings.extend(
            f"{model}: {item}"
            for item in artifact.get("warnings", [])
            if isinstance(item, str)
        )
        errors.extend(
            f"{model}: {item}"
            for item in artifact.get("errors", [])
            if isinstance(item, str)
        )
    if all(status == "success" for status in statuses):
        status = "success"
    elif all(status == "error" for status in statuses):
        status = "error"
    else:
        status = "partial"
    return {
        "schema_version": SCHEMA_VERSION,
        "script_version": SCRIPT_VERSION,
        "domain": "capacity",
        "scenario": "isvc-query-models",
        "status": status,
        "generated_at": generated_at,
        "summary": {
            "decision": "batch_query_completed",
            "models": models,
            "model_count": len(models),
            "successful_model_count": statuses.count("success"),
            "partial_model_count": statuses.count("partial"),
            "failed_model_count": statuses.count("error"),
            "max_workers": max_workers,
            "shared_list_load_count": 1,
            "remote_request_count": 0 if args.fixture else 1,
            "shared_list_response": True,
            "service_selection_count": len(service_selections),
            "write_performed": False,
        },
        "artifacts": {"isvc": items},
        "query": {
            "source": source_kind,
            "endpoint": endpoint,
            "http_status": http_status,
            "response_sha256": response_digest(response),
            "returned_info_count": len(response["data"]["info"]),
            "service_selections": service_selections,
        },
        "warnings": warnings,
        "errors": errors,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="查询 iSvc 在线部署拓扑并计算模型单实例 GPU 卡数（只读）"
    )
    commands = parser.add_subparsers(dest="command", required=True)
    query = commands.add_parser("query-model")
    query.add_argument(
        "--model-artifact",
        help="成功的容量域 model-resolution Artifact；生产查询必填",
    )
    query.add_argument(
        "--model",
        help=(
            "兼容的精确模型名；只允许 fixture，"
            "或用于校验其值与 --model-artifact 一致"
        ),
    )
    query.add_argument(
        "--pool",
        default="online",
        choices=("online",),
        help="精确资源池，当前只支持 online",
    )
    query.add_argument(
        "--service-name", help="同一模型存在多规格时精确选择 serviceName/KSN"
    )
    query.add_argument(
        "--endpoint",
        default=(
            os.environ.get("WANQING_ISVC_ENDPOINT", "").strip()
            or DEFAULT_ISVC_ENDPOINT
        ),
        help="iSvc 列表 API；默认读取 WANQING_ISVC_ENDPOINT 或生产内网地址",
    )
    query.add_argument("--timeout", type=float, default=30.0)
    query.add_argument("--fixture", help="iSvc 列表 JSON fixture，不访问 API")
    query.add_argument("--output", required=True, help="结果 Artifact 路径")
    batch_query = commands.add_parser(
        "query-models",
        help="只请求一次 iSvc 列表并为多个模型分别生成 Artifact",
    )
    batch_query.add_argument(
        "--model-artifact",
        action="append",
        required=True,
        help="成功的容量域 model-resolution Artifact；按顺序重复传入",
    )
    batch_query.add_argument(
        "--pool",
        default="online",
        choices=("online",),
        help="精确资源池，当前只支持 online",
    )
    batch_query.add_argument(
        "--service-selection",
        action="append",
        default=[],
        help="可选的逐模型精确 KSN，格式 MODEL=SERVICE，可重复传入",
    )
    batch_query.add_argument(
        "--endpoint",
        default=(
            os.environ.get("WANQING_ISVC_ENDPOINT", "").strip()
            or DEFAULT_ISVC_ENDPOINT
        ),
        help="iSvc 列表 API",
    )
    batch_query.add_argument("--timeout", type=float, default=30.0)
    batch_query.add_argument(
        "--fixture", help="单份 iSvc 列表 JSON fixture，不访问 API"
    )
    batch_query.add_argument(
        "--max-workers",
        type=int,
        default=DEFAULT_MAX_WORKERS,
        help=(
            f"最大并发规范化任务数，默认 {DEFAULT_MAX_WORKERS}，"
            f"上限 {MAX_MAX_WORKERS}"
        ),
    )
    batch_query.add_argument(
        "--output-dir", required=True, help="逐模型 Artifact 输出目录"
    )
    batch_query.add_argument(
        "--output", required=True, help="批量 Manifest 路径"
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.command == "query-models":
        try:
            artifact = query_models(args)
        except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as exc:
            artifact = {
                "schema_version": SCHEMA_VERSION,
                "script_version": SCRIPT_VERSION,
                "domain": "capacity",
                "scenario": "isvc-query-models",
                "status": "error",
                "generated_at": utc_now(),
                "summary": {
                    "decision": "batch_query_failed",
                    "write_performed": False,
                },
                "artifacts": {"isvc": []},
                "query": {},
                "warnings": [],
                "errors": [str(exc)],
            }
        try:
            output = write_artifact(args.output, artifact)
        except OSError as exc:
            print(
                json.dumps(
                    {"status": "error", "error": str(exc)},
                    ensure_ascii=False,
                )
            )
            return 1
        print(
            json.dumps(
                {
                    "status": artifact["status"],
                    "artifact": str(output),
                    "summary": artifact.get("summary", {}),
                    "warnings": artifact.get("warnings", []),
                    "errors": artifact.get("errors", []),
                },
                ensure_ascii=False,
            )
        )
        return 0 if artifact["status"] != "error" else 1

    failure_stage = "model_validation"
    request_sent = False
    try:
        verified_model = resolve_single_model(
            artifact_path=args.model_artifact,
            raw_model=args.model,
            expected_domain="capacity",
            allowed_scenarios={"headroom", "cloud-reclaim"},
            allow_unverified=bool(args.fixture),
        )
        failure_stage = "request_validation"
        model = bounded_text(verified_model.model, "model")
        pool = bounded_text(args.pool, "pool").lower()
        selected_service = (
            bounded_text(args.service_name, "service-name")
            if args.service_name is not None
            else None
        )
        endpoint = validate_endpoint(args.endpoint)
        if not 1 <= args.timeout <= 600:
            raise IsvcError("timeout 必须在 1～600 秒之间")
        if args.fixture:
            failure_stage = "fixture_load"
            response = load_fixture(args.fixture)
            http_status = None
            source_kind = "fixture"
        else:
            failure_stage = "isvc_request"
            request_sent = True
            response, http_status = query_api(endpoint, args.timeout)
            source_kind = "isvc_api"
        failure_stage = "response_normalization"
        artifact = build_artifact(
            response,
            model=model,
            pool=pool,
            selected_service=selected_service,
            endpoint=endpoint,
            source_kind=source_kind,
            http_status=http_status,
        )
        artifact["query"]["model_resolution"] = verified_model.evidence
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as exc:
        artifact = {
            "schema_version": SCHEMA_VERSION,
            "script_version": SCRIPT_VERSION,
            "domain": "capacity",
            "scenario": "isvc-single-instance-cards",
            "status": "error",
            "generated_at": utc_now(),
            "summary": {
                "decision": "query_or_normalization_failed",
                "failure_stage": failure_stage,
                "request_sent": request_sent,
                "write_performed": False,
            },
            "deployments": [],
            "query": {},
            "handoffs": {},
            "warnings": [],
            "errors": [str(exc)],
        }
    annotate_outcome(artifact)
    try:
        output = write_artifact(args.output, artifact)
    except OSError as exc:
        print(
            json.dumps(
                {"status": "error", "error": str(exc)},
                ensure_ascii=False,
            )
        )
        return 1
    terminal_result = terminal_brief(artifact, output)
    print(json.dumps(terminal_result, ensure_ascii=False))
    return 0 if artifact["status"] in {"success", "partial"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
