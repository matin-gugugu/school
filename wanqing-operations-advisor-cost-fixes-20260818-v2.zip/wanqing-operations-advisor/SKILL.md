---
name: wanqing-operations-advisor
description: 万擎资源、容量与成本运营的统一路由和只读执行 Skill。凡涉及万擎资源运营（GPU、机器、资源池、测试/QA/开发机、空闲/碎片/持有/可用资源）、模型容量（配置容量、Token/TPM 流量、余量、扩容、云上回收、KConf、iSvc、cache、TTFT、TPOT）或成本（今日/周/月云上成本构成及上云原因、资源或用量相对机器成本/云上价格的亏损对比、自部署集群运营系数、云上容量回收的前一日模型成本与估算上云成本），必须先使用本 Skill。使用本 Skill 路由到资源域、容量域或成本域并遵循对应 Reference、脚本和 Artifact 约束。
---

# 万擎资源、容量与成本运营助手

每次收到新的万擎请求，都从本文件重新路由并取得当前请求证据。不要把同一会话中的旧回答、
旧业务数值或“之前查过”视为本次已经执行；也不要为了刷新上下文而额外查询当前时间，相对
时间统一交给脚本按运行时钟解析。

## 执行约束

1. 读取 [references/domain-classification.md](references/domain-classification.md)，按最终决策
   选择一个主领域和场景；独立结果拆成原子任务，但不得拆分给多个 Subagent。
2. 只读取路由表指定的当前场景 Reference。不得调用 Data Agent、KwaiBI 数据查询接口、
   旧版万擎 Skill 或旧查询工具替代本 Skill。
3. 查询或计算只能从本文件指定的 Workflow 首入口开始，并严格执行其 `next_action`；不得由
   Agent 自行串联模型解析、容量、KConf、iSvc、资源子命令或生产 SQL。
4. 每次查询或计算必须保存完整 JSON Artifact。业务数值只能来自本次成功脚本结果，或本次
   重新读取并校验为同对象、同模型、同窗口、同参数的成功 Artifact。历史回答和 Markdown
   表格不是数据源；用户明确要求的假设分析除外，但必须标记为用户假设。
5. 工具实际成功前不得声称查询、计算或保存成功。失败、无数据、证据缺失必须分别保留
   `QUERY_FAILED`、`NO_ROWS`、`EVIDENCE_MISSING` 等语义；不完整值保持 `null`，不得当作 0。
6. 模型身份只由 Workflow 按场景锚点或版本化可信模型域解析一次；不得猜版本、自动选择
   歧义候选或直接用模糊名称查询。两个及以上模型必须走批量入口，保持顺序并逐项隔离失败。
7. 严格校验请求 Schema、模型、provider、窗口和证据绑定；未知字段、非法枚举、重复模型或
   不兼容参数不得静默降级。生产结论以 canonical `outcome` 和 `evidence_index` 为准。
8. 只获取请求深度必需的证据：无正缺口不查 KConf/iSvc/资源；只问实例数不查 iSvc/资源；
   云上回收始终由 Workflow 查询前一天模型云上成本；需要卡数或机器数时才查询当前
   `online` 模型持有量并校准上限。
9. 配置容量、实际流量、物理资源、理论换算和成本结论必须分开。查询失败不得用 fixture、
   样例、历史回答、失败 Artifact 或人工拼装数值补齐。
10. 所有能力只读。不得修改 KConf、扩缩容、迁流、变更实例或释放机器；不得执行 `env`、
    `printenv`，不得输出 Secret、Token、Cookie、Authorization 或完整认证配置。

## Reference 路由

| 场景 | 读取 | 条件读取 |
|---|---|---|
| 资源查询 | [references/resource.md](references/resource.md) | 模型解析异常时读 `model-resolution.md` |
| 成本导航 | [references/cost.md](references/cost.md) | 无 |
| 容量供给 | [references/capacity.md](references/capacity.md)、[references/capacity-supply.md](references/capacity-supply.md) | 无 |
| 容量流量 | [references/capacity.md](references/capacity.md)、[references/capacity-traffic.md](references/capacity-traffic.md) | 需要 cache/TTFT/TPOT 时读 `integration-tianwen.md` |
| 余量与扩容 | [references/capacity.md](references/capacity.md)、[references/capacity-headroom.md](references/capacity-headroom.md) | Workflow 要求时读 `integration-kconf.md`、`integration-isvc.md` |
| 云上容量回收 | [references/capacity.md](references/capacity.md)、[references/capacity-reclaim.md](references/capacity-reclaim.md) | 始终读 `integration-cost.md`；按范围/深度读 `integration-top-p.md`、`integration-kconf.md`、`integration-isvc.md`；卡数或机器数再读 `resource-model-holdings.md` |
| 模型解析确认或排障 | [references/model-resolution.md](references/model-resolution.md) | 仅在 Workflow 要求时 |

`capacity-core.md` 和 `capacity-workflow.md` 保留完整字段与兼容契约，只在排查 Artifact、Schema、
历史回放或实现问题时读取；正常业务请求不得预加载。`data-integration.md` 只在无法判断具体
集成文件时读取。

余量问题没有明确模型和 provider 时，生成 Schema 1.1 `headroom` 请求并省略这两个字段；
Workflow 固定使用版本化候选名单和 `internal/self_deployed`。用户明确模型、GPU 候选范围
或 provider 时，按用户范围生成请求，不得再叠加默认范围。

## 生产入口

资源域按 `resource.md` 的场景命令执行。供给、流量、余量与扩容统一运行：

```bash
python3.10 scripts/workflow.py capacity-analyze \
  --input <request.json> --output-dir <artifact-dir> --output <result.json>
```

云上容量回收统一从以下命令开始：

```bash
python3.10 scripts/workflow.py cloud-reclaim-prepare \
  --scope <explicit|gpu|all> --detail-level <instances|cards|machines> \
  --output-dir <artifact-dir> --output <result.json>
```

两条 Workflow 都只执行返回的 `next_action`。旧 `cloud-reclaim*` 命令继续保留兼容，但不得
作为生产首入口。

成本构成、上云原因、资源或用量亏损对比和自部署运营系数仍只按 `cost.md` 返回固定
KwaiBI 链接。只有
`cloud-reclaim-prepare` 可以按 `integration-cost.md` 跨成本域查询前一天模型成本，并从
最终容量结果估算增量上云日成本；不得由 Agent 绕过 Workflow 单独拼接 SQL 或公式。

## 回答与环境

- 先给结论，再说明对象、窗口、口径、完整性和限制；`partial` 必须列出缺失项与停止原因。
- 不暴露 SQL、大段原始数据或内部实现。成本导航回显时间范围或集群名并提示看板内筛选，
  不得声称链接已预设筛选或已经读取看板。
- 使用平台 Python 3.10 和内置 `vendor/`，不创建虚拟环境或安装依赖。缺少 ClickHouse 配置
  时只报告变量名并停止，不要求用户粘贴凭证。本地认证文件必须为 0600，打包时只保留
  `config/idp_auth_config.example.json`。
